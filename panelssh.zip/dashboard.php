<?php
require_once "config.php";
check_login();
?>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Dashboard</title>
<link rel="stylesheet" href="assets/style.css">
</head>
<body>

<div class="dashboard">
    <h1>Bienvenido, <?= $_SESSION['admin']; ?></h1>
    <p>Panel en construcción...</p>
    <a href="logout.php">Cerrar sesión</a>
</div>

</body>
</html>