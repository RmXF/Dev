document.addEventListener("mousemove", function(e) {
    document.querySelector(".bg-animation").style.background =
        `radial-gradient(circle at ${e.clientX}px ${e.clientY}px, #1e3a8a, #0f172a)`;
});