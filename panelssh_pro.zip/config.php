<?php
session_start();

$DB_HOST = "localhost";
$DB_USER = "paneluser";
$DB_PASS = "password_aqui";
$DB_NAME = "ssh_panel";

$conn = new mysqli($DB_HOST, $DB_USER, $DB_PASS, $DB_NAME);

if ($conn->connect_error) {
    die("Error de conexión a la base de datos.");
}

function check_login() {
    if (!isset($_SESSION['admin'])) {
        header("Location: index.php");
        exit();
    }
}
?>