<?php
require_once "config.php";
check_login();
?>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Dashboard - SSH Panel Pro</title>
<link rel="stylesheet" href="assets/style.css">
</head>
<body>

<div class="dashboard">
    <h1>Bienvenido, <?= htmlspecialchars($_SESSION['admin']); ?></h1>
    <p>Panel correctamente instalado.</p>
    <a class="logout-btn" href="logout.php">Cerrar sesión</a>
</div>

</body>
</html>