<?php
// config.php
session_start();

// Configuración de la base de datos (opcional, puedes seguir usando localStorage)
define('DB_HOST', 'localhost');
define('DB_NAME', 'vps_panel');
define('DB_USER', 'root');
define('DB_PASS', '');

// Configuración de SSH
define('SSH_TIMEOUT', 10); // Timeout en segundos
define('SSH_PORT', 22); // Puerto por defecto

// Headers para API
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST, GET, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

// Manejar preflight requests
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}
?>