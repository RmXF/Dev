<?php
// get_servers.php - Obtener lista de servidores
require_once 'config.php';

// Verificar método
if ($_SERVER['REQUEST_METHOD'] !== 'GET') {
    http_response_code(405);
    echo json_encode(['error' => 'Método no permitido']);
    exit();
}

// Obtener servidores del archivo JSON
$servers = [];
if (file_exists('servers.json')) {
    $servers = json_decode(file_get_contents('servers.json'), true) ?: [];
}

// Opcional: Obtener de MySQL
/*
try {
    $pdo = new PDO("mysql:host=".DB_HOST.";dbname=".DB_NAME, DB_USER, DB_PASS);
    $stmt = $pdo->query("SELECT * FROM servers ORDER BY created DESC");
    $servers = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    echo json_encode(['success' => false, 'error' => 'Error de base de datos']);
    exit();
}
*/

// Ocultar contraseñas
foreach ($servers as &$server) {
    if (isset($server['password']) && $server['password'] !== '****') {
        $server['password'] = '********';
    }
}

echo json_encode([
    'success' => true,
    'servers' => $servers
]);
?>