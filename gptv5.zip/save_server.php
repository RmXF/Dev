<?php
// save_server.php - Guardar servidor en base de datos
require_once 'config.php';

// Verificar que sea POST
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['error' => 'Método no permitido']);
    exit();
}

// Obtener datos
$input = json_decode(file_get_contents('php://input'), true);

if (!$input) {
    $input = $_POST;
}

// Validar campos
$required = ['name', 'ip', 'port', 'user', 'password', 'location'];
foreach ($required as $field) {
    if (!isset($input[$field]) || empty($input[$field])) {
        echo json_encode([
            'success' => false,
            'error' => "El campo $field es obligatorio"
        ]);
        exit();
    }
}

// Datos del servidor
$server = [
    'id' => uniqid(),
    'name' => $input['name'],
    'ip' => $input['ip'],
    'port' => intval($input['port']),
    'user' => $input['user'],
    'password' => $input['save_credentials'] ? encrypt_password($input['password']) : '****',
    'location' => $input['location'],
    'status' => 'active',
    'cpu' => $input['cpu'] ?? 0,
    'ram' => $input['ram'] ?? 0,
    'disk' => $input['disk'] ?? 0,
    'uptime' => $input['uptime'] ?? '0 días',
    'os' => $input['os'] ?? 'Linux',
    'kernel' => $input['kernel'] ?? '',
    'cpu_cores' => $input['cpu_cores'] ?? 2,
    'ram_total' => $input['ram_total'] ?? 8,
    'disk_total' => $input['disk_total'] ?? 100,
    'created' => date('Y-m-d H:i:s'),
    'last_checked' => date('Y-m-d H:i:s')
];

// Opción 1: Guardar en archivo JSON (simple)
$servers = [];
if (file_exists('servers.json')) {
    $servers = json_decode(file_get_contents('servers.json'), true) ?: [];
}

$servers[] = $server;
file_put_contents('servers.json', json_encode($servers, JSON_PRETTY_PRINT));

// Opción 2: Guardar en MySQL (comentar si no usas MySQL)
/*
try {
    $pdo = new PDO("mysql:host=".DB_HOST.";dbname=".DB_NAME, DB_USER, DB_PASS);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    
    $sql = "INSERT INTO servers (id, name, ip, port, username, password, location, status, 
            cpu, ram, disk, uptime, os, kernel, cpu_cores, ram_total, disk_total, created, last_checked) 
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
    
    $stmt = $pdo->prepare($sql);
    $stmt->execute([
        $server['id'],
        $server['name'],
        $server['ip'],
        $server['port'],
        $server['user'],
        $server['password'],
        $server['location'],
        $server['status'],
        $server['cpu'],
        $server['ram'],
        $server['disk'],
        $server['uptime'],
        $server['os'],
        $server['kernel'],
        $server['cpu_cores'],
        $server['ram_total'],
        $server['disk_total'],
        $server['created'],
        $server['last_checked']
    ]);
    
} catch (PDOException $e) {
    echo json_encode(['success' => false, 'error' => 'Error de base de datos: ' . $e->getMessage()]);
    exit();
}
*/

// Responder
echo json_encode([
    'success' => true,
    'message' => 'Servidor guardado correctamente',
    'server' => $server
]);

// Función simple para encriptar contraseña (mejor usar password_hash en producción)
function encrypt_password($password) {
    return base64_encode($password); // No es seguro, solo para demo
}
?>