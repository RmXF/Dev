<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization, X-Requested-With');

require_once '../includes/config.php';
require_once '../includes/auth.php';
require_once '../includes/functions.php';

// Verificar autenticación
if (!isLoggedIn() && !isset($_GET['public'])) {
    errorResponse('No autorizado', 401);
}

$method = $_SERVER['REQUEST_METHOD'];

if ($method === 'GET') {
    $stats = getSystemStats();
    
    // Si se solicita gráfica
    if (isset($_GET['chart'])) {
        // Obtener datos de los últimos 6 meses
        $chartData = [];
        for ($i = 5; $i >= 0; $i--) {
            $month = date('Y-m', strtotime("-$i months"));
            $count = db_select_one(
                "SELECT COUNT(*) as count FROM ssh_tokens WHERE DATE_FORMAT(created_at, '%Y-%m') = ?",
                [$month]
            )['count'] ?? 0;
            $chartData['labels'][] = date('M', strtotime("-$i months"));
            $chartData['values'][] = $count;
        }
        successResponse($chartData);
    }
    
    // Obtener estadísticas adicionales
    $totalLogs = db_select_one("SELECT COUNT(*) as count FROM logs")['count'] ?? 0;
    $logsToday = db_select_one("SELECT COUNT(*) as count FROM logs WHERE DATE(created_at) = CURDATE()")['count'] ?? 0;
    $activeSessions = db_select_one("SELECT COUNT(*) as count FROM active_sessions WHERE last_activity > UNIX_TIMESTAMP(DATE_SUB(NOW(), INTERVAL 1 HOUR))")['count'] ?? 0;
    
    $stats['total_logs'] = $totalLogs;
    $stats['logs_today'] = $logsToday;
    $stats['active_sessions'] = $activeSessions;
    $stats['timestamp'] = date('Y-m-d H:i:s');
    
    successResponse($stats);
}
?>