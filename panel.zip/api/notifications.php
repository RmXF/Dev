<?php
header('Content-Type: application/json');
require_once '../includes/config.php';
require_once '../includes/auth.php';
require_once '../includes/functions.php';

if (!isLoggedIn()) {
    errorResponse('No autorizado', 401);
}

$method = $_SERVER['REQUEST_METHOD'];

if ($method === 'GET') {
    $notifications = getNotifications($_SESSION['user_id']);
    $unreadCount = getUnreadCount($_SESSION['user_id']);
    
    successResponse([
        'notifications' => $notifications,
        'unread_count' => $unreadCount
    ]);
}

if ($method === 'POST') {
    $data = json_decode(file_get_contents('php://input'), true);
    $action = $data['action'] ?? '';
    
    if ($action === 'mark_read') {
        $id = intval($data['id']);
        markNotificationAsRead($id, $_SESSION['user_id']);
        successResponse(null, 'Notificación marcada como leída');
    }
    
    if ($action === 'mark_all_read') {
        markAllNotificationsAsRead($_SESSION['user_id']);
        successResponse(null, 'Todas las notificaciones marcadas como leídas');
    }
}
?>