<?php
header('Content-Type: application/json');
require_once '../includes/config.php';
require_once '../includes/auth.php';
require_once '../includes/functions.php';

requireAdmin();

$method = $_SERVER['REQUEST_METHOD'];

if ($method === 'GET') {
    $settings = [];
    $result = db_select("SELECT `key`, `value` FROM settings");
    foreach ($result as $row) {
        $settings[$row['key']] = $row['value'];
    }
    successResponse($settings);
}

if ($method === 'POST') {
    $data = json_decode(file_get_contents('php://input'), true);
    
    foreach ($data as $key => $value) {
        setSetting($key, $value);
    }
    
    addLog($_SESSION['user_id'], 'api_update_settings', 'Actualizó configuración vía API', getClientIP(), getUserAgent());
    successResponse(null, 'Configuración actualizada');
}
?>