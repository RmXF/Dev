<?php
require_once '../includes/config.php';
require_once '../includes/auth.php';
require_once '../includes/functions.php';

requireAdmin();

$page = isset($_GET['page']) ? intval($_GET['page']) : 1;
$limit = 50;
$offset = ($page - 1) * $limit;

$filters = [];
if (isset($_GET['action']) && !empty($_GET['action'])) {
    $filters['action'] = $_GET['action'];
}
if (isset($_GET['user_id']) && !empty($_GET['user_id'])) {
    $filters['user_id'] = intval($_GET['user_id']);
}

$logs = getLogs($limit, $offset, $filters);
$totalLogs = db_select_one("SELECT COUNT(*) as count FROM logs")['count'] ?? 0;
$totalPages = ceil($totalLogs / $limit);

// Obtener acciones únicas para el filtro
$actions = db_select("SELECT DISTINCT action FROM logs ORDER BY action");
$users = db_select("SELECT id, username FROM users ORDER BY username");
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Logs - CEO SSH Panel</title>
    <link rel="icon" href="../assets/img/favicon.ico">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="../assets/css/style.css">
    <link rel="stylesheet" href="../assets/css/responsive.css">
    <script src="../assets/js/app.js" defer></script>
</head>
<body>
    <div class="app-container">
        <aside class="sidebar" id="sidebar">
            <div class="logo">
                <div class="logo-icon"><i class="fas fa-shield-alt"></i></div>
                <div class="logo-text">CEO SSH</div>
            </div>
            <nav class="sidebar-nav">
                <div class="nav-section">
                    <div class="nav-label">Principal</div>
                    <a href="dashboard.php" class="sidebar-link"><i class="fas fa-tachometer-alt"></i><span>Dashboard</span></a>
                    <a href="users.php" class="sidebar-link"><i class="fas fa-users"></i><span>Usuarios</span></a>
                </div>
                <div class="nav-section">
                    <div class="nav-label">Configuración</div>
                    <a href="profile.php" class="sidebar-link"><i class="fas fa-user"></i><span>Mi Perfil</span></a>
                    <a href="settings.php" class="sidebar-link"><i class="fas fa-cog"></i><span>Configuración</span></a>
                    <a href="backups.php" class="sidebar-link"><i class="fas fa-database"></i><span>Backups</span></a>
                    <a href="logs.php" class="sidebar-link active"><i class="fas fa-history"></i><span>Logs</span></a>
                    <a href="help.php" class="sidebar-link"><i class="fas fa-question-circle"></i><span>Ayuda</span></a>
                </div>
            </nav>
            <div class="user-info">
                <div style="display: flex; align-items: center; gap: 12px;">
                    <div class="user-avatar"><?php echo strtoupper(substr($_SESSION['username'], 0, 1)); ?></div>
                    <div class="user-details">
                        <div class="user-name"><?php echo htmlspecialchars($_SESSION['username']); ?></div>
                        <div class="user-role">Administrador</div>
                    </div>
                </div>
            </div>
        </aside>
        
        <main class="main-content" id="mainContent">
            <header class="header">
                <div class="header-left">
                    <button class="toggle-sidebar" onclick="toggleSidebar()"><i class="fas fa-bars"></i></button>
                    <div class="page-title">
                        <h1>Registro de Actividad</h1>
                        <p>Historial completo de eventos del sistema</p>
                    </div>
                </div>
                <div class="header-right">
                    <button class="theme-toggle" onclick="toggleTheme()"><i class="fas fa-moon" id="themeIcon"></i></button>
                    <div class="user-dropdown">
                        <button class="user-btn" onclick="toggleDropdown('userDropdown')">
                            <div class="user-avatar-small"><?php echo strtoupper(substr($_SESSION['username'], 0, 1)); ?></div>
                            <span class="user-name-small"><?php echo htmlspecialchars($_SESSION['username']); ?></span>
                            <i class="fas fa-chevron-down"></i>
                        </button>
                        <div class="dropdown-menu" id="userDropdown">
                            <a href="profile.php" class="dropdown-item"><i class="fas fa-user"></i><span>Mi Perfil</span></a>
                            <div class="dropdown-divider"></div>
                            <a href="../api/auth.php?action=logout" class="dropdown-item"><i class="fas fa-sign-out-alt"></i><span>Cerrar Sesión</span></a>
                        </div>
                    </div>
                </div>
            </header>
            
            <div class="content">
                <!-- Filtros -->
                <div class="card" style="margin-bottom: 20px;">
                    <div class="card-body">
                        <form method="GET" class="row" style="align-items: flex-end;">
                            <div class="col-12 col-md-4">
                                <label class="form-label">Acción</label>
                                <select name="action" class="form-control">
                                    <option value="">Todas</option>
                                    <?php foreach ($actions as $action): ?>
                                    <option value="<?php echo htmlspecialchars($action['action']); ?>" <?php echo (isset($_GET['action']) && $_GET['action'] == $action['action']) ? 'selected' : ''; ?>>
                                        <?php echo htmlspecialchars($action['action']); ?>
                                    </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <div class="col-12 col-md-4">
                                <label class="form-label">Usuario</label>
                                <select name="user_id" class="form-control">
                                    <option value="">Todos</option>
                                    <?php foreach ($users as $user): ?>
                                    <option value="<?php echo $user['id']; ?>" <?php echo (isset($_GET['user_id']) && $_GET['user_id'] == $user['id']) ? 'selected' : ''; ?>>
                                        <?php echo htmlspecialchars($user['username']); ?>
                                    </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <div class="col-12 col-md-4">
                                <button type="submit" class="btn btn-primary" style="width: 100%;">Filtrar</button>
                            </div>
                        </form>
                    </div>
                </div>
                
                <!-- Tabla de logs -->
                <div class="card">
                    <div class="card-body">
                        <div class="table-container">
                            <table style="width: 100%;">
                                <thead>
                                    <tr>
                                        <th>ID</th>
                                        <th>Fecha</th>
                                        <th>Usuario</th>
                                        <th>Acción</th>
                                        <th>Detalles</th>
                                        <th>IP</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php if (empty($logs)): ?>
                                    <tr>
                                        <td colspan="6" style="text-align: center;">No hay registros</td>
                                    </tr>
                                    <?php else: ?>
                                        <?php foreach ($logs as $log): ?>
                                        <tr>
                                            <td><?php echo $log['id']; ?></td>
                                            <td><?php echo date('d/m/Y H:i:s', strtotime($log['created_at'])); ?></td>
                                            <td><?php echo htmlspecialchars($log['username'] ?? 'Sistema'); ?></td>
                                            <td>
                                                <span class="badge badge-info"><?php echo htmlspecialchars($log['action']); ?></span>
                                            </td>
                                            <td><?php echo htmlspecialchars($log['details']); ?></td>
                                            <td><?php echo htmlspecialchars($log['ip_address']); ?></td>
                                        </tr>
                                        <?php endforeach; ?>
                                    <?php endif; ?>
                                </tbody>
                            </table>
                        </div>
                        
                        <!-- Paginación -->
                        <?php if ($totalPages > 1): ?>
                        <div style="display: flex; justify-content: center; gap: 10px; margin-top: 20px;">
                            <?php if ($page > 1): ?>
                            <a href="?page=<?php echo $page-1; ?>&action=<?php echo urlencode($_GET['action'] ?? ''); ?>&user_id=<?php echo $_GET['user_id'] ?? ''; ?>" class="btn btn-secondary">Anterior</a>
                            <?php endif; ?>
                            
                            <span style="padding: 8px 16px;">Página <?php echo $page; ?> de <?php echo $totalPages; ?></span>
                            
                            <?php if ($page < $totalPages): ?>
                            <a href="?page=<?php echo $page+1; ?>&action=<?php echo urlencode($_GET['action'] ?? ''); ?>&user_id=<?php echo $_GET['user_id'] ?? ''; ?>" class="btn btn-secondary">Siguiente</a>
                            <?php endif; ?>
                        </div>
                        <?php endif; ?>
                    </div>
                </div>
                
                <!-- Estadísticas de logs -->
                <div class="row" style="margin-top: 20px;">
                    <div class="col-12 col-md-4">
                        <div class="card">
                            <div class="card-body" style="text-align: center;">
                                <div style="font-size: 32px; font-weight: 700; color: var(--accent);"><?php echo $totalLogs; ?></div>
                                <div>Total de registros</div>
                            </div>
                        </div>
                    </div>
                    <div class="col-12 col-md-4">
                        <div class="card">
                            <div class="card-body" style="text-align: center;">
                                <div style="font-size: 32px; font-weight: 700; color: var(--success);">
                                    <?php 
                                    $todayLogs = db_select_one("SELECT COUNT(*) as count FROM logs WHERE DATE(created_at) = CURDATE()")['count'] ?? 0;
                                    echo $todayLogs;
                                    ?>
                                </div>
                                <div>Registros hoy</div>
                            </div>
                        </div>
                    </div>
                    <div class="col-12 col-md-4">
                        <div class="card">
                            <div class="card-body" style="text-align: center;">
                                <div style="font-size: 32px; font-weight: 700; color: var(--warning);">
                                    <?php 
                                    $uniqueActions = db_select_one("SELECT COUNT(DISTINCT action) as count FROM logs")['count'] ?? 0;
                                    echo $uniqueActions;
                                    ?>
                                </div>
                                <div>Acciones distintas</div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </main>
    </div>
</body>
</html>