<?php
require_once '../includes/config.php';
require_once '../includes/auth.php';
require_once '../includes/functions.php';

requireLogin();

$message = '';
$error = '';
$user = getUserById($_SESSION['user_id']);

// Procesar cambio de contraseña
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    
    if ($action === 'change_password') {
        $current = $_POST['current_password'];
        $new = $_POST['new_password'];
        $confirm = $_POST['confirm_password'];
        
        if (password_verify($current, $user['password'])) {
            if ($new === $confirm && strlen($new) >= 6) {
                $new_hash = password_hash($new, PASSWORD_DEFAULT);
                if (updateUser($_SESSION['user_id'], ['password' => $new_hash])) {
                    $message = "Contraseña actualizada correctamente";
                    addLog($_SESSION['user_id'], 'change_password', 'Usuario cambió su contraseña', getClientIP(), getUserAgent());
                } else {
                    $error = "Error al actualizar contraseña";
                }
            } else {
                $error = "Las contraseñas no coinciden o son muy cortas (mínimo 6 caracteres)";
            }
        } else {
            $error = "Contraseña actual incorrecta";
        }
    }
    
    if ($action === 'update_profile') {
        $email = filter_var($_POST['email'], FILTER_SANITIZE_EMAIL);
        
        if (updateUser($_SESSION['user_id'], ['email' => $email])) {
            $_SESSION['email'] = $email;
            $message = "Perfil actualizado correctamente";
            addLog($_SESSION['user_id'], 'update_profile', 'Usuario actualizó su perfil', getClientIP(), getUserAgent());
        } else {
            $error = "Error al actualizar perfil";
        }
    }
    
    if ($action === 'regenerate_api_key') {
        $newApiKey = generateAPIKey($_SESSION['user_id']);
        $message = "API Key regenerada correctamente";
        addLog($_SESSION['user_id'], 'regenerate_api_key', 'Usuario regeneró su API Key', getClientIP(), getUserAgent());
        $user = getUserById($_SESSION['user_id']); // Recargar datos
    }
}

// Obtener estadísticas del usuario
$totalTokens = db_select_one("SELECT COUNT(*) as count FROM ssh_tokens WHERE created_by = ?", [$_SESSION['user_id']])['count'] ?? 0;
$activeTokens = db_select_one("SELECT COUNT(*) as count FROM ssh_tokens WHERE created_by = ? AND status = 'active' AND expires_at > NOW()", [$_SESSION['user_id']])['count'] ?? 0;
$lastLogin = $user['last_login'] ? date('d/m/Y H:i:s', strtotime($user['last_login'])) : 'Nunca';
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Mi Perfil - CEO SSH Panel</title>
    <link rel="icon" href="../assets/img/favicon.ico">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="../assets/css/style.css">
    <link rel="stylesheet" href="../assets/css/responsive.css">
    <script src="../assets/js/app.js" defer></script>
</head>
<body>
    <div class="app-container">
        <!-- Sidebar -->
        <aside class="sidebar" id="sidebar">
            <div class="logo">
                <div class="logo-icon"><i class="fas fa-shield-alt"></i></div>
                <div class="logo-text">CEO SSH</div>
            </div>
            
            <nav class="sidebar-nav">
                <div class="nav-section">
                    <div class="nav-label">Principal</div>
                    <a href="dashboard.php" class="sidebar-link">
                        <i class="fas fa-tachometer-alt"></i>
                        <span>Dashboard</span>
                    </a>
                    <a href="users.php" class="sidebar-link">
                        <i class="fas fa-users"></i>
                        <span>Usuarios</span>
                    </a>
                </div>
                
                <div class="nav-section">
                    <div class="nav-label">Configuración</div>
                    <a href="profile.php" class="sidebar-link active">
                        <i class="fas fa-user"></i>
                        <span>Mi Perfil</span>
                    </a>
                    <?php if (isAdmin()): ?>
                    <a href="settings.php" class="sidebar-link">
                        <i class="fas fa-cog"></i>
                        <span>Configuración</span>
                    </a>
                    <a href="backups.php" class="sidebar-link">
                        <i class="fas fa-database"></i>
                        <span>Backups</span>
                    </a>
                    <a href="logs.php" class="sidebar-link">
                        <i class="fas fa-history"></i>
                        <span>Logs</span>
                    </a>
                    <?php endif; ?>
                    <a href="help.php" class="sidebar-link">
                        <i class="fas fa-question-circle"></i>
                        <span>Ayuda</span>
                    </a>
                </div>
            </nav>
            
            <div class="user-info">
                <div style="display: flex; align-items: center; gap: 12px;">
                    <div class="user-avatar"><?php echo strtoupper(substr($_SESSION['username'], 0, 1)); ?></div>
                    <div class="user-details">
                        <div class="user-name"><?php echo htmlspecialchars($_SESSION['username']); ?></div>
                        <div class="user-role"><?php echo $_SESSION['role'] === 'admin' ? 'Administrador' : 'Usuario'; ?></div>
                    </div>
                </div>
            </div>
        </aside>
        
        <!-- Main Content -->
        <main class="main-content" id="mainContent">
            <header class="header">
                <div class="header-left">
                    <button class="toggle-sidebar" onclick="toggleSidebar()"><i class="fas fa-bars"></i></button>
                    <div class="page-title">
                        <h1>Mi Perfil</h1>
                        <p>Gestiona tu información personal</p>
                    </div>
                </div>
                
                <div class="header-right">
                    <button class="theme-toggle" onclick="toggleTheme()"><i class="fas fa-moon" id="themeIcon"></i></button>
                    <div class="user-dropdown">
                        <button class="user-btn" onclick="toggleDropdown('userDropdown')">
                            <div class="user-avatar-small"><?php echo strtoupper(substr($_SESSION['username'], 0, 1)); ?></div>
                            <span class="user-name-small"><?php echo htmlspecialchars($_SESSION['username']); ?></span>
                            <i class="fas fa-chevron-down"></i>
                        </button>
                        <div class="dropdown-menu" id="userDropdown">
                            <a href="profile.php" class="dropdown-item"><i class="fas fa-user"></i><span>Mi Perfil</span></a>
                            <div class="dropdown-divider"></div>
                            <a href="../api/auth.php?action=logout" class="dropdown-item"><i class="fas fa-sign-out-alt"></i><span>Cerrar Sesión</span></a>
                        </div>
                    </div>
                </div>
            </header>
            
            <div class="content">
                <?php if ($message): ?>
                    <div style="background: var(--success); color: white; padding: 12px 16px; border-radius: 12px; margin-bottom: 20px;">
                        <i class="fas fa-check-circle"></i> <?php echo $message; ?>
                    </div>
                <?php endif; ?>
                
                <?php if ($error): ?>
                    <div style="background: var(--error); color: white; padding: 12px 16px; border-radius: 12px; margin-bottom: 20px;">
                        <i class="fas fa-exclamation-triangle"></i> <?php echo $error; ?>
                    </div>
                <?php endif; ?>
                
                <div class="row">
                    <!-- Información del perfil -->
                    <div class="col-12 col-md-6">
                        <div class="card">
                            <div class="card-header">
                                <h3 class="card-title"><i class="fas fa-user-circle"></i> Información de la Cuenta</h3>
                            </div>
                            <div class="card-body">
                                <form method="POST">
                                    <input type="hidden" name="action" value="update_profile">
                                    
                                    <div class="form-group">
                                        <label class="form-label">Usuario</label>
                                        <input type="text" class="form-control" value="<?php echo htmlspecialchars($_SESSION['username']); ?>" disabled>
                                    </div>
                                    
                                    <div class="form-group">
                                        <label class="form-label">Email</label>
                                        <input type="email" name="email" class="form-control" value="<?php echo htmlspecialchars($_SESSION['email'] ?? ''); ?>" required>
                                    </div>
                                    
                                    <div class="form-group">
                                        <label class="form-label">Rol</label>
                                        <input type="text" class="form-control" value="<?php echo $_SESSION['role'] === 'admin' ? 'Administrador' : 'Usuario'; ?>" disabled>
                                    </div>
                                    
                                    <div class="form-group">
                                        <label class="form-label">Último acceso</label>
                                        <input type="text" class="form-control" value="<?php echo $lastLogin; ?>" disabled>
                                    </div>
                                    
                                    <button type="submit" class="btn btn-primary"><i class="fas fa-save"></i> Actualizar Perfil</button>
                                </form>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Cambiar contraseña -->
                    <div class="col-12 col-md-6">
                        <div class="card">
                            <div class="card-header">
                                <h3 class="card-title"><i class="fas fa-key"></i> Cambiar Contraseña</h3>
                            </div>
                            <div class="card-body">
                                <form method="POST">
                                    <input type="hidden" name="action" value="change_password">
                                    
                                    <div class="form-group">
                                        <label class="form-label">Contraseña Actual</label>
                                        <input type="password" name="current_password" class="form-control" required>
                                    </div>
                                    
                                    <div class="form-group">
                                        <label class="form-label">Nueva Contraseña</label>
                                        <input type="password" name="new_password" class="form-control" required minlength="6">
                                    </div>
                                    
                                    <div class="form-group">
                                        <label class="form-label">Confirmar Nueva Contraseña</label>
                                        <input type="password" name="confirm_password" class="form-control" required>
                                    </div>
                                    
                                    <button type="submit" class="btn btn-primary"><i class="fas fa-lock"></i> Cambiar Contraseña</button>
                                </form>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Estadísticas personales -->
                    <div class="col-12 col-md-6">
                        <div class="card">
                            <div class="card-header">
                                <h3 class="card-title"><i class="fas fa-chart-line"></i> Mis Estadísticas</h3>
                            </div>
                            <div class="card-body">
                                <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 20px;">
                                    <div style="text-align: center;">
                                        <div style="font-size: 32px; font-weight: 700; color: var(--accent);"><?php echo $totalTokens; ?></div>
                                        <div style="color: var(--text-secondary); font-size: 14px;">Total Usuarios Creados</div>
                                    </div>
                                    <div style="text-align: center;">
                                        <div style="font-size: 32px; font-weight: 700; color: var(--success);"><?php echo $activeTokens; ?></div>
                                        <div style="color: var(--text-secondary); font-size: 14px;">Usuarios Activos</div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <!-- API Key -->
                    <?php if (isAdmin()): ?>
                    <div class="col-12 col-md-6">
                        <div class="card">
                            <div class="card-header">
                                <h3 class="card-title"><i class="fas fa-code"></i> API Key</h3>
                            </div>
                            <div class="card-body">
                                <div class="form-group">
                                    <label class="form-label">Tu API Key para integraciones</label>
                                    <div style="display: flex; gap: 10px;">
                                        <input type="text" id="apiKey" class="form-control" value="<?php echo htmlspecialchars($user['api_key'] ?? 'No generada'); ?>" readonly style="font-family: monospace;">
                                        <button class="btn btn-secondary" onclick="copyToClipboard(document.getElementById('apiKey').value)"><i class="fas fa-copy"></i></button>
                                    </div>
                                </div>
                                
                                <form method="POST">
                                    <input type="hidden" name="action" value="regenerate_api_key">
                                    <button type="submit" class="btn btn-warning" onclick="return confirm('¿Regenerar API Key? Las integraciones actuales dejarán de funcionar.')">
                                        <i class="fas fa-sync-alt"></i> Regenerar API Key
                                    </button>
                                </form>
                                
                                <div style="margin-top: 15px; padding: 12px; background: var(--bg-tertiary); border-radius: 8px;">
                                    <small style="color: var(--text-tertiary);">
                                        <i class="fas fa-info-circle"></i> Usa tu API Key en el header: <code>Authorization: Bearer TU_API_KEY</code>
                                    </small>
                                </div>
                            </div>
                        </div>
                    </div>
                    <?php endif; ?>
                </div>
                
                <!-- Actividad reciente -->
                <div class="card" style="margin-top: 20px;">
                    <div class="card-header">
                        <h3 class="card-title"><i class="fas fa-clock"></i> Actividad Reciente</h3>
                        <a href="logs.php" class="btn btn-sm btn-secondary">Ver todos</a>
                    </div>
                    <div class="card-body">
                        <?php
                        $logs = getLogs(10, 0, ['user_id' => $_SESSION['user_id']]);
                        if (empty($logs)):
                        ?>
                            <div class="empty-state">
                                <i class="fas fa-history"></i>
                                <p>No hay actividad reciente</p>
                            </div>
                        <?php else: ?>
                            <table style="width: 100%;">
                                <thead>
                                    <tr>
                                        <th>Fecha</th>
                                        <th>Acción</th>
                                        <th>Detalles</th>
                                        <th>IP</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($logs as $log): ?>
                                    <tr>
                                        <td><?php echo date('d/m/Y H:i:s', strtotime($log['created_at'])); ?></td>
                                        <td><?php echo htmlspecialchars($log['action']); ?></td>
                                        <td><?php echo htmlspecialchars($log['details']); ?></td>
                                        <td><?php echo htmlspecialchars($log['ip_address']); ?></td>
                                    </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </main>
    </div>
</body>
</html>