<?php
require_once __DIR__ . '/functions.php';

// ==============================================
// FUNCIONES DE AUTENTICACIÓN
// ==============================================

function login($username, $password, $ip, $userAgent) {
    $user = getUserByUsername($username);
    
    if (!$user) {
        addLog(0, 'login_failed', "Intento de login fallido: $username", $ip, $userAgent);
        return false;
    }
    
    // Verificar intentos de login
    $attempts = db_select_one(
        "SELECT COUNT(*) as count FROM logs WHERE action = 'login_failed' AND ip_address = ? AND created_at > DATE_SUB(NOW(), INTERVAL 15 MINUTE)",
        [$ip]
    );
    
    if ($attempts && $attempts['count'] >= MAX_LOGIN_ATTEMPTS) {
        addLog($user['id'], 'login_blocked', "Demasiados intentos fallidos", $ip, $userAgent);
        return false;
    }
    
    // Verificar contraseña
    if (!password_verify($password, $user['password'])) {
        addLog($user['id'], 'login_failed', "Contraseña incorrecta", $ip, $userAgent);
        return false;
    }
    
    // Verificar estado
    if ($user['status'] !== 'active') {
        addLog($user['id'], 'login_blocked', "Cuenta $user[status]", $ip, $userAgent);
        return false;
    }
    
    // Iniciar sesión
    $_SESSION['user_id'] = $user['id'];
    $_SESSION['username'] = $user['username'];
    $_SESSION['email'] = $user['email'];
    $_SESSION['role'] = $user['role'];
    $_SESSION['logged_in'] = true;
    $_SESSION['login_time'] = time();
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    
    // Actualizar último login
    updateUser($user['id'], [
        'last_login' => date('Y-m-d H:i:s'),
        'last_ip' => $ip
    ]);
    
    addLog($user['id'], 'login', "Inicio de sesión exitoso", $ip, $userAgent);
    return true;
}

function logout() {
    if (isLoggedIn()) {
        addLog($_SESSION['user_id'], 'logout', "Cierre de sesión", getClientIP(), getUserAgent());
    }
    
    $_SESSION = [];
    session_destroy();
    return true;
}

function isLoggedIn() {
    if (!isset($_SESSION['logged_in']) || !$_SESSION['logged_in']) {
        return false;
    }
    
    // Verificar timeout
    if (isset($_SESSION['login_time']) && (time() - $_SESSION['login_time']) > SESSION_TIMEOUT) {
        logout();
        return false;
    }
    
    // Verificar que el usuario aún existe en BD
    $user = getUserById($_SESSION['user_id']);
    if (!$user || $user['status'] !== 'active') {
        logout();
        return false;
    }
    
    return true;
}

function requireLogin() {
    if (!isLoggedIn()) {
        header('Location: /index.php');
        exit;
    }
}

function isAdmin() {
    return isLoggedIn() && $_SESSION['role'] === 'admin';
}

function requireAdmin() {
    requireLogin();
    if (!isAdmin()) {
        header('HTTP/1.0 403 Forbidden');
        die('<h1>Acceso Denegado</h1><p>No tienes permisos para acceder a esta página.</p>');
    }
}

function isReseller() {
    return isLoggedIn() && ($_SESSION['role'] === 'reseller' || $_SESSION['role'] === 'admin');
}

function checkPermission($requiredRole) {
    if (!$isLoggedIn()) return false;
    
    $roles = ['user' => 1, 'reseller' => 2, 'admin' => 3];
    $userRole = $roles[$_SESSION['role']] ?? 0;
    $required = $roles[$requiredRole] ?? 0;
    
    return $userRole >= $required;
}

function generateAPIKey($userId) {
    $apiKey = bin2hex(random_bytes(32));
    updateUser($userId, ['api_key' => $apiKey]);
    return $apiKey;
}

function verifyAPIKey($apiKey) {
    $user = db_select_one("SELECT id, username, role FROM users WHERE api_key = ? AND status = 'active'", [$apiKey]);
    return $user ?: false;
}
?>