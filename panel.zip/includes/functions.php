<?php
require_once __DIR__ . '/config.php';

// ==============================================
// FUNCIONES DE BASE DE DATOS
// ==============================================

function db_query($sql, $params = []) {
    $conn = getDB();
    if (!$conn) return false;
    
    $stmt = $conn->prepare($sql);
    if ($stmt === false) return false;
    
    if (!empty($params)) {
        $types = str_repeat('s', count($params));
        $stmt->bind_param($types, ...$params);
    }
    
    $stmt->execute();
    return $stmt;
}

function db_select($sql, $params = []) {
    $stmt = db_query($sql, $params);
    if ($stmt && $stmt->result) {
        return $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
    }
    return [];
}

function db_select_one($sql, $params = []) {
    $results = db_select($sql, $params);
    return $results[0] ?? null;
}

function db_insert($table, $data) {
    $conn = getDB();
    $fields = array_keys($data);
    $placeholders = array_fill(0, count($fields), '?');
    
    $sql = "INSERT INTO $table (" . implode(',', $fields) . ") VALUES (" . implode(',', $placeholders) . ")";
    $stmt = db_query($sql, array_values($data));
    
    if ($stmt) {
        return $conn->insert_id;
    }
    return false;
}

function db_update($table, $data, $where, $whereParams = []) {
    $sets = [];
    $values = [];
    
    foreach ($data as $field => $value) {
        $sets[] = "$field = ?";
        $values[] = $value;
    }
    
    $values = array_merge($values, $whereParams);
    $sql = "UPDATE $table SET " . implode(',', $sets) . " WHERE $where";
    $stmt = db_query($sql, $values);
    
    return $stmt !== false;
}

function db_delete($table, $where, $params = []) {
    $sql = "DELETE FROM $table WHERE $where";
    $stmt = db_query($sql, $params);
    return $stmt !== false;
}

// ==============================================
// FUNCIONES DE USUARIOS
// ==============================================

function getUserById($id) {
    return db_select_one("SELECT id, username, email, role, status, balance, created_at, last_login FROM users WHERE id = ?", [$id]);
}

function getUserByUsername($username) {
    return db_select_one("SELECT * FROM users WHERE username = ?", [$username]);
}

function getUsers($filters = []) {
    $sql = "SELECT id, username, email, role, status, created_at, last_login FROM users WHERE 1=1";
    $params = [];
    
    if (isset($filters['role'])) {
        $sql .= " AND role = ?";
        $params[] = $filters['role'];
    }
    
    if (isset($filters['status'])) {
        $sql .= " AND status = ?";
        $params[] = $filters['status'];
    }
    
    if (isset($filters['search'])) {
        $sql .= " AND (username LIKE ? OR email LIKE ?)";
        $params[] = "%{$filters['search']}%";
        $params[] = "%{$filters['search']}%";
    }
    
    $sql .= " ORDER BY created_at DESC";
    
    if (isset($filters['limit'])) {
        $sql .= " LIMIT " . intval($filters['limit']);
        if (isset($filters['offset'])) {
            $sql .= " OFFSET " . intval($filters['offset']);
        }
    }
    
    return db_select($sql, $params);
}

function createUser($data) {
    return db_insert('users', $data);
}

function updateUser($id, $data) {
    return db_update('users', $data, 'id = ?', [$id]);
}

function deleteUser($id) {
    return db_delete('users', 'id = ?', [$id]);
}

// ==============================================
// FUNCIONES DE TOKENS SSH
// ==============================================

function getSSHTokens($filters = []) {
    $sql = "SELECT t.*, u.username as creator FROM ssh_tokens t LEFT JOIN users u ON t.created_by = u.id WHERE 1=1";
    $params = [];
    
    if (isset($filters['status'])) {
        $sql .= " AND t.status = ?";
        $params[] = $filters['status'];
    }
    
    if (isset($filters['username'])) {
        $sql .= " AND t.username LIKE ?";
        $params[] = "%{$filters['username']}%";
    }
    
    $sql .= " ORDER BY t.created_at DESC";
    
    if (isset($filters['limit'])) {
        $sql .= " LIMIT " . intval($filters['limit']);
    }
    
    return db_select($sql, $params);
}

function getSSHTokenById($id) {
    return db_select_one("SELECT * FROM ssh_tokens WHERE id = ?", [$id]);
}

function getSSHTokenByUsername($username) {
    return db_select_one("SELECT * FROM ssh_tokens WHERE username = ?", [$username]);
}

function createSSHToken($data) {
    return db_insert('ssh_tokens', $data);
}

function updateSSHToken($id, $data) {
    return db_update('ssh_tokens', $data, 'id = ?', [$id]);
}

function deleteSSHToken($id) {
    $token = getSSHTokenById($id);
    if ($token) {
        // Eliminar usuario del sistema
        shell_exec("userdel -r -f " . escapeshellarg($token['username']) . " 2>/dev/null");
        return db_delete('ssh_tokens', 'id = ?', [$id]);
    }
    return false;
}

function getExpiredTokens() {
    return db_select("SELECT * FROM ssh_tokens WHERE expires_at < NOW() AND status = 'active'");
}

function expireOldTokens() {
    $expired = getExpiredTokens();
    foreach ($expired as $token) {
        updateSSHToken($token['id'], ['status' => 'expired']);
        shell_exec("usermod -L " . escapeshellarg($token['username']) . " 2>/dev/null");
    }
    return count($expired);
}

// ==============================================
// FUNCIONES DE LOGS
// ==============================================

function addLog($userId, $action, $details, $ip = null, $userAgent = null) {
    $ip = $ip ?: getClientIP();
    $userAgent = $userAgent ?: getUserAgent();
    
    return db_insert('logs', [
        'user_id' => $userId,
        'action' => $action,
        'details' => $details,
        'ip_address' => $ip,
        'user_agent' => $userAgent
    ]);
}

function getLogs($limit = 100, $offset = 0, $filters = []) {
    $sql = "SELECT l.*, u.username FROM logs l LEFT JOIN users u ON l.user_id = u.id WHERE 1=1";
    $params = [];
    
    if (isset($filters['action'])) {
        $sql .= " AND l.action = ?";
        $params[] = $filters['action'];
    }
    
    if (isset($filters['user_id'])) {
        $sql .= " AND l.user_id = ?";
        $params[] = $filters['user_id'];
    }
    
    $sql .= " ORDER BY l.created_at DESC LIMIT ? OFFSET ?";
    $params[] = $limit;
    $params[] = $offset;
    
    return db_select($sql, $params);
}

// ==============================================
// FUNCIONES DE NOTIFICACIONES
// ==============================================

function addNotification($userId, $title, $message, $type = 'info') {
    return db_insert('notifications', [
        'user_id' => $userId,
        'title' => $title,
        'message' => $message,
        'type' => $type
    ]);
}

function getNotifications($userId, $limit = 20) {
    return db_select("SELECT * FROM notifications WHERE user_id = ? ORDER BY created_at DESC LIMIT ?", [$userId, $limit]);
}

function markNotificationAsRead($id, $userId) {
    return db_update('notifications', ['is_read' => 1], 'id = ? AND user_id = ?', [$id, $userId]);
}

function markAllNotificationsAsRead($userId) {
    return db_update('notifications', ['is_read' => 1], 'user_id = ?', [$userId]);
}

function getUnreadCount($userId) {
    $result = db_select_one("SELECT COUNT(*) as count FROM notifications WHERE user_id = ? AND is_read = 0", [$userId]);
    return $result['count'] ?? 0;
}

// ==============================================
// FUNCIONES DE CONFIGURACIÓN
// ==============================================

function getSetting($key, $default = null) {
    $result = db_select_one("SELECT value FROM settings WHERE `key` = ?", [$key]);
    return $result ? $result['value'] : $default;
}

function setSetting($key, $value, $description = '') {
    return db_insert('settings', ['key' => $key, 'value' => $value, 'description' => $description])
        ?: db_update('settings', ['value' => $value, 'description' => $description], '`key` = ?', [$key]);
}

// ==============================================
// FUNCIONES DE SISTEMA
// ==============================================

function getSystemStats() {
    $load = sys_getloadavg();
    
    // Estadísticas de usuarios
    $totalUsers = db_select_one("SELECT COUNT(*) as count FROM users")['count'] ?? 0;
    $activeTokens = db_select_one("SELECT COUNT(*) as count FROM ssh_tokens WHERE status = 'active' AND expires_at > NOW()")['count'] ?? 0;
    $expiredTokens = db_select_one("SELECT COUNT(*) as count FROM ssh_tokens WHERE expires_at <= NOW() OR status = 'expired'")['count'] ?? 0;
    
    // Estadísticas del sistema
    $onlineUsers = shell_exec("ps aux | grep -E 'sshd|dropbear' | grep -v grep | wc -l") ?: 0;
    $diskUsage = shell_exec("df -h / | awk 'NR==2 {print $5}' | sed 's/%//'") ?: 0;
    $memoryUsage = shell_exec("free | grep Mem | awk '{print ($3/$2) * 100}'") ?: 0;
    
    return [
        'load' => round($load[0], 2),
        'total_users' => intval($totalUsers),
        'active_tokens' => intval($activeTokens),
        'expired_tokens' => intval($expiredTokens),
        'online_users' => intval(trim($onlineUsers)),
        'disk_usage' => intval(trim($diskUsage)),
        'memory_usage' => round(floatval(trim($memoryUsage)), 1),
        'timestamp' => date('Y-m-d H:i:s')
    ];
}

function getServerInfo() {
    return [
        'hostname' => gethostname(),
        'os' => php_uname('s') . ' ' . php_uname('r'),
        'php_version' => PHP_VERSION,
        'mysql_version' => getDB()->server_info,
        'nginx_version' => shell_exec("nginx -v 2>&1 | cut -d'/' -f2") ?: 'Unknown',
        'uptime' => shell_exec("uptime -p") ?: 'Unknown',
        'timezone' => date_default_timezone_get()
    ];
}

function createBackup() {
    $backupDir = BACKUP_PATH;
    if (!is_dir($backupDir)) {
        mkdir($backupDir, 0755, true);
    }
    
    $filename = 'backup_' . date('Ymd_His') . '.sql';
    $filepath = $backupDir . '/' . $filename;
    
    $command = sprintf(
        'mysqldump -u %s -p%s %s > %s',
        escapeshellarg(DB_USER),
        escapeshellarg(DB_PASS),
        escapeshellarg(DB_NAME),
        escapeshellarg($filepath)
    );
    
    shell_exec($command);
    
    if (file_exists($filepath)) {
        db_insert('backups', [
            'filename' => $filename,
            'size' => filesize($filepath),
            'type' => 'database',
            'created_by' => $_SESSION['user_id'] ?? 0
        ]);
        return $filename;
    }
    
    return false;
}

function cleanOldBackups() {
    $backupDir = BACKUP_PATH;
    $files = glob($backupDir . '/backup_*.sql');
    $keepDays = BACKUP_KEEP_DAYS;
    
    foreach ($files as $file) {
        if (filemtime($file) < time() - ($keepDays * 86400)) {
            unlink($file);
        }
    }
}

// ==============================================
// FUNCIONES DE SSH
// ==============================================

function createSystemUser($username, $password, $expireDate) {
    // Verificar si ya existe
    $check = shell_exec("id " . escapeshellarg($username) . " 2>/dev/null");
    if ($check) return false;
    
    // Crear usuario
    $cmd = sprintf(
        'useradd -m -s /bin/false -e %s %s && echo "%s:%s" | chpasswd',
        escapeshellarg($expireDate),
        escapeshellarg($username),
        escapeshellarg($username),
        escapeshellarg($password)
    );
    
    shell_exec($cmd);
    return true;
}

function deleteSystemUser($username) {
    shell_exec("userdel -r -f " . escapeshellarg($username) . " 2>/dev/null");
    return true;
}

function extendSystemUser($username, $days) {
    $currentExp = shell_exec("chage -l " . escapeshellarg($username) . " | grep 'Account expires' | cut -d: -f2");
    $currentExp = trim($currentExp);
    
    if ($currentExp == 'never' || empty($currentExp)) {
        $newExp = date('Y-m-d', strtotime("+$days days"));
    } else {
        $newExp = date('Y-m-d', strtotime($currentExp . " + $days days"));
    }
    
    shell_exec("usermod -e " . escapeshellarg($newExp) . " " . escapeshellarg($username));
    return $newExp;
}

function getUserConnections($username) {
    $connections = shell_exec("ps aux | grep -E 'sshd|dropbear' | grep " . escapeshellarg($username) . " | grep -v grep | wc -l");
    return intval(trim($connections));
}

function killUserConnections($username) {
    shell_exec("pkill -u " . escapeshellarg($username) . " 2>/dev/null");
    return true;
}
?>