<?php
// test_api.php - Archivo de prueba para verificar API
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST, GET, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

// Manejar OPTIONS preflight
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

// Responder según el método
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $input = json_decode(file_get_contents('php://input'), true);
    
    echo json_encode([
        'success' => true,
        'message' => 'POST funcionando correctamente',
        'data' => $input,
        'method' => 'POST',
        'time' => date('Y-m-d H:i:s')
    ]);
    
} else if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    echo json_encode([
        'success' => true,
        'message' => 'GET funcionando correctamente',
        'method' => 'GET',
        'time' => date('Y-m-d H:i:s')
    ]);
    
} else {
    http_response_code(405);
    echo json_encode([
        'success' => false,
        'error' => 'Método no permitido: ' . $_SERVER['REQUEST_METHOD']
    ]);
}
?>