<?php
// get_servers.php - Versión corregida
error_reporting(0);
ini_set('display_errors', 0);

header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

if ($_SERVER['REQUEST_METHOD'] !== 'GET') {
    http_response_code(405);
    echo json_encode([
        'success' => false,
        'error' => 'Método no permitido. Usa GET.'
    ]);
    exit();
}

$servers = [];
if (file_exists('servers.json')) {
    $content = file_get_contents('servers.json');
    $servers = json_decode($content, true);
    if (!is_array($servers)) $servers = [];
}

echo json_encode([
    'success' => true,
    'data' => $servers
]);
?>