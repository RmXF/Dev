<?php
// save_server.php - Versión corregida
error_reporting(0);
ini_set('display_errors', 0);

header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST, GET, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode([
        'success' => false,
        'error' => 'Método no permitido. Usa POST.',
        'method' => $_SERVER['REQUEST_METHOD']
    ]);
    exit();
}

$input = json_decode(file_get_contents('php://input'), true);
if (!$input) $input = $_POST;

if (!$input) {
    echo json_encode(['success' => false, 'error' => 'No se recibieron datos']);
    exit();
}

error_log("save_server.php - Datos: " . print_r($input, true));

// Validar campos
$required = ['name', 'ip', 'port', 'user', 'password', 'location'];
foreach ($required as $field) {
    if (!isset($input[$field]) || empty($input[$field])) {
        echo json_encode(['success' => false, 'error' => "Campo $field requerido"]);
        exit();
    }
}

// Crear o leer archivo
$servers = [];
if (file_exists('servers.json')) {
    $content = file_get_contents('servers.json');
    $servers = json_decode($content, true);
    if (!is_array($servers)) $servers = [];
}

// Crear nuevo servidor
$newServer = [
    'id' => uniqid(),
    'name' => $input['name'],
    'ip' => $input['ip'],
    'port' => intval($input['port']),
    'user' => $input['user'],
    'password' => '****',
    'location' => $input['location'],
    'status' => 'active',
    'cpu' => isset($input['cpu']) ? intval($input['cpu']) : rand(20, 60),
    'ram' => isset($input['ram']) ? floatval($input['ram']) : rand(2, 8),
    'disk' => isset($input['disk']) ? intval($input['disk']) : rand(40, 120),
    'uptime' => $input['uptime'] ?? 'desconocido',
    'os' => $input['os'] ?? 'Linux',
    'kernel' => $input['kernel'] ?? '',
    'cpu_cores' => isset($input['cpu_cores']) ? intval($input['cpu_cores']) : 4,
    'ram_total' => isset($input['ram_total']) ? intval($input['ram_total']) : 8,
    'disk_total' => isset($input['disk_total']) ? intval($input['disk_total']) : 160,
    'created' => date('Y-m-d H:i:s'),
    'last_checked' => date('Y-m-d H:i:s')
];

$servers[] = $newServer;

if (file_put_contents('servers.json', json_encode($servers, JSON_PRETTY_PRINT))) {
    echo json_encode([
        'success' => true,
        'message' => 'Servidor guardado',
        'data' => $newServer
    ]);
} else {
    echo json_encode([
        'success' => false,
        'error' => 'No se pudo guardar el servidor'
    ]);
}
?>