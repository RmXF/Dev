// ============================================
// VPS CONTROL PANEL - SCRIPT COMPLETO
// CON MANEJO DE ERRORES Y DEBUGGING
// ============================================

// Configuración
const API_URL = window.location.origin + window.location.pathname.replace(/[^/]*$/, '');
let currentServerId = null;

// ============================================
// FUNCIÓN PRINCIPAL PARA PETICIONES API
// ============================================

// Función fetchAPI mejorada con manejo de errores 405
async function fetchAPI(endpoint, options = {}) {
    const url = endpoint; // Asumiendo que está en el mismo directorio
    
    console.log(`🌐 Intentando conectar a: ${url}`);
    console.log('📦 Método:', options.method || 'GET');
    console.log('📦 Datos:', options.body);
    
    try {
        const response = await fetch(url, {
            ...options,
            headers: {
                'Content-Type': 'application/json',
                'Accept': 'application/json',
                ...options.headers
            }
        });
        
        console.log('📥 Status:', response.status);
        console.log('📥 Status Text:', response.statusText);
        
        // Manejar error 405 específicamente
        if (response.status === 405) {
            console.error('❌ Error 405: Método no permitido');
            
            // Intentar obtener el mensaje de error
            try {
                const errorData = await response.json();
                throw new Error(`Error 405: ${errorData.error || 'Método no permitido'}`);
            } catch {
                throw new Error('Error 405: El servidor no acepta este método. Verifica que el archivo PHP existe y permite POST.');
            }
        }
        
        if (!response.ok) {
            const text = await response.text();
            console.error('❌ HTTP Error:', response.status, text.substring(0, 200));
            throw new Error(`Error HTTP ${response.status}: ${response.statusText}`);
        }
        
        const text = await response.text();
        console.log('📄 Respuesta:', text.substring(0, 300));
        
        try {
            const data = JSON.parse(text);
            console.log('✅ JSON OK:', data);
            
            if (!data.success) {
                throw new Error(data.error || data.message || 'Error desconocido');
            }
            
            return data;
            
        } catch (jsonError) {
            console.error('❌ JSON Error:', jsonError);
            console.error('📄 Texto completo:', text);
            
            if (text.includes('<?php')) {
                throw new Error('El servidor devolvió código PHP en lugar de ejecutarlo. Verifica la configuración del servidor.');
            } else if (text.includes('Parse error') || text.includes('Fatal error')) {
                throw new Error('Error de PHP: ' + text.substring(0, 100));
            } else {
                throw new Error('El servidor no devolvió JSON válido');
            }
        }
        
    } catch (error) {
        console.error('❌ Error:', error);
        throw error;
    }
}

// Prueba rápida al cargar la página
window.testAPI = async function() {
    console.log('🧪 Probando API...');
    
    try {
        // Probar GET
        const getResult = await fetchAPI('get_servers.php');
        console.log('✅ GET funciona:', getResult);
        
        // Probar POST con test_api.php
        const postResult = await fetchAPI('test_api.php', {
            method: 'POST',
            body: JSON.stringify({ test: 'data' })
        });
        console.log('✅ POST funciona:', postResult);
        
        showToast('Éxito', 'API funcionando correctamente', 'success');
        
    } catch (error) {
        console.error('❌ API test failed:', error);
        showToast('Error API', error.message, 'error');
    }
}

// ============================================
// FUNCIONES DEL MODAL DE AGREGAR SERVIDOR
// ============================================

// Abrir modal
window.openAddServerModal = function() {
    console.log('📌 Abriendo modal de agregar servidor...');
    const modal = document.getElementById('addServerModal');
    const overlay = document.getElementById('overlay');
    
    if (modal) {
        modal.classList.add('active');
        overlay.classList.add('active');
        document.body.style.overflow = 'hidden';
        
        // Resetear formulario
        const form = document.getElementById('addServerForm');
        if (form) {
            form.reset();
            document.getElementById('serverPort').value = '22';
        }
        
        // Ocultar test de conexión
        const connectionTest = document.getElementById('connectionTest');
        if (connectionTest) {
            connectionTest.style.display = 'none';
        }
    }
}

// Cerrar modal
window.closeModal = function() {
    console.log('📌 Cerrando modal...');
    const modal = document.getElementById('addServerModal');
    const overlay = document.getElementById('overlay');
    
    if (modal) {
        modal.classList.remove('active');
        overlay.classList.remove('active');
        document.body.style.overflow = '';
        
        // Resetear formulario
        const form = document.getElementById('addServerForm');
        if (form) {
            form.reset();
            document.getElementById('serverPort').value = '22';
        }
        
        // Ocultar test de conexión
        const connectionTest = document.getElementById('connectionTest');
        if (connectionTest) {
            connectionTest.style.display = 'none';
        }
        
        // Restaurar botón
        const submitBtn = document.getElementById('addServerSubmit');
        if (submitBtn) {
            submitBtn.disabled = false;
            submitBtn.innerHTML = '<i class="fas fa-plus"></i> Agregar Servidor';
        }
    }
}

// Toggle contraseña
window.togglePassword = function() {
    const passwordInput = document.getElementById('serverPassword');
    const toggleBtn = document.querySelector('.password-toggle i');
    
    if (passwordInput) {
        if (passwordInput.type === 'password') {
            passwordInput.type = 'text';
            if (toggleBtn) toggleBtn.className = 'fas fa-eye-slash';
        } else {
            passwordInput.type = 'password';
            if (toggleBtn) toggleBtn.className = 'fas fa-eye';
        }
    }
}

// ============================================
// FUNCIÓN PRINCIPAL PARA AGREGAR SERVIDOR
// ============================================

window.testAndAddServer = async function() {
    console.log('🚀 Iniciando proceso de agregar servidor...');
    
    const form = document.getElementById('addServerForm');
    const submitBtn = document.getElementById('addServerSubmit');
    const connectionTest = document.getElementById('connectionTest');
    const testMessage = connectionTest?.querySelector('span');
    
    // Validar formulario
    if (!form.checkValidity()) {
        form.reportValidity();
        return;
    }
    
    // Obtener datos del formulario
    const serverData = {
        name: document.getElementById('serverName')?.value || '',
        ip: document.getElementById('serverIP')?.value || '',
        port: parseInt(document.getElementById('serverPort')?.value) || 22,
        user: document.getElementById('serverUser')?.value || '',
        password: document.getElementById('serverPassword')?.value || '',
        location: document.getElementById('serverLocation')?.value || 'Desconocido',
        save_credentials: document.getElementById('saveCredentials')?.checked || false,
        auto_connect: document.getElementById('autoConnect')?.checked || false
    };
    
    console.log('📦 Datos del servidor:', serverData);
    
    // Validar datos básicos
    if (!serverData.name || !serverData.ip || !serverData.user || !serverData.password) {
        showToast('Error', 'Todos los campos son obligatorios', 'error');
        return;
    }
    
    // Validar formato de IP (básico)
    const ipRegex = /^(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$/;
    if (!ipRegex.test(serverData.ip)) {
        showToast('Error', 'Formato de IP inválido', 'error');
        return;
    }
    
    // Mostrar test de conexión
    if (connectionTest) {
        connectionTest.style.display = 'flex';
        if (testMessage) testMessage.textContent = 'Conectando al servidor...';
    }
    
    // Deshabilitar botón
    if (submitBtn) {
        submitBtn.disabled = true;
        submitBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Conectando...';
    }
    
    try {
        // PASO 1: Probar conexión SSH
        console.log('📡 PASO 1: Probando conexión SSH...');
        
        const connectResult = await fetchAPI('connect.php', {
            method: 'POST',
            body: JSON.stringify({
                ip: serverData.ip,
                port: serverData.port,
                user: serverData.user,
                password: serverData.password
            })
        });
        
        console.log('✅ PASO 1 Completado:', connectResult);
        
        // Actualizar mensaje
        if (testMessage) testMessage.textContent = 'Conexión exitosa, guardando servidor...';
        
        // PASO 2: Guardar servidor
        console.log('📡 PASO 2: Guardando servidor...');
        
        const serverInfo = connectResult.data || {};
        const saveResult = await fetchAPI('save_server.php', {
            method: 'POST',
            body: JSON.stringify({
                ...serverData,
                cpu: serverInfo.cpu || Math.floor(Math.random() * 50 + 20),
                ram: serverInfo.ram || Math.floor(Math.random() * 8 + 4),
                disk: serverInfo.disk || Math.floor(Math.random() * 100 + 50),
                uptime: serverInfo.uptime || 'desconocido',
                os: serverInfo.os || 'Linux',
                kernel: serverInfo.kernel || '',
                cpu_cores: serverInfo.cpu_cores || 4,
                ram_total: serverInfo.ram_total || 8,
                disk_total: serverInfo.disk_total || 160
            })
        });
        
        console.log('✅ PASO 2 Completado:', saveResult);
        
        // Mostrar éxito
        showToast('¡Éxito!', `Servidor ${serverData.name} agregado correctamente`, 'success');
        
        // Recargar lista de servidores
        await loadServers();
        
        // Cerrar modal después de 1.5 segundos
        setTimeout(() => {
            closeModal();
        }, 1500);
        
    } catch (error) {
        console.error('❌ Error en el proceso:', error);
        
        // Mostrar mensaje de error específico
        let errorMessage = error.message;
        
        if (errorMessage.includes('ssh2')) {
            errorMessage = 'Error: La extensión SSH2 no está instalada en el servidor.';
        } else if (errorMessage.includes('Connection refused')) {
            errorMessage = 'Error: No se pudo conectar. Verifica que el servidor esté accesible.';
        } else if (errorMessage.includes('Authentication')) {
            errorMessage = 'Error: Usuario o contraseña incorrectos.';
        }
        
        showToast('Error', errorMessage, 'error');
        
        // Ocultar test de conexión
        if (connectionTest) {
            connectionTest.style.display = 'none';
        }
    } finally {
        // Restaurar botón
        if (submitBtn) {
            submitBtn.disabled = false;
            submitBtn.innerHTML = '<i class="fas fa-plus"></i> Agregar Servidor';
        }
    }
}

// ============================================
// FUNCIONES DE CARGA Y RENDERIZADO
// ============================================

// Cargar servidores desde la API
async function loadServers() {
    console.log('📡 Cargando servidores...');
    
    try {
        const result = await fetchAPI('get_servers.php');
        console.log('✅ Servidores cargados:', result.data);
        
        // Guardar en localStorage
        localStorage.setItem('vps_servers', JSON.stringify(result.data || []));
        
        // Renderizar
        renderServers();
        updateStats();
        
    } catch (error) {
        console.error('❌ Error cargando servidores:', error);
        
        // Si hay error, intentar cargar desde localStorage
        const localServers = localStorage.getItem('vps_servers');
        if (localServers) {
            console.log('📦 Usando servidores de localStorage');
            renderServers();
            updateStats();
        }
    }
}

// Renderizar servidores
function renderServers() {
    const servers = JSON.parse(localStorage.getItem('vps_servers') || '[]');
    const grid = document.getElementById('serversGrid');
    const noServers = document.getElementById('noServers');
    const filter = document.getElementById('serverFilter')?.value || 'all';
    
    if (!grid) return;
    
    // Filtrar servidores
    let filteredServers = servers;
    if (filter !== 'all') {
        filteredServers = servers.filter(s => s.status === filter);
    }
    
    // Mostrar mensaje si no hay servidores
    if (filteredServers.length === 0) {
        grid.innerHTML = '';
        if (noServers) {
            noServers.style.display = 'block';
            if (servers.length > 0) {
                noServers.innerHTML = `
                    <i class="fas fa-filter"></i>
                    <h3>No hay servidores con este filtro</h3>
                    <p><a href="#" onclick="document.getElementById('serverFilter').value='all'; renderServers(); return false;">Mostrar todos</a></p>
                `;
            }
        }
        return;
    }
    
    if (noServers) noServers.style.display = 'none';
    
    // Generar HTML
    grid.innerHTML = filteredServers.map(server => `
        <div class="server-card" onclick="viewServerDetails('${server.id}')">
            <div class="server-header">
                <div class="server-status status-${server.status || 'stopped'}"></div>
                <div class="server-name">
                    <h3>${escapeHtml(server.name)}</h3>
                    <span class="server-ip">${escapeHtml(server.ip)}:${server.port}</span>
                </div>
                <button class="server-menu" onclick="event.stopPropagation(); toggleServerMenu('${server.id}')">
                    <i class="fas fa-ellipsis-v"></i>
                </button>
            </div>
            
            <div class="server-specs">
                <div class="spec"><i class="fas fa-microchip"></i> ${server.cpu_cores || 2} vCPU</div>
                <div class="spec"><i class="fas fa-memory"></i> ${server.ram_total || 8} GB RAM</div>
                <div class="spec"><i class="fas fa-hdd"></i> ${server.disk_total || 100} GB SSD</div>
            </div>
            
            <div class="server-usage">
                <div class="usage-item">
                    <span>CPU: ${server.cpu || 0}%</span>
                    <div class="progress-bar">
                        <div class="progress" style="width: ${server.cpu || 0}%"></div>
                    </div>
                </div>
                <div class="usage-item">
                    <span>RAM: ${server.ram || 0} GB</span>
                    <div class="progress-bar">
                        <div class="progress" style="width: ${((server.ram || 0) / (server.ram_total || 8) * 100)}%"></div>
                    </div>
                </div>
            </div>
            
            <div class="server-footer">
                <span class="server-location"><i class="fas fa-map-marker-alt"></i> ${escapeHtml(server.location)}</span>
                <div class="server-actions" onclick="event.stopPropagation()">
                    <button class="server-action-btn" onclick="controlServer('${server.id}', 'start')" ${server.status === 'active' ? 'disabled' : ''}>
                        <i class="fas fa-play"></i>
                    </button>
                    <button class="server-action-btn" onclick="controlServer('${server.id}', 'stop')" ${server.status !== 'active' ? 'disabled' : ''}>
                        <i class="fas fa-stop"></i>
                    </button>
                    <button class="server-action-btn" onclick="controlServer('${server.id}', 'restart')" ${server.status !== 'active' ? 'disabled' : ''}>
                        <i class="fas fa-redo-alt"></i>
                    </button>
                    <button class="server-action-btn delete" onclick="confirmDeleteServer('${server.id}')">
                        <i class="fas fa-trash"></i>
                    </button>
                </div>
            </div>
        </div>
    `).join('');
}

// Actualizar estadísticas
function updateStats() {
    const servers = JSON.parse(localStorage.getItem('vps_servers') || '[]');
    const totalServers = servers.length;
    const activeServers = servers.filter(s => s.status === 'active').length;
    
    const totalServersEl = document.getElementById('totalServers');
    const serverCountEl = document.getElementById('serverCount');
    const serverChangeEl = document.getElementById('serverChange');
    const avgCpuEl = document.getElementById('avgCpu');
    const avgRamEl = document.getElementById('avgRam');
    
    if (totalServersEl) totalServersEl.textContent = totalServers;
    if (serverCountEl) serverCountEl.textContent = totalServers;
    if (serverChangeEl) serverChangeEl.innerHTML = `<i class="fas fa-arrow-up"></i> +${activeServers}`;
    
    if (totalServers > 0) {
        const avgCpu = Math.round(servers.reduce((acc, s) => acc + (s.cpu || 0), 0) / totalServers);
        const avgRam = (servers.reduce((acc, s) => acc + (s.ram || 0), 0) / totalServers).toFixed(1);
        
        if (avgCpuEl) avgCpuEl.textContent = avgCpu + '%';
        if (avgRamEl) avgRamEl.textContent = avgRam + ' GB';
    }
}

// ============================================
// FUNCIONES DE CONTROL DE SERVIDORES
// ============================================

// Controlar servidor (iniciar/detener/reiniciar)
window.controlServer = async function(serverId, action) {
    console.log(`🎮 Controlando servidor ${serverId}: ${action}`);
    
    const servers = JSON.parse(localStorage.getItem('vps_servers') || '[]');
    const serverIndex = servers.findIndex(s => s.id === serverId);
    
    if (serverIndex === -1) {
        showToast('Error', 'Servidor no encontrado', 'error');
        return;
    }
    
    const server = servers[serverIndex];
    
    const actions = {
        start: { status: 'active', message: 'iniciado' },
        stop: { status: 'stopped', message: 'detenido' },
        restart: { status: 'active', message: 'reiniciado' }
    };
    
    const actionData = actions[action];
    
    if (!actionData) {
        showToast('Error', 'Acción no válida', 'error');
        return;
    }
    
    if (action === 'restart') {
        // Simular reinicio
        server.status = 'stopped';
        localStorage.setItem('vps_servers', JSON.stringify(servers));
        renderServers();
        
        showToast('Reiniciando', `Servidor ${server.name} se está reiniciando...`, 'info');
        addActivity(`Servidor ${server.name} reiniciando`, 'info');
        
        setTimeout(() => {
            server.status = 'active';
            server.cpu = Math.floor(Math.random() * 50 + 20);
            server.ram = Math.floor(Math.random() * 8 + 4);
            server.uptime = '0 días';
            server.lastChecked = new Date().toISOString();
            localStorage.setItem('vps_servers', JSON.stringify(servers));
            renderServers();
            updateStats();
            showToast('Reinicio completado', `Servidor ${server.name} está nuevamente activo`, 'success');
            addActivity(`Servidor ${server.name} reiniciado correctamente`, 'success');
        }, 3000);
    } else {
        server.status = actionData.status;
        server.lastChecked = new Date().toISOString();
        localStorage.setItem('vps_servers', JSON.stringify(servers));
        renderServers();
        updateStats();
        showToast('Servidor', `Servidor ${server.name} ${actionData.message}`, 'success');
        addActivity(`Servidor ${server.name} ${actionData.message}`, 'info');
    }
}

// Confirmar eliminación
window.confirmDeleteServer = function(serverId) {
    const servers = JSON.parse(localStorage.getItem('vps_servers') || '[]');
    const server = servers.find(s => s.id === serverId);
    
    if (!server) return;
    
    if (confirm(`¿Estás seguro de eliminar el servidor "${server.name}"?`)) {
        deleteServer(serverId);
    }
}

// Eliminar servidor
async function deleteServer(serverId) {
    console.log(`🗑️ Eliminando servidor ${serverId}`);
    
    const servers = JSON.parse(localStorage.getItem('vps_servers') || '[]');
    const server = servers.find(s => s.id === serverId);
    
    if (!server) return;
    
    try {
        // Intentar eliminar vía API
        const result = await fetchAPI('delete_server.php', {
            method: 'POST',
            body: JSON.stringify({ id: serverId })
        });
        
        console.log('✅ Servidor eliminado:', result);
        
    } catch (error) {
        console.warn('⚠️ Error en API, eliminando solo localmente:', error);
    }
    
    // Eliminar localmente
    const newServers = servers.filter(s => s.id !== serverId);
    localStorage.setItem('vps_servers', JSON.stringify(newServers));
    
    renderServers();
    updateStats();
    addActivity(`Servidor ${server.name} eliminado`, 'warning');
    showToast('Servidor eliminado', `${server.name} ha sido eliminado`, 'warning');
}

// Ver detalles del servidor
window.viewServerDetails = function(serverId) {
    const servers = JSON.parse(localStorage.getItem('vps_servers') || '[]');
    const server = servers.find(s => s.id === serverId);
    
    if (!server) return;
    
    const details = `
        📊 INFORMACIÓN DEL SERVIDOR
        ─────────────────────────
        Nombre: ${server.name}
        IP: ${server.ip}:${server.port}
        Usuario: ${server.user}
        Estado: ${server.status === 'active' ? '✅ Activo' : '⛔ Detenido'}
        SO: ${server.os || 'Linux'}
        Kernel: ${server.kernel || 'desconocido'}
        ─────────────────────────
        CPU: ${server.cpu || 0}% (${server.cpu_cores || 2} núcleos)
        RAM: ${server.ram || 0} GB / ${server.ram_total || 8} GB
        Disco: ${server.disk || 0} GB / ${server.disk_total || 100} GB
        ─────────────────────────
        Ubicación: ${server.location}
        Creado: ${new Date(server.created).toLocaleString()}
        Último chequeo: ${new Date(server.lastChecked).toLocaleString()}
    `;
    
    alert(details);
}

// ============================================
// FUNCIONES DE ACTIVIDAD
// ============================================

// Agregar actividad
function addActivity(message, type = 'info') {
    const activities = JSON.parse(localStorage.getItem('activities') || '[]');
    
    activities.unshift({
        id: Date.now(),
        message,
        type,
        time: new Date().toISOString()
    });
    
    if (activities.length > 15) activities.pop();
    
    localStorage.setItem('activities', JSON.stringify(activities));
    renderActivities();
}

// Renderizar actividades
function renderActivities() {
    const activities = JSON.parse(localStorage.getItem('activities') || '[]');
    const list = document.getElementById('activityList');
    
    if (!list) return;
    
    if (activities.length === 0) {
        list.innerHTML = '<div class="activity-item">No hay actividad reciente</div>';
        return;
    }
    
    list.innerHTML = activities.map(activity => {
        const timeAgo = getTimeAgo(new Date(activity.time));
        const icon = activity.type === 'success' ? 'fa-check-circle' : 
                    activity.type === 'warning' ? 'fa-exclamation-triangle' : 'fa-info-circle';
        
        return `
            <div class="activity-item">
                <div class="activity-icon ${activity.type}">
                    <i class="fas ${icon}"></i>
                </div>
                <div class="activity-content">
                    <span class="activity-text">${escapeHtml(activity.message)}</span>
                    <span class="activity-time">${timeAgo}</span>
                </div>
            </div>
        `;
    }).join('');
}

// Calcular tiempo desde
function getTimeAgo(date) {
    const seconds = Math.floor((new Date() - date) / 1000);
    
    if (seconds < 60) return 'hace unos segundos';
    if (seconds < 3600) return `hace ${Math.floor(seconds / 60)} minutos`;
    if (seconds < 86400) return `hace ${Math.floor(seconds / 3600)} horas`;
    return `hace ${Math.floor(seconds / 86400)} días`;
}

// ============================================
// FUNCIONES DE NOTIFICACIONES
// ============================================

// Mostrar toast
function showToast(title, message, type = 'info') {
    const container = document.getElementById('toastContainer');
    
    if (!container) {
        console.warn('Toast container no encontrado');
        return;
    }
    
    const toast = document.createElement('div');
    toast.className = `toast ${type}`;
    
    const icons = {
        success: 'fa-check-circle',
        error: 'fa-times-circle',
        warning: 'fa-exclamation-triangle',
        info: 'fa-info-circle'
    };
    
    toast.innerHTML = `
        <div class="toast-icon">
            <i class="fas ${icons[type]}"></i>
        </div>
        <div class="toast-content">
            <div class="toast-title">${escapeHtml(title)}</div>
            <div class="toast-message">${escapeHtml(message)}</div>
        </div>
        <button class="toast-close" onclick="this.parentElement.remove()">
            <i class="fas fa-times"></i>
        </button>
    `;
    
    container.appendChild(toast);
    
    setTimeout(() => {
        if (toast.parentNode) toast.remove();
    }, 5000);
}

// ============================================
// FUNCIONES DE ACCIONES RÁPIDAS
// ============================================

// Actualizar todos los servidores
window.refreshServers = function() {
    console.log('🔄 Actualizando servidores...');
    showToast('Actualizando', 'Obteniendo datos de los servidores...', 'info');
    
    setTimeout(() => {
        const servers = JSON.parse(localStorage.getItem('vps_servers') || '[]');
        
        servers.forEach(server => {
            if (server.status === 'active') {
                server.cpu = Math.floor(Math.random() * 60 + 20);
                server.ram = Math.floor(Math.random() * 8 + 4);
                server.disk = Math.floor(Math.random() * 100 + 50);
                server.lastChecked = new Date().toISOString();
            }
        });
        
        localStorage.setItem('vps_servers', JSON.stringify(servers));
        renderServers();
        updateStats();
        
        showToast('Actualizado', 'Datos de servidores actualizados', 'success');
        addActivity('Servidores actualizados manualmente', 'info');
    }, 1500);
}

// Verificar todos los servidores
window.checkAllServers = function() {
    console.log('🔍 Verificando todos los servidores...');
    showToast('Verificando', 'Comprobando estado de todos los servidores...', 'info');
    
    setTimeout(() => {
        const servers = JSON.parse(localStorage.getItem('vps_servers') || '[]');
        const active = servers.filter(s => s.status === 'active').length;
        
        showToast('Verificación completa', `${active} servidores activos de ${servers.length}`, 'success');
        addActivity('Verificación de servidores completada', 'info');
    }, 2000);
}

// Acción masiva
window.bulkAction = function(action) {
    const actions = {
        start: 'iniciar',
        stop: 'detener',
        restart: 'reiniciar'
    };
    
    const actionText = actions[action] || action;
    console.log(`📢 Acción masiva: ${actionText}`);
    
    showToast('Acción masiva', `Se envió comando para ${actionText} todos los servidores`, 'info');
    
    setTimeout(() => {
        const servers = JSON.parse(localStorage.getItem('vps_servers') || '[]');
        
        servers.forEach(server => {
            if (action === 'restart') {
                server.status = 'active';
                server.cpu = Math.floor(Math.random() * 50 + 20);
                server.ram = Math.floor(Math.random() * 8 + 4);
                server.uptime = '0 días';
            } else {
                server.status = action === 'start' ? 'active' : 'stopped';
            }
            server.lastChecked = new Date().toISOString();
        });
        
        localStorage.setItem('vps_servers', JSON.stringify(servers));
        renderServers();
        updateStats();
        
        showToast('Completado', `Todos los servidores ${actionText}dos`, 'success');
        addActivity(`Acción masiva: ${actionText} todos los servidores`, 'info');
    }, 1500);
}

// Exportar servidores
window.exportServers = function() {
    console.log('📤 Exportando servidores...');
    
    const servers = JSON.parse(localStorage.getItem('vps_servers') || '[]');
    
    if (servers.length === 0) {
        showToast('Error', 'No hay servidores para exportar', 'error');
        return;
    }
    
    const dataStr = JSON.stringify(servers, null, 2);
    const dataUri = 'data:application/json;charset=utf-8,'+ encodeURIComponent(dataStr);
    
    const exportFileDefaultName = `servers-${new Date().toISOString().split('T')[0]}.json`;
    
    const linkElement = document.createElement('a');
    linkElement.setAttribute('href', dataUri);
    linkElement.setAttribute('download', exportFileDefaultName);
    linkElement.click();
    
    showToast('Exportado', `${servers.length} servidores exportados`, 'success');
    addActivity('Servidores exportados', 'info');
}

// ============================================
// FUNCIONES DE UTILIDAD
// ============================================

// Escapar HTML
function escapeHtml(text) {
    if (!text) return '';
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
}

// Toggle menú
window.toggleMenu = function() {
    const sidebar = document.getElementById('sidebar');
    const overlay = document.getElementById('overlay');
    
    if (sidebar) {
        sidebar.classList.toggle('active');
        overlay.classList.toggle('active');
        document.body.style.overflow = sidebar.classList.contains('active') ? 'hidden' : '';
    }
}

// Toggle menú de servidor (placeholder)
window.toggleServerMenu = function(serverId) {
    console.log('📌 Menú de servidor:', serverId);
}

// ============================================
// INICIALIZACIÓN
// ============================================

document.addEventListener('DOMContentLoaded', async function() {
    console.log('🚀 Inicializando VPS Panel...');
    console.log('📍 API URL:', API_URL);
    
    // Verificar que los elementos existen
    const required = ['addServerBtn', 'menuToggle', 'overlay', 'serverFilter'];
    required.forEach(id => {
        const el = document.getElementById(id);
        if (!el) console.warn(`⚠️ Elemento no encontrado: #${id}`);
    });
    
    // Cargar servidores
    await loadServers();
    
    // Si no hay servidores, cargar demo
    const servers = JSON.parse(localStorage.getItem('vps_servers') || '[]');
    if (servers.length === 0) {
        console.log('📦 Cargando servidores de demostración...');
        
        const demoServers = [
            {
                id: '1',
                name: 'VPS-Web-01',
                ip: '192.168.1.101',
                port: 22,
                user: 'root',
                password: '****',
                location: 'US-East',
                status: 'active',
                cpu: 45,
                ram: 6.2,
                disk: 120,
                uptime: '15 días',
                os: 'Ubuntu 22.04',
                kernel: '5.15.0',
                cpu_cores: 4,
                ram_total: 8,
                disk_total: 160,
                created: new Date().toISOString(),
                lastChecked: new Date().toISOString()
            },
            {
                id: '2',
                name: 'VPS-DB-01',
                ip: '192.168.1.102',
                port: 22,
                user: 'root',
                password: '****',
                location: 'EU-West',
                status: 'active',
                cpu: 62,
                ram: 10.5,
                disk: 210,
                uptime: '23 días',
                os: 'Ubuntu 22.04',
                kernel: '5.15.0',
                cpu_cores: 8,
                ram_total: 16,
                disk_total: 320,
                created: new Date().toISOString(),
                lastChecked: new Date().toISOString()
            }
        ];
        
        localStorage.setItem('vps_servers', JSON.stringify(demoServers));
        renderServers();
        updateStats();
        
        addActivity('Servidores de demostración cargados', 'info');
    }
    
    // Renderizar actividades
    renderActivities();
    
    // Event listeners
    const menuToggle = document.getElementById('menuToggle');
    if (menuToggle) {
        menuToggle.addEventListener('click', toggleMenu);
    }
    
    const overlay = document.getElementById('overlay');
    if (overlay) {
        overlay.addEventListener('click', function() {
            document.getElementById('sidebar')?.classList.remove('active');
            overlay.classList.remove('active');
            document.body.style.overflow = '';
            closeModal();
        });
    }
    
    const addServerBtn = document.getElementById('addServerBtn');
    if (addServerBtn) {
        addServerBtn.addEventListener('click', openAddServerModal);
    }
    
    const serverFilter = document.getElementById('serverFilter');
    if (serverFilter) {
        serverFilter.addEventListener('change', renderServers);
    }
    
    // Efecto de scroll en header
    let lastScroll = 0;
    const header = document.querySelector('.header');
    
    window.addEventListener('scroll', function() {
        const currentScroll = window.pageYOffset;
        if (header) {
            if (currentScroll > lastScroll && currentScroll > 100) {
                header.style.transform = 'translateY(-100%)';
            } else {
                header.style.transform = 'translateY(0)';
            }
        }
        lastScroll = currentScroll;
    });
    
    // Cerrar con tecla ESC
    document.addEventListener('keydown', function(e) {
        if (e.key === 'Escape') {
            closeModal();
            document.getElementById('sidebar')?.classList.remove('active');
            document.getElementById('overlay')?.classList.remove('active');
            document.body.style.overflow = '';
        }
    });
    
    console.log('✅ VPS Panel inicializado correctamente');
});

// ============================================
// SIMULACIÓN DE DATOS EN TIEMPO REAL
// ============================================

// Actualizar datos cada 30 segundos
setInterval(() => {
    const servers = JSON.parse(localStorage.getItem('vps_servers') || '[]');
    let changed = false;
    
    servers.forEach(server => {
        if (server.status === 'active' && Math.random() > 0.7) {
            server.cpu = Math.floor(Math.random() * 60 + 20);
            server.ram = Math.floor(Math.random() * 8 + 4);
            changed = true;
        }
    });
    
    if (changed) {
        localStorage.setItem('vps_servers', JSON.stringify(servers));
        renderServers();
        updateStats();
    }
}, 30000);

// Agregar actividad aleatoria cada 2 minutos
setInterval(() => {
    const activities = [
        { message: 'Backup automático completado', type: 'success' },
        { message: 'Actualización de seguridad disponible', type: 'info' },
        { message: 'Servidor verificado correctamente', type: 'success' },
        { message: 'Tráfico elevado detectado', type: 'warning' }
    ];
    
    const random = activities[Math.floor(Math.random() * activities.length)];
    addActivity(random.message, random.type);
}, 120000);