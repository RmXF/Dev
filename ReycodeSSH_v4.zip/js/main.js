
// main.js - loader, Lottie init, particles init, AOS trigger
document.addEventListener('DOMContentLoaded', function(){
  // Simulated loader progress for UX
  var progress = 0;
  var bar = document.getElementById('progress-bar');
  var pct = document.getElementById('progress-percent');
  var loader = document.getElementById('loader');
  var main = document.getElementById('main-content');

  function step(){
    progress += Math.floor(Math.random()*10)+5;
    if(progress>100) progress=100;
    if(bar) bar.style.width = progress+'%';
    if(pct) pct.textContent = progress+'%';
    if(progress<100){
      setTimeout(step, 250);
    } else {
      // finish
      setTimeout(function(){
        loader.style.opacity = 0;
        setTimeout(function(){ loader.style.display = 'none'; main.removeAttribute('aria-hidden'); }, 600);
      }, 300);
    }
  }
  step();

  // init particles (simple local)
  if(window.initParticles) window.initParticles();

  // init lottie after small delay
  function startLottie(){
    if(window.lottie){
      try {
        lottie.loadAnimation({
          container: document.getElementById('lottie-container'),
          renderer: 'svg',
          loop: true,
          autoplay: true,
          path: 'lotties/animation.json'
        });
      } catch(e){ console.warn('Lottie failed', e); }
    } else {
      setTimeout(startLottie, 700);
    }
  }
  startLottie();

  // simple AOS-like: add class when in view
  var obs = new IntersectionObserver(function(entries){ entries.forEach(function(e){ if(e.isIntersecting) e.target.classList.add('aos-animated'); }); }, {threshold:0.12});
  document.querySelectorAll('[data-aos]').forEach(function(el){ obs.observe(el); });
});
