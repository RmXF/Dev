// Prueba directa desde consola
async function testDirect() {
  console.log('🔍 Probando conexión directa...');
  
  // Probar archivo simple
  try {
    const response = await fetch('connect_simple.php', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        ip: '192.168.1.1',
        port: 22,
        user: 'root',
        password: 'test'
      })
    });
    
    console.log('📥 Status:', response.status);
    console.log('📥 Status Text:', response.statusText);
    
    const text = await response.text();
    console.log('📄 Respuesta:', text);
    
    try {
      const data = JSON.parse(text);
      console.log('✅ JSON:', data);
    } catch (e) {
      console.error('❌ No es JSON:', text);
    }
    
  } catch (error) {
    console.error('❌ Error:', error);
  }
}

// Ejecutar
testDirect();