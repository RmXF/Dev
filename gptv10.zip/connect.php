<?php
// connect_simple.php - Versión ultra simple para probar
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

// Responder a OPTIONS inmediatamente
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

// Solo aceptar POST
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode([
        'success' => false,
        'error' => 'Método no permitido',
        'method' => $_SERVER['REQUEST_METHOD']
    ]);
    exit();
}

// Obtener datos
$input = json_decode(file_get_contents('php://input'), true);

// Responder siempre con éxito para prueba
echo json_encode([
    'success' => true,
    'message' => 'Conexión simulada exitosa',
    'data' => [
        'ip' => $input['ip'] ?? 'unknown',
        'port' => $input['port'] ?? 22,
        'user' => $input['user'] ?? 'root',
        'hostname' => 'test-server',
        'os' => 'Ubuntu 22.04',
        'kernel' => '5.15.0',
        'uptime' => '10 days',
        'cpu' => 45,
        'ram' => 4,
        'disk' => 80,
        'cpu_cores' => 4,
        'ram_total' => 8,
        'disk_total' => 160
    ]
]);
?>