<?php
// diagnostico.php - Diagnóstico completo del sistema
?>
<!DOCTYPE html>
<html>
<head>
    <title>Diagnóstico VPS Panel</title>
    <style>
        body { font-family: Arial; padding: 20px; background: #1a1a2e; color: #fff; }
        .container { max-width: 800px; margin: 0 auto; }
        .card { background: #16213e; padding: 20px; margin: 10px 0; border-radius: 10px; border-left: 4px solid #6c5ce7; }
        .success { color: #00b894; }
        .error { color: #d63031; }
        .warning { color: #fdcb6e; }
        pre { background: #0f0f1f; padding: 10px; border-radius: 5px; overflow: auto; }
        button { background: #6c5ce7; color: white; border: none; padding: 10px 20px; border-radius: 5px; cursor: pointer; }
        input { padding: 8px; margin: 5px; border-radius: 3px; border: none; }
    </style>
</head>
<body>
    <div class="container">
        <h1>🔍 Diagnóstico VPS Panel</h1>
        
        <div class="card">
            <h2>📋 Información del Servidor</h2>
            <?php
            echo "<p><strong>PHP Version:</strong> " . phpversion() . "</p>";
            echo "<p><strong>Servidor:</strong> " . $_SERVER['SERVER_SOFTWARE'] . "</p>";
            echo "<p><strong>Document Root:</strong> " . $_SERVER['DOCUMENT_ROOT'] . "</p>";
            echo "<p><strong>Directorio actual:</strong> " . __DIR__ . "</p>";
            ?>
        </div>
        
        <div class="card">
            <h2>🔌 Extensiones PHP</h2>
            <?php
            $required = ['json', 'ssh2'];
            foreach ($required as $ext) {
                if (extension_loaded($ext)) {
                    echo "<p class='success'>✅ $ext instalado</p>";
                } else {
                    echo "<p class='error'>❌ $ext NO instalado</p>";
                }
            }
            ?>
        </div>
        
        <div class="card">
            <h2>📁 Permisos de archivos</h2>
            <?php
            $files = ['connect.php', 'save_server.php', 'get_servers.php', 'servers.json'];
            foreach ($files as $file) {
                if (file_exists($file)) {
                    $perms = substr(sprintf('%o', fileperms($file)), -4);
                    $writable = is_writable($file);
                    echo "<p class='" . ($writable ? 'success' : 'error') . "'>";
                    echo ($writable ? '✅' : '❌') . " $file - Permisos: $perms";
                    echo "</p>";
                } else {
                    echo "<p class='error'>❌ $file no existe</p>";
                    if ($file === 'servers.json') {
                        file_put_contents('servers.json', json_encode([]));
                        chmod('servers.json', 0666);
                        echo "<p class='success'>✅ servers.json creado automáticamente</p>";
                    }
                }
            }
            ?>
        </div>
        
        <div class="card">
            <h2>🌐 Prueba de Métodos HTTP</h2>
            <button onclick="testMethod('GET')">Probar GET</button>
            <button onclick="testMethod('POST')">Probar POST</button>
            <button onclick="testMethod('OPTIONS')">Probar OPTIONS</button>
            <div id="result"></div>
        </div>
        
        <div class="card">
            <h2>🔧 Probar Conexión SSH Manual</h2>
            <input type="text" id="test_ip" placeholder="IP" value="192.168.1.1">
            <input type="number" id="test_port" placeholder="Puerto" value="22">
            <input type="text" id="test_user" placeholder="Usuario" value="root">
            <input type="password" id="test_pass" placeholder="Contraseña">
            <button onclick="testSSH()">Probar Conexión SSH</button>
            <div id="sshResult"></div>
        </div>
    </div>
    
    <script>
    async function testMethod(method) {
        const resultDiv = document.getElementById('result');
        resultDiv.innerHTML = 'Probando...';
        
        try {
            const response = await fetch('test_api.php', {
                method: method,
                headers: {
                    'Content-Type': 'application/json'
                },
                body: method === 'POST' ? JSON.stringify({test: 'data'}) : undefined
            });
            
            const text = await response.text();
            let data;
            
            try {
                data = JSON.parse(text);
            } catch {
                data = { error: 'No JSON', text: text.substring(0, 200) };
            }
            
            resultDiv.innerHTML = `
                <p><strong>Status:</strong> ${response.status}</p>
                <p><strong>Status Text:</strong> ${response.statusText}</p>
                <p><strong>Response:</strong></p>
                <pre>${JSON.stringify(data, null, 2)}</pre>
            `;
            
        } catch (error) {
            resultDiv.innerHTML = `<p class='error'>Error: ${error.message}</p>`;
        }
    }
    
    async function testSSH() {
        const ip = document.getElementById('test_ip').value;
        const port = document.getElementById('test_port').value;
        const user = document.getElementById('test_user').value;
        const pass = document.getElementById('test_pass').value;
        
        const resultDiv = document.getElementById('sshResult');
        resultDiv.innerHTML = 'Conectando...';
        
        try {
            const response = await fetch('connect.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    ip: ip,
                    port: parseInt(port),
                    user: user,
                    password: pass
                })
            });
            
            const data = await response.json();
            resultDiv.innerHTML = `<pre>${JSON.stringify(data, null, 2)}</pre>`;
            
        } catch (error) {
            resultDiv.innerHTML = `<p class='error'>Error: ${error.message}</p>`;
        }
    }
    </script>
</body>
</html>