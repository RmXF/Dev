<?php
session_start();
include('config.php');
if(!isset($_SESSION['usuario'])){ header('Location: index.php'); exit(); }
$message='';
if($_SERVER['REQUEST_METHOD']==='POST' && !empty($_POST['url'])){
    $url = $_POST['url'];
    $tmp = sys_get_temp_dir() . DIRECTORY_SEPARATOR . 'panel_update.zip';
    $backup = sys_get_temp_dir() . DIRECTORY_SEPARATOR . 'panel_backup_' . time() . '.zip';
    $data = @file_get_contents($url);
    if($data === false){ $message = 'No se pudo descargar. Verifique la URL.'; }
    else { file_put_contents($tmp, $data); }
    if(!$message && file_exists($tmp) && filesize($tmp) > 100){
        $zip = new ZipArchive();
        if($zip->open($tmp) === true){
            $zipb = new ZipArchive();
            if($zipb->open($backup, ZipArchive::CREATE) === true){
                $root = __DIR__ . DIRECTORY_SEPARATOR;
                $it = new RecursiveIteratorIterator(new RecursiveDirectoryIterator($root, RecursiveDirectoryIterator::SKIP_DOTS));
                foreach($it as $f){
                    $filePath = $f->getRealPath();
                    $local = substr($filePath, strlen($root));
                    if(strpos($local, 'data/')===0) continue;
                    $zipb->addFile($filePath, $local);
                }
                $zipb->close();
            }
            $extract_dir = sys_get_temp_dir() . DIRECTORY_SEPARATOR . 'panel_update_tmp';
            if(is_dir($extract_dir)) { shell_exec('rm -rf ' . escapeshellarg($extract_dir)); }
            mkdir($extract_dir);
            $zip->extractTo($extract_dir);
            $zip->close();
            $it2 = new RecursiveIteratorIterator(new RecursiveDirectoryIterator($extract_dir, RecursiveDirectoryIterator::SKIP_DOTS), RecursiveIteratorIterator::SELF_FIRST);
            foreach($it2 as $item){
                $dest = __DIR__ . DIRECTORY_SEPARATOR . $it2->getSubPathName();
                if($item->isDir()){
                    if(!is_dir($dest)) mkdir($dest, 0755, true);
                } else {
                    copy($item->getPathname(), $dest);
                }
            }
            shell_exec('rm -rf ' . escapeshellarg($extract_dir));
            unlink($tmp);
            $message = 'Actualización completada. Backup en: ' . $backup;
        } else { $message = 'El archivo no es un ZIP válido.'; }
    } else { if(!$message) $message = 'Archivo ZIP inválido o demasiado pequeño.'; }
}
?><!doctype html><html><head><meta charset="utf-8"><title>Actualizar</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="assets/neumorph.css" rel="stylesheet"></head><body class="bg-light">
<div class="container py-4">
  <h3>Actualizar panel</h3>
  <?php if($message): ?><div class="alert alert-info"><?=htmlspecialchars($message)?></div><?php endif; ?>
  <form method="post"><div class="mb-3"><label>URL directa al ZIP</label><input class="form-control" type="url" name="url" placeholder="https://.../panel_v2_update.zip" required></div>
  <div class="d-grid"><button class="btn btn-success">Descargar y actualizar</button></div></form>
  <a href="dashboard.php" class="btn btn-secondary mt-3">Volver</a>
</div>
</body></html>