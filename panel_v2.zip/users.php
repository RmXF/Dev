<?php
session_start();
include('config.php');
if(!isset($_SESSION['usuario'])){ header('Location: index.php'); exit(); }
$users = json_decode(file_get_contents($users_file), true);
if($_SERVER['REQUEST_METHOD']==='POST'){
    if(isset($_POST['add'])){
        $new = ['id'=> time(), 'name'=>$_POST['name'],'email'=>$_POST['email'],'role'=>$_POST['role']];
        $users[] = $new;
        file_put_contents($users_file, json_encode($users, JSON_PRETTY_PRINT));
        header('Location: users.php'); exit();
    } elseif(isset($_POST['delete'])){
        $id = intval($_POST['delete']);
        $users = array_values(array_filter($users, function($u) use ($id){ return $u['id'] !== $id; }));
        file_put_contents($users_file, json_encode($users, JSON_PRETTY_PRINT));
        header('Location: users.php'); exit();
    }
}
?>
<!doctype html><html><head><meta charset="utf-8"><title>Usuarios</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="assets/neumorph.css" rel="stylesheet"></head><body class="bg-light">
<div class="container py-4">
  <h3>Usuarios</h3>
  <div class="card neum p-3 mb-3">
    <form method="post" class="row g-2">
      <div class="col-md-4"><input class="form-control" name="name" placeholder="Nombre" required></div>
      <div class="col-md-4"><input class="form-control" name="email" placeholder="Email" required></div>
      <div class="col-md-2"><select class="form-select" name="role"><option>user</option><option>admin</option></select></div>
      <div class="col-md-2"><button class="btn btn-primary w-100" name="add">Agregar</button></div>
    </form>
  </div>
  <div class="card neum p-3">
    <table class="table">
      <thead><tr><th>Nombre</th><th>Email</th><th>Role</th><th></th></tr></thead>
      <tbody>
      <?php foreach($users as $u): ?>
        <tr><td><?=htmlspecialchars($u['name'])?></td><td><?=htmlspecialchars($u['email'])?></td><td><?=htmlspecialchars($u['role'])?></td>
        <td><form method="post" style="display:inline;"><button class="btn btn-sm btn-danger" name="delete" value="<?= $u['id'] ?>">Eliminar</button></form></td></tr>
      <?php endforeach; ?>
      </tbody>
    </table>
  </div>
  <a href="dashboard.php" class="btn btn-secondary mt-3">Volver</a>
</div>
</body></html>