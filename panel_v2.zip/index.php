<?php
session_start();
include('config.php');
if(isset($_SESSION['usuario'])){ header('Location: dashboard.php'); exit(); }
$error='';
if($_SERVER['REQUEST_METHOD']==='POST'){
    $user = $_POST['usuario'] ?? '';
    $pass = $_POST['contrasena'] ?? '';
    if($user === $usuario_panel && $pass === $contrasena_panel){
        $_SESSION['usuario'] = $user;
        header('Location: dashboard.php');
        exit();
    } else { $error = 'Usuario o contraseña incorrectos'; }
}
?>
<!doctype html><html lang="es"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Login - Panel v2</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="assets/neumorph.css" rel="stylesheet">
</head>
<body class="bg-light">
<div class="container d-flex vh-100 align-items-center justify-content-center">
  <div class="card neum card-shadow" style="max-width:420px;width:100%;border-radius:18px;">
    <div class="card-body">
      <div class="text-center mb-3">
        <img src="assets/logo.svg" alt="Logo" style="width:86px;">
        <h4 class="mt-2">Panel v2 - Neumorphism</h4>
      </div>
      <?php if($error): ?><div class="alert alert-danger"><?=htmlspecialchars($error)?></div><?php endif; ?>
      <form method="post" novalidate>
        <div class="mb-3"><label class="form-label">Usuario</label><input class="form-control" name="usuario" required></div>
        <div class="mb-3"><label class="form-label">Contraseña</label><input type="password" class="form-control" name="contrasena" required></div>
        <div class="d-grid"><button class="btn btn-primary">Ingresar</button></div>
      </form>
    </div>
    <div class="card-footer text-center small text-muted">credenciales: admin / 1234</div>
  </div>
</div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body></html>