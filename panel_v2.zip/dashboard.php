<?php
session_start();
include('config.php');
if(!isset($_SESSION['usuario'])){ header('Location: index.php'); exit(); }
?>
<!doctype html><html lang="es"><head><meta charset="utf-8'><meta name='viewport' content='width=device-width,initial-scale=1'>
<title>Dashboard - Panel v2</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="assets/neumorph.css" rel="stylesheet">
</head>
<body class="bg-light">
<nav class="navbar navbar-expand-lg bg-white neum-nav border-bottom">
  <div class="container-fluid">
    <a class="navbar-brand" href="#">Panel v2</a>
    <div class="d-flex align-items-center">
      <button id="themeToggle" class="btn btn-outline-secondary btn-sm me-2">Modo oscuro</button>
      <div class="dropdown">
        <a class="btn btn-sm btn-secondary dropdown-toggle" href="#" data-bs-toggle="dropdown"><?=htmlspecialchars($_SESSION['usuario'])?></a>
        <ul class="dropdown-menu dropdown-menu-end"><li><a class="dropdown-item" href="logout.php">Cerrar sesión</a></li></ul>
      </div>
    </div>
  </div>
</nav>
<div class="container-fluid">
  <div class="row">
    <aside class="col-12 col-md-3 col-lg-2 p-3 vh-100 sidebar-neu">
      <ul class="nav flex-column">
        <li class="nav-item"><a class="nav-link active" href="dashboard.php">Inicio</a></li>
        <li class="nav-item"><a class="nav-link" href="users.php">Usuarios</a></li>
        <li class="nav-item"><a class="nav-link" href="settings.php">Configuración</a></li>
        <li class="nav-item"><a class="nav-link" href="stats.php">Estadísticas</a></li>
      </ul>
    </aside>
    <main class="col p-4">
      <div class="d-flex justify-content-between align-items-center mb-3">
        <h2>Bienvenido, <?=htmlspecialchars($_SESSION['usuario'])?> 👋</h2>
        <small id="clock" class="text-muted"></small>
      </div>
      <div class="row g-3">
        <div class="col-sm-6 col-lg-3"><div class="card neum card-shadow p-3"><h6>Usuarios</h6><h3>124</h3></div></div>
        <div class="col-sm-6 col-lg-3"><div class="card neum card-shadow p-3"><h6>Sesiones</h6><h3>18</h3></div></div>
        <div class="col-sm-6 col-lg-3"><div class="card neum card-shadow p-3"><h6>Visitas</h6><h3>3,421</h3></div></div>
        <div class="col-sm-6 col-lg-3"><div class="card neum card-shadow p-3"><h6>Estado</h6><h3>Estable</h3></div></div>
      </div>

      <div class="mt-4">
        <h5>Actualización rápida</h5>
        <p>Pega la URL directa al ZIP y actualiza el panel automáticamente.</p>
        <form method="post" action="update.php" class="row g-2">
          <div class="col-md-8"><input type="url" name="url" placeholder="https://tu-dominio.com/panel_v2_update.zip" class="form-control" required></div>
          <div class="col-md-4"><button class="btn btn-success w-100">Actualizar</button></div>
        </form>
      </div>

    </main>
  </div>
</div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
<script src="assets/neumorph.js"></script>
</body></html>