<?php
$usuario_panel = "admin";
$contrasena_panel = "1234";
$panel_dir = __DIR__;
$users_file = __DIR__ . '/data/users.json';
if(!file_exists(dirname($users_file))){ mkdir(dirname($users_file), 0755, true); }
if(!file_exists($users_file)){ file_put_contents($users_file, json_encode([{"id":1,"name":"Admin","email":"admin@local","role":"admin"}], JSON_PRETTY_PRINT)); }
?>