# Instalación de CEOSSH

## Requisitos

- VPS limpio con Debian/Ubuntu o RHEL/CentOS
- Acceso root
- Puertos 22/80 disponibles

## Pasos

1. Subir el `install.sh` al servidor:
   ```bash
   scp install.sh root@TU_IP:/root/