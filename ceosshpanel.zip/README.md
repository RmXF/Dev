# CEOSSH

Panel web de gestión de usuarios SSH sobre VPS.

## Instalación

```bash
sudo bash install.sh