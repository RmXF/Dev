<?php
session_name('ceossh_sess');
session_start();

require_once '/opt/ceossh/config/config.php';

if (empty($_SESSION['admin'])) {
    header('Location: index.php');
    exit;
}

// Conexión y conteos
try {
    $pdo = new PDO(
        'mysql:host=' . DB_HOST . ';dbname=' . DB_NAME . ';charset=utf8mb4',
        DB_USER, DB_PASS,
        [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]
    );

    // Contadores (con fallback si las tablas aún no existen)
    $safe_count = function ($sql) use ($pdo) {
        try { return (int) $pdo->query($sql)->fetchColumn(); }
        catch (Throwable $e) { return 0; }
    };

    $total_users    = $safe_count("SELECT COUNT(*) FROM ssh_users");
    $total_vps      = $safe_count("SELECT COUNT(*) FROM vps");
    $total_expired  = $safe_count("SELECT COUNT(*) FROM ssh_users WHERE status='expired' OR expires_at < NOW()");
    $total_groups   = $safe_count("SELECT COUNT(*) FROM vps_groups");
    $total_active   = $safe_count("SELECT COUNT(*) FROM ssh_users WHERE status='active' AND expires_at >= NOW()");
} catch (Throwable $e) {
    die('Error de conexión con la base de datos: ' . $e->getMessage());
}
?>
<!DOCTYPE html>
<html lang="es" data-theme="dark">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>CEOSSH — Dashboard</title>
    <link rel="stylesheet" href="assets/css/main.css">
    <link rel="stylesheet" href="assets/css/dashboard.css">
</head>
<body>

<!-- ============ HEADER ============ -->
<header class="topnav">
    <div class="brand">
        <span class="brand-logo">CEOSSH</span>
    </div>

    <nav class="main-nav">
        <a href="#" class="nav-item active">Inicio</a>
        <a href="#" class="nav-item">Usuarios</a>
        <a href="#" class="nav-item">VPS</a>
        <a href="#" class="nav-item">Grupos</a>
    </nav>

    <div class="nav-actions">
        <button class="icon-btn" id="demoBtn" title="Generar demo">
            <span class="icon">👤</span><span class="icon-clock">⏱</span>
        </button>

        <button class="icon-btn" id="themeToggle" title="Cambiar tema">
            <span class="theme-icon">🌙</span>
        </button>

        <div class="user-chip">
            <span class="user-avatar"><?= strtoupper(substr($_SESSION['admin'], 0, 1)) ?></span>
            <span class="user-name"><?= htmlspecialchars($_SESSION['admin']) ?></span>
        </div>

        <a href="logout.php" class="logout-btn">Salir</a>
    </div>
</header>

<!-- ============ MAIN ============ -->
<main class="dashboard">

    <div class="page-title">
        <h1>Panel de Control</h1>
        <p class="muted">Resumen general del sistema CEOSSH</p>
    </div>

    <!-- CARDS -->
    <section class="cards-grid">

        <div class="card card-users">
            <div class="card-icon">👥</div>
            <div class="card-info">
                <div class="card-value"><?= number_format($total_users) ?></div>
                <div class="card-label">Usuarios Registrados</div>
            </div>
            <div class="card-glow"></div>
        </div>

        <div class="card card-vps">
            <div class="card-icon">🖥️</div>
            <div class="card-info">
                <div class="card-value"><?= number_format($total_vps) ?></div>
                <div class="card-label">VPS Registradas</div>
            </div>
            <div class="card-glow"></div>
        </div>

        <div class="card card-expired">
            <div class="card-icon">⛔</div>
            <div class="card-info">
                <div class="card-value"><?= number_format($total_expired) ?></div>
                <div class="card-label">Usuarios Vencidos</div>
            </div>
            <div class="card-glow"></div>
        </div>

        <div class="card card-active">
            <div class="card-icon">✅</div>
            <div class="card-info">
                <div class="card-value"><?= number_format($total_active) ?></div>
                <div class="card-label">Usuarios Activos</div>
            </div>
            <div class="card-glow"></div>
        </div>

        <div class="card card-groups">
            <div class="card-icon">📁</div>
            <div class="card-info">
                <div class="card-value"><?= number_format($total_groups) ?></div>
                <div class="card-label">Grupos</div>
            </div>
            <div class="card-glow"></div>
        </div>

    </section>

    <!-- SECCIÓN EXTRA: accesos rápidos -->
    <section class="quick-actions">
        <h2>Accesos Rápidos</h2>
        <div class="quick-grid">
            <a href="#" class="quick-item">
                <span class="quick-icon">➕</span>
                <span>Agregar Usuario</span>
            </a>
            <a href="#" class="quick-item">
                <span class="quick-icon">➕</span>
                <span>Agregar VPS</span>
            </a>
            <a href="#" class="quick-item">
                <span class="quick-icon">📋</span>
                <span>Listar Usuarios</span>
            </a>
            <a href="#" class="quick-item">
                <span class="quick-icon">🎁</span>
                <span>Generar Demo</span>
            </a>
        </div>
    </section>

</main>

<!-- ============ MODAL DEMO (placeholder) ============ -->
<div class="modal-overlay" id="demoModal">
    <div class="modal">
        <div class="modal-header">
            <h3>Generar Demo</h3>
            <button class="modal-close" data-close>&times;</button>
        </div>
        <div class="modal-body">
            <p class="muted">Próximamente — se integrará con la API de demos.</p>
        </div>
        <div class="modal-footer">
            <button class="btn-secondary" data-close>Cerrar</button>
        </div>
    </div>
</div>

<script src="assets/js/theme.js"></script>
<script src="assets/js/dashboard.js"></script>
</body>
</html>