<?php
session_name('ceossh_sess');
session_start();
require_once __DIR__ . '/../config/config.php';

if (empty($_SESSION['admin'])) {
    header('Location: index.php');
    exit;
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>CEOSSH — Dashboard</title>
    <link rel="stylesheet" href="assets/css/main.css">
</head>
<body>
    <h1>Bienvenido, <?= htmlspecialchars($_SESSION['admin']) ?></h1>
    <p>Panel en construcción. Aquí irán las secciones de gestión.</p>
    <a href="logout.php">Cerrar sesión</a>
</body>
</html>