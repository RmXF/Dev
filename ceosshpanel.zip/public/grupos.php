<?php
session_name('ceossh_sess');
session_start();

require_once '/opt/ceossh/config/config.php';

if (empty($_SESSION['admin'])) {
    header('Location: index.php');
    exit;
}

try {
    $pdo = new PDO(
        'mysql:host=' . DB_HOST . ';dbname=' . DB_NAME . ';charset=utf8mb4',
        DB_USER, DB_PASS,
        [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]
    );

    // Listar grupos con conteo de VPS y usuarios
    $groups = $pdo->query("
        SELECT g.*,
            (SELECT COUNT(*) FROM vps v WHERE v.group_id = g.id) AS vps_count,
            (SELECT COUNT(*) FROM ssh_users u WHERE u.group_id = g.id) AS users_count
        FROM vps_groups g
        ORDER BY g.created_at DESC
    ")->fetchAll(PDO::FETCH_ASSOC);
} catch (Throwable $e) {
    die('Error de conexión: ' . $e->getMessage());
}
?>
<!DOCTYPE html>
<html lang="es" data-theme="dark">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>CEOSSH — Grupos</title>

    <script>
    (function () {
        const t = localStorage.getItem('ceossh_theme');
        const prefersDark = window.matchMedia('(prefers-color-scheme: dark)').matches;
        document.documentElement.setAttribute('data-theme', t || (prefersDark ? 'dark' : 'light'));
    })();
    </script>

    <link rel="stylesheet" href="assets/css/main.css">
    <link rel="stylesheet" href="assets/css/dashboard.css">
    <link rel="stylesheet" href="assets/css/sidebar.css">
    <link rel="stylesheet" href="assets/css/grupos.css">
</head>
<body>

<?php require __DIR__ . '/partials/sidebar.php'; ?>

<div class="sidebar-overlay" id="sidebarOverlay"></div>

<?php require __DIR__ . '/partials/header.php'; ?>

<main class="dashboard">

    <div class="page-title">
        <h1>Grupos</h1>
        <p class="muted">Agrupa VPS y usuarios para asignarlos en bloque</p>
    </div>

    <div class="grupos-actions">
        <button class="btn-primary" id="openAddGroup">
            <span>➕</span> Nuevo Grupo
        </button>
        <button class="btn-secondary" id="refreshGroups">
            <span>🔄</span> Refrescar
        </button>
    </div>

    <section class="grupos-grid" id="gruposGrid">
        <?php if (empty($groups)): ?>
            <div class="empty-state" id="emptyState">
                <div class="empty-icon">📁</div>
                <h3>No hay grupos creados</h3>
                <p class="muted">Crea tu primer grupo para organizar tus VPS y usuarios.</p>
            </div>
        <?php else: ?>
            <?php foreach ($groups as $g): ?>
                <div class="group-card" data-id="<?= (int)$g['id'] ?>">
                    <div class="group-header">
                        <div class="group-icon">📁</div>
                        <div class="group-info">
                            <h3><?= htmlspecialchars($g['name']) ?></h3>
                            <?php if ($g['description']): ?>
                                <p class="group-desc"><?= htmlspecialchars($g['description']) ?></p>
                            <?php endif; ?>
                        </div>
                        <div class="group-actions">
                            <button class="icon-action edit"   data-id="<?= (int)$g['id'] ?>" title="Editar">✏️</button>
                            <button class="icon-action delete" data-id="<?= (int)$g['id'] ?>" title="Eliminar">🗑</button>
                        </div>
                    </div>

                    <div class="group-stats">
                        <div class="stat">
                            <span class="stat-value"><?= (int)$g['vps_count'] ?></span>
                            <span class="stat-label">VPS</span>
                        </div>
                        <div class="stat">
                            <span class="stat-value"><?= (int)$g['users_count'] ?></span>
                            <span class="stat-label">Usuarios</span>
                        </div>
                    </div>

                    <div class="group-footer">
                        <span class="muted">Creado: <?= htmlspecialchars($g['created_at']) ?></span>
                    </div>
                </div>
            <?php endforeach; ?>
        <?php endif; ?>
    </section>

</main>

<!-- ============ MODAL: Agregar/Editar Grupo ============ -->
<div class="modal-overlay" id="groupModal">
    <div class="modal">
        <div class="modal-header">
            <h3 id="groupModalTitle">Nuevo Grupo</h3>
            <button class="modal-close" data-close>&times;</button>
        </div>

        <form id="groupForm" class="modal-body">
            <input type="hidden" name="id" id="g-id">

            <label class="field">
                <span>Nombre del grupo</span>
                <input type="text" name="name" id="g-name" placeholder="Ej: Venezuela, Premium, etc." required>
            </label>

            <label class="field">
                <span>Descripción (opcional)</span>
                <input type="text" name="description" id="g-description" placeholder="Breve descripción del grupo">
            </label>

            <div class="modal-feedback" id="groupFeedback"></div>
        </form>

        <div class="modal-footer">
            <button class="btn-secondary" data-close>Cancelar</button>
            <button class="btn-primary" id="groupSubmit">Guardar</button>
        </div>
    </div>
</div>

<script src="assets/js/sidebar.js"></script>
<script src="assets/js/theme.js"></script>
<script src="assets/js/grupos.js"></script>
</body>
</html>