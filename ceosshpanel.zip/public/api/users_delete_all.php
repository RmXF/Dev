<?php
/**
 * CEOSSH - Eliminar usuario SSH
 * Borra de la BD Y propaga a todas las VPS del grupo (mata sesiones activas)
 */
session_name('ceossh_sess');
session_start();
require_once '/opt/ceossh/config/config.php';
require_once '/opt/ceossh/app/SshManager.php';
require_once '/opt/ceossh/app/VpsHelper.php';
header('Content-Type: application/json');

if (empty($_SESSION['admin'])) {
    http_response_code(401);
    echo json_encode(['ok' => false, 'msg' => 'No autorizado']); exit;
}

$in = json_decode(file_get_contents('php://input'), true) ?: [];
$id = (int)($in['id'] ?? 0);
if ($id <= 0) { echo json_encode(['ok' => false, 'msg' => 'ID inválido']); exit; }

try {
    $pdo = new PDO(
        'mysql:host=' . DB_HOST . ';dbname=' . DB_NAME . ';charset=utf8mb4',
        DB_USER, DB_PASS,
        [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]
    );

    // 1. Obtener el usuario
    $stmt = $pdo->prepare("SELECT username, group_id FROM ssh_users WHERE id = ?");
    $stmt->execute([$id]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$user) {
        echo json_encode(['ok' => false, 'msg' => 'Usuario no encontrado']); exit;
    }

    $username = $user['username'];

    // 2. Propagar eliminación a todas las VPS del grupo
    $propagation = [
        'total'   => 0,
        'ok'      => 0,
        'failed'  => 0,
        'details' => [],
    ];

    if ($user['group_id']) {
        $vpsList = VpsHelper::getVpsByGroup($pdo, (int)$user['group_id']);
        $propagation['total'] = count($vpsList);

        foreach ($vpsList as $vps) {
            $result = SshManager::deleteUser($vps, $username);

            if ($result['ok']) {
                $propagation['ok']++;
                $propagation['details'][] = [
                    'vps'    => $vps['name'],
                    'status' => 'ok',
                    'msg'    => 'Usuario eliminado y sesiones cortadas',
                ];
            } else {
                $propagation['failed']++;
                $propagation['details'][] = [
                    'vps'    => $vps['name'],
                    'status' => 'error',
                    'msg'    => $result['error'] ?: 'No se pudo conectar',
                ];

                // Loguear el error
                @file_put_contents(
                    '/opt/ceossh/storage/logs/delete_errors.log',
                    date('Y-m-d H:i:s') . " - VPS: {$vps['name']} - User: $username - Error: {$result['error']}\n",
                    FILE_APPEND
                );
            }
        }
    }

    // 3. Eliminar de la BD SIEMPRE (aunque alguna VPS falle)
    $pdo->prepare("DELETE FROM ssh_users WHERE id = ?")->execute([$id]);

    // 4. Respuesta
    $msg = "Usuario '$username' eliminado";
    if ($propagation['total'] > 0) {
        $msg .= " — {$propagation['ok']}/{$propagation['total']} VPS actualizadas";
        if ($propagation['failed'] > 0) {
            $msg .= " ({$propagation['failed']} fallaron)";
        }
    } else {
        $msg .= " (sin grupo asignado, no se propagó a VPS)";
    }

    echo json_encode([
        'ok' => true,
        'msg' => $msg,
        'propagation' => $propagation,
    ]);

} catch (Throwable $e) {
    echo json_encode(['ok' => false, 'msg' => $e->getMessage()]);
}