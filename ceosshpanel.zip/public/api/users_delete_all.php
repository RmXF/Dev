<?php
session_name('ceossh_sess');
session_start();
require_once '/opt/ceossh/config/config.php';
header('Content-Type: application/json');

if (empty($_SESSION['admin'])) {
    http_response_code(401);
    echo json_encode(['ok' => false, 'msg' => 'No autorizado']); exit;
}

try {
    $pdo = new PDO(
        'mysql:host=' . DB_HOST . ';dbname=' . DB_NAME . ';charset=utf8mb4',
        DB_USER, DB_PASS,
        [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]
    );

    $users = $pdo->query("SELECT username FROM ssh_users")->fetchAll(PDO::FETCH_COLUMN);

    foreach ($users as $u) {
        $cmd = escapeshellcmd("/opt/ceossh/scripts/delete_ssh_user.sh " . escapeshellarg($u));
        @shell_exec("sudo $cmd 2>&1");
    }

    $pdo->exec("DELETE FROM ssh_users");

    echo json_encode(['ok' => true, 'deleted' => count($users)]);
} catch (Throwable $e) {
    echo json_encode(['ok' => false, 'msg' => $e->getMessage()]);
}