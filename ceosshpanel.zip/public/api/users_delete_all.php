<?php
session_name('ceossh_sess');
session_start();
require_once '/opt/ceossh/config/config.php';
require_once '/opt/ceossh/app/SshManager.php';
require_once '/opt/ceossh/app/VpsHelper.php';
header('Content-Type: application/json');

if (empty($_SESSION['admin'])) {
    http_response_code(401);
    echo json_encode(['ok' => false, 'msg' => 'No autorizado']); exit;
}

try {
    $pdo = new PDO(
        'mysql:host=' . DB_HOST . ';dbname=' . DB_NAME . ';charset=utf8mb4',
        DB_USER, DB_PASS,
        [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]
    );

    $users = $pdo->query("SELECT username, group_id FROM ssh_users")->fetchAll(PDO::FETCH_ASSOC);

    $totalSSH = 0;
    $okSSH = 0;

    foreach ($users as $u) {
        if (!$u['group_id']) continue;

        $vpsList = VpsHelper::getVpsByGroup($pdo, (int)$u['group_id']);
        foreach ($vpsList as $vps) {
            $totalSSH++;
            $res = SshManager::deleteUser($vps, $u['username']);
            if ($res['ok']) $okSSH++;
        }
    }

    $count = count($users);
    $pdo->exec("DELETE FROM ssh_users");

    echo json_encode([
        'ok' => true,
        'deleted' => $count,
        'ssh_deleted' => $okSSH,
        'ssh_total' => $totalSSH,
        'msg' => "Se eliminaron $count usuarios en BD ($okSSH/$totalSSH en VPS)"
    ]);
} catch (Throwable $e) {
    echo json_encode(['ok' => false, 'msg' => $e->getMessage()]);
}