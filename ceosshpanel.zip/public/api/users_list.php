<?php
session_name('ceossh_sess');
session_start();
require_once '/opt/ceossh/config/config.php';
header('Content-Type: application/json');

if (empty($_SESSION['admin'])) {
    http_response_code(401);
    echo json_encode(['ok' => false, 'msg' => 'No autorizado']); exit;
}

$filter = $_GET['filter'] ?? 'all';

try {
    $pdo = new PDO(
        'mysql:host=' . DB_HOST . ';dbname=' . DB_NAME . ';charset=utf8mb4',
        DB_USER, DB_PASS,
        [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]
    );

    $sql = "
        SELECT u.*, g.name AS group_name
        FROM ssh_users u
        LEFT JOIN vps_groups g ON g.id = u.group_id
    ";

    if ($filter === 'expired') {
        $sql .= " WHERE u.status = 'expired' OR u.expires_at < NOW()";
    }

    $sql .= " ORDER BY u.created_at DESC";

    $users = $pdo->query($sql)->fetchAll(PDO::FETCH_ASSOC);

    // Descifrar contraseñas (base64) y formatear
    foreach ($users as &$u) {
        $u['password_plain'] = $u['password'] ? base64_decode($u['password']) : '';
        // Eliminar el password encriptado del output
        unset($u['password']);

        // Auto-actualizar status
        if ($u['status'] === 'active' && strtotime($u['expires_at']) < time()) {
            $u['status'] = 'expired';
        }
    }

    echo json_encode(['ok' => true, 'users' => $users]);
} catch (Throwable $e) {
    echo json_encode(['ok' => false, 'msg' => $e->getMessage()]);
}