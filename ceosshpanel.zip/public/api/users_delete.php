<?php
session_name('ceossh_sess');
session_start();
require_once '/opt/ceossh/config/config.php';
header('Content-Type: application/json');

if (empty($_SESSION['admin'])) {
    http_response_code(401);
    echo json_encode(['ok' => false, 'msg' => 'No autorizado']); exit;
}

$in = json_decode(file_get_contents('php://input'), true) ?: [];
$id = (int)($in['id'] ?? 0);
if ($id <= 0) { echo json_encode(['ok' => false, 'msg' => 'ID inválido']); exit; }

try {
    $pdo = new PDO(
        'mysql:host=' . DB_HOST . ';dbname=' . DB_NAME . ';charset=utf8mb4',
        DB_USER, DB_PASS,
        [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]
    );

    $stmt = $pdo->prepare("SELECT username FROM ssh_users WHERE id = ?");
    $stmt->execute([$id]);
    $username = $stmt->fetchColumn();

    if (!$username) { echo json_encode(['ok' => false, 'msg' => 'Usuario no encontrado']); exit; }

    // Eliminar del sistema operativo
    $cmd = escapeshellcmd("/opt/ceossh/scripts/delete_ssh_user.sh " . escapeshellarg($username));
    @shell_exec("sudo $cmd 2>&1");

    // Eliminar de BD
    $pdo->prepare("DELETE FROM ssh_users WHERE id = ?")->execute([$id]);

    echo json_encode(['ok' => true, 'msg' => 'Usuario eliminado']);
} catch (Throwable $e) {
    echo json_encode(['ok' => false, 'msg' => $e->getMessage()]);
}