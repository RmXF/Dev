<?php
session_name('ceossh_sess');
session_start();
require_once '/opt/ceossh/config/config.php';
require_once '/opt/ceossh/app/SshManager.php';
header('Content-Type: application/json');

if (empty($_SESSION['admin'])) {
    http_response_code(401);
    echo json_encode(['ok' => false, 'msg' => 'No autorizado']); exit;
}

$id = (int)($_GET['id'] ?? 0);
if ($id <= 0) { echo json_encode(['ok' => false, 'msg' => 'ID inválido']); exit; }

try {
    $pdo = new PDO(
        'mysql:host=' . DB_HOST . ';dbname=' . DB_NAME . ';charset=utf8mb4',
        DB_USER, DB_PASS,
        [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]
    );

    $stmt = $pdo->prepare("SELECT * FROM vps WHERE id = ?");
    $stmt->execute([$id]);
    $vps = $stmt->fetch(PDO::FETCH_ASSOC);
    if (!$vps) { echo json_encode(['ok' => false, 'msg' => 'VPS no encontrada']); exit; }

    // Listar usuarios reales (UID >= 1000, sin nobody/nogroup)
    $result = SshManager::exec($vps, "awk -F: '\$3 >= 1000 && \$3 < 65534 {print \$1}' /etc/passwd");

    if (!$result['ok']) {
        echo json_encode(['ok' => false, 'msg' => 'Error SSH: ' . $result['error']]); exit;
    }

    $users = array_filter(explode("\n", trim($result['output'])));

    echo json_encode(['ok' => true, 'users' => array_values($users)]);
} catch (Throwable $e) {
    echo json_encode(['ok' => false, 'msg' => $e->getMessage()]);
}