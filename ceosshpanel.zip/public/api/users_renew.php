<?php
session_name('ceossh_sess');
session_start();
require_once '/opt/ceossh/config/config.php';
header('Content-Type: application/json');

if (empty($_SESSION['admin'])) {
    http_response_code(401);
    echo json_encode(['ok' => false, 'msg' => 'No autorizado']); exit;
}

$in = json_decode(file_get_contents('php://input'), true) ?: [];
$id   = (int)($in['id'] ?? 0);
$days = max(1, (int)($in['days'] ?? 30));

if ($id <= 0) { echo json_encode(['ok' => false, 'msg' => 'ID inválido']); exit; }

try {
    $pdo = new PDO(
        'mysql:host=' . DB_HOST . ';dbname=' . DB_NAME . ';charset=utf8mb4',
        DB_USER, DB_PASS,
        [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]
    );

    $stmt = $pdo->prepare("SELECT username FROM ssh_users WHERE id = ?");
    $stmt->execute([$id]);
    $username = $stmt->fetchColumn();

    if (!$username) { echo json_encode(['ok' => false, 'msg' => 'Usuario no encontrado']); exit; }

    $expires_at = date('Y-m-d H:i:s', strtotime("+$days days"));

    $pdo->prepare("UPDATE ssh_users SET expires_at = ?, status = 'active' WHERE id = ?")
        ->execute([$expires_at, $id]);

    // Actualizar en el SO
    $cmd = escapeshellcmd("/opt/ceossh/scripts/renew_ssh_user.sh " .
        escapeshellarg($username) . " " . escapeshellarg($days));
    @shell_exec("sudo $cmd 2>&1");

    echo json_encode(['ok' => true, 'expires_at' => $expires_at]);
} catch (Throwable $e) {
    echo json_encode(['ok' => false, 'msg' => $e->getMessage()]);
}