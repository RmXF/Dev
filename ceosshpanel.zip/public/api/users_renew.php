$stmt = $pdo->prepare("SELECT username FROM ssh_users WHERE id = ?");
