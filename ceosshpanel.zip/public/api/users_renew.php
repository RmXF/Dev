<?php
/**
 * CEOSSH - Renovar usuario SSH (o eliminar si days <= 0)
 */
session_name('ceossh_sess');
session_start();
require_once '/opt/ceossh/config/config.php';
require_once '/opt/ceossh/app/SshManager.php';
require_once '/opt/ceossh/app/VpsHelper.php';
header('Content-Type: application/json');

if (empty($_SESSION['admin'])) {
    http_response_code(401);
    echo json_encode(['ok' => false, 'msg' => 'No autorizado']); exit;
}

$in = json_decode(file_get_contents('php://input'), true) ?: [];
$id   = (int)($in['id'] ?? 0);
$days = (int)($in['days'] ?? 30);

if ($id <= 0) { echo json_encode(['ok' => false, 'msg' => 'ID inválido']); exit; }

try {
    $pdo = new PDO(
        'mysql:host=' . DB_HOST . ';dbname=' . DB_NAME . ';charset=utf8mb4',
        DB_USER, DB_PASS,
        [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]
    );

    $stmt = $pdo->prepare("SELECT username, group_id FROM ssh_users WHERE id = ?");
    $stmt->execute([$id]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);
    if (!$user) { echo json_encode(['ok' => false, 'msg' => 'Usuario no encontrado']); exit; }

    $username = $user['username'];

    // Si days <= 0 → eliminar en vez de renovar
    if ($days <= 0) {
        // Forzar expiración inmediata
        $pdo->prepare("UPDATE ssh_users SET expires_at = NOW(), status = 'expired' WHERE id = ?")
            ->execute([$id]);

        // Propagar eliminación a VPS
        $propagation = ['total' => 0, 'ok' => 0, 'failed' => 0, 'details' => []];
        if ($user['group_id']) {
            $vpsList = VpsHelper::getVpsByGroup($pdo, (int)$user['group_id']);
            $propagation['total'] = count($vpsList);

            foreach ($vpsList as $vps) {
                $res = SshManager::deleteUser($vps, $username);
                if ($res['ok']) {
                    $propagation['ok']++;
                    $propagation['details'][] = [
                        'vps' => $vps['name'], 'status' => 'ok',
                    ];
                } else {
                    $propagation['failed']++;
                    $propagation['details'][] = [
                        'vps' => $vps['name'], 'status' => 'error',
                        'msg' => $res['error'] ?: 'Error desconocido',
                    ];
                }
            }
        }

        // Eliminar de la BD
        $pdo->prepare("DELETE FROM ssh_users WHERE id = ?")->execute([$id]);

        echo json_encode([
            'ok' => true,
            'msg' => "Usuario '$username' eliminado (días = 0)",
            'propagation' => $propagation,
            'deleted' => true,
        ]);
        exit;
    }

    // Renovación normal
    $expires_at = date('Y-m-d H:i:s', strtotime("+$days days"));

    $pdo->prepare("UPDATE ssh_users SET expires_at = ?, status = 'active' WHERE id = ?")
        ->execute([$expires_at, $id]);

    // Propagar renovación a las VPS del grupo
    $propagation = ['total' => 0, 'ok' => 0, 'failed' => 0, 'details' => []];
    if ($user['group_id']) {
        $vpsList = VpsHelper::getVpsByGroup($pdo, (int)$user['group_id']);
        $propagation['total'] = count($vpsList);

        foreach ($vpsList as $vps) {
            $res = SshManager::renewUser($vps, $username, $days);
            if ($res['ok']) {
                $propagation['ok']++;
                $propagation['details'][] = [
                    'vps' => $vps['name'], 'status' => 'ok',
                ];
            } else {
                $propagation['failed']++;
                $propagation['details'][] = [
                    'vps' => $vps['name'], 'status' => 'error',
                    'msg' => $res['error'] ?: 'Error desconocido',
                ];
            }
        }
    }

    $msg = "Renovado hasta $expires_at";
    if ($propagation['total'] > 0) {
        $msg .= " — actualizado en {$propagation['ok']}/{$propagation['total']} VPS";
        if ($propagation['failed'] > 0) {
            $msg .= " ({$propagation['failed']} fallaron)";
        }
    }

    echo json_encode([
        'ok' => true,
        'expires_at' => $expires_at,
        'msg' => $msg,
        'propagation' => $propagation,
    ]);

} catch (Throwable $e) {
    echo json_encode(['ok' => false, 'msg' => $e->getMessage()]);
}