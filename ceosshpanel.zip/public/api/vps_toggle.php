<?php
session_name('ceossh_sess');
session_start();
require_once '/opt/ceossh/config/config.php';
header('Content-Type: application/json');

if (empty($_SESSION['admin'])) {
    http_response_code(401);
    echo json_encode(['ok' => false, 'msg' => 'No autorizado']); exit;
}

$in = json_decode(file_get_contents('php://input'), true) ?: [];
$id = (int)($in['id'] ?? 0);
if ($id <= 0) { echo json_encode(['ok' => false, 'msg' => 'ID inválido']); exit; }

try {
    $pdo = new PDO(
        'mysql:host=' . DB_HOST . ';dbname=' . DB_NAME . ';charset=utf8mb4',
        DB_USER, DB_PASS,
        [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]
    );
    $stmt = $pdo->prepare("SELECT status FROM vps WHERE id=?");
    $stmt->execute([$id]);
    $cur = $stmt->fetchColumn();

    if ($cur === false) { echo json_encode(['ok' => false, 'msg' => 'VPS no encontrada']); exit; }

    $new = $cur === 'active' ? 'disabled' : 'active';
    $pdo->prepare("UPDATE vps SET status=? WHERE id=?")->execute([$new, $id]);

    echo json_encode(['ok' => true, 'status' => $new]);
} catch (Throwable $e) {
    echo json_encode(['ok' => false, 'msg' => $e->getMessage()]);
}