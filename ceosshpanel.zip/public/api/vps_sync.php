<?php
/**
 * CEOSSH - Sincronizar usuarios activos del grupo a todas las VPS del grupo
 * Se usa cuando agregas una VPS nueva a un grupo ya existente.
 */
session_name('ceossh_sess');
session_start();
require_once '/opt/ceossh/config/config.php';
require_once '/opt/ceossh/app/SshManager.php';
require_once '/opt/ceossh/app/VpsHelper.php';
header('Content-Type: application/json');

if (empty($_SESSION['admin'])) {
    http_response_code(401);
    echo json_encode(['ok' => false, 'msg' => 'No autorizado']); exit;
}

$in = json_decode(file_get_contents('php://input'), true) ?: [];
$vpsId = (int)($in['vps_id'] ?? 0);

if ($vpsId <= 0) {
    echo json_encode(['ok' => false, 'msg' => 'ID de VPS inválido']); exit;
}

try {
    $pdo = new PDO(
        'mysql:host=' . DB_HOST . ';dbname=' . DB_NAME . ';charset=utf8mb4',
        DB_USER, DB_PASS,
        [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]
    );

    // 1. Cargar la VPS
    $stmt = $pdo->prepare("SELECT * FROM vps WHERE id = ?");
    $stmt->execute([$vpsId]);
    $vps = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$vps) {
        echo json_encode(['ok' => false, 'msg' => 'VPS no encontrada']); exit;
    }

    if (empty($vps['group_id'])) {
        echo json_encode(['ok' => false, 'msg' => 'Esta VPS no tiene grupo asignado']); exit;
    }

    if ($vps['status'] !== 'active') {
        echo json_encode(['ok' => false, 'msg' => 'Esta VPS está deshabilitada']); exit;
    }

    // 2. Probar conexión SSH primero
    $test = SshManager::testConnection($vps);
    if (!$test['ok']) {
        // Marcar como disabled si no responde
        $pdo->prepare("UPDATE vps SET status='disabled' WHERE id=?")->execute([$vpsId]);
        echo json_encode([
            'ok' => false,
            'msg' => 'Sin conexión SSH: ' . ($test['error'] ?: 'VPS no responde'),
        ]); exit;
    }

    // 3. Obtener todos los usuarios activos del grupo
    $stmt = $pdo->prepare("
        SELECT id, username, password, connection_limit, expires_at
        FROM ssh_users
        WHERE group_id = ?
          AND status = 'active'
          AND expires_at > NOW()
    ");
    $stmt->execute([(int)$vps['group_id']]);
    $users = $stmt->fetchAll(PDO::FETCH_ASSOC);

    if (empty($users)) {
        echo json_encode([
            'ok' => true,
            'msg' => 'El grupo no tiene usuarios activos para sincronizar',
            'synced' => 0,
            'failed' => 0,
            'total' => 0,
        ]); exit;
    }

    // 4. Propagar cada usuario a esta VPS
    $synced = 0;
    $failed = 0;
    $details = [];

    foreach ($users as $u) {
        $password = base64_decode($u['password']);

        // Días restantes hasta el vencimiento
        $diff = strtotime($u['expires_at']) - time();
        $days = max(1, (int) ceil($diff / 86400));

        $result = SshManager::createUser(
            $vps,
            $u['username'],
            $password,
            $days,
            (int)$u['connection_limit']
        );

        if ($result['ok']) {
            $synced++;
            $details[] = [
                'username' => $u['username'],
                'status'   => 'ok',
                'days'     => $days,
            ];
        } else {
            $failed++;
            $details[] = [
                'username' => $u['username'],
                'status'   => 'error',
                'msg'      => $result['error'] ?: 'Error desconocido',
            ];
        }
    }

    // 5. Actualizar last_sync de la VPS
    $pdo->prepare("UPDATE vps SET last_sync=NOW() WHERE id=?")->execute([$vpsId]);

    // 6. Devolver resultado
    $total = count($users);
    $msg = "Sincronizados {$synced}/{$total} usuarios en {$vps['name']}";
    if ($failed > 0) {
        $msg .= " — {$failed} fallaron";
    }

    echo json_encode([
        'ok' => $synced > 0,
        'msg' => $msg,
        'vps' => $vps['name'],
        'synced' => $synced,
        'failed' => $failed,
        'total' => $total,
        'details' => $details,
    ]);

} catch (Throwable $e) {
    echo json_encode(['ok' => false, 'msg' => $e->getMessage()]);
}