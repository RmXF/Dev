<?php
session_name('ceossh_sess');
session_start();
require_once '/opt/ceossh/config/config.php';
require_once '/opt/ceossh/app/SshManager.php';
header('Content-Type: application/json');

if (empty($_SESSION['admin'])) {
    http_response_code(401);
    echo json_encode(['ok' => false, 'msg' => 'No autorizado']); exit;
}

$in = json_decode(file_get_contents('php://input'), true) ?: [];
$id       = (int)($in['id'] ?? 0);
$name     = trim($in['name'] ?? '');
$host     = trim($in['host'] ?? '');
$ssh_port = (int)($in['ssh_port'] ?? 22);
$ssh_user = trim($in['ssh_user'] ?? '');
$ssh_pass = (string)($in['ssh_pass'] ?? '');
$group_id = $in['group_id'] ? (int)$in['group_id'] : null;

if (!$name || !$host || !$ssh_user) {
    echo json_encode(['ok' => false, 'msg' => 'Faltan campos obligatorios']); exit;
}

try {
    $pdo = new PDO(
        'mysql:host=' . DB_HOST . ';dbname=' . DB_NAME . ';charset=utf8mb4',
        DB_USER, DB_PASS,
        [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]
    );

    $enc_pass = $ssh_pass !== '' ? base64_encode($ssh_pass) : null;

    if ($id > 0) {
        if ($ssh_pass === '') {
            $stmt = $pdo->prepare("UPDATE vps SET name=?, host=?, ssh_port=?, ssh_user=?, group_id=? WHERE id=?");
            $stmt->execute([$name, $host, $ssh_port, $ssh_user, $group_id, $id]);
        } else {
            $stmt = $pdo->prepare("UPDATE vps SET name=?, host=?, ssh_port=?, ssh_user=?, ssh_pass=?, group_id=? WHERE id=?");
            $stmt->execute([$name, $host, $ssh_port, $ssh_user, $enc_pass, $group_id, $id]);
        }
        echo json_encode(['ok' => true, 'msg' => 'VPS actualizada']); exit;
    }

    // Al crear: probar conexión primero
    $testVps = [
        'host'     => $host,
        'ssh_port' => $ssh_port,
        'ssh_user' => $ssh_user,
        'ssh_pass' => $enc_pass,
    ];
    $test = SshManager::testConnection($testVps);

    if (!$test['ok']) {
        echo json_encode([
            'ok' => false,
            'msg' => 'No se pudo conectar por SSH: ' . ($test['error'] ?: 'sin respuesta'),
            'ssh_test' => $test,
        ]);
        exit;
    }

    $stmt = $pdo->prepare("INSERT INTO vps (name, host, ssh_port, ssh_user, ssh_pass, group_id, status, last_sync) VALUES (?,?,?,?,?,?, 'active', NOW())");
    $stmt->execute([$name, $host, $ssh_port, $ssh_user, $enc_pass, $group_id]);

    echo json_encode([
        'ok' => true,
        'msg' => 'VPS creada y verificada por SSH',
        'id' => $pdo->lastInsertId(),
        'ssh_test' => $test,
    ]);

} catch (Throwable $e) {
    echo json_encode(['ok' => false, 'msg' => $e->getMessage()]);
}