<?php
session_name('ceossh_sess');
session_start();
require_once '/opt/ceossh/config/config.php';
header('Content-Type: application/json');

if (empty($_SESSION['admin'])) {
    http_response_code(401);
    echo json_encode(['ok' => false, 'msg' => 'No autorizado']); exit;
}

$in = json_decode(file_get_contents('php://input'), true) ?: [];
$id       = (int)($in['id'] ?? 0);
$name     = trim($in['name'] ?? '');
$host     = trim($in['host'] ?? '');
$ssh_port = (int)($in['ssh_port'] ?? 22);
$ssh_user = trim($in['ssh_user'] ?? '');
$ssh_pass = (string)($in['ssh_pass'] ?? '');
$group_id = $in['group_id'] ? (int)$in['group_id'] : null;

if (!$name || !$host || !$ssh_user) {
    echo json_encode(['ok' => false, 'msg' => 'Faltan campos obligatorios']); exit;
}

try {
    $pdo = new PDO(
        'mysql:host=' . DB_HOST . ';dbname=' . DB_NAME . ';charset=utf8mb4',
        DB_USER, DB_PASS,
        [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]
    );

    $enc_pass = $ssh_pass !== '' ? base64_encode($ssh_pass) : null;

    if ($id > 0) {
        if ($ssh_pass === '') {
            $stmt = $pdo->prepare("UPDATE vps SET name=?, host=?, ssh_port=?, ssh_user=?, group_id=? WHERE id=?");
            $stmt->execute([$name, $host, $ssh_port, $ssh_user, $group_id, $id]);
        } else {
            $stmt = $pdo->prepare("UPDATE vps SET name=?, host=?, ssh_port=?, ssh_user=?, ssh_pass=?, group_id=? WHERE id=?");
            $stmt->execute([$name, $host, $ssh_port, $ssh_user, $enc_pass, $group_id, $id]);
        }
        echo json_encode(['ok' => true, 'msg' => 'VPS actualizada']); exit;
    }

    $stmt = $pdo->prepare("INSERT INTO vps (name, host, ssh_port, ssh_user, ssh_pass, group_id) VALUES (?,?,?,?,?,?)");
    $stmt->execute([$name, $host, $ssh_port, $ssh_user, $enc_pass, $group_id]);
    echo json_encode(['ok' => true, 'msg' => 'VPS creada', 'id' => $pdo->lastInsertId()]);

} catch (Throwable $e) {
    echo json_encode(['ok' => false, 'msg' => $e->getMessage()]);
}