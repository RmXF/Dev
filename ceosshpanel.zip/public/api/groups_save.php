<?php
session_name('ceossh_sess');
session_start();
require_once '/opt/ceossh/config/config.php';
header('Content-Type: application/json');

if (empty($_SESSION['admin'])) {
    http_response_code(401);
    echo json_encode(['ok' => false, 'msg' => 'No autorizado']); exit;
}

$in = json_decode(file_get_contents('php://input'), true) ?: [];
$id          = (int)($in['id'] ?? 0);
$name        = trim($in['name'] ?? '');
$description = trim($in['description'] ?? '');

if (!$name) {
    echo json_encode(['ok' => false, 'msg' => 'El nombre es obligatorio']); exit;
}

try {
    $pdo = new PDO(
        'mysql:host=' . DB_HOST . ';dbname=' . DB_NAME . ';charset=utf8mb4',
        DB_USER, DB_PASS,
        [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]
    );

    if ($id > 0) {
        // Verificar duplicado en otro ID
        $stmt = $pdo->prepare("SELECT COUNT(*) FROM vps_groups WHERE name = ? AND id != ?");
        $stmt->execute([$name, $id]);
        if ($stmt->fetchColumn() > 0) {
            echo json_encode(['ok' => false, 'msg' => 'Ya existe otro grupo con ese nombre']); exit;
        }

        $stmt = $pdo->prepare("UPDATE vps_groups SET name = ?, description = ? WHERE id = ?");
        $stmt->execute([$name, $description ?: null, $id]);
        echo json_encode(['ok' => true, 'msg' => 'Grupo actualizado']); exit;
    }

    // Verificar duplicado
    $stmt = $pdo->prepare("SELECT COUNT(*) FROM vps_groups WHERE name = ?");
    $stmt->execute([$name]);
    if ($stmt->fetchColumn() > 0) {
        echo json_encode(['ok' => false, 'msg' => 'Ya existe un grupo con ese nombre']); exit;
    }

    $stmt = $pdo->prepare("INSERT INTO vps_groups (name, description) VALUES (?, ?)");
    $stmt->execute([$name, $description ?: null]);
    echo json_encode(['ok' => true, 'msg' => 'Grupo creado', 'id' => $pdo->lastInsertId()]);

} catch (Throwable $e) {
    echo json_encode(['ok' => false, 'msg' => $e->getMessage()]);
}