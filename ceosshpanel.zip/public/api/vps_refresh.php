<?php
session_name('ceossh_sess');
session_start();
require_once '/opt/ceossh/config/config.php';
require_once '/opt/ceossh/app/SshManager.php';
header('Content-Type: application/json');

if (empty($_SESSION['admin'])) {
    http_response_code(401);
    echo json_encode(['ok' => false, 'msg' => 'No autorizado']); exit;
}

$in = json_decode(file_get_contents('php://input'), true) ?: [];
$id = (int)($in['id'] ?? 0);
if ($id <= 0) { echo json_encode(['ok' => false, 'msg' => 'ID inválido']); exit; }

try {
    $pdo = new PDO(
        'mysql:host=' . DB_HOST . ';dbname=' . DB_NAME . ';charset=utf8mb4',
        DB_USER, DB_PASS,
        [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]
    );

    $stmt = $pdo->prepare("SELECT * FROM vps WHERE id = ?");
    $stmt->execute([$id]);
    $vps = $stmt->fetch(PDO::FETCH_ASSOC);
    if (!$vps) { echo json_encode(['ok' => false, 'msg' => 'VPS no encontrada']); exit; }

    $ping = SshManager::ping($vps);

    if ($ping['ok']) {
        $pdo->prepare("UPDATE vps SET last_sync=NOW(), status='active' WHERE id=?")->execute([$id]);
        echo json_encode(['ok' => true, 'msg' => 'VPS responde: ' . trim($ping['output'])]);
    } else {
        $pdo->prepare("UPDATE vps SET status='disabled' WHERE id=?")->execute([$id]);
        echo json_encode(['ok' => false, 'msg' => 'VPS no responde: ' . $ping['error']]);
    }
} catch (Throwable $e) {
    echo json_encode(['ok' => false, 'msg' => $e->getMessage()]);
}