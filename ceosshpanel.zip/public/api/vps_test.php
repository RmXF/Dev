<?php
session_name('ceossh_sess');
session_start();
require_once '/opt/ceossh/config/config.php';
require_once '/opt/ceossh/app/SshManager.php';
header('Content-Type: application/json');

if (empty($_SESSION['admin'])) {
    http_response_code(401);
    echo json_encode(['ok' => false, 'msg' => 'No autorizado']); exit;
}

$in = json_decode(file_get_contents('php://input'), true) ?: [];

// Puede venir por datos directos (para probar antes de guardar) o por ID
if (!empty($in['id'])) {
    try {
        $pdo = new PDO(
            'mysql:host=' . DB_HOST . ';dbname=' . DB_NAME . ';charset=utf8mb4',
            DB_USER, DB_PASS,
            [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]
        );
        $stmt = $pdo->prepare("SELECT * FROM vps WHERE id = ?");
        $stmt->execute([(int)$in['id']]);
        $vps = $stmt->fetch(PDO::FETCH_ASSOC);
        if (!$vps) {
            echo json_encode(['ok' => false, 'msg' => 'VPS no encontrada']); exit;
        }
    } catch (Throwable $e) {
        echo json_encode(['ok' => false, 'msg' => $e->getMessage()]); exit;
    }
} else {
    // Prueba directa con datos del formulario
    $vps = [
        'host'     => trim($in['host'] ?? ''),
        'ssh_port' => (int)($in['ssh_port'] ?? 22),
        'ssh_user' => trim($in['ssh_user'] ?? ''),
        'ssh_pass' => base64_encode($in['ssh_pass'] ?? ''),
    ];
    if (!$vps['host'] || !$vps['ssh_user']) {
        echo json_encode(['ok' => false, 'msg' => 'Faltan host o usuario']); exit;
    }
}

$result = SshManager::testConnection($vps);

if ($result['ok']) {
    echo json_encode(['ok' => true, 'msg' => 'Conexión SSH exitosa']);
} else {
    echo json_encode(['ok' => false, 'msg' => 'No se pudo conectar: ' . $result['error']]);
}