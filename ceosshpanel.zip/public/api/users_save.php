<?php
session_name('ceossh_sess');
session_start();
require_once '/opt/ceossh/config/config.php';
require_once '/opt/ceossh/app/SshManager.php';
require_once '/opt/ceossh/app/VpsHelper.php';
header('Content-Type: application/json');

if (empty($_SESSION['admin'])) {
    http_response_code(401);
    echo json_encode(['ok' => false, 'msg' => 'No autorizado']); exit;
}

$in = json_decode(file_get_contents('php://input'), true) ?: [];
$id       = (int)($in['id'] ?? 0);
$username = trim($in['username'] ?? '');
$password = (string)($in['password'] ?? '');
$group_id = $in['group_id'] ? (int)$in['group_id'] : null;
$limit    = max(1, (int)($in['connection_limit'] ?? 1));
$days     = max(1, (int)($in['days'] ?? 30));

if (!$username || !$password) {
    echo json_encode(['ok' => false, 'msg' => 'Faltan campos obligatorios']); exit;
}

if (!preg_match('/^[a-zA-Z0-9_]{3,32}$/', $username)) {
    echo json_encode(['ok' => false, 'msg' => 'Usuario inválido (3-32 chars: a-z, 0-9, _)']); exit;
}

try {
    $pdo = new PDO(
        'mysql:host=' . DB_HOST . ';dbname=' . DB_NAME . ';charset=utf8mb4',
        DB_USER, DB_PASS,
        [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]
    );

    $enc_pass   = base64_encode($password);
    $expires_at = date('Y-m-d H:i:s', strtotime("+$days days"));

    if ($id > 0) {
        // Editar
        $stmt = $pdo->prepare("
            UPDATE ssh_users
            SET username = ?, password = ?, connection_limit = ?, expires_at = ?, group_id = ?, status = 'active'
            WHERE id = ?
        ");
        $stmt->execute([$username, $enc_pass, $limit, $expires_at, $group_id, $id]);
        $action = 'actualizado';
    } else {
        // Verificar duplicado
        $stmt = $pdo->prepare("SELECT COUNT(*) FROM ssh_users WHERE username = ?");
        $stmt->execute([$username]);
        if ($stmt->fetchColumn() > 0) {
            echo json_encode(['ok' => false, 'msg' => 'El usuario ya existe']); exit;
        }

        $stmt = $pdo->prepare("
            INSERT INTO ssh_users (username, password, connection_limit, expires_at, group_id, status)
            VALUES (?, ?, ?, ?, ?, 'active')
        ");
        $stmt->execute([$username, $enc_pass, $limit, $expires_at, $group_id]);
        $id = $pdo->lastInsertId();
        $action = 'creado';
    }

    // ---------- Propagación por SSH a las VPS del grupo ----------
    $propagation = ['total' => 0, 'ok' => 0, 'failed' => 0, 'details' => []];

    if ($group_id) {
        $vpsList = VpsHelper::getVpsByGroup($pdo, $group_id);
        $propagation['total'] = count($vpsList);

        foreach ($vpsList as $vps) {
            $res = SshManager::createUser($vps, $username, $password, $days, $limit);
            if ($res['ok']) {
                $propagation['ok']++;
                $propagation['details'][] = [
                    'vps'    => $vps['name'],
                    'status' => 'ok',
                ];
            } else {
                $propagation['failed']++;
                $propagation['details'][] = [
                    'vps'    => $vps['name'],
                    'status' => 'error',
                    'msg'    => $res['error'] ?: 'Error desconocido',
                ];
            }
        }
    }

    // Obtener nombre del grupo
    $groupName = null;
    if ($group_id) {
        $stmt = $pdo->prepare("SELECT name FROM vps_groups WHERE id = ?");
        $stmt->execute([$group_id]);
        $groupName = $stmt->fetchColumn() ?: null;
    }

    $msg = "Usuario $action";
    if ($propagation['total'] > 0) {
        $msg .= " — propagado a {$propagation['ok']}/{$propagation['total']} VPS";
        if ($propagation['failed'] > 0) {
            $msg .= " ({$propagation['failed']} fallaron)";
        }
    } elseif ($group_id) {
        $msg .= " — el grupo no tiene VPS activas";
    }

    echo json_encode([
        'ok' => true,
        'msg' => $msg,
        'id' => $id,
        'credentials' => [
            'username' => $username,
            'password' => $password,
            'expires_at' => $expires_at,
            'connection_limit' => $limit,
            'group_name' => $groupName
        ],
        'propagation' => $propagation,
    ]);
} catch (Throwable $e) {
    echo json_encode(['ok' => false, 'msg' => $e->getMessage()]);
}