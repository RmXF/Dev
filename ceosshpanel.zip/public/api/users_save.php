<?php
session_name('ceossh_sess');
session_start();
require_once '/opt/ceossh/config/config.php';
header('Content-Type: application/json');

if (empty($_SESSION['admin'])) {
    http_response_code(401);
    echo json_encode(['ok' => false, 'msg' => 'No autorizado']); exit;
}

$in = json_decode(file_get_contents('php://input'), true) ?: [];
$id       = (int)($in['id'] ?? 0);
$username = trim($in['username'] ?? '');
$password = (string)($in['password'] ?? '');
$group_id = $in['group_id'] ? (int)$in['group_id'] : null;
$limit    = max(1, (int)($in['connection_limit'] ?? 1));
$days     = max(1, (int)($in['days'] ?? 30));

if (!$username || !$password) {
    echo json_encode(['ok' => false, 'msg' => 'Faltan campos obligatorios']); exit;
}

// Validar nombre de usuario (seguridad)
if (!preg_match('/^[a-zA-Z0-9_]{3,32}$/', $username)) {
    echo json_encode(['ok' => false, 'msg' => 'Usuario inválido (3-32 chars: a-z, 0-9, _)']); exit;
}

try {
    $pdo = new PDO(
        'mysql:host=' . DB_HOST . ';dbname=' . DB_NAME . ';charset=utf8mb4',
        DB_USER, DB_PASS,
        [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]
    );

    $enc_pass   = base64_encode($password);
    $expires_at = date('Y-m-d H:i:s', strtotime("+$days days"));

    if ($id > 0) {
        // Editar
        $stmt = $pdo->prepare("
            UPDATE ssh_users
            SET username = ?, password = ?, connection_limit = ?, expires_at = ?, group_id = ?, status = 'active'
            WHERE id = ?
        ");
        $stmt->execute([$username, $enc_pass, $limit, $expires_at, $group_id, $id]);

        // Actualizar usuario del sistema operativo
        $cmd = escapeshellcmd("/opt/ceossh/scripts/update_ssh_user.sh " .
            escapeshellarg($username) . " " .
            escapeshellarg($password) . " " .
            escapeshellarg($days) . " " .
            escapeshellarg($limit));
        @shell_exec("sudo $cmd 2>&1");

        echo json_encode(['ok' => true, 'msg' => 'Usuario actualizado']);
        exit;
    }

    // Verificar duplicado
    $stmt = $pdo->prepare("SELECT COUNT(*) FROM ssh_users WHERE username = ?");
    $stmt->execute([$username]);
    if ($stmt->fetchColumn() > 0) {
        echo json_encode(['ok' => false, 'msg' => 'El usuario ya existe']); exit;
    }

    // Insertar en BD
    $stmt = $pdo->prepare("
        INSERT INTO ssh_users (username, password, connection_limit, expires_at, group_id, status)
        VALUES (?, ?, ?, ?, ?, 'active')
    ");
    $stmt->execute([$username, $enc_pass, $limit, $expires_at, $group_id]);
    $newId = $pdo->lastInsertId();

    // Crear usuario en el sistema operativo (via script)
    $cmd = escapeshellcmd("/opt/ceossh/scripts/create_ssh_user.sh " .
        escapeshellarg($username) . " " .
        escapeshellarg($password) . " " .
        escapeshellarg($days) . " " .
        escapeshellarg($limit));
    $output = @shell_exec("sudo $cmd 2>&1");

    // Obtener nombre del grupo
    $groupName = null;
    if ($group_id) {
        $stmt = $pdo->prepare("SELECT name FROM vps_groups WHERE id = ?");
        $stmt->execute([$group_id]);
        $groupName = $stmt->fetchColumn() ?: null;
    }

    echo json_encode([
        'ok' => true,
        'msg' => 'Usuario creado',
        'id' => $newId,
        'credentials' => [
            'username' => $username,
            'password' => $password,
            'expires_at' => $expires_at,
            'connection_limit' => $limit,
            'group_name' => $groupName
        ]
    ]);
} catch (Throwable $e) {
    echo json_encode(['ok' => false, 'msg' => $e->getMessage()]);
}