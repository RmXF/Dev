/* ============================================
   CEOSSH — Módulo Grupos
   ============================================ */
(function() {
  'use strict';
  
  const modal = document.getElementById('groupModal');
  const form = document.getElementById('groupForm');
  const modalTitle = document.getElementById('groupModalTitle');
  const submitBtn = document.getElementById('groupSubmit');
  const feedback = document.getElementById('groupFeedback');
  
  if (!modal || !form) return;
  
  // Abrir modal para agregar
  document.getElementById('openAddGroup')?.addEventListener('click', () => {
    resetForm();
    modalTitle.textContent = 'Nuevo Grupo';
    openModal();
  });
  
  // Refrescar
  document.getElementById('refreshGroups')?.addEventListener('click', () => {
    location.reload();
  });
  
  // Cerrar
  document.querySelectorAll('#groupModal [data-close]').forEach(el => {
    el.addEventListener('click', closeModal);
  });
  modal.addEventListener('click', (e) => {
    if (e.target === modal) closeModal();
  });
  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape') closeModal();
  });
  
  // Guardar
  submitBtn.addEventListener('click', async () => {
    const data = {
      id: document.getElementById('g-id').value,
      name: document.getElementById('g-name').value.trim(),
      description: document.getElementById('g-description').value.trim()
    };
    
    if (!data.name) return showFeedback('El nombre es obligatorio', 'error');
    
    submitBtn.disabled = true;
    submitBtn.textContent = 'Guardando...';
    
    try {
      const res = await fetch('api/groups_save.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data)
      });
      const json = await res.json();
      
      if (json.ok) {
        showFeedback('Guardado correctamente', 'success');
        setTimeout(() => location.reload(), 600);
      } else {
        showFeedback(json.msg || 'Error al guardar', 'error');
      }
    } catch {
      showFeedback('Error de conexión', 'error');
    } finally {
      submitBtn.disabled = false;
      submitBtn.textContent = 'Guardar';
    }
  });
  
  // Editar
  document.querySelectorAll('.icon-action.edit').forEach(btn => {
    btn.addEventListener('click', async () => {
      const id = btn.dataset.id;
      try {
        const res = await fetch(`api/groups_get.php?id=${id}`);
        const json = await res.json();
        if (!json.ok) return alert(json.msg);
        
        const g = json.group;
        document.getElementById('g-id').value = g.id;
        document.getElementById('g-name').value = g.name;
        document.getElementById('g-description').value = g.description || '';
        
        modalTitle.textContent = 'Editar Grupo';
        openModal();
      } catch {
        alert('Error al cargar grupo');
      }
    });
  });
  
  // Eliminar
  document.querySelectorAll('.icon-action.delete').forEach(btn => {
    btn.addEventListener('click', async () => {
      if (!confirm('¿Eliminar este grupo? Los usuarios y VPS asociados quedarán sin grupo.')) return;
      const id = btn.dataset.id;
      try {
        const res = await fetch('api/groups_delete.php', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ id })
        });
        const json = await res.json();
        if (json.ok) location.reload();
        else alert(json.msg || 'Error al eliminar');
      } catch {
        alert('Error de conexión');
      }
    });
  });
  
  function openModal() {
    modal.classList.add('open');
    document.body.style.overflow = 'hidden';
  }
  
  function closeModal() {
    modal.classList.remove('open');
    document.body.style.overflow = '';
  }
  
  function resetForm() {
    form.reset();
    document.getElementById('g-id').value = '';
    feedback.className = 'modal-feedback';
    feedback.textContent = '';
  }
  
  function showFeedback(msg, type) {
    feedback.className = 'modal-feedback ' + type;
    feedback.textContent = msg;
  }
})();