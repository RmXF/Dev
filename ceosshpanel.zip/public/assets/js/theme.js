/* ============================================
   CEOSSH — Lógica del Dashboard
   ============================================ */
document.addEventListener('DOMContentLoaded', () => {
  
  // ---- Modal Demo ----
  const demoBtn = document.getElementById('demoBtn');
  const demoModal = document.getElementById('demoModal');
  
  if (demoBtn && demoModal) {
    demoBtn.addEventListener('click', () => openModal(demoModal));
  }
  
  // ---- Cierre genérico de modales ----
  document.querySelectorAll('[data-close]').forEach(el => {
    el.addEventListener('click', (e) => {
      const overlay = e.target.closest('.modal-overlay');
      if (overlay) closeModal(overlay);
    });
  });
  
  // Cerrar al hacer clic en el fondo oscuro
  document.querySelectorAll('.modal-overlay').forEach(overlay => {
    overlay.addEventListener('click', (e) => {
      if (e.target === overlay) closeModal(overlay);
    });
  });
  
  // Cerrar con Escape
  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape') {
      document.querySelectorAll('.modal-overlay.open').forEach(closeModal);
    }
  });
  
  // ---- Funciones ----
  function openModal(modal) {
    modal.classList.add('open');
    document.body.style.overflow = 'hidden';
  }
  
  function closeModal(modal) {
    modal.classList.remove('open');
    document.body.style.overflow = '';
  }
  
  // ---- Animación de entrada de las cards ----
  const cards = document.querySelectorAll('.card');
  cards.forEach((card, i) => {
    card.style.opacity = '0';
    card.style.transform = 'translateY(12px)';
    setTimeout(() => {
      card.style.transition = 'opacity 0.4s ease, transform 0.4s ease';
      card.style.opacity = '1';
      card.style.transform = 'translateY(0)';
    }, 80 * i);
  });
});