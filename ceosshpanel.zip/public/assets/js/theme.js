/* ============================================
   CEOSSH — Manejo de tema claro/oscuro
   ============================================ */
(function() {
  'use strict';
  
  const STORAGE_KEY = 'ceossh_theme';
  const html = document.documentElement;
  
  function currentTheme() {
    return html.getAttribute('data-theme') || 'dark';
  }
  
  function applyTheme(theme) {
    html.setAttribute('data-theme', theme);
    localStorage.setItem(STORAGE_KEY, theme);
    updateToggleIcon(theme);
  }
  
  function updateToggleIcon(theme) {
    const icon = document.querySelector('#themeToggle .theme-icon');
    if (icon) icon.textContent = theme === 'dark' ? '☀️' : '🌙';
  }
  
  function initToggle() {
    const toggle = document.getElementById('themeToggle');
    if (!toggle) return;
    
    updateToggleIcon(currentTheme());
    
    toggle.addEventListener('click', () => {
      const next = currentTheme() === 'dark' ? 'light' : 'dark';
      applyTheme(next);
    });
  }
  
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', initToggle);
  } else {
    initToggle();
  }
  
  window.addEventListener('pageshow', () => {
    const saved = localStorage.getItem(STORAGE_KEY);
    if (saved) {
      html.setAttribute('data-theme', saved);
      updateToggleIcon(saved);
    }
  });
})();