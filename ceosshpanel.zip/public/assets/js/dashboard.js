/* ============================================
   CEOSSH — Lógica del Dashboard
   ============================================ */
document.addEventListener('DOMContentLoaded', () => {
  
  // ---- Modal Demo ----
  const demoBtn = document.getElementById('demoBtn');
  const demoModal = document.getElementById('demoModal');
  
  if (demoBtn && demoModal) {
    demoBtn.addEventListener('click', () => openModal(demoModal));
  }
  
  // ---- Cierre genérico de modales ----
  document.querySelectorAll('[data-close]').forEach(el => {
    el.addEventListener('click', (e) => {
      const overlay = e.target.closest('.modal-overlay');
      if (overlay) closeModal(overlay);
    });
  });
  
  document.querySelectorAll('.modal-overlay').forEach(overlay => {
    overlay.addEventListener('click', (e) => {
      if (e.target === overlay) closeModal(overlay);
    });
  });
  
  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape') {
      document.querySelectorAll('.modal-overlay.open').forEach(closeModal);
    }
  });
  
  function openModal(modal) {
    modal.classList.add('open');
    document.body.style.overflow = 'hidden';
  }
  
  function closeModal(modal) {
    modal.classList.remove('open');
    document.body.style.overflow = '';
  }
  
  // ---- Animación de entrada de las cards ----
  const cards = document.querySelectorAll('.card');
  cards.forEach((card, i) => {
    card.style.opacity = '0';
    card.style.transform = 'translateY(12px)';
    setTimeout(() => {
      card.style.transition = 'opacity 0.4s ease, transform 0.4s ease';
      card.style.opacity = '1';
      card.style.transform = 'translateY(0)';
    }, 80 * i);
  });
  
  // ---- Menú deslizable: scroll horizontal con rueda del mouse ----
  const nav = document.getElementById('mainNav');
  if (nav) {
    nav.addEventListener('wheel', (e) => {
      // Convertir scroll vertical en horizontal cuando el mouse pasa por el nav
      if (Math.abs(e.deltaY) > Math.abs(e.deltaX)) {
        e.preventDefault();
        nav.scrollLeft += e.deltaY;
      }
    }, { passive: false });
    
    // Marcar el nav como "con overflow" para futuras flechas (opcional)
    checkOverflow(nav);
    window.addEventListener('resize', () => checkOverflow(nav));
  }
  
  function checkOverflow(el) {
    if (el.scrollWidth > el.clientWidth) {
      el.classList.add('has-overflow');
    } else {
      el.classList.remove('has-overflow');
    }
  }
});