/* ============================================
   CEOSSH — Sidebar (menú lateral)
   ============================================ */
(function() {
  'use strict';
  
  const toggle = document.getElementById('sidebarToggle');
  const close = document.getElementById('sidebarClose');
  const overlay = document.getElementById('sidebarOverlay');
  const sidebar = document.getElementById('ceosshSidebar');
  
  if (!toggle || !close || !overlay || !sidebar) return;
  
  function openSidebar() {
    document.body.classList.add('sidebar-open');
    toggle.setAttribute('aria-expanded', 'true');
    toggle.setAttribute('aria-label', 'Cerrar menú');
  }
  
  function closeSidebar() {
    document.body.classList.remove('sidebar-open');
    toggle.setAttribute('aria-expanded', 'false');
    toggle.setAttribute('aria-label', 'Abrir menú');
  }
  
  function toggleSidebar() {
    document.body.classList.contains('sidebar-open') ?
      closeSidebar() :
      openSidebar();
  }
  
  toggle.addEventListener('click', toggleSidebar);
  close.addEventListener('click', closeSidebar);
  overlay.addEventListener('click', closeSidebar);
  
  document.addEventListener('keydown', function(e) {
    if (e.key === 'Escape') closeSidebar();
  });
  
  // Cerrar en móvil al hacer clic en un enlace
  sidebar.querySelectorAll('a').forEach(function(link) {
    link.addEventListener('click', function() {
      if (window.innerWidth < 1100) closeSidebar();
    });
  });
  
  // Navegación interna con data-section
  sidebar.querySelectorAll('[data-section]').forEach(function(link) {
    link.addEventListener('click', function(e) {
      e.preventDefault();
      sidebar.querySelectorAll('[data-section]').forEach(function(item) {
        item.classList.remove('active');
      });
      this.classList.add('active');
    });
  });
  
  // Botón Demo desde el sidebar → dispara el botón del header
  const sidebarDemo = document.getElementById('sidebarDemo');
  const demoBtn = document.getElementById('demoBtn');
  
  if (sidebarDemo && demoBtn) {
    sidebarDemo.addEventListener('click', function(e) {
      e.preventDefault();
      closeSidebar();
      demoBtn.click();
    });
  }
})();