/* ============================================
   CEOSSH — Módulo Usuarios SSH
   ============================================ */
(function () {
    'use strict';

    const addModal   = document.getElementById('addUserModal');
    const credModal  = document.getElementById('credModal');
    const form       = document.getElementById('userForm');
    const submitBtn  = document.getElementById('userSubmit');
    const feedback   = document.getElementById('userFeedback');
    const tbody      = document.getElementById('usersTbody');
    const emptyState = document.getElementById('emptyState');
    const filterInfo = document.getElementById('filterInfo');

    let currentFilter = 'all';

    // ---------- Cargar lista ----------
    async function loadUsers(filter = 'all') {
        currentFilter = filter;
        tbody.innerHTML = '<tr><td colspan="7" class="loading-row">Cargando usuarios...</td></tr>';
        emptyState.classList.add('hidden');

        // Actualizar botones
        document.getElementById('filterAll').classList.toggle('active', filter === 'all');
        document.getElementById('filterExpired').classList.toggle('active', filter === 'expired');

        try {
            const res  = await fetch(`api/users_list.php?filter=${filter}`);
            const json = await res.json();

            if (!json.ok) {
                tbody.innerHTML = `<tr><td colspan="7" class="loading-row">Error: ${json.msg}</td></tr>`;
                return;
            }

            if (!json.users.length) {
                tbody.innerHTML = '';
                emptyState.classList.remove('hidden');
                filterInfo.classList.remove('show');
                return;
            }

            filterInfo.textContent = `Mostrando ${json.users.length} usuario(s)${filter === 'expired' ? ' vencidos' : ''}`;
            filterInfo.classList.add('show');

            tbody.innerHTML = json.users.map(u => `
                <tr data-id="${u.id}">
                    <td data-label="Usuario"><code>${escapeHtml(u.username)}</code></td>
                    <td data-label="Contraseña"><code>${escapeHtml(u.password_plain || '•••••••')}</code></td>
                    <td data-label="Grupo">${u.group_name ? `<span class="badge">${escapeHtml(u.group_name)}</span>` : '<span class="muted">—</span>'}</td>
                    <td data-label="Límite">${u.connection_limit}</td>
                    <td data-label="Vencimiento">${u.expires_at}</td>
                    <td data-label="Estado"><span class="status-pill status-${u.status}">${statusLabel(u.status)}</span></td>
                    <td data-label="Acciones" class="row-actions">
                        <button class="icon-action edit"   data-id="${u.id}" title="Editar">✏️</button>
                        <button class="icon-action renew"  data-id="${u.id}" title="Renovar">🔄</button>
                        <button class="icon-action delete" data-id="${u.id}" title="Eliminar">🗑</button>
                    </td>
                </tr>
            `).join('');

            bindRowActions();
        } catch {
            tbody.innerHTML = '<tr><td colspan="7" class="loading-row">Error de conexión</td></tr>';
        }
    }

    // ---------- Bind de acciones de fila ----------
    function bindRowActions() {
        document.querySelectorAll('.icon-action.edit').forEach(btn => {
            btn.addEventListener('click', () => openEdit(btn.dataset.id));
        });

        document.querySelectorAll('.icon-action.delete').forEach(btn => {
            btn.addEventListener('click', () => deleteUser(btn.dataset.id));
        });

        document.querySelectorAll('.icon-action.renew').forEach(btn => {
            btn.addEventListener('click', () => renewUser(btn.dataset.id));
        });
    }

    // ---------- Abrir modal agregar ----------
    document.getElementById('openAddUser').addEventListener('click', () => {
        resetForm();
        document.getElementById('userModalTitle').textContent = 'Agregar Usuario';
        openModal(addModal);
    });

    // ---------- Editar ----------
    async function openEdit(id) {
        try {
            const res  = await fetch(`api/users_get.php?id=${id}`);
            const json = await res.json();
            if (!json.ok) return alert(json.msg);

            const u = json.user;
            document.getElementById('u-id').value       = u.id;
            document.getElementById('u-username').value = u.username;
            document.getElementById('u-password').value = u.password_plain || '';
            document.getElementById('u-group').value    = u.group_id || '';
            document.getElementById('u-limit').value    = u.connection_limit;
            document.getElementById('u-days').value     = u.days_left || 30;

            document.getElementById('userModalTitle').textContent = 'Editar Usuario';
            openModal(addModal);
        } catch {
            alert('Error al cargar usuario');
        }
    }

    // ---------- Guardar ----------
    submitBtn.addEventListener('click', async () => {
        const data = {
            id:               document.getElementById('u-id').value,
            username:         document.getElementById('u-username').value.trim(),
            password:         document.getElementById('u-password').value,
            group_id:         document.getElementById('u-group').value || null,
            connection_limit: document.getElementById('u-limit').value,
            days:             document.getElementById('u-days').value
        };

        if (!data.username || !data.password) {
            return showFeedback('Completa usuario y contraseña', 'error');
        }

        submitBtn.disabled = true;
        submitBtn.textContent = 'Guardando...';

        try {
            const res = await fetch('api/users_save.php', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(data)
            });
            const json = await res.json();

            if (json.ok) {
                showFeedback('Guardado correctamente', 'success');
                if (json.credentials && !data.id) {
                    showCredentials(json.credentials);
                }
                setTimeout(() => {
                    closeModal(addModal);
                    loadUsers(currentFilter);
                }, 500);
            } else {
                showFeedback(json.msg || 'Error al guardar', 'error');
            }
        } catch {
            showFeedback('Error de conexión', 'error');
        } finally {
            submitBtn.disabled = false;
            submitBtn.textContent = 'Generar Cuenta';
        }
    });

    // ---------- Eliminar ----------
    async function deleteUser(id) {
        if (!confirm('¿Eliminar este usuario? Se desconectará inmediatamente.')) return;
        try {
            const res = await fetch('api/users_delete.php', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ id })
            });
            const json = await res.json();
            if (json.ok) loadUsers(currentFilter);
            else alert(json.msg);
        } catch {
            alert('Error de conexión');
        }
    }

    // ---------- Eliminar todos ----------
    document.getElementById('deleteAll').addEventListener('click', async () => {
        if (!confirm('⚠️ ¿Eliminar TODOS los usuarios? Esta acción no se puede deshacer.')) return;
        if (!confirm('¿Estás completamente seguro? Se desconectarán todas las sesiones activas.')) return;

        try {
            const res = await fetch('api/users_delete_all.php', { method: 'POST' });
            const json = await res.json();
            if (json.ok) {
                alert(`Se eliminaron ${json.deleted} usuarios`);
                loadUsers(currentFilter);
            } else alert(json.msg);
        } catch {
            alert('Error de conexión');
        }
    });

    // ---------- Renovar ----------
    async function renewUser(id) {
        const days = prompt('¿Renovar por cuántos días?', '30');
        if (!days || isNaN(days) || days <= 0) return;

        try {
            const res = await fetch('api/users_renew.php', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ id, days: parseInt(days) })
            });
            const json = await res.json();
            if (json.ok) {
                alert(`Renovado hasta: ${json.expires_at}`);
                loadUsers(currentFilter);
            } else alert(json.msg);
        } catch {
            alert('Error de conexión');
        }
    }

    // ---------- Filtros ----------
    document.getElementById('filterAll').addEventListener('click', () => loadUsers('all'));
    document.getElementById('filterExpired').addEventListener('click', () => loadUsers('expired'));

    // ---------- Generadores aleatorios ----------
    document.getElementById('genUser').addEventListener('click', () => {
        const rnd = Math.random().toString(36).substring(2, 8);
        document.getElementById('u-username').value = 'ceo_' + rnd;
    });

    document.getElementById('genPass').addEventListener('click', () => {
        const chars = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
        let pass = '';
        for (let i = 0; i < 10; i++) pass += chars.charAt(Math.floor(Math.random() * chars.length));
        document.getElementById('u-password').value = pass;
    });

    // ---------- Modal credenciales ----------
    function showCredentials(c) {
        document.getElementById('c-user').textContent  = c.username;
        document.getElementById('c-pass').textContent  = c.password;
        document.getElementById('c-exp').textContent   = c.expires_at;
        document.getElementById('c-lim').textContent   = c.connection_limit;
        document.getElementById('c-group').textContent = c.group_name || 'Sin grupo';
        openModal(credModal);
    }

    document.getElementById('copyCreds').addEventListener('click', () => {
        const text = [
            `🔐 Usuario: ${document.getElementById('c-user').textContent}`,
            `🔑 Contraseña: ${document.getElementById('c-pass').textContent}`,
            `📅 Vence: ${document.getElementById('c-exp').textContent}`,
            `👥 Límite: ${document.getElementById('c-lim').textContent} conexiones`
        ].join('\n');

        navigator.clipboard.writeText(text).then(() => {
            const btn = document.getElementById('copyCreds');
            const old = btn.textContent;
            btn.textContent = '✅ Copiado';
            setTimeout(() => btn.textContent = old, 1500);
        });
    });

    document.getElementById('shareCreds').addEventListener('click', async () => {
        const text = [
            `🔐 Usuario: ${document.getElementById('c-user').textContent}`,
            `🔑 Contraseña: ${document.getElementById('c-pass').textContent}`,
            `📅 Vence: ${document.getElementById('c-exp').textContent}`,
            `👥 Límite: ${document.getElementById('c-lim').textContent} conexiones`
        ].join('\n');

        if (navigator.share) {
            try { await navigator.share({ title: 'CEOSSH - Cuenta SSH', text }); }
            catch {}
        } else {
            navigator.clipboard.writeText(text);
            alert('Copiado al portapapeles');
        }
    });

    // ---------- Modales ----------
    document.querySelectorAll('[data-close]').forEach(el => {
        el.addEventListener('click', (e) => {
            const overlay = e.target.closest('.modal-overlay');
            if (overlay) closeModal(overlay);
        });
    });

    [addModal, credModal].forEach(m => {
        m.addEventListener('click', (e) => { if (e.target === m) closeModal(m); });
    });

    document.addEventListener('keydown', (e) => {
        if (e.key === 'Escape') {
            document.querySelectorAll('.modal-overlay.open').forEach(closeModal);
        }
    });

    function openModal(m) {
        m.classList.add('open');
        document.body.style.overflow = 'hidden';
    }

    function closeModal(m) {
        m.classList.remove('open');
        document.body.style.overflow = '';
    }

    function resetForm() {
        form.reset();
        document.getElementById('u-id').value = '';
        document.getElementById('u-limit').value = '1';
        document.getElementById('u-days').value = '30';
        feedback.className = 'modal-feedback';
        feedback.textContent = '';
    }

    function showFeedback(msg, type) {
        feedback.className = 'modal-feedback ' + type;
        feedback.textContent = msg;
    }

    function statusLabel(s) {
        return { active: '● Activo', expired: '● Vencido', disabled: '● Deshabilitado' }[s] || s;
    }

    function escapeHtml(str) {
        return String(str).replace(/[&<>"']/g, m => ({
            '&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'
        }[m]));
    }

    // ---------- Cargar al inicio ----------
    loadUsers('all');

    // ---------- Auto-refresh cada 30s ----------
    setInterval(() => loadUsers(currentFilter), 30000);
})();