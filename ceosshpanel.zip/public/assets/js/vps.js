/* ============================================
   CEOSSH — Módulo VPS
   ============================================ */
(function() {
  'use strict';
  
  const modal = document.getElementById('vpsModal');
  const form = document.getElementById('vpsForm');
  const modalTitle = document.getElementById('modalTitle');
  const submitBtn = document.getElementById('vpsSubmit');
  const feedback = document.getElementById('vpsFeedback');
  
  if (!modal || !form) return;
  
  document.getElementById('openAddVps')?.addEventListener('click', () => {
    resetForm();
    modalTitle.textContent = 'Agregar VPS';
    openModal();
  });
  
  document.getElementById('refreshList')?.addEventListener('click', () => {
    location.reload();
  });
  
  document.querySelectorAll('#vpsModal [data-close]').forEach(el => {
    el.addEventListener('click', closeModal);
  });
  modal.addEventListener('click', (e) => {
    if (e.target === modal) closeModal();
  });
  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape') closeModal();
  });
  
  submitBtn.addEventListener('click', async () => {
    const data = {
      id: document.getElementById('vps-id').value,
      name: document.getElementById('vps-name').value.trim(),
      host: document.getElementById('vps-host').value.trim(),
      ssh_port: document.getElementById('vps-port').value.trim(),
      ssh_user: document.getElementById('vps-user').value.trim(),
      ssh_pass: document.getElementById('vps-pass').value,
      group_id: document.getElementById('vps-group').value || null
    };
    
    if (!data.name || !data.host || !data.ssh_user) {
      return showFeedback('Completa todos los campos obligatorios', 'error');
    }
    
    submitBtn.disabled = true;
    submitBtn.textContent = 'Guardando...';
    
    try {
      const res = await fetch('api/vps_save.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data)
      });
      const json = await res.json();
      
      if (json.ok) {
        showFeedback('Guardado correctamente', 'success');
        setTimeout(() => location.reload(), 700);
      } else {
        showFeedback(json.msg || 'Error al guardar', 'error');
      }
    } catch (err) {
      showFeedback('Error de conexión con el servidor', 'error');
    } finally {
      submitBtn.disabled = false;
      submitBtn.textContent = 'Guardar';
    }
  });
  
  document.querySelectorAll('.icon-action.edit').forEach(btn => {
    btn.addEventListener('click', async () => {
      const id = btn.dataset.id;
      try {
        const res = await fetch(`api/vps_get.php?id=${id}`);
        const json = await res.json();
        if (!json.ok) return showFeedback(json.msg, 'error');
        
        const v = json.vps;
        document.getElementById('vps-id').value = v.id;
        document.getElementById('vps-name').value = v.name;
        document.getElementById('vps-host').value = v.host;
        document.getElementById('vps-port').value = v.ssh_port;
        document.getElementById('vps-user').value = v.ssh_user;
        document.getElementById('vps-pass').value = '';
        document.getElementById('vps-group').value = v.group_id || '';
        
        modalTitle.textContent = 'Editar VPS';
        openModal();
      } catch {
        alert('Error al cargar VPS');
      }
    });
  });
  
  document.querySelectorAll('.icon-action.delete').forEach(btn => {
    btn.addEventListener('click', async () => {
      if (!confirm('¿Eliminar esta VPS? Esta acción no se puede deshacer.')) return;
      const id = btn.dataset.id;
      try {
        const res = await fetch('api/vps_delete.php', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ id })
        });
        const json = await res.json();
        if (json.ok) location.reload();
        else alert(json.msg || 'Error al eliminar');
      } catch {
        alert('Error de conexión');
      }
    });
  });
  
  document.querySelectorAll('.icon-action.toggle').forEach(btn => {
    btn.addEventListener('click', async () => {
      const id = btn.dataset.id;
      try {
        const res = await fetch('api/vps_toggle.php', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ id })
        });
        const json = await res.json();
        if (json.ok) location.reload();
        else alert(json.msg || 'Error al cambiar estado');
      } catch {
        alert('Error de conexión');
      }
    });
  });
  
  document.querySelectorAll('.icon-action.refresh').forEach(btn => {
    btn.addEventListener('click', async () => {
      const id = btn.dataset.id;
      btn.disabled = true;
      btn.textContent = '⏳';
      try {
        const res = await fetch('api/vps_refresh.php', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ id })
        });
        const json = await res.json();
        if (json.ok) {
          btn.textContent = '✅';
          setTimeout(() => location.reload(), 800);
        } else {
          btn.textContent = '⚠️';
          alert(json.msg || 'Error al refrescar');
        }
      } catch {
        btn.textContent = '⚠️';
        alert('Error de conexión');
      } finally {
        btn.disabled = false;
      }
    });
  });
  
  function openModal() {
    modal.classList.add('open');
    document.body.style.overflow = 'hidden';
  }
  
  function closeModal() {
    modal.classList.remove('open');
    document.body.style.overflow = '';
  }
  
  function resetForm() {
    form.reset();
    document.getElementById('vps-id').value = '';
    document.getElementById('vps-port').value = '22';
    feedback.className = 'modal-feedback';
    feedback.textContent = '';
  }
  
  function showFeedback(msg, type) {
    feedback.className = 'modal-feedback ' + type;
    feedback.textContent = msg;
  }
})();