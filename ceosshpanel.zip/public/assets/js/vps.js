/* ============================================
   CEOSSH — Módulo VPS
   ============================================ */
(function () {
    'use strict';

    const modal      = document.getElementById('vpsModal');
    const syncModal  = document.getElementById('syncModal');
    const syncBody   = document.getElementById('syncBody');
    const syncTitle  = document.getElementById('syncTitle');
    const form       = document.getElementById('vpsForm');
    const modalTitle = document.getElementById('modalTitle');
    const submitBtn  = document.getElementById('vpsSubmit');
    const testBtn    = document.getElementById('vpsTest');
    const feedback   = document.getElementById('vpsFeedback');

    if (!modal || !form) return;

    // ---------- Abrir modal agregar ----------
    document.getElementById('openAddVps')?.addEventListener('click', () => {
        resetForm();
        modalTitle.textContent = 'Agregar VPS';
        openModal(modal);
    });

    document.getElementById('refreshList')?.addEventListener('click', () => location.reload());

    // ---------- Cerrar modales ----------
    document.querySelectorAll('[data-close]').forEach(el => {
        el.addEventListener('click', (e) => {
            const overlay = e.target.closest('.modal-overlay');
            if (overlay) closeModal(overlay);
        });
    });

    [modal, syncModal].forEach(m => {
        if (m) m.addEventListener('click', (e) => { if (e.target === m) closeModal(m); });
    });

    document.addEventListener('keydown', (e) => {
        if (e.key === 'Escape') {
            document.querySelectorAll('.modal-overlay.open').forEach(closeModal);
        }
    });

    // ---------- Probar conexión desde el modal ----------
    testBtn?.addEventListener('click', async () => {
        const data = {
            host:     document.getElementById('vps-host').value.trim(),
            ssh_port: document.getElementById('vps-port').value.trim(),
            ssh_user: document.getElementById('vps-user').value.trim(),
            ssh_pass: document.getElementById('vps-pass').value,
        };

        if (!data.host || !data.ssh_user) {
            return showFeedback('Completa host y usuario', 'error');
        }

        testBtn.disabled = true;
        testBtn.textContent = '⏳ Probando...';

        try {
            const res  = await fetch('api/vps_test.php', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(data)
            });
            const json = await res.json();

            if (json.ok) showFeedback('✅ ' + (json.msg || 'Conexión OK'), 'success');
            else         showFeedback('❌ ' + (json.msg || 'Error'), 'error');
        } catch {
            showFeedback('Error de conexión con el servidor', 'error');
        } finally {
            testBtn.disabled = false;
            testBtn.textContent = '📡 Probar';
        }
    });

    // ---------- Guardar ----------
    submitBtn.addEventListener('click', async () => {
        const data = {
            id:       document.getElementById('vps-id').value,
            name:     document.getElementById('vps-name').value.trim(),
            host:     document.getElementById('vps-host').value.trim(),
            ssh_port: document.getElementById('vps-port').value.trim(),
            ssh_user: document.getElementById('vps-user').value.trim(),
            ssh_pass: document.getElementById('vps-pass').value,
            group_id: document.getElementById('vps-group').value || null
        };

        if (!data.name || !data.host || !data.ssh_user) {
            return showFeedback('Completa todos los campos obligatorios', 'error');
        }

        submitBtn.disabled = true;
        submitBtn.textContent = 'Guardando...';

        try {
            const res = await fetch('api/vps_save.php', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(data)
            });
            const json = await res.json();

            if (json.ok) {
                showFeedback('✅ ' + (json.msg || 'Guardado'), 'success');
                setTimeout(() => location.reload(), 800);
            } else {
                showFeedback('❌ ' + (json.msg || 'Error al guardar'), 'error');
            }
        } catch {
            showFeedback('Error de conexión', 'error');
        } finally {
            submitBtn.disabled = false;
            submitBtn.textContent = 'Guardar';
        }
    });

    // ---------- Editar ----------
    document.querySelectorAll('.icon-action.edit').forEach(btn => {
        btn.addEventListener('click', async () => {
            const id = btn.dataset.id;
            try {
                const res  = await fetch(`api/vps_get.php?id=${id}`);
                const json = await res.json();
                if (!json.ok) return alert(json.msg);

                const v = json.vps;
                document.getElementById('vps-id').value    = v.id;
                document.getElementById('vps-name').value  = v.name;
                document.getElementById('vps-host').value  = v.host;
                document.getElementById('vps-port').value  = v.ssh_port;
                document.getElementById('vps-user').value  = v.ssh_user;
                document.getElementById('vps-pass').value  = '';
                document.getElementById('vps-group').value = v.group_id || '';

                modalTitle.textContent = 'Editar VPS';
                openModal(modal);
            } catch {
                alert('Error al cargar VPS');
            }
        });
    });

    // ---------- Eliminar ----------
    document.querySelectorAll('.icon-action.delete').forEach(btn => {
        btn.addEventListener('click', async () => {
            if (!confirm('¿Eliminar esta VPS? Esta acción no se puede deshacer.')) return;
            const id = btn.dataset.id;
            try {
                const res  = await fetch('api/vps_delete.php', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ id })
                });
                const json = await res.json();
                if (json.ok) location.reload();
                else alert(json.msg || 'Error al eliminar');
            } catch {
                alert('Error de conexión');
            }
        });
    });

    // ---------- Toggle activo/deshabilitado ----------
    document.querySelectorAll('.icon-action.toggle').forEach(btn => {
        btn.addEventListener('click', async () => {
            const id = btn.dataset.id;
            try {
                const res  = await fetch('api/vps_toggle.php', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ id })
                });
                const json = await res.json();
                if (json.ok) location.reload();
                else alert(json.msg || 'Error al cambiar estado');
            } catch {
                alert('Error de conexión');
            }
        });
    });

    // ---------- Ping (probar conexión) ----------
    document.querySelectorAll('.icon-action.ping').forEach(btn => {
        btn.addEventListener('click', async () => {
            const id = btn.dataset.id;
            const old = btn.textContent;
            btn.disabled = true;
            btn.textContent = '⏳';
            try {
                const res  = await fetch('api/vps_refresh.php', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ id })
                });
                const json = await res.json();
                if (json.ok) {
                    btn.textContent = '✅';
                    setTimeout(() => location.reload(), 900);
                } else {
                    btn.textContent = '⚠️';
                    alert(json.msg || 'VPS no responde');
                }
            } catch {
                btn.textContent = '⚠️';
                alert('Error de conexión');
            } finally {
                btn.disabled = false;
                setTimeout(() => btn.textContent = old, 2000);
            }
        });
    });

    // ---------- 🔄 SINCRONIZAR USUARIOS DEL GRUPO ----------
    document.querySelectorAll('.icon-action.sync').forEach(btn => {
        btn.addEventListener('click', async () => {
            const id = btn.dataset.id;

            if (!confirm(
                '🔄 Sincronizar usuarios del grupo\n\n' +
                'Se crearán todos los usuarios activos del grupo en esta VPS.\n' +
                'Los usuarios ya existentes se actualizarán.\n\n' +
                '¿Continuar?'
            )) return;

            // Mostrar modal de progreso
            syncTitle.textContent = 'Sincronizando usuarios...';
            syncBody.innerHTML = `
                <p class="muted">Conectando por SSH a la VPS...</p>
                <div class="sync-progress">
                    <div class="spinner"></div>
                </div>
            `;
            openModal(syncModal);

            btn.disabled = true;
            const old = btn.textContent;
            btn.textContent = '⏳';

            try {
                const res = await fetch('api/vps_sync.php', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ vps_id: id })
                });
                const json = await res.json();

                // Actualizar modal con el resultado
                if (json.ok) {
                    syncTitle.textContent = '✅ Sincronización completada';

                    let html = `
                        <div class="sync-result success">
                            <div class="sync-stat">
                                <span class="sync-num">${json.synced}</span>
                                <span class="sync-label">Sincronizados</span>
                            </div>
                            <div class="sync-stat">
                                <span class="sync-num">${json.total}</span>
                                <span class="sync-label">Total grupo</span>
                            </div>
                            <div class="sync-stat">
                                <span class="sync-num ${json.failed > 0 ? 'error' : ''}">${json.failed}</span>
                                <span class="sync-label">Fallaron</span>
                            </div>
                        </div>
                        <p class="sync-vps-name">VPS: <strong>${escapeHtml(json.vps)}</strong></p>
                    `;

                    if (json.details && json.details.length) {
                        html += '<div class="sync-details"><h4>Detalle</h4><ul>';
                        json.details.forEach(d => {
                            if (d.status === 'ok') {
                                html += `<li class="ok">✅ ${escapeHtml(d.username)} (${d.days} días)</li>`;
                            } else {
                                html += `<li class="err">❌ ${escapeHtml(d.username)} — ${escapeHtml(d.msg || 'error')}</li>`;
                            }
                        });
                        html += '</ul></div>';
                    }

                    syncBody.innerHTML = html;
                    setTimeout(() => location.reload(), 3000);
                } else {
                    syncTitle.textContent = '❌ Error al sincronizar';
                    syncBody.innerHTML = `<div class="sync-result error-box">
                        <p><strong>${escapeHtml(json.msg || 'Error desconocido')}</strong></p>
                    </div>`;
                }
            } catch (err) {
                syncTitle.textContent = '❌ Error de conexión';
                syncBody.innerHTML = `<div class="sync-result error-box">
                    <p>No se pudo contactar con el servidor</p>
                </div>`;
            } finally {
                btn.disabled = false;
                btn.textContent = old;
            }
        });
    });

    // ---------- Helpers ----------
    function openModal(m) {
        if (!m) return;
        m.classList.add('open');
        document.body.style.overflow = 'hidden';
    }

    function closeModal(m) {
        if (!m) return;
        m.classList.remove('open');
        document.body.style.overflow = '';
    }

    function resetForm() {
        form.reset();
        document.getElementById('vps-id').value = '';
        document.getElementById('vps-port').value = '22';
        feedback.className = 'modal-feedback';
        feedback.textContent = '';
    }

    function showFeedback(msg, type) {
        feedback.className = 'modal-feedback ' + type;
        feedback.textContent = msg;
    }

    function escapeHtml(str) {
        return String(str).replace(/[&<>"']/g, m => ({
            '&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'
        }[m]));
    }
})();