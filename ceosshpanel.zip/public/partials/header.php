<!-- ============ HEADER ============ -->
<header class="topnav">

    <button
        class="sidebar-toggle"
        id="sidebarToggle"
        aria-label="Abrir menú"
        aria-expanded="false"
        aria-controls="ceosshSidebar"
    >
        <span></span>
        <span></span>
        <span></span>
    </button>

    <div class="brand">
        <span class="brand-logo">CEOSSH</span>
    </div>

    <nav class="main-nav">
        <a href="dasboard.php" class="nav-item active">Inicio</a>
        <a href="usuarios.php" class="nav-item">Usuarios</a>
        <a href="vps.php" class="nav-item">VPS</a>
        <a href="grupos.php" class="nav-item">Grupos</a>
    </nav>

    <div class="nav-actions">

        <button class="icon-btn" id="demoBtn" title="Generar demo">
            <span class="icon">👤</span>
            <span class="icon-clock">⏱</span>
        </button>

        <button class="icon-btn" id="themeToggle" title="Cambiar tema">
            <span class="theme-icon">🌙</span>
        </button>

        <div class="user-chip">
            <span class="user-avatar">
                <?= strtoupper(substr($_SESSION['admin'], 0, 1)) ?>
            </span>
            <span class="user-name">
                <?= htmlspecialchars($_SESSION['admin']) ?>
            </span>
        </div>

        <a href="logout.php" class="logout-btn">Salir</a>

    </div>

</header>