<!-- ============ SIDEBAR ============ -->
<aside class="ceossh-sidebar" id="ceosshSidebar">

    <div class="sidebar-header">
        <div class="sidebar-brand">
            <div class="sidebar-brand-mark">C</div>
            <div>
                <div class="sidebar-brand-text">CEOSSH</div>
                <span class="sidebar-brand-subtitle">Control Center</span>
            </div>
        </div>
        <button class="sidebar-close" id="sidebarClose" aria-label="Cerrar menú">&times;</button>
    </div>

    <div class="sidebar-content">

        <div class="sidebar-section-title">Principal</div>

        <nav class="sidebar-nav">
            <a href="dashboard.php" data-page="dashboard">
                <span class="sidebar-icon">⌂</span>
                <span>Inicio</span>
            </a>
            <a href="usuarios.php" data-page="usuarios">
                <span class="sidebar-icon">♙</span>
                <span>Usuarios</span>
            </a>
            <a href="vps.php" data-page="vps">
                <span class="sidebar-icon">▣</span>
                <span>VPS</span>
            </a>
            <a href="grupos.php" data-page="grupos">
                <span class="sidebar-icon">▦</span>
                <span>Grupos</span>
            </a>
        </nav>

        <div class="sidebar-section-title">Sistema</div>

        <nav class="sidebar-nav">
            <a href="#" id="sidebarDemo">
                <span class="sidebar-icon">✦</span>
                <span>Generar Demo</span>
            </a>
            <a href="logout.php">
                <span class="sidebar-icon">↪</span>
                <span>Cerrar sesión</span>
            </a>
        </nav>

    </div>

    <div class="sidebar-footer">
        <div class="sidebar-status">
            <span class="status-dot"></span>
            <div class="status-text">
                <strong>Sistema operativo</strong>
                Todos los servicios disponibles
            </div>
        </div>
    </div>

</aside>