<?php
session_name('ceossh_sess');
session_start();
require_once __DIR__ . '/../config/config.php';

if (!empty($_SESSION['admin'])) {
    header('Location: dashboard.php');
    exit;
}

$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username'] ?? '');
    $password = $_POST['password'] ?? '';

    if ($username === '' || $password === '') {
        $error = 'Completa todos los campos';
    } else {
        try {
            $pdo = new PDO(
                'mysql:host=' . DB_HOST . ';dbname=' . DB_NAME . ';charset=utf8mb4',
                DB_USER, DB_PASS,
                [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]
            );

            $stmt = $pdo->prepare("SELECT * FROM panel_admins WHERE username = ? LIMIT 1");
            $stmt->execute([$username]);
            $admin = $stmt->fetch(PDO::FETCH_ASSOC);

            if ($admin && password_verify($password, $admin['password'])) {
                $_SESSION['admin'] = $admin['username'];
                $_SESSION['admin_id'] = $admin['id'];
                $pdo->prepare("UPDATE panel_admins SET last_login = NOW() WHERE id = ?")
                    ->execute([$admin['id']]);
                header('Location: dashboard.php');
                exit;
            }
            $error = 'Credenciales inválidas';
        } catch (Throwable $e) {
            $error = 'Error de conexión con la base de datos';
        }
    }
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>CEOSSH — Login</title>
    <link rel="stylesheet" href="assets/css/main.css">
</head>
<body class="login-body">
    <form method="POST" class="login-box" autocomplete="off">
        <h1 class="brand">CEOSSH</h1>
        <p class="subtitle">Panel de Gestión</p>

        <?php if ($error): ?>
            <div class="alert error"><?= htmlspecialchars($error) ?></div>
        <?php endif; ?>

        <input type="text" name="username" placeholder="Usuario" required autofocus>
        <input type="password" name="password" placeholder="Contraseña" required>

        <button type="submit">Ingresar</button>

        <p class="footer"><?= htmlspecialchars(SERVER_IP) ?> — v<?= CEOSSH_VERSION ?></p>
    </form>
</body>
</html>