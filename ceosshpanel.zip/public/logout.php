<?php
session_name('ceossh_sess');
session_start();
session_destroy();
header('Location: index.php');
exit;