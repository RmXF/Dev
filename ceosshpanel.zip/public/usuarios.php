<?php
session_name('ceossh_sess');
session_start();

require_once '/opt/ceossh/config/config.php';

if (empty($_SESSION['admin'])) {
    header('Location: index.php');
    exit;
}

try {
    $pdo = new PDO(
        'mysql:host=' . DB_HOST . ';dbname=' . DB_NAME . ';charset=utf8mb4',
        DB_USER, DB_PASS,
        [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]
    );

    $groups = $pdo->query("SELECT id, name FROM vps_groups ORDER BY name")->fetchAll(PDO::FETCH_ASSOC);
} catch (Throwable $e) {
    die('Error de conexión: ' . $e->getMessage());
}
?>
<!DOCTYPE html>
<html lang="es" data-theme="dark">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>CEOSSH — Gestión de Usuarios</title>

    <script>
    (function () {
        const t = localStorage.getItem('ceossh_theme');
        const prefersDark = window.matchMedia('(prefers-color-scheme: dark)').matches;
        document.documentElement.setAttribute('data-theme', t || (prefersDark ? 'dark' : 'light'));
    })();
    </script>

    <link rel="stylesheet" href="assets/css/main.css">
    <link rel="stylesheet" href="assets/css/dashboard.css">
    <link rel="stylesheet" href="assets/css/sidebar.css">
    <link rel="stylesheet" href="assets/css/usuarios.css">
</head>
<body>

<?php require __DIR__ . '/partials/sidebar.php'; ?>

<div class="sidebar-overlay" id="sidebarOverlay"></div>

<?php require __DIR__ . '/partials/header.php'; ?>

<main class="dashboard">

    <div class="page-title">
        <h1>Gestión de Usuarios SSH</h1>
        <p class="muted">Administra las cuentas SSH creadas en el sistema</p>
    </div>

    <!-- Submenú -->
    <div class="users-actions">
        <button class="btn-primary" id="openAddUser">
            <span>➕</span> Agregar Usuario
        </button>
        <button class="btn-secondary" data-filter="all" id="filterAll">
            <span>📋</span> Listado
        </button>
        <button class="btn-secondary" data-filter="expired" id="filterExpired">
            <span>⛔</span> Vencidos
        </button>
        <button class="btn-danger" id="deleteAll">
            <span>🗑</span> Eliminar Todos
        </button>
    </div>

    <!-- Info filtro activo -->
    <div class="filter-info" id="filterInfo"></div>

    <!-- Tabla -->
    <section class="users-table-wrap">
        <table class="users-table" id="usersTable">
            <thead>
                <tr>
                    <th>Usuario</th>
                    <th>Contraseña</th>
                    <th>Grupo</th>
                    <th>Límite</th>
                    <th>Vencimiento</th>
                    <th>Estado</th>
                    <th>Acciones</th>
                </tr>
            </thead>
            <tbody id="usersTbody">
                <tr><td colspan="7" class="loading-row">Cargando usuarios...</td></tr>
            </tbody>
        </table>

        <div class="empty-state hidden" id="emptyState">
            <div class="empty-icon">👥</div>
            <h3>No hay usuarios</h3>
            <p class="muted">Crea el primer usuario con el botón de arriba.</p>
        </div>
    </section>

</main>

<!-- ============ MODAL: Agregar Usuario ============ -->
<div class="modal-overlay" id="addUserModal">
    <div class="modal">
        <div class="modal-header">
            <h3 id="userModalTitle">Agregar Usuario</h3>
            <button class="modal-close" data-close>&times;</button>
        </div>

        <form id="userForm" class="modal-body">
            <input type="hidden" name="id" id="u-id">

            <label class="field">
                <span>Usuario</span>
                <div class="input-with-btn">
                    <input type="text" name="username" id="u-username" placeholder="usuario123" required>
                    <button type="button" class="mini-btn" id="genUser" title="Generar aleatorio">🎲</button>
                </div>
            </label>

            <label class="field">
                <span>Contraseña</span>
                <div class="input-with-btn">
                    <input type="text" name="password" id="u-password" placeholder="••••••••" required>
                    <button type="button" class="mini-btn" id="genPass" title="Generar aleatoria">🎲</button>
                </div>
            </label>

            <label class="field">
                <span>Grupo</span>
                <select name="group_id" id="u-group">
                    <option value="">Sin grupo</option>
                    <?php foreach ($groups as $g): ?>
                        <option value="<?= (int)$g['id'] ?>"><?= htmlspecialchars($g['name']) ?></option>
                    <?php endforeach; ?>
                </select>
            </label>

            <div class="field-row">
                <label class="field">
                    <span>Límite conexiones</span>
                    <input type="number" name="connection_limit" id="u-limit" value="1" min="1" max="100" required>
                </label>

                <label class="field">
                    <span>Duración (días)</span>
                    <input type="number" name="days" id="u-days" value="30" min="1" max="3650" required>
                </label>
            </div>

            <div class="modal-feedback" id="userFeedback"></div>
        </form>

        <div class="modal-footer">
            <button class="btn-secondary" data-close>Cancelar</button>
            <button class="btn-primary" id="userSubmit">Generar Cuenta</button>
        </div>
    </div>
</div>

<!-- ============ MODAL: Credenciales generadas ============ -->
<div class="modal-overlay" id="credModal">
    <div class="modal modal-credentials">
        <div class="modal-header cred-success">
            <h3>✓ Cuenta Generada</h3>
            <button class="modal-close" data-close>&times;</button>
        </div>

        <div class="modal-body">
            <div class="cred-row">
                <span class="cred-label">Usuario</span>
                <span class="cred-value" id="c-user">—</span>
            </div>
            <div class="cred-row">
                <span class="cred-label">Contraseña</span>
                <span class="cred-value" id="c-pass">—</span>
            </div>
            <div class="cred-row">
                <span class="cred-label">Vencimiento</span>
                <span class="cred-value" id="c-exp">—</span>
            </div>
            <div class="cred-row">
                <span class="cred-label">Límite</span>
                <span class="cred-value" id="c-lim">—</span>
            </div>
            <div class="cred-row">
                <span class="cred-label">Grupo</span>
                <span class="cred-value" id="c-group">—</span>
            </div>

            <div class="cred-hint">
                Comparte estos datos con el cliente. La cuenta se activará automáticamente.
            </div>
        </div>

        <div class="modal-footer">
            <button class="btn-secondary" id="copyCreds">📋 Copiar</button>
            <button class="btn-secondary" id="shareCreds">🔗 Compartir</button>
            <button class="btn-primary" data-close>Cerrar</button>
        </div>
    </div>
</div>

<script>
document.querySelector('[data-section="users"]')?.classList.add('active');
document.querySelector('[data-section="home"]')?.classList.remove('active');
</script>
<script src="assets/js/sidebar.js"></script>
<script src="assets/js/theme.js"></script>
<script src="assets/js/usuarios.js"></script>
</body>
</html>