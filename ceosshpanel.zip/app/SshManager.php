<?php
/**
 * CEOSSH - SshManager
 * Maneja conexiones SSH salientes del panel hacia las VPS remotas
 */

class SshManager
{
    const SSH_TIMEOUT = 10;

    /**
     * Ejecuta un comando remoto en una VPS por SSH.
     */
    public static function exec(array $vps, string $cmd): array
    {
        $host    = $vps['host'] ?? '';
        $port    = (int)($vps['ssh_port'] ?? 22);
        $user    = $vps['ssh_user'] ?? 'root';
        $passB64 = $vps['ssh_pass'] ?? '';
        $pass    = $passB64 ? base64_decode($passB64) : '';

        if (!$host || !$user) {
            return ['ok' => false, 'output' => '', 'error' => 'Datos de VPS incompletos'];
        }

        if ($pass === '') {
            return self::execWithKey($host, $port, $user, $cmd);
        }

        return self::execWithPassword($host, $port, $user, $pass, $cmd);
    }

    private static function execWithPassword(string $host, int $port, string $user, string $pass, string $cmd): array
    {
        $check = shell_exec('which sshpass 2>/dev/null');
        if (!$check) {
            return ['ok' => false, 'output' => '', 'error' => 'sshpass no está instalado'];
        }

        $sshCmd = sprintf(
            'sshpass -p %s ssh -o StrictHostKeyChecking=no -o UserKnownHostsFile=/dev/null ' .
            '-o ConnectTimeout=%d -o LogLevel=ERROR -p %d %s@%s %s',
            escapeshellarg($pass),
            self::SSH_TIMEOUT,
            $port,
            escapeshellarg($user),
            escapeshellarg($host),
            escapeshellarg($cmd)
        );

        return self::run($sshCmd);
    }

    private static function execWithKey(string $host, int $port, string $user, string $cmd): array
    {
        $sshCmd = sprintf(
            'ssh -o StrictHostKeyChecking=no -o UserKnownHostsFile=/dev/null ' .
            '-o ConnectTimeout=%d -o BatchMode=yes -o LogLevel=ERROR ' .
            '-p %d %s@%s %s',
            self::SSH_TIMEOUT,
            $port,
            escapeshellarg($user),
            escapeshellarg($host),
            escapeshellarg($cmd)
        );

        return self::run($sshCmd);
    }

    private static function run(string $sshCmd): array
    {
        $wrapped = 'timeout ' . (self::SSH_TIMEOUT + 5) . ' ' . $sshCmd . ' 2>&1';
        $output = shell_exec($wrapped) ?? '';

        $lower = strtolower($output);
        $hasError = (
            str_contains($lower, 'permission denied') ||
            str_contains($lower, 'connection refused') ||
            str_contains($lower, 'no route to host') ||
            str_contains($lower, 'connection timed out') ||
            str_contains($lower, 'host key verification failed')
        );

        return [
            'ok'     => !$hasError,
            'output' => trim($output),
            'error'  => $hasError ? trim($output) : '',
        ];
    }

    /**
     * Prueba la conexión SSH a una VPS.
     */
    public static function testConnection(array $vps): array
    {
        $result = self::exec($vps, 'echo CEOSSH_OK');
        $result['ok'] = $result['ok'] && str_contains($result['output'], 'CEOSSH_OK');
        return $result;
    }

    /**
     * Crea un usuario SSH remoto en la VPS.
     */
    public static function createUser(array $vps, string $username, string $password, int $days, int $limit): array
    {
        $expires = date('Y-m-d', strtotime("+{$days} days"));

        $script = <<<BASH
set -e
USER="$username"
PASS="$password"
DAYS="$days"
LIMIT="$limit"
EXPIRES="$expires"

if ! echo "\$USER" | grep -qE '^[a-zA-Z0-9_]{3,32}\$'; then
    echo "ERROR: nombre de usuario inválido"
    exit 1
fi

if id "\$USER" &>/dev/null; then
    echo "\$USER:\$PASS" | chpasswd
    chage -M "\$DAYS" -E "\$EXPIRES" "\$USER"
    echo "CEOSSH_USER_UPDATED"
    exit 0
fi

useradd -m -s /bin/bash "\$USER"
echo "\$USER:\$PASS" | chpasswd
chage -M "\$DAYS" -E "\$EXPIRES" "\$USER"

if [ "\$LIMIT" -gt 0 ]; then
    sed -i "/^\$USER /d" /etc/security/limits.conf
    echo "\$USER hard maxlogins \$LIMIT" >> /etc/security/limits.conf
fi

echo "CEOSSH_USER_CREATED"
BASH;

        $result = self::exec($vps, $script);
        $result['ok'] = $result['ok'] &&
            (str_contains($result['output'], 'CEOSSH_USER_CREATED') ||
             str_contains($result['output'], 'CEOSSH_USER_UPDATED'));

        return $result;
    }

    /**
     * Elimina un usuario SSH remoto en la VPS y corta TODAS las sesiones.
     * Usa 5 métodos para asegurar que no quede ninguna sesión activa.
     */
    public static function deleteUser(array $vps, string $username): array
    {
        $script = <<<BASH
USER="$username"
if ! echo "\$USER" | grep -qE '^[a-zA-Z0-9_]{3,32}\$'; then
    echo "ERROR: nombre inválido"
    exit 1
fi

if id "\$USER" &>/dev/null; then
    # 1. Bloquear cuenta (impide nuevos logins inmediatamente)
    passwd -l "\$USER" 2>/dev/null || true
    usermod -s /usr/sbin/nologin "\$USER" 2>/dev/null || true

    # 2. Cortar con pkill (por nombre)
    pkill -9 -u "\$USER" 2>/dev/null || true

    # 3. Cortar con killall
    killall -9 -u "\$USER" 2>/dev/null || true

    # 4. Cortar por UID (más agresivo)
    UID_NUM=\$(id -u "\$USER" 2>/dev/null)
    if [ -n "\$UID_NUM" ]; then
        for pid in \$(ps -o pid= -u "\$UID_NUM" 2>/dev/null); do
            kill -9 "\$pid" 2>/dev/null || true
        done
    fi

    # 5. Cortar sesiones SSH activas del usuario
    SSHD_PIDS=\$(ps -eo pid,user | awk -v u="\$USER" '\$2==u {print \$1}')
    for pid in \$SSHD_PIDS; do
        kill -9 "\$pid" 2>/dev/null || true
    done
fi

# 6. Eliminar el usuario del sistema (con su home)
userdel -r "\$USER" 2>/dev/null || true

# 7. Limpiar límites
sed -i "/^\$USER /d" /etc/security/limits.conf 2>/dev/null || true

echo "CEOSSH_USER_DELETED"
BASH;

        $result = self::exec($vps, $script);
        $result['ok'] = $result['ok'] && str_contains($result['output'], 'CEOSSH_USER_DELETED');
        return $result;
    }

    /**
     * Renueva la expiración de un usuario SSH remoto.
     */
    public static function renewUser(array $vps, string $username, int $days): array
    {
        $expires = date('Y-m-d', strtotime("+{$days} days"));

        $script = <<<BASH
USER="$username"
DAYS="$days"
EXPIRES="$expires"

if ! id "\$USER" &>/dev/null; then
    echo "CEOSSH_USER_MISSING"
    exit 1
fi

chage -M "\$DAYS" -E "\$EXPIRES" "\$USER"
echo "CEOSSH_USER_RENEWED"
BASH;

        $result = self::exec($vps, $script);
        $result['ok'] = $result['ok'] && str_contains($result['output'], 'CEOSSH_USER_RENEWED');
        return $result;
    }

    /**
     * Refresca el estado de una VPS (ping + uptime).
     */
    public static function ping(array $vps): array
    {
        return self::exec($vps, 'uptime');
    }
}