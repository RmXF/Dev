<?php
/**
 * CEOSSH - SshManager
 * Maneja conexiones SSH salientes del panel hacia las VPS remotas
 */

class SshManager
{
    /** Timeout de conexión en segundos */
    const SSH_TIMEOUT = 10;

    /**
     * Ejecuta un comando remoto en una VPS por SSH.
     *
     * @param array  $vps  Datos de la VPS: host, ssh_port, ssh_user, ssh_pass (base64)
     * @param string $cmd  Comando a ejecutar
     * @return array ['ok' => bool, 'output' => string, 'error' => string]
     */
    public static function exec(array $vps, string $cmd): array
    {
        $host    = $vps['host'] ?? '';
        $port    = (int)($vps['ssh_port'] ?? 22);
        $user    = $vps['ssh_user'] ?? 'root';
        $passB64 = $vps['ssh_pass'] ?? '';
        $pass    = $passB64 ? base64_decode($passB64) : '';

        if (!$host || !$user) {
            return ['ok' => false, 'output' => '', 'error' => 'Datos de VPS incompletos'];
        }

        // Si no hay password, intentar con llave SSH
        if ($pass === '') {
            return self::execWithKey($host, $port, $user, $cmd);
        }

        return self::execWithPassword($host, $port, $user, $pass, $cmd);
    }

    /**
     * Conexión con contraseña usando sshpass.
     */
    private static function execWithPassword(string $host, int $port, string $user, string $pass, string $cmd): array
    {
        // Verificar que sshpass esté instalado
        $check = shell_exec('which sshpass 2>/dev/null');
        if (!$check) {
            return ['ok' => false, 'output' => '', 'error' => 'sshpass no está instalado en el servidor del panel'];
        }

        $sshCmd = sprintf(
            'sshpass -p %s ssh -o StrictHostKeyChecking=no -o UserKnownHostsFile=/dev/null ' .
            '-o ConnectTimeout=%d -o LogLevel=ERROR -p %d %s@%s %s',
            escapeshellarg($pass),
            self::SSH_TIMEOUT,
            $port,
            escapeshellarg($user),
            escapeshellarg($host),
            escapeshellarg($cmd)
        );

        return self::run($sshCmd);
    }

    /**
     * Conexión con llave SSH (para usuarios sin contraseña).
     */
    private static function execWithKey(string $host, int $port, string $user, string $cmd): array
    {
        $sshCmd = sprintf(
            'ssh -o StrictHostKeyChecking=no -o UserKnownHostsFile=/dev/null ' .
            '-o ConnectTimeout=%d -o BatchMode=yes -o LogLevel=ERROR ' .
            '-p %d %s@%s %s',
            self::SSH_TIMEOUT,
            $port,
            escapeshellarg($user),
            escapeshellarg($host),
            escapeshellarg($cmd)
        );

        return self::run($sshCmd);
    }

    /**
     * Ejecuta el comando con timeout y devuelve resultado estructurado.
     */
    private static function run(string $sshCmd): array
    {
        // Envolver con timeout para evitar comandos colgados
        $wrapped = 'timeout ' . (self::SSH_TIMEOUT + 5) . ' ' . $sshCmd . ' 2>&1';

        $output = shell_exec($wrapped);
        $output = $output ?? '';

        $lower = strtolower($output);
        $hasError = (
            str_contains($lower, 'permission denied') ||
            str_contains($lower, 'connection refused') ||
            str_contains($lower, 'no route to host') ||
            str_contains($lower, 'connection timed out') ||
            str_contains($lower, 'host key verification failed')
        );

        return [
            'ok'     => !$hasError,
            'output' => trim($output),
            'error'  => $hasError ? trim($output) : '',
        ];
    }

    /**
     * Prueba la conexión SSH a una VPS.
     */
    public static function testConnection(array $vps): array
    {
        $result = self::exec($vps, 'echo CEOSSH_OK');
        $result['ok'] = $result['ok'] && str_contains($result['output'], 'CEOSSH_OK');
        return $result;
    }

    /**
     * Crea un usuario SSH remoto en la VPS.
     */
    public static function createUser(array $vps, string $username, string $password, int $days, int $limit): array
    {
        $expires = date('Y-m-d', strtotime("+{$days} days"));

        // Script bash robusto que se ejecuta en la VPS remota
        $script = <<<BASH
set -e
USER="$username"
PASS="$password"
DAYS="$days"
LIMIT="$limit"
EXPIRES="$expires"

# Sanitizar nombre
if ! echo "\$USER" | grep -qE '^[a-zA-Z0-9_]{3,32}$'; then
    echo "ERROR: nombre de usuario inválido"
    exit 1
fi

# Si ya existe, actualizar
if id "\$USER" &>/dev/null; then
    echo "\$USER:\$PASS" | chpasswd
    chage -M "\$DAYS" -E "\$EXPIRES" "\$USER"
    echo "CEOSSH_USER_UPDATED"
    exit 0
fi

# Crear usuario
useradd -m -s /bin/bash "\$USER"
echo "\$USER:\$PASS" | chpasswd
chage -M "\$DAYS" -E "\$EXPIRES" "\$USER"

# Límite de conexiones simultáneas
if [ "\$LIMIT" -gt 0 ]; then
    sed -i "/^\$USER /d" /etc/security/limits.conf
    echo "\$USER hard maxlogins \$LIMIT" >> /etc/security/limits.conf
fi

echo "CEOSSH_USER_CREATED"
BASH;

        $result = self::exec($vps, $script);
        $result['ok'] = $result['ok'] &&
            (str_contains($result['output'], 'CEOSSH_USER_CREATED') ||
             str_contains($result['output'], 'CEOSSH_USER_UPDATED'));

        return $result;
    }

    /**
     * Elimina un usuario SSH remoto en la VPS.
     */
    public static function deleteUser(array $vps, string $username): array
    {
        $script = <<<BASH
USER="$username"
if ! echo "\$USER" | grep -qE '^[a-zA-Z0-9_]{3,32}$'; then
    echo "ERROR: nombre inválido"
    exit 1
fi

pkill -KILL -u "\$USER" 2>/dev/null || true
userdel -r "\$USER" 2>/dev/null || true
sed -i "/^\$USER /d" /etc/security/limits.conf

echo "CEOSSH_USER_DELETED"
BASH;

        $result = self::exec($vps, $script);
        $result['ok'] = $result['ok'] && str_contains($result['output'], 'CEOSSH_USER_DELETED');
        return $result;
    }

    /**
     * Renueva la expiración de un usuario SSH remoto.
     */
    public static function renewUser(array $vps, string $username, int $days): array
    {
        $expires = date('Y-m-d', strtotime("+{$days} days"));

        $script = <<<BASH
USER="$username"
DAYS="$days"
EXPIRES="$expires"

if ! id "\$USER" &>/dev/null; then
    echo "CEOSSH_USER_MISSING"
    exit 1
fi

chage -M "\$DAYS" -E "\$EXPIRES" "\$USER"
echo "CEOSSH_USER_RENEWED"
BASH;

        $result = self::exec($vps, $script);
        $result['ok'] = $result['ok'] && str_contains($result['output'], 'CEOSSH_USER_RENEWED');
        return $result;
    }

    /**
     * Refresca el estado (ping + uptime) de una VPS.
     */
    public static function ping(array $vps): array
    {
        return self::exec($vps, 'uptime');
    }
}