<?php
/**
 * CEOSSH - VpsHelper
 * Utilidades para obtener VPS desde la base de datos
 */

class VpsHelper
{
    /**
     * Devuelve todas las VPS activas de un grupo.
     */
    public static function getVpsByGroup(PDO $pdo, ?int $groupId): array
    {
        if (!$groupId) return [];

        $stmt = $pdo->prepare("
            SELECT id, name, host, ssh_port, ssh_user, ssh_pass
            FROM vps
            WHERE group_id = ? AND status = 'active'
        ");
        $stmt->execute([$groupId]);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    /**
     * Devuelve una VPS por ID.
     */
    public static function getVpsById(PDO $pdo, int $id): ?array
    {
        $stmt = $pdo->prepare("SELECT * FROM vps WHERE id = ?");
        $stmt->execute([$id]);
        $vps = $stmt->fetch(PDO::FETCH_ASSOC);
        return $vps ?: null;
    }

    /**
     * Ejecuta una función sobre todas las VPS de un grupo.
     * Devuelve un resumen de resultados.
     *
     * @param callable $fn  function(array $vps): array
     */
    public static function forEachVps(array $vpsList, callable $fn): array
    {
        $results = [];
        foreach ($vpsList as $vps) {
            $results[] = [
                'vps_id'   => $vps['id'] ?? null,
                'vps_name' => $vps['name'] ?? 'desconocida',
                'host'     => $vps['host'] ?? '',
                'result'   => $fn($vps),
            ];
        }
        return $results;
    }
}