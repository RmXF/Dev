#!/bin/bash
# CEOSSH - Actualiza un usuario SSH existente
# Uso: update_ssh_user.sh <usuario> <password> <dias> <limite>

USER="$1"; PASS="$2"; DAYS="$3"; LIMIT="$4"
[[ -z "$USER" || -z "$PASS" ]] && exit 1

if ! id "$USER" &>/dev/null; then
    # Si no existe, crearlo
    exec /opt/ceossh/scripts/create_ssh_user.sh "$USER" "$PASS" "$DAYS" "$LIMIT"
fi

echo "$USER:$PASS" | chpasswd
chage -M "$DAYS" -E "$(date -d "+$DAYS days" +%Y-%m-%d)" "$USER"

if [[ "$LIMIT" -gt 0 ]]; then
    sed -i "/^$USER /d" /etc/security/limits.conf
    echo "$USER hard maxlogins $LIMIT" >> /etc/security/limits.conf
fi

echo "OK"