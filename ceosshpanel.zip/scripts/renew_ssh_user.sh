#!/bin/bash
# CEOSSH - Renueva la expiración de un usuario SSH
# Uso: renew_ssh_user.sh <usuario> <dias>

USER="$1"; DAYS="$2"
[[ -z "$USER" || -z "$DAYS" ]] && exit 1

if id "$USER" &>/dev/null; then
    chage -E "$(date -d "+$DAYS days" +%Y-%m-%d)" "$USER"
    echo "OK"
else
    echo "Usuario no existe"
    exit 1
fi