#!/bin/bash
# CEOSSH - Elimina un usuario SSH
# Uso: delete_ssh_user.sh <usuario>

USER="$1"
[[ -z "$USER" ]] && exit 1

# Matar todas las sesiones activas
pkill -KILL -u "$USER" 2>/dev/null || true

# Eliminar usuario y su home
userdel -r "$USER" 2>/dev/null || true

# Quitar límites
sed -i "/^$USER /d" /etc/security/limits.conf

echo "OK"