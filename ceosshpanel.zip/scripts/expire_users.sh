#!/bin/bash
# CEOSSH - Cron: expira y corta usuarios vencidos (local + VPS remotas)

CONFIG="/opt/ceossh/config/config.php"
[[ -f "$CONFIG" ]] || exit 1

DB_NAME=$(grep "DB_NAME" "$CONFIG" | cut -d"'" -f4)
DB_USER=$(grep "DB_USER" "$CONFIG" | cut -d"'" -f4)
DB_PASS=$(grep "DB_PASS" "$CONFIG" | cut -d"'" -f4)

# Llamar al API interno de PHP para propagar por SSH
php -r "
require '/opt/ceossh/config/config.php';
require '/opt/ceossh/app/SshManager.php';
require '/opt/ceossh/app/VpsHelper.php';

\$pdo = new PDO('mysql:host='.DB_HOST.';dbname='.DB_NAME.';charset=utf8mb4', DB_USER, DB_PASS);

\$expired = \$pdo->query(\"
    SELECT id, username, group_id FROM ssh_users
    WHERE expires_at < NOW() AND status = 'active'
\")->fetchAll(PDO::FETCH_ASSOC);

foreach (\$expired as \$u) {
    // Eliminar de VPS remotas
    if (\$u['group_id']) {
        \$vpsList = VpsHelper::getVpsByGroup(\$pdo, (int)\$u['group_id']);
        foreach (\$vpsList as \$vps) {
            SshManager::deleteUser(\$vps, \$u['username']);
        }
    }
    // Marcar como vencido
    \$pdo->prepare('UPDATE ssh_users SET status=\"expired\" WHERE id=?')->execute([\$u['id']]);
    file_put_contents('/opt/ceossh/storage/logs/expire.log', date('Y-m-d H:i:s').\" - Vencido: {\$u['username']}\n\", FILE_APPEND);
}
echo 'Procesados: '.count(\$expired).PHP_EOL;
" >> /opt/ceossh/storage/logs/cron.log 2>&1