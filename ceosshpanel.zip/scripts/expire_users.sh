#!/bin/bash
# CEOSSH - Cron: expira y corta usuarios vencidos

CONFIG="/opt/ceossh/config/config.php"
[[ -f "$CONFIG" ]] || exit 1

DB_NAME=$(grep "DB_NAME" "$CONFIG" | cut -d"'" -f4)
DB_USER=$(grep "DB_USER" "$CONFIG" | cut -d"'" -f4)
DB_PASS=$(grep "DB_PASS" "$CONFIG" | cut -d"'" -f4)

# Buscar usuarios vencidos que aún estén activos
EXPIRED=$(mysql -u"$DB_USER" -p"$DB_PASS" "$DB_NAME" -N -e "
    SELECT username FROM ssh_users
    WHERE expires_at < NOW() AND status = 'active';
")

for u in $EXPIRED; do
    # Cortar sesiones
    pkill -KILL -u "$u" 2>/dev/null || true

    # Eliminar usuario del SO
    /opt/ceossh/scripts/delete_ssh_user.sh "$u" >/dev/null 2>&1

    # Marcar como vencido
    mysql -u"$DB_USER" -p"$DB_PASS" "$DB_NAME" -e "
        UPDATE ssh_users SET status = 'expired' WHERE username = '$u';
    "

    echo "$(date) - Usuario vencido cortado: $u" >> /opt/ceossh/storage/logs/expire.log
done