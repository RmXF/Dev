#!/bin/bash
# CEOSSH - Crea un usuario SSH en el sistema
# Uso: create_ssh_user.sh <usuario> <password> <dias> <limite>

USER="$1"; PASS="$2"; DAYS="$3"; LIMIT="$4"

[[ -z "$USER" || -z "$PASS" ]] && { echo "Faltan parámetros"; exit 1; }

# Si ya existe, solo actualizar
if id "$USER" &>/dev/null; then
    echo "$USER:$PASS" | chpasswd
    chage -M "$DAYS" -E "$(date -d "+$DAYS days" +%Y-%m-%d)" "$USER"
    exit 0
fi

# Crear usuario con shell válido pero sin acceso a comandos (solo túneles)
useradd -m -s /bin/bash "$USER"
echo "$USER:$PASS" | chpasswd

# Fecha de expiración
chage -M "$DAYS" -E "$(date -d "+$DAYS days" +%Y-%m-%d)" "$USER"

# Límite de conexiones simultáneas
if [[ "$LIMIT" -gt 0 ]]; then
    # Eliminar entradas previas del usuario
    sed -i "/^$USER /d" /etc/security/limits.conf
    echo "$USER hard maxlogins $LIMIT" >> /etc/security/limits.conf
fi

echo "OK"