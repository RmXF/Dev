# CEOSSH 2.0 — Reemplazar el panel existente

Este paquete incluye todos los archivos, pero la nueva cola, las alertas y el cifrado requieren **migración de la base de datos**. No reemplaces solamente `public`.

## Pasos

1. Subí el ZIP a `/root/` y extraelo allí, fuera de `/opt/ceossh`.
2. Confirmá que el panel anterior está en `/opt/ceossh` y tiene `config/config.php`. Si tu ruta es diferente, adaptá el despliegue antes de ejecutarlo.
3. Revisá con qué zona horaria se guardaron los vencimientos originales. Si `config.php` anterior configuraba `date_default_timezone_set`, esa zona se detecta. Si era una zona distinta de PHP CLI, agregá al config anterior `define('LEGACY_DATA_TIMEZONE', 'America/Argentina/Buenos_Aires');` (o la zona correcta). La migración convierte esas fechas a UTC una sola vez. Sin una definición usa la zona PHP anterior, generalmente UTC.
4. Ejecutá:

```bash
cd /root
unzip CEOSSH_2.0_completo.zip
cd ceossh-completo
sudo bash install.sh --update
```

El actualizador primero bloquea el worker, respalda la base de datos y el directorio completo en `/root/ceossh-backups/FECHA/`, conserva `config.php`, claves y `storage`, copia el código nuevo, migra tablas y configura permisos/cron. Si el respaldo falla, no continúa con el reemplazo.

La configuración Apache existente se conserva. Revisá que su `DocumentRoot` sea `/opt/ceossh/public`. Si antes tenías una copia física del frontend en `/var/www/...`, modificá el VirtualHost para apuntar a `/opt/ceossh/public` y comprobá con `apache2ctl configtest`; una copia antigua no se actualizará por sí sola.

Las sesiones y administradores previos siguen siendo compatibles. El config anterior puede seguir mostrando su constante de versión vieja; las nuevas pantallas muestran 2.0.

## Cuentas y VPS que ya existían

El esquema anterior no guardaba la asociación real por servidor. La migración conserva como posibles destinos **todas las VPS del grupo anterior, incluso las deshabilitadas**, para poder limpiar cuentas que sigan existiendo en ellas. Revisá esas asociaciones si tu configuración histórica era distinta.

Los scripts nuevos protegen cuentas del sistema y no modifican cuentas remotas existentes que no hayan sido registradas como administradas por CEOSSH. Para tus cuentas anteriores:

```bash
sudo bash /opt/ceossh/scripts/trust-vps.sh IP_VPS PUERTO
sudo php /opt/ceossh/scripts/adopt.php ID_VPS CONFIRMO
```

Obtené el ID de VPS desde la tabla o el enlace de sus acciones; el comando registra las cuentas que la migración asoció a ese servidor, solo si existen y tienen UID normal (1000–65533). Revisá la lista antes de ejecutarlo. No crea usuarios ni cambia sus contraseñas. Si una cuenta no existe, luego la sincronización la crea.

Después probá conexión, presioná Sincronizar y revisá Operaciones. Las cuentas anteriores siguen funcionando en la VPS hasta que haya una operación real sobre ellas.

El nombre de cuenta queda fijo para evitar cuentas huérfanas. Editar grupo programa bajas en el grupo anterior y altas en el nuevo; editar una cuenta conserva el vencimiento. Renovar suma días desde el mayor entre el vencimiento actual y el momento presente.

Deshabilitar una VPS evita nuevas asignaciones y posterga actualizaciones de sus cuentas existentes. **No la apaga**. Las bajas por vencimiento o eliminación sí se intentan aun si está deshabilitada. Para quitar una VPS del panel deben quedar confirmadas sus bajas y no tener tareas pendientes.

## Verificación después del reemplazo

- Login y datos originales visibles.
- Crear una cuenta de prueba propia, revisar alta confirmada en Operaciones, renovar y eliminar.
- Worker activo en Ajustes tras 1–2 minutos.
- Estado SSH y muestras reales en Inicio.
- La contraseña no aparece en el listado; se consulta desde Datos y queda auditada.
- Bajas fallidas quedan visibles en Bajas pendientes, con reintento.

## Volver al código anterior

Primero detené el cron nuevo y cualquier cron anterior que llame a `expire_users.sh`. Restaurá **juntos** los archivos y SQL del mismo respaldo y reactivá tu configuración original. El código anterior no interpreta las contraseñas cifradas nuevas: restaurar solamente archivos no alcanza. Revisá manualmente cambios remotos realizados desde el upgrade; restaurar SQL no deshace cuentas ni contraseñas ya modificadas en VPS.

No se borra ni reinstala MySQL. No se restablecen contraseñas de administradores existentes. El actualizador necesita acceso a la base de datos mediante el config anterior y `mysqldump`.
