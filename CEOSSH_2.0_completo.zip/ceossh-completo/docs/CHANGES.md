# Cambios de CEOSSH 2.0

## Interfaz

Diseño unificado, adaptable a celular, menú lateral, tema persistente, formularios compartidos, avisos breves, confirmaciones y navegación funcional. CSS de usuarios completo. Búsqueda, paginación y filtros por grupo/estado. Demos con duración en minutos. Nuevas pantallas de Alertas, Operaciones y Ajustes.

## Backend

Conexión y seguridad centralizadas. Cifrado AES-256-GCM compatible con migración Base64 anterior. CSRF en escrituras, regeneración de sesión, límite de intentos de login, contraseñas ocultas en listado y consulta auditada.

SSH con verificación estricta de identidad, claves conocidas, código de salida real y datos transmitidos de forma literal. Protección de cuentas del sistema y cuentas no registradas como administradas por CEOSSH.

Cola de tareas por cuenta y VPS, bloqueos, reintentos y resultados persistentes. Edición conserva vencimiento y evita renombrar cuentas. Cambio de grupo programa bajas antiguas y altas nuevas. Renovación conserva días restantes y recrea cuentas vencidas. Eliminar todos funciona y exige confirmación. Las bajas fallidas conservan el registro y el destino hasta confirmar su aplicación.

Monitoreo real por SSH: CPU, RAM, disco, uptime, carga y sesiones sshd; muestras con fecha. Estado administrativo separado de conectividad. Alertas internas de vencimiento, recursos, conexión y tareas fallidas. Histórico de actividad y consulta de credenciales.

## Instalación

Instalación nueva y actualización con respaldo previo, migración repetible, conversión única de fechas anteriores a UTC, cron y rotación de logs. Configuración, claves y datos existentes se conservan durante actualización.

Ver UPDATE.md antes de reemplazar: migrar la base es obligatorio y las cuentas anteriores necesitan verificar confianza SSH y registrar su gestión.
