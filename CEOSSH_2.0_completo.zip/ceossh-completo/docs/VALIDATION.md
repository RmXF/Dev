# Validación de CEOSSH 2.0

Fecha: 30/09/2026. Revisado sobre el proyecto entregado en ZIP.

## Comprobaciones realizadas

- Sintaxis de 51 archivos PHP con PHP 8.3.
- Sintaxis de 8 archivos JavaScript con Node.
- Sintaxis Bash de 11 scripts.
- Conservación de IDs de páginas, formularios, tablas, botones y modales originales; el modal de demo se comparte mediante un partial.
- Migración sobre MariaDB 10.11 en una base aislada con el esquema original y credenciales Base64. Dos ejecuciones consecutivas sin duplicar asociaciones ni volver a convertir fechas.
- Cifrado autenticado AES-256-GCM, descifrado de credenciales anteriores y rechazo de contenido manipulado.
- Contraseñas con comillas, backticks y sustituciones de shell se transmiten como texto literal; no ejecutan instrucciones.
- Protección de root y rechazo de nombres con caracteres de comandos.
- SSH distingue fallo y éxito mediante código de salida y marcador esperado.
- Respuesta 401 sin autenticación y 403 sin token CSRF.
- Las siete pantallas responden sin avisos ni errores PHP en el entorno aislado.
- Alta de cuenta, edición sin cambiar vencimiento, rechazo de renombrado y renovación conservando días restantes.
- El listado no devuelve contraseñas; la consulta individual exige POST y queda auditada.
- Una baja con conexión SSH fallida conserva la cuenta y una tarea fallida reintentable.
- Se impide eliminar grupos con asociados y VPS con cuentas/tareas pendientes.
- Eliminar todos exige frase de confirmación y programa las bajas del conjunto.
- Con un doble de prueba SSH que devuelve confirmación positiva, el worker completa tareas y elimina registros solo tras confirmar todas las bajas. Esta prueba no modifica usuarios reales.
- Formularios probados mediante Happy DOM contra el backend PHP real: carga de las pantallas y contadores, creación de cuenta, modales, guardado/restauración del tema y apertura/cierre del menú en viewport móvil. No equivale a una inspección gráfica en un navegador de producción.

## Prueba reproducible incluida

```bash
php tests/security.php
```

Usa un directorio temporal y dobles de SSH. No usa la base de datos ni modifica cuentas reales.

## Límites de esta validación

No se ejecutó el instalador sobre tu servidor ni se utilizaron tus credenciales/VPS. El instalador se comprobó por sintaxis y revisión del flujo; Apache, systemd, cron, permisos, SSL y particularidades de tu distribución necesitan verificación en destino.

El navegador gráfico del entorno de trabajo no pudo iniciarse. Se comprobó la lógica DOM, pero queda pendiente la inspección visual con Chrome/Safari reales en tu dispositivo.

Las pruebas positivas de cuentas remotas usan un doble explícito; falta probar useradd/chpasswd/chage/PAM en tus VPS. Las fallas SSH y la preservación de bajas pendientes sí se verificaron con un destino local que no responde.

Antes de entregar cuentas a clientes, comprobá un alta, renovación y baja de una cuenta propia, confirmadas en Operaciones. Consultá INSTALL.md y UPDATE.md para límites de vencimientos, PAM y sincronización.
