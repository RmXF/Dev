# CEOSSH 2.0 — Instalación nueva

Requisitos: Debian/Ubuntu con systemd, PHP 8.1 o superior, Apache, MariaDB/MySQL, acceso root en el servidor del panel y en las VPS administradas. Las VPS remotas requieren Bash, OpenSSH, utilidades GNU, shadow-utils, procps y PAM. No necesita Composer ni npm para funcionar.

## Instalación

1. Subí `CEOSSH_2.0_completo.zip` a `/root/`.
2. Ejecutá:

```bash
cd /root
unzip CEOSSH_2.0_completo.zip
cd ceossh-completo
sudo bash install.sh --install
```

El instalador pregunta usuario y contraseña del administrador (mínimo 12 caracteres) y puerto HTTP dedicado (8088 por defecto). No reemplaza otros VirtualHost ni configura SSL automáticamente. Crea una base de datos y usuario con nombres aleatorios, guarda las credenciales en `/opt/ceossh/config/config.php` y configura un cron cada minuto.

Abrí `http://IP_DEL_SERVIDOR:8088/` si elegiste el puerto predeterminado. Usá un VirtualHost HTTPS o un proxy HTTPS antes de ingresar credenciales desde Internet. Si el firewall está activo, permití solo los puertos que vayas a usar. En un proxy, configurá HTTPS de forma que PHP reciba `HTTPS=on`; no se confía en encabezados arbitrarios del cliente.

La raíz web debe ser `/opt/ceossh/public`. Nunca expongas `/opt/ceossh` completo: contiene configuración y claves.

## Agregar una VPS

1. Desde su consola verificá la huella: `ssh-keygen -lf /etc/ssh/ssh_host_ed25519_key.pub`.
2. En el servidor del panel ejecutá `sudo bash /opt/ceossh/scripts/trust-vps.sh IP_VPS 22` y compará la huella antes de escribir `CONFIRMO`.
3. Creá un grupo desde Grupos.
4. Guardá la VPS con usuario remoto root, puerto, contraseña y grupo.
5. Probá la conexión desde VPS.
6. Creá una cuenta o presioná Sincronizar.
7. Verificá el resultado en Operaciones. El cron aplica las cuentas; guardar no significa aplicación remota confirmada.

Si elegís autenticación por clave, instalá **solo la clave pública** `/opt/ceossh/config/ssh/id_ed25519.pub` en `authorized_keys` de root de la VPS. No compartas la clave privada. La clave privada pertenece al proceso `www-data`, que necesita autenticar operaciones salientes.

## Worker, vencimientos y límites

- Cron: `/etc/cron.d/ceossh`; logs: `/opt/ceossh/storage/logs/worker.log`.
- Procesa hasta 8 tareas y comprueba hasta 3 VPS por ciclo. Con muchas cuentas/servidores el cron distribuye el trabajo entre ciclos; no se promete activación inmediata.
- Los fallos se reintentan desde 1 minuto, con espera creciente hasta 1 hora; también se pueden reintentar desde Operaciones.
- Una cuenta vencida conserva su registro. Se elimina remotamente y una renovación la vuelve a crear si hace falta.
- El corte central se solicita cada minuto; las VPS deben ser alcanzables para confirmarlo. `chage` ofrece expiración local por día, configurada al día siguiente para evitar cortar antes del horario preciso. Si el panel o VPS pierde conexión, el corte exacto puede retrasarse. No se garantiza corte al segundo.
- El límite usa `pam_limits` y `maxlogins`. Revisá que `sshd` utilice PAM y `pam_limits.so` esté activo. Este mecanismo no garantiza contar todos los túneles multiplexados o clientes VPN como conexiones independientes. La interfaz muestra sesiones `sshd`, no consumo de datos ni un detector universal de clientes VPN.
- CPU, RAM, disco, uptime y carga proceden de `/proc` y `df` de la VPS. Cada muestra lleva fecha. La caída del servidor del panel impide nuevas muestras y notificaciones.
- Las alertas son internas al panel; no se envían WhatsApp, correo ni mensajes externos.

## Respaldos

```bash
sudo bash /opt/ceossh/scripts/backup.sh
```

Guardá juntos el respaldo SQL, los archivos y `config/secret.key`. Sin esa clave no se pueden descifrar contraseñas ni tareas. `known_hosts` y la clave SSH también deben preservarse.

## Diagnóstico

```bash
sudo tail -n 80 /opt/ceossh/storage/logs/worker.log
sudo tail -n 80 /var/log/apache2/ceossh-error.log
sudo cat /etc/cron.d/ceossh
sudo -u www-data php /opt/ceossh/scripts/worker.php
```

La ejecución manual del worker realiza tareas pendientes reales. Usala después de revisar Operaciones.

Para instalaciones sin systemd, Nginx o rutas distintas, configurá PHP, base de datos, permisos, cron y DocumentRoot manualmente siguiendo los pasos del instalador; el modo automático se limita a Debian/Ubuntu con Apache.
