#!/usr/bin/env bash
set -euo pipefail
umask 027
trap 'echo "[ERROR] Instalación detenida en línea $LINENO. No continúes sin revisar el mensaje anterior." >&2' ERR
[[ $(id -u) == 0 ]] || { echo 'Ejecutá con sudo bash install.sh'; exit 1; }
MODE=${1:---install}
[[ "$MODE" == --install || "$MODE" == --update ]] || { echo 'Uso: install.sh --install | --update'; exit 1; }
SOURCE=$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)
TARGET=/opt/ceossh
[[ "$SOURCE" != "$TARGET" && "$SOURCE" != "$TARGET/"* ]] || { echo 'Extraé el ZIP en /root/ceossh-completo y ejecutá desde allí.'; exit 1; }
. /etc/os-release
[[ "$ID" == ubuntu || "$ID" == debian ]] || { echo 'Este instalador requiere Debian/Ubuntu. Ver docs/INSTALL.md para instalación manual.'; exit 1; }
echo '[INFO] Instalando dependencias del panel'
export DEBIAN_FRONTEND=noninteractive
apt-get update
apt-get install -y apache2 libapache2-mod-php php-cli php-mysql php-curl mariadb-client openssh-client sshpass rsync unzip cron openssl util-linux iproute2
php -r 'if(PHP_VERSION_ID<80100){fwrite(STDERR,"PHP 8.1 o superior requerido\n");exit(1);}'
if [[ "$MODE" == --update ]]; then
 [[ -f "$TARGET/config/config.php" ]] || { echo 'No existe /opt/ceossh/config/config.php. Usá --install para una instalación nueva.'; exit 1; }
 # Detener el worker mediante su mismo bloqueo antes del backup/migración.
 mkdir -p "$TARGET/storage"
 exec 9>"$TARGET/storage/worker.lock"
 flock -w 120 9 || { echo 'El worker sigue ejecutándose. Reintentá en un minuto.'; exit 1; }
 echo '[INFO] Respaldo obligatorio de archivos y base de datos'
 BACKUP="/root/ceossh-backups/$(date +%Y%m%d-%H%M%S)"
 mkdir -p "$BACKUP";chmod 0700 "$BACKUP"
 # Usar el config del panel existente sin copiarlo al ZIP nuevo.
 CEOSSH_BACKUP_CONFIG="$TARGET/config/config.php" php "$SOURCE/scripts/backup.php" "$BACKUP/database.sql"
else
 [[ ! -e "$TARGET/config/config.php" ]] || { echo 'Ya hay un panel instalado. Usá --update.'; exit 1; }
 apt-get install -y mariadb-server
 systemctl enable --now mariadb
 read -r -p 'Usuario administrador (ej. admin): ' CEOSSH_ADMIN_NAME
 read -r -s -p 'Contraseña administrador (mínimo 12 caracteres): ' CEOSSH_ADMIN_PASSWORD;echo
 read -r -p 'Puerto HTTP dedicado del panel [8088]: ' PANEL_PORT;PANEL_PORT=${PANEL_PORT:-8088}
 [[ "$PANEL_PORT" =~ ^[0-9]+$ && "$PANEL_PORT" -ge 1024 && "$PANEL_PORT" -le 65535 ]] || { echo 'Puerto inválido (1024–65535)'; exit 1; }
 [[ ${#CEOSSH_ADMIN_PASSWORD} -ge 12 && ${#CEOSSH_ADMIN_PASSWORD} -le 128 && "$CEOSSH_ADMIN_NAME" =~ ^[a-zA-Z0-9_]{3,64}$ ]] || { echo 'Administrador inválido'; exit 1; }
 ss -lnt | awk '{print $4}' | grep -qE ":$PANEL_PORT$" && { echo 'El puerto ya está ocupado'; exit 1; }
 mkdir -p "$TARGET/config"
 CEOSSH_DB_PASS=$(openssl rand -hex 24);CEOSSH_DB_NAME="ceossh_$(openssl rand -hex 4)";CEOSSH_DB_USER="ceo_$(openssl rand -hex 4)"
 mysql <<SQL
CREATE DATABASE \`$CEOSSH_DB_NAME\` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
CREATE USER '$CEOSSH_DB_USER'@'localhost' IDENTIFIED BY '$CEOSSH_DB_PASS';
GRANT ALL PRIVILEGES ON \`$CEOSSH_DB_NAME\`.* TO '$CEOSSH_DB_USER'@'localhost';
SQL
 export CEOSSH_DB_PASS CEOSSH_DB_NAME CEOSSH_DB_USER
 php -r '$c="<?php\n";foreach(["DB_HOST"=>"localhost","DB_NAME"=>getenv("CEOSSH_DB_NAME"),"DB_USER"=>getenv("CEOSSH_DB_USER"),"DB_PASS"=>getenv("CEOSSH_DB_PASS"),"APP_TIMEZONE"=>"America/Argentina/Buenos_Aires","LEGACY_DATA_TIMEZONE"=>"UTC","CEOSSH_VERSION"=>"2.0.0","SERVER_IP"=>"127.0.0.1"] as $k=>$v)$c.="define(".var_export($k,true).", ".var_export($v,true).");\n";file_put_contents("/opt/ceossh/config/config.php",$c);'
 unset CEOSSH_DB_PASS
fi
if [[ "$MODE" == --update ]]; then
 tar -czf "$BACKUP/panel.tar.gz" -C /opt ceossh
 echo "[OK] Respaldo completo en $BACKUP"
fi
mkdir -p "$TARGET/storage/logs" "$TARGET/storage/tmp" "$TARGET/storage/cache" "$TARGET/config/ssh"
rsync -a --exclude config --exclude storage --exclude tests --exclude .git --exclude 'install.sh' "$SOURCE/" "$TARGET/"
cp "$SOURCE/config/config.example.php" "$TARGET/config/config.example.php"
cp "$SOURCE/install.sh" "$TARGET/install.sh"
echo '[INFO] Actualizando esquema y cifrando credenciales anteriores'
php "$TARGET/scripts/migrate.php"
if [[ "$MODE" == --install ]]; then
 export CEOSSH_ADMIN_NAME CEOSSH_ADMIN_PASSWORD
 php "$TARGET/scripts/admin.php"
 unset CEOSSH_ADMIN_PASSWORD
fi
# Propiedad: código y configuración no editables desde el proceso web.
chown -R root:www-data "$TARGET"
find "$TARGET" -type d -exec chmod 0750 {} +
find "$TARGET" -type f -exec chmod 0640 {} +
chmod 0750 "$TARGET/install.sh" "$TARGET"/scripts/*.sh
chown -R www-data:www-data "$TARGET/storage"
chmod 0750 "$TARGET/storage" "$TARGET/storage/logs" "$TARGET/storage/tmp" "$TARGET/storage/cache"
# Identidad SSH opcional para VPS sin contraseña. Se conserva entre actualizaciones.
if [[ ! -f "$TARGET/config/ssh/id_ed25519" ]]; then
 ssh-keygen -q -t ed25519 -N '' -f "$TARGET/config/ssh/id_ed25519"
fi
chown www-data:www-data "$TARGET/config/ssh/id_ed25519";chmod 0600 "$TARGET/config/ssh/id_ed25519"
touch "$TARGET/config/known_hosts";chown root:www-data "$TARGET/config/known_hosts";chmod 0640 "$TARGET/config/known_hosts"
if [[ "$MODE" == --install ]]; then
 cat > /etc/apache2/sites-available/ceossh.conf <<APACHE
Listen $PANEL_PORT
<VirtualHost *:$PANEL_PORT>
    DocumentRoot /opt/ceossh/public
    <Directory /opt/ceossh/public>
        Require all granted
        AllowOverride None
        Options -Indexes
        DirectoryIndex index.php
    </Directory>
    <Directory /opt/ceossh/config>
        Require all denied
    </Directory>
    ErrorLog \${APACHE_LOG_DIR}/ceossh-error.log
    CustomLog \${APACHE_LOG_DIR}/ceossh-access.log combined
</VirtualHost>
APACHE
 a2ensite ceossh
fi
apache2ctl configtest
systemctl enable --now apache2 cron
systemctl reload apache2
printf '* * * * * www-data /usr/bin/php /opt/ceossh/scripts/worker.php >> /opt/ceossh/storage/logs/worker.log 2>&1\n' > /etc/cron.d/ceossh
chmod 0644 /etc/cron.d/ceossh
cat > /etc/logrotate.d/ceossh <<'ROTATE'
/opt/ceossh/storage/logs/*.log {
    weekly
    rotate 8
    compress
    missingok
    notifempty
    su www-data www-data
    copytruncate
}
ROTATE
if [[ "$MODE" == --update ]]; then flock -u 9;fi
echo '[OK] Archivos, migración y cron preparados.'
echo 'Registrá las huellas SSH con scripts/trust-vps.sh antes de probar las VPS.'
if [[ "$MODE" == --update ]]; then
 echo 'Para cuentas de la versión anterior, ejecutá scripts/adopt.php ID_VPS CONFIRMO después de revisar sus asociaciones.'
 echo 'La configuración Apache existente se conserva. Su DocumentRoot debe apuntar a /opt/ceossh/public.'
else
 echo "Panel: http://IP_DEL_SERVIDOR:$PANEL_PORT/ — configurá HTTPS antes de usarlo en producción."
fi
echo 'Comprobá el worker en Ajustes luego de 1–2 minutos.'
