document.addEventListener('DOMContentLoaded', () => {
  const esc = CEO.escape;
  document.getElementById('quickDemo').onclick = () =>
    CEO.open(document.getElementById('demoModal'));
  const load = async () => {
    if (document.hidden) return;
    try {
      const r = await CEO.api('dashboard_data');
      document
        .querySelectorAll('[data-stat]')
        .forEach((el) => (el.textContent = String(r.stats[el.dataset.stat])));
      document.getElementById('workerNotice').hidden = r.worker_ok;
      document.getElementById('serversGrid').innerHTML = r.vps.length
        ? r.vps
            .map((v) => {
              const m = v.metrics;
              const label =
                v.status === 'disabled'
                  ? 'Deshabilitada'
                  : v.stale
                    ? 'Sin comprobación reciente'
                    : v.health === 'online'
                      ? 'SSH disponible'
                      : v.health === 'offline'
                        ? 'SSH sin conexión'
                        : 'Sin comprobar';
              const bars = m
                ? ['cpu', 'ram', 'disk']
                    .map(
                      (k) =>
                        `<div class="resource"><span>${{ cpu: 'CPU', ram: 'RAM', disk: 'Disco' }[k]}</span><span>${Number(m[k]).toFixed(1)}%</span></div><div class="resource-bar"><span style="width:${Math.max(0, Math.min(100, Number(m[k])))}%"></span></div>`,
                    )
                    .join('')
                : '<p class="muted">Sin datos todavía</p>';
              return `<article class="panel"><h3>${esc(v.name)}</h3><p>${esc(v.host)}</p><span class="status-pill ${v.health === 'online' && !v.stale ? 'status-active' : 'status-pending'}">${label}</span>${bars}<p class="muted" style="margin-top:14px">Comprobación: ${esc(v.checked_display || 'Nunca')}</p>${m ? `<p class="muted">Uptime: ${Math.floor(m.uptime / 3600)} h · Carga: ${Number(m.load).toFixed(2)} · Sesiones sshd: ${m.sessions.length}</p>` : ''}</article>`;
            })
            .join('')
        : '<div class="panel"><h3>Agregá tu primer servidor</h3><p>Los recursos aparecerán después de comprobar su conexión SSH.</p><a class="btn-primary" href="vps.php?add=1">Agregar VPS</a></div>';
    } catch (e) {
      CEO.toast(e.message, 'error');
    }
  };
  load();
  setInterval(load, 60000);
});
