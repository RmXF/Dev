// El tema y el menú se controlan en common.js.
