'use strict';
window.CEO = {
  escape: (value) =>
    String(value ?? '').replace(
      /[&<>"']/g,
      (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[c],
    ),
  async api(name, data = null, query = {}) {
    const token = document.querySelector('meta[name="csrf-token"]')?.content || '';
    const opts =
      data === null
        ? {}
        : {
            method: 'POST',
            headers: { 'Content-Type': 'application/json', 'X-CSRF-Token': token },
            body: JSON.stringify(data),
          };
    const response = await fetch(
      'api/' + name + '.php' + (data === null ? '?' + new URLSearchParams(query) : ''),
      opts,
    );
    let result;
    try {
      result = await response.json();
    } catch {
      throw new Error('Respuesta inválida. Revisá los logs PHP y la instalación.');
    }
    if (response.status === 401) {
      location.href = 'index.php';
      throw new Error('Sesión vencida');
    }
    if (!response.ok || !result.ok)
      throw new Error(result.msg || 'No se pudo completar la operación');
    return result;
  },
  toast(message, type = 'info') {
    let stack = document.getElementById('toastStack');
    if (!stack) {
      stack = document.createElement('div');
      stack.id = 'toastStack';
      stack.className = 'toast-stack';
      stack.setAttribute('aria-live', 'polite');
      document.body.append(stack);
    }
    const el = document.createElement('div');
    el.className = 'toast ' + type;
    el.textContent = message;
    stack.append(el);
    setTimeout(() => el.remove(), type === 'error' ? 12000 : 6500);
  },
  open(modal) {
    if (!modal) return;
    modal.classList.add('open');
    modal._trigger = document.activeElement;
    document.body.style.overflow = 'hidden';
    setTimeout(() => modal.querySelector('input:not([type=hidden]),select,button')?.focus(), 20);
  },
  close(modal) {
    if (!modal) return;
    modal.classList.remove('open');
    if (!document.querySelector('.modal-overlay.open')) document.body.style.overflow = '';
    modal._trigger?.focus();
  },
  async confirm(title, message, phrase = '') {
    return new Promise((resolve) => {
      const el = document.createElement('div');
      el.className = 'modal-overlay';
      el.innerHTML =
        '<div class="modal" role="dialog" aria-modal="true"><div class="modal-header"><h3></h3></div><div class="modal-body"><p></p><input aria-label="Confirmación" hidden></div><div class="modal-footer"><button class="btn-secondary" data-cancel>Cancelar</button><button class="btn-danger" data-accept>Confirmar</button></div></div>';
      el.querySelector('h3').textContent = title;
      el.querySelector('p').textContent = message;
      const input = el.querySelector('input');
      if (phrase) {
        input.hidden = false;
        input.placeholder = phrase;
        el.querySelector('[data-accept]').disabled = true;
        input.addEventListener(
          'input',
          () => (el.querySelector('[data-accept]').disabled = input.value !== phrase),
        );
      }
      const finish = (value) => {
        CEO.close(el);
        el.remove();
        document.removeEventListener('keydown', key);
        resolve(value);
      };
      const key = (e) => {
        if (e.key === 'Escape') finish(false);
      };
      document.addEventListener('keydown', key);
      el.querySelector('[data-cancel]').onclick = () => finish(false);
      el.querySelector('[data-accept]').onclick = () => finish(true);
      el.onclick = (e) => {
        if (e.target === el) finish(false);
      };
      document.body.append(el);
      CEO.open(el);
    });
  },
  async copy(text) {
    try {
      await navigator.clipboard.writeText(text);
      CEO.toast('Copiado');
    } catch {
      CEO.toast('No se pudo copiar. Usá HTTPS o seleccioná el texto.', 'error');
    }
  },
  random(length = 14) {
    const alphabet = 'abcdefghijkmnpqrstuvwxyzABCDEFGHJKLMNPQRSTUVWXYZ23456789';
    let s = '';
    while (s.length < length) {
      const values = crypto.getRandomValues(new Uint8Array(length));
      for (const v of values) {
        if (v < Math.floor(256 / alphabet.length) * alphabet.length)
          s += alphabet[v % alphabet.length];
        if (s.length === length) break;
      }
    }
    return s;
  },
};
document.addEventListener('DOMContentLoaded', () => {
  const toggle = document.getElementById('sidebarToggle');
  toggle?.addEventListener('click', () => {
    if (innerWidth > 1000) document.body.classList.toggle('sidebar-collapsed');
    else document.body.classList.toggle('sidebar-open');
    toggle.setAttribute('aria-expanded', String(document.body.classList.contains('sidebar-open')));
  });
  const closeSidebar = () => {
    document.body.classList.remove('sidebar-open');
    toggle?.setAttribute('aria-expanded', 'false');
  };
  document.getElementById('sidebarClose')?.addEventListener('click', closeSidebar);
  document.getElementById('sidebarOverlay')?.addEventListener('click', closeSidebar);
  const theme = document.getElementById('themeToggle');
  const updateTheme = () => {
    const icon = theme?.querySelector('.theme-icon');
    if (icon) icon.textContent = document.documentElement.dataset.theme === 'dark' ? '☀' : '☾';
  };
  updateTheme();
  theme?.addEventListener('click', () => {
    const t = document.documentElement.dataset.theme === 'dark' ? 'light' : 'dark';
    document.documentElement.dataset.theme = t;
    try {
      localStorage.setItem('ceossh_theme', t);
    } catch {}
    updateTheme();
  });
  document.addEventListener('click', (e) => {
    const close = e.target.closest('[data-close]');
    if (close) CEO.close(close.closest('.modal-overlay'));
    if (e.target.classList.contains('modal-overlay')) CEO.close(e.target);
  });
  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape') {
      closeSidebar();
      document.querySelectorAll('.modal-overlay.open').forEach(CEO.close);
    }
    if (e.key === 'Tab') {
      const modal = [...document.querySelectorAll('.modal-overlay.open')].pop();
      if (!modal) return;
      const items = [
        ...modal.querySelectorAll(
          'button:not(:disabled),input:not([type=hidden]):not(:disabled),select:not(:disabled),a[href]',
        ),
      ].filter((x) => !x.hidden && x.offsetParent !== null);
      const first = items[0],
        last = items.at(-1);
      if (e.shiftKey && document.activeElement === first) {
        e.preventDefault();
        last?.focus();
      } else if (!e.shiftKey && document.activeElement === last) {
        e.preventDefault();
        first?.focus();
      }
    }
  });
  document
    .getElementById('demoBtn')
    ?.addEventListener('click', () => CEO.open(document.getElementById('demoModal')));
  document.getElementById('sidebarDemo')?.addEventListener('click', (e) => {
    e.preventDefault();
    closeSidebar();
    CEO.open(document.getElementById('demoModal'));
  });
  document.getElementById('demoForm')?.addEventListener('submit', async (e) => {
    e.preventDefault();
    const btn = e.target.querySelector('button[type=submit]');
    btn.disabled = true;
    try {
      const r = await CEO.api('demo_create', {
        group_id: document.getElementById('demoGroup').value,
        minutes: document.getElementById('demoMinutes').value,
      });
      const output = document.getElementById('demoResult');
      output.hidden = false;
      output.textContent = `Usuario: ${r.credentials.username}\nContraseña: ${r.credentials.password}\nVence: ${r.credentials.expires_at}\nEstado: pendiente de aplicación en VPS`;
      CEO.toast(r.msg, 'warning');
    } catch (err) {
      CEO.toast(err.message, 'error');
    } finally {
      btn.disabled = false;
    }
  });
  const health = async () => {
    if (document.hidden) return;
    try {
      const [a, d] = await Promise.all([CEO.api('alerts_list'), CEO.api('dashboard_data')]);
      const c = document.getElementById('alertCount');
      if (c) c.textContent = String(a.unread);
      const s = document.getElementById('systemStatus');
      if (s)
        s.textContent = d.worker_ok
          ? 'Worker activo · ' + d.worker_last
          : 'Worker sin actividad reciente';
      const dot = document.querySelector('.status-dot');
      if (dot) dot.style.background = d.worker_ok ? 'var(--good)' : 'var(--warn)';
    } catch {
      const s = document.getElementById('systemStatus');
      if (s) s.textContent = 'No se pudo comprobar el estado';
    }
  };
  if (document.getElementById('systemStatus')) {
    health();
    setInterval(health, 60000);
  }
});
