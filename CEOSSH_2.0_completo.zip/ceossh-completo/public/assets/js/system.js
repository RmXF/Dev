document.addEventListener('DOMContentLoaded', () => {
  const esc = CEO.escape,
    date = (v) =>
      v
        ? new Intl.DateTimeFormat('es-AR', { dateStyle: 'short', timeStyle: 'short' }).format(
            new Date(v.replace(' ', 'T') + 'Z'),
          )
        : '—';
  async function alerts() {
    const r = await CEO.api('alerts_list');
    const f = document.getElementById('alertFilter').value;
    document.getElementById('eventsList').innerHTML =
      r.events
        .filter(
          (e) =>
            f === 'all' ||
            (f === 'open' && !e.read_at && !e.resolved_at && e.severity !== 'info') ||
            (f === 'error' && e.severity === 'error'),
        )
        .map(
          (e) =>
            `<article class="alert-item ${esc(e.severity)} ${e.read_at || e.resolved_at ? 'read' : ''}"><div class="alert-message">${esc(e.message)}<small>${esc(date(e.created_at))} · ${esc(e.actor)} · ${e.resolved_at ? 'Resuelta' : e.read_at ? 'Leída' : 'Nueva'}</small></div>${!e.read_at ? `<button class="btn-secondary" data-read="${e.id}">Leída</button>` : ''}</article>`,
        )
        .join('') || '<div class="panel">No hay alertas en este filtro.</div>';
  }
  async function jobs() {
    const r = await CEO.api('jobs_list');
    document.getElementById('jobsTbody').innerHTML =
      r.jobs
        .map(
          (j) =>
            `<tr><td>${esc(j.username || 'Cuenta eliminada')}<br><small class="muted">#${j.user_id}</small></td><td>${esc(j.vps_name || '#' + j.vps_id)}</td><td>${j.kind === 'upsert' ? 'Aplicar cuenta' : 'Eliminar cuenta'}</td><td><span class="status-pill status-${esc(j.status)}">${{ done: 'Completada', pending: 'Pendiente', running: 'En curso', failed: 'Fallida' }[j.status] || esc(j.status)}</span></td><td>${j.attempts}</td><td class="job-error">${esc(j.last_error || j.created_display)}</td><td>${j.status === 'failed' ? `<button class="btn-secondary" data-retry="${j.id}">Reintentar</button>` : '—'}</td></tr>`,
        )
        .join('') || '<tr><td colspan="7">Todavía no hay operaciones.</td></tr>';
  }
  const guarded = (fn) => async () => {
    try {
      await fn();
    } catch (e) {
      CEO.toast(e.message, 'error');
    }
  };
  if (document.getElementById('eventsList')) {
    const load = guarded(alerts);
    load();
    document.getElementById('alertFilter').onchange = load;
    document.getElementById('readAll').onclick = guarded(async () => {
      await CEO.api('alerts_read', {});
      await alerts();
    });
    document.getElementById('eventsList').onclick = async (e) => {
      const b = e.target.closest('[data-read]');
      if (b) {
        b.disabled = true;
        await guarded(async () => {
          await CEO.api('alerts_read', { id: b.dataset.read });
          await alerts();
        })();
      }
    };
    setInterval(() => {
      if (!document.hidden) load();
    }, 30000);
  }
  if (document.getElementById('jobsTbody')) {
    const load = guarded(jobs);
    load();
    setInterval(() => {
      if (!document.hidden) load();
    }, 15000);
    document.getElementById('jobsTbody').onclick = async (e) => {
      const b = e.target.closest('[data-retry]');
      if (b) {
        b.disabled = true;
        await guarded(async () => {
          const r = await CEO.api('jobs_retry', { id: b.dataset.retry });
          CEO.toast(r.msg);
          await jobs();
        })();
      }
    };
  }
  if (document.getElementById('passwordForm')) {
    guarded(async () => {
      const r = await CEO.api('dashboard_data');
      document.getElementById('workerDetails').textContent = r.worker_ok
        ? 'Worker activo. Última actividad: ' + r.worker_last
        : 'No hay actividad reciente. Revisá el cron.';
    })();
    document.getElementById('passwordForm').onsubmit = async (e) => {
      e.preventDefault();
      const b = e.target.querySelector('button');
      if (
        document.getElementById('newPassword').value !==
        document.getElementById('repeatPassword').value
      ) {
        CEO.toast('Las contraseñas no coinciden', 'error');
        return;
      }
      b.disabled = true;
      await guarded(async () => {
        const r = await CEO.api('password_change', {
          current: document.getElementById('currentPassword').value,
          new: document.getElementById('newPassword').value,
        });
        e.target.reset();
        CEO.toast(r.msg);
      })();
      b.disabled = false;
    };
  }
});
