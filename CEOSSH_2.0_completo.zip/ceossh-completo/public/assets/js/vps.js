document.addEventListener('DOMContentLoaded', () => {
  const $ = (id) => document.getElementById(id);
  const modal = $('vpsModal');
  const data = () => ({
    id: $('vps-id').value,
    name: $('vps-name').value,
    host: $('vps-host').value,
    ssh_port: $('vps-port').value,
    ssh_user: $('vps-user').value,
    ssh_pass: $('vps-pass').value,
    group_id: $('vps-group').value,
  });
  const feedback = (msg, type) => {
    $('vpsFeedback').className = 'modal-feedback ' + type;
    $('vpsFeedback').textContent = msg;
  };
  function add() {
    $('vpsForm').reset();
    $('vps-id').value = '';
    $('modalTitle').textContent = 'Agregar VPS';
    $('vpsFeedback').className = 'modal-feedback';
    CEO.open(modal);
  }
  $('openAddVps').onclick = add;
  $('refreshList').onclick = () => location.reload();
  $('vpsSubmit').onclick = async () => {
    if (!$('vpsForm').reportValidity()) return;
    $('vpsSubmit').disabled = true;
    try {
      const r = await CEO.api('vps_save', data());
      CEO.close(modal);
      CEO.toast(r.msg);
      setTimeout(() => location.reload(), 1800);
    } catch (e) {
      feedback(e.message, 'error');
    } finally {
      $('vpsSubmit').disabled = false;
    }
  };
  $('vpsForm').onsubmit = (e) => {
    e.preventDefault();
    $('vpsSubmit').click();
  };
  $('vpsTest').onclick = async () => {
    $('vpsTest').disabled = true;
    try {
      const r = await CEO.api('vps_test', data());
      feedback(r.msg, 'success');
    } catch (e) {
      feedback(e.message, 'error');
    } finally {
      $('vpsTest').disabled = false;
    }
  };
  document.querySelectorAll('.row-actions .icon-action').forEach(
    (btn) =>
      (btn.onclick = async () => {
        btn.disabled = true;
        const id = Number(btn.dataset.id);
        try {
          if (btn.classList.contains('edit')) {
            const r = await CEO.api('vps_get', null, { id });
            const v = r.vps;
            $('vpsForm').reset();
            $('vps-id').value = id;
            $('vps-name').value = v.name;
            $('vps-host').value = v.host;
            $('vps-port').value = v.ssh_port;
            $('vps-user').value = v.ssh_user;
            $('vps-group').value = v.group_id || '';
            $('modalTitle').textContent = 'Editar VPS';
            $('vpsFeedback').className = 'modal-feedback';
            CEO.open(modal);
          } else if (btn.classList.contains('delete')) {
            if (
              await CEO.confirm(
                'Quitar VPS',
                'Solo se podrá quitar cuando no tenga cuentas asociadas ni tareas pendientes.',
              )
            ) {
              const r = await CEO.api('vps_delete', { id });
              CEO.toast(r.msg);
              location.reload();
            }
          } else if (btn.classList.contains('toggle')) {
            if (
              await CEO.confirm(
                'Cambiar participación',
                'Deshabilitar evita nuevas sincronizaciones. No apaga el servidor ni corta cuentas existentes.',
              )
            ) {
              await CEO.api('vps_toggle', { id });
              location.reload();
            }
          } else if (btn.classList.contains('ping')) {
            const r = await CEO.api('vps_refresh', { id });
            CEO.toast(r.msg);
          } else if (btn.classList.contains('sync')) {
            const r = await CEO.api('vps_sync', { vps_id: id });
            $('syncTitle').textContent = 'Sincronización en cola';
            $('syncBody').textContent =
              r.msg + '. Revisá Operaciones para conocer el resultado real.';
            CEO.open($('syncModal'));
          }
        } catch (e) {
          CEO.toast(e.message, 'error');
        } finally {
          btn.disabled = false;
        }
      }),
  );
  if (new URLSearchParams(location.search).has('add')) add();
});
