document.addEventListener('DOMContentLoaded', () => {
  const $ = (id) => document.getElementById(id),
    esc = CEO.escape;
  let filter = 'all',
    page = 1,
    pages = 1,
    renewId = 0,
    seq = 0;
  const feedback = (msg, type) => {
    $('userFeedback').className = 'modal-feedback ' + type;
    $('userFeedback').textContent = msg;
  };
  async function load() {
    const current = ++seq;
    try {
      const r = await CEO.api('users_list', null, {
        filter,
        page,
        search: $('userSearch').value,
        group_id: $('userGroupFilter').value,
      });
      if (current !== seq) return;
      pages = r.pages;
      if (page > pages) {
        page = pages;
        return load();
      }
      $('filterInfo').textContent =
        `${r.total} cuenta(s) · ${filter === 'pending' ? 'Bajas pendientes' : filter === 'expired' ? 'Vencidos' : filter === 'active' ? 'Activos' : 'Listado'}`;
      $('pageInfo').textContent = `Página ${page} de ${pages}`;
      $('prevPage').disabled = page <= 1;
      $('nextPage').disabled = page >= pages;
      document
        .querySelectorAll('[data-filter]')
        .forEach((b) => b.classList.toggle('active', b.dataset.filter === filter));
      $('emptyState').classList.toggle('hidden', r.users.length > 0);
      $('usersTbody').innerHTML = r.users
        .map(
          (u) =>
            `<tr data-id="${u.id}"><td data-label="Usuario"><code>${esc(u.username)}</code></td><td data-label="Sincronización"><span class="status-pill ${u.pending > 0 ? 'status-pending' : 'status-active'}">${u.pending > 0 ? u.pending + ' pendiente(s)' : 'Sin tareas pendientes'}</span></td><td data-label="Grupo">${esc(u.group_name || 'Sin grupo')}</td><td data-label="Límite">${u.connection_limit}</td><td data-label="Vencimiento">${esc(u.expires_display)}</td><td data-label="Estado"><span class="status-pill status-${esc(u.status)}">${u.delete_requested == 1 ? 'Baja pendiente' : { active: 'Habilitado', expired: 'Vencido', disabled: 'Deshabilitado' }[u.status] || esc(u.status)}</span></td><td data-label="Acciones" class="row-actions">${u.delete_requested == 1 ? '<a href="operaciones.php" class="btn-secondary">Ver tareas</a>' : `<button class="icon-action" data-action="edit" data-id="${u.id}">Editar</button><button class="icon-action" data-action="renew" data-id="${u.id}">Renovar</button><button class="icon-action" data-action="reveal" data-id="${u.id}">Datos</button><button class="icon-action" data-action="delete" data-id="${u.id}">Eliminar</button>`}</td></tr>`,
        )
        .join('');
    } catch (e) {
      CEO.toast(e.message, 'error');
    }
  }
  function openAdd() {
    $('userForm').reset();
    $('u-id').value = '';
    $('u-username').readOnly = false;
    $('u-username').pattern = '[a-z][a-z0-9_]{2,31}';
    $('genUser').disabled = false;
    $('u-password').required = true;
    $('u-password').placeholder = 'Mínimo 8 caracteres';
    $('u-days').disabled = false;
    $('userFeedback').className = 'modal-feedback';
    $('userModalTitle').textContent = 'Agregar usuario';
    $('userSubmit').textContent = 'Crear cuenta';
    CEO.open($('addUserModal'));
  }
  $('openAddUser').onclick = openAdd;
  document.querySelectorAll('[data-filter]').forEach(
    (b) =>
      (b.onclick = () => {
        filter = b.dataset.filter;
        page = 1;
        load();
      }),
  );
  let timer;
  $('userSearch').oninput = () => {
    clearTimeout(timer);
    timer = setTimeout(() => {
      page = 1;
      load();
    }, 300);
  };
  $('userGroupFilter').onchange = () => {
    page = 1;
    load();
  };
  $('prevPage').onclick = () => {
    page--;
    load();
  };
  $('nextPage').onclick = () => {
    page++;
    load();
  };
  $('genUser').onclick = () => {
    $('u-username').value = 'ceo_' + CEO.random(6).toLowerCase();
  };
  $('genPass').onclick = () => {
    $('u-password').value = CEO.random();
  };
  $('userSubmit').onclick = async () => {
    if (!$('userForm').reportValidity()) return;
    const btn = $('userSubmit');
    btn.disabled = true;
    try {
      const editing = !!$('u-id').value;
      const r = await CEO.api('users_save', {
        id: $('u-id').value,
        username: $('u-username').value,
        password: $('u-password').value,
        group_id: $('u-group').value,
        connection_limit: $('u-limit').value,
        days: $('u-days').value,
      });
      CEO.close($('addUserModal'));
      CEO.toast(r.msg, 'warning');
      if (!editing) credentials(r.credentials);
      load();
    } catch (e) {
      feedback(e.message, 'error');
    } finally {
      btn.disabled = false;
    }
  };
  $('userForm').onsubmit = (e) => {
    e.preventDefault();
    $('userSubmit').click();
  };
  $('usersTbody').onclick = async (e) => {
    const b = e.target.closest('[data-action]');
    if (!b) return;
    const id = Number(b.dataset.id);
    b.disabled = true;
    try {
      if (b.dataset.action === 'edit') {
        const r = await CEO.api('users_get', null, { id });
        const u = r.user;
        $('userForm').reset();
        $('u-id').value = u.id;
        $('u-username').value = u.username;
        $('u-username').readOnly = true;
        $('u-username').removeAttribute('pattern');
        $('genUser').disabled = true;
        $('u-password').required = false;
        $('u-password').placeholder = 'Vacío conserva la contraseña';
        $('u-group').value = u.group_id || '';
        $('u-limit').value = u.connection_limit;
        $('u-days').disabled = true;
        $('userModalTitle').textContent = 'Editar usuario · conserva el vencimiento';
        $('userSubmit').textContent = 'Guardar cambios';
        $('userFeedback').className = 'modal-feedback';
        CEO.open($('addUserModal'));
      }
      if (b.dataset.action === 'renew') {
        renewId = id;
        CEO.open($('renewModal'));
      }
      if (
        b.dataset.action === 'delete' &&
        (await CEO.confirm(
          'Eliminar cuenta',
          'La baja se aplicará a cada VPS. El registro se conservará si hay fallos.',
        ))
      ) {
        const r = await CEO.api('users_delete', { id });
        CEO.toast(r.msg, 'warning');
        load();
      }
      if (b.dataset.action === 'reveal') {
        const r = await CEO.api('users_reveal', { id });
        credentials({ ...r, group_name: 'Consultado desde el panel' });
      }
    } catch (err) {
      CEO.toast(err.message, 'error');
    } finally {
      b.disabled = false;
    }
  };
  $('renewForm').onsubmit = async (e) => {
    e.preventDefault();
    const b = e.target.querySelector('button[type=submit]');
    b.disabled = true;
    try {
      const r = await CEO.api('users_renew', { id: renewId, days: $('renewDays').value });
      CEO.close($('renewModal'));
      CEO.toast(r.msg + ' Vence: ' + r.expires_at, 'warning');
      load();
    } catch (err) {
      CEO.toast(err.message, 'error');
    } finally {
      b.disabled = false;
    }
  };
  $('deleteAll').onclick = async () => {
    if (
      !(await CEO.confirm(
        'Eliminar todos',
        'Solicitará la baja de todas las cuentas, en todos sus servidores. Escribí ELIMINAR TODOS.',
        'ELIMINAR TODOS',
      ))
    )
      return;
    $('deleteAll').disabled = true;
    try {
      const r = await CEO.api('users_delete_all', { confirmation: 'ELIMINAR TODOS' });
      CEO.toast(r.msg, 'warning');
      load();
    } catch (e) {
      CEO.toast(e.message, 'error');
    } finally {
      $('deleteAll').disabled = false;
    }
  };
  function credentials(c) {
    $('c-user').textContent = c.username;
    $('c-pass').textContent = c.password || 'Sin cambios';
    $('c-exp').textContent = c.expires_at;
    $('c-lim').textContent = c.connection_limit;
    $('c-group').textContent = c.group_name || '—';
    CEO.open($('credModal'));
  }
  const text = () =>
    `Usuario: ${$('c-user').textContent}\nContraseña: ${$('c-pass').textContent}\nVence: ${$('c-exp').textContent}\nLímite: ${$('c-lim').textContent}`;
  $('copyCreds').onclick = () => CEO.copy(text());
  $('shareCreds').onclick = async () => {
    if (navigator.share) {
      try {
        await navigator.share({ title: 'Cuenta SSH', text: text() });
      } catch (e) {
        if (e.name !== 'AbortError') CEO.toast(e.message, 'error');
      }
    } else CEO.copy(text());
  };
  load();
  setInterval(() => {
    if (!document.hidden && !document.querySelector('.modal-overlay.open')) load();
  }, 30000);
  if (new URLSearchParams(location.search).has('add')) openAdd();
});
