document.addEventListener('DOMContentLoaded', () => {
  const $ = (id) => document.getElementById(id),
    modal = $('groupModal');
  const feedback = (m, t) => {
    $('groupFeedback').className = 'modal-feedback ' + t;
    $('groupFeedback').textContent = m;
  };
  $('openAddGroup').onclick = () => {
    $('groupForm').reset();
    $('g-id').value = '';
    $('groupModalTitle').textContent = 'Nuevo grupo';
    $('groupFeedback').className = 'modal-feedback';
    CEO.open(modal);
  };
  $('refreshGroups').onclick = () => location.reload();
  $('groupSubmit').onclick = async () => {
    if (!$('groupForm').reportValidity()) return;
    $('groupSubmit').disabled = true;
    try {
      await CEO.api('groups_save', {
        id: $('g-id').value,
        name: $('g-name').value,
        description: $('g-description').value,
      });
      location.reload();
    } catch (e) {
      feedback(e.message, 'error');
    } finally {
      $('groupSubmit').disabled = false;
    }
  };
  $('groupForm').onsubmit = (e) => {
    e.preventDefault();
    $('groupSubmit').click();
  };
  document.querySelectorAll('.group-actions button').forEach(
    (btn) =>
      (btn.onclick = async () => {
        btn.disabled = true;
        try {
          const id = Number(btn.dataset.id);
          if (btn.classList.contains('edit')) {
            const r = await CEO.api('groups_get', null, { id });
            $('g-id').value = id;
            $('g-name').value = r.group.name;
            $('g-description').value = r.group.description || '';
            $('groupModalTitle').textContent = 'Editar grupo';
            $('groupFeedback').className = 'modal-feedback';
            CEO.open(modal);
          } else if (
            await CEO.confirm(
              'Eliminar grupo',
              'Solo se puede eliminar un grupo sin usuarios ni VPS.',
            )
          ) {
            await CEO.api('groups_delete', { id });
            location.reload();
          }
        } catch (e) {
          CEO.toast(e.message, 'error');
        } finally {
          btn.disabled = false;
        }
      }),
  );
});
