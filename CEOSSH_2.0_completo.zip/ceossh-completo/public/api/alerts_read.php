<?php
require dirname(__DIR__,2).'/app/Api.php';
apiDispatch('alerts_read');
