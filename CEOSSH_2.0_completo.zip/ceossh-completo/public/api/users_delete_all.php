<?php
require dirname(__DIR__,2).'/app/Api.php';
apiDispatch('users_delete_all');
