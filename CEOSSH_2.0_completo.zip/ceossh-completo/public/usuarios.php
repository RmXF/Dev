<?php
require dirname(__DIR__).'/app/bootstrap.php';
require_admin();
try {
    $pdo = Core::db();
    $groups = $pdo->query("SELECT id, name FROM vps_groups ORDER BY name")->fetchAll(PDO::FETCH_ASSOC);
} catch (Throwable $e) {
    error_log($e->getMessage()); http_response_code(503); exit('Base de datos no disponible. Revisá la instalación y los logs.');
}
?>
<!DOCTYPE html>
<html lang="es" data-theme="dark">
<head>
    <?php require __DIR__.'/partials/head.php'; ?>
    <title>CEOSSH — Gestión de Usuarios</title>
</head>
<body>

<?php require __DIR__ . '/partials/sidebar.php'; ?>

<div class="sidebar-overlay" id="sidebarOverlay"></div>

<?php require __DIR__ . '/partials/header.php'; ?>

<main class="dashboard">

    <div class="page-title">
        <h1>Gestión de Usuarios SSH</h1>
        <p class="muted">Administra las cuentas SSH creadas en el sistema</p>
    </div>

    <!-- Submenú -->
    <div class="users-actions">
        <button class="btn-primary" id="openAddUser">
            <span>➕</span> Agregar Usuario
        </button>
        <button class="btn-secondary" data-filter="all" id="filterAll">
            <span>📋</span> Listado
        </button>
        <button class="btn-secondary" data-filter="expired" id="filterExpired">
            <span>⛔</span> Vencidos
        </button>
        <button class="btn-danger" id="deleteAll">
            <span>🗑</span> Eliminar Todos
        </button>
    </div>

    <div class="toolbar"><input id="userSearch" type="search" placeholder="Buscar usuario…" aria-label="Buscar usuario"><select id="userGroupFilter" aria-label="Filtrar grupo"><option value="">Todos los grupos</option><?php foreach ($groups as $g): ?><option value="<?= (int)$g['id'] ?>"><?= h($g['name']) ?></option><?php endforeach; ?></select><button class="btn-secondary" data-filter="active" id="filterActive">Activos</button><button class="btn-secondary" data-filter="pending" id="filterPending">Bajas pendientes</button></div>
    <!-- Info filtro activo -->
    <div class="filter-info" id="filterInfo"></div>

    <!-- Tabla -->
    <section class="users-table-wrap">
        <table class="users-table" id="usersTable">
            <thead>
                <tr>
                    <th>Usuario</th>
                    <th>Sincronización</th>
                    <th>Grupo</th>
                    <th>Límite</th>
                    <th>Vencimiento</th>
                    <th>Estado</th>
                    <th>Acciones</th>
                </tr>
            </thead>
            <tbody id="usersTbody">
                <tr><td colspan="7" class="loading-row">Cargando usuarios...</td></tr>
            </tbody>
        </table>

        <div class="empty-state hidden" id="emptyState">
            <div class="empty-icon">👥</div>
            <h3>No hay usuarios</h3>
            <p class="muted">Crea el primer usuario con el botón de arriba.</p>
        </div>
    </section>

<div class="pagination"><button class="btn-secondary" id="prevPage">Anterior</button><span id="pageInfo" class="muted"></span><button class="btn-secondary" id="nextPage">Siguiente</button></div></main>

<!-- ============ MODAL: Agregar Usuario ============ -->
<div class="modal-overlay" id="addUserModal">
    <div class="modal">
        <div class="modal-header">
            <h3 id="userModalTitle">Agregar Usuario</h3>
            <button class="modal-close" data-close>&times;</button>
        </div>

        <form id="userForm" class="modal-body">
            <input type="hidden" name="id" id="u-id">

            <label class="field">
                <span>Usuario</span>
                <div class="input-with-btn">
                    <input type="text" name="username" id="u-username" pattern="[a-z][a-z0-9_]{2,31}" placeholder="usuario123" required>
                    <button type="button" class="mini-btn" id="genUser" title="Generar aleatorio">🎲</button>
                </div>
            </label>

            <label class="field">
                <span>Contraseña</span>
                <div class="input-with-btn">
                    <input type="password" name="password" id="u-password" placeholder="Mínimo 8 caracteres" minlength="8" maxlength="128" autocomplete="new-password">
                    <button type="button" class="mini-btn" id="genPass" title="Generar aleatoria">🎲</button>
                </div>
            </label>

            <label class="field">
                <span>Grupo</span>
                <select name="group_id" id="u-group">
                    <option value="">Sin grupo</option>
                    <?php foreach ($groups as $g): ?>
                        <option value="<?= (int)$g['id'] ?>"><?= htmlspecialchars($g['name']) ?></option>
                    <?php endforeach; ?>
                </select>
            </label>

            <div class="field-row">
                <label class="field">
                    <span>Límite conexiones</span>
                    <input type="number" name="connection_limit" id="u-limit" value="1" min="1" max="100" required>
                </label>

                <label class="field">
                    <span>Duración (días)</span>
                    <input type="number" name="days" id="u-days" value="30" min="1" max="3650" required>
                </label>
            </div>

            <div class="modal-feedback" id="userFeedback"></div>
        </form>

        <div class="modal-footer">
            <button class="btn-secondary" data-close>Cancelar</button>
            <button class="btn-primary" id="userSubmit">Generar Cuenta</button>
        </div>
    </div>
</div>

<!-- ============ MODAL: Credenciales generadas ============ -->
<div class="modal-overlay" id="credModal">
    <div class="modal modal-credentials">
        <div class="modal-header cred-success">
            <h3>Credenciales de la cuenta</h3>
            <button class="modal-close" data-close>&times;</button>
        </div>

        <div class="modal-body">
            <div class="cred-row">
                <span class="cred-label">Usuario</span>
                <span class="cred-value" id="c-user">—</span>
            </div>
            <div class="cred-row">
                <span class="cred-label">Contraseña</span>
                <span class="cred-value" id="c-pass">—</span>
            </div>
            <div class="cred-row">
                <span class="cred-label">Vencimiento</span>
                <span class="cred-value" id="c-exp">—</span>
            </div>
            <div class="cred-row">
                <span class="cred-label">Límite</span>
                <span class="cred-value" id="c-lim">—</span>
            </div>
            <div class="cred-row">
                <span class="cred-label">Grupo</span>
                <span class="cred-value" id="c-group">—</span>
            </div>

            <div class="cred-hint">
                Comparte estos datos con el cliente. La aplicación en las VPS está pendiente. Comprobá el resultado en Operaciones antes de entregar la cuenta.
            </div>
        </div>

        <div class="modal-footer">
            <button class="btn-secondary" id="copyCreds">📋 Copiar</button>
            <button class="btn-secondary" id="shareCreds">🔗 Compartir</button>
            <button class="btn-primary" data-close>Cerrar</button>
        </div>
    </div>
</div>




<div class="modal-overlay" id="renewModal"><div class="modal" role="dialog" aria-modal="true"><div class="modal-header"><h3>Renovar cuenta</h3><button class="modal-close" data-close>×</button></div><form id="renewForm" class="modal-body"><p class="muted">Se conservarán los días restantes de la cuenta.</p><label class="field"><span>Días a agregar</span><input id="renewDays" type="number" min="1" max="3650" value="30" required></label><button class="btn-primary" type="submit">Renovar</button></form></div></div><script src="assets/js/usuarios.js" defer></script>
<?php require __DIR__.'/partials/demo.php'; ?>
</body>
</html>