<?php require dirname(__DIR__).'/app/bootstrap.php'; require_admin(); ?>
<!DOCTYPE html><html lang="es" data-theme="dark"><head><title>CEOSSH · Inicio</title><?php require __DIR__.'/partials/head.php'; ?></head><body>
<?php require __DIR__.'/partials/sidebar.php'; ?><div class="sidebar-overlay" id="sidebarOverlay"></div><?php require __DIR__.'/partials/header.php'; ?>
<main class="dashboard"><div class="page-title"><p class="muted">CENTRO DE ADMINISTRACIÓN</p><h1>Panel de control</h1><p>Usuarios, servidores y tareas pendientes en un solo lugar.</p></div>
<div class="notice" id="workerNotice" hidden>El worker no tiene actividad reciente. Las tareas necesitan el cron de instalación. Revisá Operaciones y los logs.</div>
<section class="cards-grid">
<?php foreach (['users'=>['Usuarios registrados','♙','users'],'active'=>['Cuentas habilitadas','✓','active'],'expired'=>['Usuarios vencidos','◷','expired'],'vps'=>['VPS registradas','▣','vps'],'pending'=>['Operaciones pendientes','↻','pending'],'groups'=>['Grupos','▦','groups']] as $key=>$c): ?>
<div class="card card-<?= h($c[2]) ?>"><div class="card-icon"><?= h($c[1]) ?></div><div class="card-info"><div class="card-value" data-stat="<?= h($key) ?>">—</div><div class="card-label"><?= h($c[0]) ?></div></div><div class="card-glow"></div></div>
<?php endforeach; ?></section>
<section class="quick-actions"><h2>Accesos rápidos</h2><div class="quick-grid"><a href="usuarios.php?add=1" class="quick-item">＋ Agregar usuario</a><a href="vps.php?add=1" class="quick-item">＋ Agregar VPS</a><a href="usuarios.php" class="quick-item">Ver usuarios</a><button class="btn-secondary" id="quickDemo">Generar demo</button><a href="operaciones.php" class="quick-item">Revisar operaciones</a></div></section>
<h2 class="section-heading">Estado de los servidores</h2><p class="muted">Muestras reales por SSH. Los valores muestran la fecha de comprobación; una muestra antigua no confirma el estado actual.</p><section class="servers-grid" id="serversGrid"><div class="panel">Cargando servidores…</div></section>
</main><?php require __DIR__.'/partials/demo.php'; ?><script src="assets/js/dashboard.js" defer></script></body></html>
