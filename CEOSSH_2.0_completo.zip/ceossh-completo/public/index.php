<?php
require dirname(__DIR__).'/app/bootstrap.php';
if (!empty($_SESSION['admin'])) { header('Location: dashboard.php'); exit; }
$error='';
if ($_SERVER['REQUEST_METHOD']==='POST') {
    try {
        if (!hash_equals($_SESSION['csrf'],$_POST['csrf']??'')) throw new RuntimeException('Recargá e intentá nuevamente');
        $ip=hash('sha256',($_SERVER['REMOTE_ADDR']??'unknown').Core::key());
        $attempts=(int)Core::query('SELECT COUNT(*) FROM login_attempts WHERE ip_hash=? AND created_at>DATE_SUB(UTC_TIMESTAMP(),INTERVAL 15 MINUTE)',[$ip])->fetchColumn();
        if ($attempts>=5) throw new RuntimeException('Demasiados intentos. Esperá 15 minutos.');
        $admin=Core::query('SELECT * FROM panel_admins WHERE username=? LIMIT 1',[trim($_POST['username']??'')])->fetch();
        $valid=password_verify((string)($_POST['password']??''),$admin['password']??'$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2uheWG/igi.');
        if (!$admin || !$valid) {
            Core::query('INSERT INTO login_attempts(ip_hash,created_at) VALUES(?,UTC_TIMESTAMP())',[$ip]);
            throw new RuntimeException('Credenciales inválidas');
        }
        session_regenerate_id(true); $_SESSION['admin']=$admin['username'];$_SESSION['admin_id']=$admin['id'];$_SESSION['seen']=time();$_SESSION['csrf']=bin2hex(random_bytes(32));
        Core::query('UPDATE panel_admins SET last_login=UTC_TIMESTAMP() WHERE id=?',[$admin['id']]);Core::query('DELETE FROM login_attempts WHERE ip_hash=?',[$ip]);Core::event('login','info','Ingreso al panel');
        header('Location: dashboard.php');exit;
    } catch (PDOException $e) {error_log($e->getMessage());$error='No se pudo conectar. Verificá instalación y migración.';}
    catch (Throwable $e) {$error=$e->getMessage();}
}
?>
<!DOCTYPE html><html lang="es" data-theme="dark"><head><title>CEOSSH · Ingresar</title><?php require __DIR__.'/partials/head.php'; ?></head><body class="login-body"><form method="POST" class="login-box"><div class="sidebar-brand-mark" style="display:inline-block">C</div><h1>Bienvenido a CEOSSH</h1><p class="subtitle">Tu centro de administración SSH.</p><?php if($error): ?><div class="alert error"><?= h($error) ?></div><?php endif; ?><input type="hidden" name="csrf" value="<?= h($_SESSION['csrf']) ?>"><label class="field"><span>Usuario</span><input name="username" type="text" autocomplete="username" maxlength="64" required autofocus></label><label class="field"><span>Contraseña</span><input name="password" type="password" autocomplete="current-password" maxlength="128" required></label><button class="btn-primary" type="submit">Ingresar al panel</button><p class="footer">CEOSSH 2.0 · Administración de VPS</p></form></body></html>
