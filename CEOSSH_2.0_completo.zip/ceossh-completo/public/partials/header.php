<?php if (!defined('CEOSSH_ROOT')) { http_response_code(404); exit; } ?>
<header class="topnav">
<button class="sidebar-toggle" id="sidebarToggle" aria-label="Abrir menú" aria-expanded="false" aria-controls="ceosshSidebar"><span></span><span></span><span></span></button>
<a class="brand" href="dashboard.php">CEOSSH <small>CONTROL CENTER</small></a>
<div class="nav-actions"><a href="alertas.php" class="icon-btn" title="Alertas">◎ <span id="alertCount" class="alert-count">0</span></a><button class="icon-btn" id="demoBtn" title="Generar demo">Demo</button><button class="icon-btn" id="themeToggle" aria-label="Cambiar tema"><span class="theme-icon">☀</span></button><span class="user-chip"><?= h($_SESSION['admin']) ?></span><a href="logout.php" class="logout-btn">Salir</a></div>
</header>
