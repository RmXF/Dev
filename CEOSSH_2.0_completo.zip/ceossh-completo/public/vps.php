<?php
require dirname(__DIR__).'/app/bootstrap.php';
require_admin();
try {
    $pdo = Core::db();
    $vpsList = $pdo->query("
        SELECT v.*, g.name AS group_name,
               (SELECT COUNT(*) FROM user_vps m WHERE m.vps_id = v.id) AS group_users
        FROM vps v
        LEFT JOIN vps_groups g ON g.id = v.group_id
        ORDER BY v.created_at DESC
    ")->fetchAll(PDO::FETCH_ASSOC);

    $groups = $pdo->query("SELECT id, name FROM vps_groups ORDER BY name")->fetchAll(PDO::FETCH_ASSOC);
} catch (Throwable $e) {
    error_log($e->getMessage()); http_response_code(503); exit('Base de datos no disponible. Revisá la instalación y los logs.');
}
?>
<!DOCTYPE html>
<html lang="es" data-theme="dark">
<head>
    <?php require __DIR__.'/partials/head.php'; ?>
    <title>CEOSSH — Gestión de VPS</title>
</head>
<body>

<?php require __DIR__ . '/partials/sidebar.php'; ?>

<div class="sidebar-overlay" id="sidebarOverlay"></div>

<?php require __DIR__ . '/partials/header.php'; ?>

<main class="dashboard">

    <div class="page-title">
        <h1>Gestión de VPS</h1>
        <p class="muted">Administra los servidores VPS conectados a CEOSSH</p>
    </div>

    <div class="notice">Para una VPS nueva, verificá su huella SSH y registrala con <code>sudo bash /opt/ceossh/scripts/trust-vps.sh HOST PUERTO</code>. Guardar una VPS no confirma la conexión.</div><div class="vps-actions">
        <button class="btn-primary" id="openAddVps">
            <span>➕</span> Agregar VPS
        </button>
        <button class="btn-secondary" id="refreshList">
            <span>🔄</span> Refrescar lista
        </button>
    </div>

    <section class="vps-table-wrap">
        <?php if (empty($vpsList)): ?>
            <div class="empty-state">
                <div class="empty-icon">🖥️</div>
                <h3>No hay VPS registradas</h3>
                <p class="muted">Comienza agregando tu primer VPS con el botón de arriba.</p>
            </div>
        <?php else: ?>
            <table class="vps-table">
                <thead>
                    <tr>
                        <th>Nombre</th>
                        <th>Host</th>
                        <th>Grupo</th>
                        <th>Cuentas asociadas</th>
                        <th>Estado</th>
                        <th>Última sincronización</th>
                        <th>Acciones</th>
                    </tr>
                </thead>
                <tbody>
                <?php foreach ($vpsList as $v): ?>
                    <tr data-id="<?= (int)$v['id'] ?>">
                        <td data-label="Nombre"><strong><?= h($v['name']) ?></strong><br><small class="muted">ID #<?= (int)$v['id'] ?></small></td>
                        <td data-label="Host"><code><?= htmlspecialchars($v['host']) ?>:<?= (int)$v['ssh_port'] ?></code></td>
                        <td data-label="Grupo">
                            <?= $v['group_name']
                                ? '<span class="badge">'.htmlspecialchars($v['group_name']).'</span>'
                                : '<span class="muted">—</span>' ?>
                        </td>
                        <td data-label="Cuentas asociadas"><?= (int)$v['group_users'] ?></td>
                        <td data-label="Estado">
                            <?php if ($v['status'] === 'active'): ?>
                                <span class="status-pill status-on">Habilitada</span>
                            <?php else: ?>
                                <span class="status-pill status-off">Deshabilitada</span>
                            <?php endif; ?>
                        </td>
                        <td data-label="Última sincronización">
                            <?= $v['last_sync']
                                ? h(Core::stamp($v['last_sync']))
                                : '<span class="muted">Nunca</span>' ?>
                        </td>
                        <td data-label="Acciones" class="row-actions">
                            <button class="icon-action sync" data-id="<?= (int)$v['id'] ?>" title="Sincronizar usuarios del grupo">🔄</button>
                            <button class="icon-action ping" data-id="<?= (int)$v['id'] ?>" title="Probar conexión">📡</button>
                            <button class="icon-action edit" data-id="<?= (int)$v['id'] ?>" title="Editar">✏️</button>
                            <button class="icon-action toggle" data-id="<?= (int)$v['id'] ?>" title="Activar/Desactivar">⏻</button>
                            <button class="icon-action delete" data-id="<?= (int)$v['id'] ?>" title="Eliminar">🗑</button>
                        </td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        <?php endif; ?>
    </section>

</main>

<div class="modal-overlay" id="vpsModal">
    <div class="modal">
        <div class="modal-header">
            <h3 id="modalTitle">Agregar VPS</h3>
            <button class="modal-close" data-close>&times;</button>
        </div>

        <form id="vpsForm" class="modal-body">
            <input type="hidden" name="id" id="vps-id">

            <label class="field">
                <span>Nombre</span>
                <input type="text" name="name" id="vps-name" placeholder="Mi VPS Principal" required>
            </label>

            <label class="field">
                <span>Host / IP</span>
                <input type="text" name="host" id="vps-host" placeholder="192.168.1.10 o vps.midominio.com" required>
            </label>

            <label class="field">
                <span>Puerto SSH</span>
                <input type="number" name="ssh_port" id="vps-port" value="22" min="1" max="65535" required>
            </label>

            <label class="field">
                <span>Usuario SSH</span>
                <input type="text" name="ssh_user" id="vps-user" placeholder="root" required>
            </label>

            <label class="field">
                <span>Contraseña SSH</span>
                <input type="password" name="ssh_pass" id="vps-pass" placeholder="••••••••" autocomplete="new-password">
                <small class="muted">Vacío conserva la contraseña existente; en una VPS nueva usa la clave del panel.</small>
            </label>

            <label class="field">
                <span>Grupo</span>
                <select name="group_id" id="vps-group">
                    <option value="">Sin grupo</option>
                    <?php foreach ($groups as $g): ?>
                        <option value="<?= (int)$g['id'] ?>"><?= htmlspecialchars($g['name']) ?></option>
                    <?php endforeach; ?>
                </select>
            </label>

            <div class="modal-feedback" id="vpsFeedback"></div>
        </form>

        <div class="modal-footer">
            <button class="btn-secondary" data-close>Cancelar</button>
            <button class="btn-secondary" id="vpsTest">📡 Probar</button>
            <button class="btn-primary" id="vpsSubmit">Guardar</button>
        </div>
    </div>
</div>

<!-- ============ MODAL: Resultado de sincronización ============ -->
<div class="modal-overlay" id="syncModal">
    <div class="modal">
        <div class="modal-header">
            <h3 id="syncTitle">Sincronizando usuarios</h3>
            <button class="modal-close" data-close>&times;</button>
        </div>

        <div class="modal-body">
            <div id="syncBody">
                <p class="muted">Iniciando...</p>
            </div>
        </div>

        <div class="modal-footer">
            <button class="btn-primary" data-close>Cerrar</button>
        </div>
    </div>
</div>



<script src="assets/js/vps.js" defer></script>
<?php require __DIR__.'/partials/demo.php'; ?>
</body>
</html>