<?php
require dirname(__DIR__).'/app/bootstrap.php';
$_SESSION=[];session_destroy();setcookie(session_name(),'',time()-3600,'/','',!empty($_SERVER['HTTPS']),true);header('Location: index.php');exit;
