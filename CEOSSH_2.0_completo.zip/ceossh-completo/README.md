# CEOSSH 2.0

Panel PHP/MySQL de gestión de cuentas SSH con diseño responsive claro/oscuro, VPS y grupos, demos, alertas internas, historial de operaciones y sincronización con reintentos.

**Instalación nueva:** `sudo bash install.sh --install`.
**Actualización:** `sudo bash install.sh --update` desde el ZIP extraído fuera de `/opt/ceossh`.

Leer `docs/INSTALL.md` y `docs/UPDATE.md` antes de reemplazar. El actualizador conserva configuración/datos y respalda antes de migrar. La aplicación necesita PHP 8.1+, base de datos y cron.

## Organización

- `app`: bootstrap, seguridad, acceso a datos, SSH y cola.
- `public`: páginas y API; única raíz accesible desde la web.
- `config`: ejemplo de configuración; archivos privados generados durante instalación.
- `database`: esquema original compatible; `scripts/migrate.php` añade el esquema 2.0.
- `scripts`: instalación, migración, worker, backup, confianza SSH y registro de cuentas existentes.
- `storage`: logs y temporales persistentes.
- `tests`: pruebas de regresión para entorno aislado.

Los estados de cuenta del panel y la conectividad de la VPS son diferentes. Crear/renovar/borrar registra una operación pendiente; su aplicación remota se confirma en Operaciones. No se generan métricas simuladas.

Se conservaron los IDs de formularios, tablas, botones y modales existentes. Las implementaciones PHP/API cambiaron para corregir errores; integraciones externas que consumían respuestas antiguas deben adaptarse al contrato nuevo. `users_list` ya no devuelve contraseñas; `users_reveal` exige POST autenticado y token CSRF.

Más detalles de límites y validación en `docs/VALIDATION.md`.
