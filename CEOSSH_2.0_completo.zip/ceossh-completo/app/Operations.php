<?php
final class Operations {
    public static function queue(array $u,int $vpsId,string $kind): void {
        $replaced=Core::query("SELECT id FROM jobs WHERE user_id=? AND vps_id=? AND status IN ('pending','failed')",[$u['id'],$vpsId])->fetchAll(PDO::FETCH_COLUMN);
        Core::query("UPDATE jobs SET status='superseded',payload=? WHERE user_id=? AND vps_id=? AND status IN ('pending','failed')",[Core::encrypt('{}'),$u['id'],$vpsId]);
        foreach ($replaced as $jobId) Core::resolve('job:'.$jobId);
        $payload=['username'=>$u['username'],'password'=>$kind==='upsert'?Core::decrypt($u['password']):'','expires_at'=>$u['expires_at'],'connection_limit'=>(int)$u['connection_limit']];
        Core::query("INSERT INTO jobs(user_id,vps_id,kind,payload,status,created_at,next_attempt) VALUES(?,?,?,?,'pending',UTC_TIMESTAMP(),UTC_TIMESTAMP())",[$u['id'],$vpsId,$kind,Core::encrypt(json_encode($payload,JSON_THROW_ON_ERROR))]);
        Core::query("INSERT INTO user_vps(user_id,vps_id,state) VALUES(?,?,'pending') ON DUPLICATE KEY UPDATE state='pending'",[$u['id'],$vpsId]);
    }
    public static function reconcile(array $u): void {
        $desired=[];
        $known=array_map('intval',Core::query('SELECT vps_id FROM user_vps WHERE user_id=?',[$u['id']])->fetchAll(PDO::FETCH_COLUMN));
        if (!$u['delete_requested'] && $u['status']==='active' && strtotime($u['expires_at'].' UTC')>time() && $u['group_id']) {
            $groupVps=Core::query('SELECT id,status FROM vps WHERE group_id=?',[$u['group_id']])->fetchAll();
            foreach ($groupVps as $v) if ($v['status']==='active' || in_array((int)$v['id'],$known,true)) $desired[]=(int)$v['id'];
        }
        $known=array_map('intval',Core::query('SELECT vps_id FROM user_vps WHERE user_id=?',[$u['id']])->fetchAll(PDO::FETCH_COLUMN));
        foreach ($known as $id) if (!in_array($id,$desired,true)) self::queue($u,$id,'delete');
        foreach ($desired as $id) self::queue($u,$id,'upsert');
        if ((!$u['group_id'] || !Core::query("SELECT id FROM vps WHERE group_id=? AND status='active' LIMIT 1",[$u['group_id']])->fetchColumn()) && !$u['delete_requested'] && $u['status']==='active') Core::event('assignment','warning','Cuenta '.$u['username'].' sin VPS habilitadas.','assignment:'.$u['id']);
        else Core::resolve('assignment:'.$u['id']);
    }
    public static function expire(): void {
        $users=Core::query("SELECT * FROM ssh_users WHERE status='active' AND expires_at<=UTC_TIMESTAMP() AND delete_requested=0")->fetchAll();
        foreach ($users as $u) {
            $lock='ceossh_user_'.$u['id'];
            if (!(int)Core::query('SELECT GET_LOCK(?,0)',[$lock])->fetchColumn()) continue;
            Core::db()->beginTransaction();
            try {
                $locked=Core::query('SELECT * FROM ssh_users WHERE id=? FOR UPDATE',[$u['id']])->fetch();
                if ($locked && $locked['status']==='active' && strtotime($locked['expires_at'].' UTC')<=time()) {
                    Core::query("UPDATE ssh_users SET status='expired' WHERE id=?",[$u['id']]);
                    $locked['status']='expired'; self::reconcile($locked); Core::resolve('soon:'.$u['id']);
                    Core::event('expiry','warning','Venció la cuenta '.$u['username'],'expired:'.$u['id']);
                }
                Core::db()->commit();
            } catch (Throwable $e) { Core::db()->rollBack(); throw $e; }
            finally { Core::query('SELECT RELEASE_LOCK(?)',[$lock]); }
        }
        foreach (Core::query("SELECT id,username FROM ssh_users WHERE status='active' AND delete_requested=0 AND expires_at>UTC_TIMESTAMP() AND expires_at<=DATE_ADD(UTC_TIMESTAMP(),INTERVAL 3 DAY)")->fetchAll() as $u) Core::event('expiry','warning','La cuenta '.$u['username'].' vence dentro de los próximos 3 días.','soon:'.$u['id']);
    }
    public static function runJobs(int $limit=8): int {
        $count=0;
        // Recuperar operaciones interrumpidas: scripts idempotentes.
        Core::query("UPDATE jobs SET status='failed',next_attempt=UTC_TIMESTAMP(),last_error='Worker interrumpido; se reintentará' WHERE status='running' AND started_at<DATE_SUB(UTC_TIMESTAMP(),INTERVAL 5 MINUTE)");
        $jobs=Core::query("SELECT * FROM jobs WHERE status IN ('pending','failed') AND next_attempt<=UTC_TIMESTAMP() ORDER BY id LIMIT ".max(1,min(50,$limit)))->fetchAll();
        foreach ($jobs as $job) {
            // MySQL advisory lock compartido con guardado/renovación/eliminación.
            $lock='ceossh_user_'.$job['user_id'];
            if (!(int)Core::query('SELECT GET_LOCK(?,0)',[$lock])->fetchColumn()) continue;
            try {
                $live=Core::query('SELECT * FROM jobs WHERE id=?',[$job['id']])->fetch();
                if (!$live || !in_array($live['status'],['pending','failed'],true)) continue;
                $vps=Core::query('SELECT * FROM vps WHERE id=?',[$job['vps_id']])->fetch();
                if (!$vps) throw new RuntimeException('VPS no encontrada; revisar asociación');
                Core::query("UPDATE jobs SET status='running',started_at=UTC_TIMESTAMP(),attempts=attempts+1 WHERE id=?",[$job['id']]);
                $payload=json_decode(Core::decrypt($job['payload']),true,512,JSON_THROW_ON_ERROR);
                $u=Core::query('SELECT * FROM ssh_users WHERE id=?',[$job['user_id']])->fetch();
                if ($job['kind']==='upsert' && (!$u || $u['delete_requested'] || $u['status']!=='active' || strtotime($u['expires_at'].' UTC')<=time() || $u['group_id']!=$vps['group_id'])) {
                    Core::query("UPDATE jobs SET status='superseded' WHERE id=?",[$job['id']]); continue;
                }
                if ($job['kind']==='upsert' && $vps['status']!=='active') {
                    Core::query("UPDATE jobs SET status='pending',next_attempt=DATE_ADD(UTC_TIMESTAMP(),INTERVAL 60 SECOND),last_error='VPS deshabilitada por administrador' WHERE id=?",[$job['id']]); continue;
                }
                if ($job['kind']==='upsert') $payload=['username'=>$u['username'],'password'=>Core::decrypt($u['password']),'expires_at'=>$u['expires_at'],'connection_limit'=>$u['connection_limit']];
                $result=SshManager::apply($vps,$job['kind'],$payload);
                if (!$result['ok'] || !str_contains($result['output'],'CEOSSH_APPLIED')) throw new RuntimeException($result['error']?:'VPS no confirmó la operación');
                Core::db()->beginTransaction();
                Core::query("UPDATE jobs SET status='done',completed_at=UTC_TIMESTAMP(),last_error=NULL,payload=? WHERE id=?",[Core::encrypt('{}'),$job['id']]);
                if ($job['kind']==='delete') Core::query('DELETE FROM user_vps WHERE user_id=? AND vps_id=?',[$job['user_id'],$job['vps_id']]);
                else Core::query("UPDATE user_vps SET state='synced',last_sync=UTC_TIMESTAMP() WHERE user_id=? AND vps_id=?",[$job['user_id'],$job['vps_id']]);
                Core::query('UPDATE vps SET last_sync=UTC_TIMESTAMP() WHERE id=?',[$job['vps_id']]);
                Core::resolve('job:'.$job['id']);
                Core::db()->commit(); $count++;
            } catch (Throwable $e) {
                if (Core::db()->inTransaction()) Core::db()->rollBack();
                $error=mbSafe(substr($e->getMessage(),0,1000));
                $delay=min(3600,60*(2**min(6,(int)$job['attempts'])));
                Core::query("UPDATE jobs SET status='failed',last_error=?,next_attempt=DATE_ADD(UTC_TIMESTAMP(),INTERVAL $delay SECOND) WHERE id=?",[$error,$job['id']]);
                Core::query("UPDATE user_vps SET state='failed' WHERE user_id=? AND vps_id=?",[$job['user_id'],$job['vps_id']]);
                Core::event('sync','error','Operación '.$job['kind'].' falló en VPS #'.$job['vps_id'].': '.$error,'job:'.$job['id']);
            } finally { Core::query('SELECT RELEASE_LOCK(?)',[$lock]); }
        }
        self::finalizeDeletes(); return $count;
    }
    public static function finalizeDeletes(): void {
        $users=Core::query('SELECT id,username FROM ssh_users WHERE delete_requested=1 AND NOT EXISTS(SELECT 1 FROM user_vps WHERE user_id=ssh_users.id) AND NOT EXISTS(SELECT 1 FROM jobs WHERE user_id=ssh_users.id AND status IN (\'pending\',\'failed\',\'running\'))')->fetchAll();
        foreach ($users as $u) {
            Core::query('DELETE FROM ssh_users WHERE id=? AND delete_requested=1',[$u['id']]);
            Core::resolve('soon:'.$u['id']); Core::resolve('expired:'.$u['id']); Core::resolve('assignment:'.$u['id']);
            Core::event('delete','info','Baja remota confirmada: '.$u['username']);
        }
    }
    public static function monitor(array $vps): array {
        $r=SshManager::ping($vps);
        if (!$r['ok']) {
            Core::query("UPDATE vps SET health='offline',last_checked=UTC_TIMESTAMP(),last_error=? WHERE id=?",[substr($r['error'],0,1000),$vps['id']]);
            Core::event('vps','error','VPS '.$vps['name'].' sin conexión SSH.','offline:'.$vps['id']);
            return $r;
        }
        $m=[]; $sessions=[];
        foreach (explode("\n",$r['output']) as $line) {
            $pair=explode('=',$line,2); if (count($pair)!==2) continue;
            if ($pair[0]==='session') $sessions[]=$pair[1];
            elseif (in_array($pair[0],['cpu','ram','disk','uptime','load'],true) && is_numeric($pair[1])) $m[$pair[0]]=(float)$pair[1];
        }
        if (count($m)!==5) return ['ok'=>false,'output'=>'','error'=>'Métricas incompletas'];
        $m['sessions']=$sessions;
        Core::query("UPDATE vps SET health='online',last_checked=UTC_TIMESTAMP(),last_error=NULL,metrics=? WHERE id=?",[json_encode($m),$vps['id']]);
        Core::resolve('offline:'.$vps['id']);
        foreach (['cpu'=>90,'ram'=>90,'disk'=>85] as $key=>$threshold) {
            if ($m[$key]>=$threshold) Core::event('resource','warning',$vps['name'].': '.strtoupper($key).' al '.$m[$key].'%.','resource:'.$vps['id'].':'.$key);
            else Core::resolve('resource:'.$vps['id'].':'.$key);
        }
        return ['ok'=>true,'output'=>'Métricas actualizadas','error'=>'','metrics'=>$m];
    }
}
function mbSafe(string $value): string { return iconv('UTF-8','UTF-8//IGNORE',$value) ?: 'Error de operación'; }
