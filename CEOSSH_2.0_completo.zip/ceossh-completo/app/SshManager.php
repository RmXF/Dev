<?php
class SshManager {
    public static function exec(array $vps,string $script): array {
        $host=(string)($vps['host']??''); $user=(string)($vps['ssh_user']??''); $port=(int)($vps['ssh_port']??22);
        if (!preg_match('/^(?:[a-zA-Z0-9][a-zA-Z0-9.\-]*|[a-fA-F0-9:]+)$/D',$host) || !preg_match('/^[a-z_][a-z0-9_-]{0,31}$/D',$user) || $port<1 || $port>65535) return ['ok'=>false,'output'=>'','error'=>'Datos SSH inválidos'];
        $args=['ssh','-o','StrictHostKeyChecking=yes','-o','UserKnownHostsFile='.CEOSSH_ROOT.'/config/known_hosts','-o','ConnectTimeout=8','-o','ServerAliveInterval=5','-o','ServerAliveCountMax=2','-o','LogLevel=ERROR','-p',(string)$port,'--', $user.'@'.$host,'bash -s'];
        $env=getenv(); $pass=Core::decrypt($vps['ssh_pass']??null);
        if ($pass!=='') { array_unshift($args,'sshpass','-e'); $env['SSHPASS']=$pass; }
        else { array_splice($args,1,0,['-o','BatchMode=yes','-i',CEOSSH_ROOT.'/config/ssh/id_ed25519']); }
        $pipes=[]; $process=@proc_open($args,[0=>['pipe','r'],1=>['pipe','w'],2=>['pipe','w']],$pipes,null,$env);
        if (!is_resource($process)) return ['ok'=>false,'output'=>'','error'=>'No se pudo iniciar SSH'];
        fwrite($pipes[0],$script."\n"); fclose($pipes[0]);
        stream_set_blocking($pipes[1],false); stream_set_blocking($pipes[2],false);
        $out=''; $err=''; $deadline=microtime(true)+25; $exit=-1;
        do {
            $out.=stream_get_contents($pipes[1]); $err.=stream_get_contents($pipes[2]);
            $status=proc_get_status($process);
            if (!$status['running']) { $exit=$status['exitcode']; break; }
            if (microtime(true)>$deadline) { proc_terminate($process,9); $err='Tiempo máximo SSH superado'; break; }
            usleep(20000);
        } while (true);
        $out.=stream_get_contents($pipes[1]); $err.=stream_get_contents($pipes[2]);
        fclose($pipes[1]); fclose($pipes[2]); $closed=proc_close($process);
        if ($exit<0 && $closed>=0) $exit=$closed;
        return ['ok'=>$exit===0,'output'=>trim($out),'error'=>$exit===0?'':trim($err?:$out?:'SSH falló (código '.$exit.')')];
    }
    public static function testConnection(array $vps): array {
        $r=self::exec($vps,'printf "CEOSSH_OK\\n"'); $r['ok']=$r['ok'] && trim($r['output'])==='CEOSSH_OK'; return $r;
    }
    public static function script(string $operation,array $data): string {
        Core::username($data['username']);
        $prefix="set -euo pipefail\n";
        foreach (['username','password','expires_at','connection_limit'] as $key) {
            $b64=base64_encode((string)($data[$key]??''));
            $prefix.=strtoupper($key).'=$(printf %s '.escapeshellarg($b64)." | base64 -d)\n";
        }
        $file=CEOSSH_ROOT.'/scripts/remote-'.$operation.'.sh';
        if (!is_file($file)) throw new RuntimeException('Operación SSH desconocida');
        return $prefix.file_get_contents($file);
    }
    public static function apply(array $vps,string $operation,array $data): array { return self::exec($vps,self::script($operation,$data)); }
    public static function ping(array $vps): array { return self::exec($vps,(string)file_get_contents(CEOSSH_ROOT.'/scripts/remote-metrics.sh')); }
}
