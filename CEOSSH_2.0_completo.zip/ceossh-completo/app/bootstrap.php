<?php
declare(strict_types=1);
define('CEOSSH_ROOT', dirname(__DIR__));
if (!is_file(CEOSSH_ROOT . '/config/config.php')) {
    http_response_code(503); exit('CEOSSH necesita configuración. Ejecutá install.sh o seguí docs/INSTALL.md.');
}
require_once CEOSSH_ROOT . '/config/config.php';
define('CEOSSH_PREVIOUS_TIMEZONE', date_default_timezone_get());
date_default_timezone_set(defined('APP_TIMEZONE') ? APP_TIMEZONE : 'America/Argentina/Buenos_Aires');
require_once __DIR__ . '/Core.php';
require_once __DIR__ . '/SshManager.php';
require_once __DIR__ . '/Operations.php';
if (PHP_SAPI !== 'cli') {
    header('X-Content-Type-Options: nosniff');
    header('X-Frame-Options: DENY');
    header('Referrer-Policy: same-origin');
    header('Cache-Control: no-store');
    session_name('ceossh_sess');
    session_set_cookie_params(['httponly'=>true,'secure'=>!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off','samesite'=>'Strict','path'=>'/']);
    ini_set('session.use_strict_mode', '1');
    session_start();
    if (!isset($_SESSION['csrf'])) $_SESSION['csrf'] = bin2hex(random_bytes(32));
    if (!empty($_SESSION['admin']) && time() - (int)($_SESSION['seen'] ?? time()) > 1800) {
        session_unset(); $_SESSION['csrf'] = bin2hex(random_bytes(32));
    }
    if (!empty($_SESSION['admin'])) $_SESSION['seen'] = time();
}
