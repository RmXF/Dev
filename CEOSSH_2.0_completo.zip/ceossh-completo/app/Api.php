<?php
require_once __DIR__.'/bootstrap.php';
header('Content-Type: application/json; charset=utf-8');
require_admin(true);
function reply(array $data): void { echo json_encode($data,JSON_INVALID_UTF8_SUBSTITUTE); }
function userById(int $id): array {
    $u=Core::query('SELECT * FROM ssh_users WHERE id=?',[$id])->fetch();
    if (!$u) throw new InvalidArgumentException('Usuario no encontrado'); return $u;
}
function lockUser(int $id): void {
    $key='ceossh_user_'.$id;
    if (!(int)Core::query('SELECT GET_LOCK(?,2)',[$key])->fetchColumn()) throw new RuntimeException('Hay una operación en curso para esta cuenta. Reintentá.');
    register_shutdown_function(function()use($key){Core::query('SELECT RELEASE_LOCK(?)',[$key]);});
}
function apiDispatch(string $action): void {
    try {
        $reads=['users_list','users_get','vps_get','groups_get','alerts_list','dashboard_data','jobs_list'];
        if (!in_array($action,$reads,true)) {
            if ($_SERVER['REQUEST_METHOD']!=='POST') { http_response_code(405); reply(['ok'=>false,'msg'=>'Usar POST']); return; }
            if (!hash_equals($_SESSION['csrf'],$_SERVER['HTTP_X_CSRF_TOKEN']??'')) { http_response_code(403); reply(['ok'=>false,'msg'=>'Token de seguridad inválido. Recargá la página.']); return; }
        } elseif ($_SERVER['REQUEST_METHOD']!=='GET') { http_response_code(405); reply(['ok'=>false,'msg'=>'Usar GET']); return; }
        $in=$_SERVER['REQUEST_METHOD']==='GET'?$_GET:json_decode(file_get_contents('php://input'),true,512,JSON_THROW_ON_ERROR);
        if (!is_array($in)) throw new InvalidArgumentException('Solicitud inválida');
        $id=(int)($in['id']??0);
        switch ($action) {
        case 'users_list':
            $filter=$in['filter']??'all'; $where=['u.delete_requested=0']; $args=[];
            if ($filter==='expired') $where[]="(u.status='expired' OR u.expires_at<=UTC_TIMESTAMP())";
            if ($filter==='active') $where[]="u.status='active' AND u.expires_at>UTC_TIMESTAMP()";
            if ($filter==='pending') $where=['u.delete_requested=1'];
            if (!empty($in['group_id'])) { $where[]='u.group_id=?'; $args[]=(int)$in['group_id']; }
            if (!empty($in['search'])) { $where[]='u.username LIKE ?'; $args[]='%'.substr($in['search'],0,64).'%'; }
            $page=max(1,(int)($in['page']??1)); $size=25; $offset=($page-1)*$size;
            $where=implode(' AND ',$where);
            $total=(int)Core::query("SELECT COUNT(*) FROM ssh_users u WHERE $where",$args)->fetchColumn();
            $users=Core::query("SELECT u.id,u.username,u.group_id,u.connection_limit,u.expires_at,u.status,u.delete_requested,g.name AS group_name,(SELECT COUNT(*) FROM jobs j WHERE j.user_id=u.id AND j.status IN ('pending','failed','running')) AS pending FROM ssh_users u LEFT JOIN vps_groups g ON g.id=u.group_id WHERE $where ORDER BY u.created_at DESC,u.id DESC LIMIT $size OFFSET $offset",$args)->fetchAll();
            foreach ($users as &$u) { $u['expires_display']=Core::stamp($u['expires_at']); if ($u['status']==='active' && strtotime($u['expires_at'].' UTC')<=time()) $u['status']='expired'; } unset($u);
            reply(['ok'=>true,'users'=>$users,'total'=>$total,'page'=>$page,'pages'=>max(1,(int)ceil($total/$size))]); break;
        case 'users_get':
            $u=userById($id); unset($u['password']); $u['expires_display']=Core::stamp($u['expires_at']);
            reply(['ok'=>true,'user'=>$u]); break;
        case 'users_reveal':
            $u=userById($id); Core::event('credential','info','Credenciales consultadas de '.$u['username']);
            reply(['ok'=>true,'username'=>$u['username'],'password'=>Core::decrypt($u['password']),'expires_at'=>Core::stamp($u['expires_at']),'connection_limit'=>$u['connection_limit']]); break;
        case 'users_save':
            $username=trim($in['username']??''); Core::username($username);
            $password=(string)($in['password']??'');
            if ($password!=='' && (strlen($password)<8 || strlen($password)>128 || strpbrk($password,":\r\n")!==false)) throw new InvalidArgumentException('Contraseña: 8–128 caracteres, sin dos puntos ni saltos de línea.');
            $limit=Core::bounded($in['connection_limit']??1,1,100,'Límite');
            $group=!empty($in['group_id'])?(int)$in['group_id']:null;
            if ($group && !Core::query('SELECT id FROM vps_groups WHERE id=?',[$group])->fetchColumn()) throw new InvalidArgumentException('Grupo no encontrado');
            if ($id>0) {
                lockUser($id); $old=userById($id);
                if ($old['delete_requested']) throw new InvalidArgumentException('Cuenta con eliminación pendiente');
                if ($old['username']!==$username) throw new InvalidArgumentException('El nombre de cuenta es permanente. Creá otra cuenta si necesitás cambiarlo.');
                $expires=$old['expires_at']; $enc=$password!==''?Core::encrypt($password):$old['password']; $status=$old['status'];
            } else {
                if ($password==='') throw new InvalidArgumentException('La contraseña es obligatoria');
                $days=Core::bounded($in['days']??30,1,3650,'Días'); $expires=gmdate('Y-m-d H:i:s',time()+86400*$days); $enc=Core::encrypt($password); $status='active';
            }
            Core::db()->beginTransaction();
            if ($id) Core::query('UPDATE ssh_users SET password=?,connection_limit=?,group_id=? WHERE id=?',[$enc,$limit,$group,$id]);
            else { Core::query("INSERT INTO ssh_users(username,password,connection_limit,expires_at,status,group_id) VALUES(?,?,?,?,?,?)",[$username,$enc,$limit,$expires,$status,$group]); $id=(int)Core::db()->lastInsertId(); }
            $u=userById($id); Operations::reconcile($u);
            Core::event('user','info',($in['id']??0?'Cuenta actualizada: ':'Cuenta creada: ').$username);
            Core::db()->commit();
            reply(['ok'=>true,'msg'=>'Guardado. La aplicación en las VPS está en cola; revisá Operaciones.','id'=>$id,'credentials'=>['username'=>$username,'password'=>$password,'expires_at'=>Core::stamp($expires),'connection_limit'=>$limit,'group_name'=>$group?Core::query('SELECT name FROM vps_groups WHERE id=?',[$group])->fetchColumn():'Sin grupo']]); break;
        case 'users_renew':
            lockUser($id); $u=userById($id); if ($u['delete_requested']) throw new InvalidArgumentException('Baja pendiente');
            $days=Core::bounded($in['days']??30,1,3650,'Días');
            // Conservar los días restantes de una cuenta activa.
            $start=max(time(),strtotime($u['expires_at'].' UTC')); $expires=gmdate('Y-m-d H:i:s',$start+$days*86400);
            Core::db()->beginTransaction();
            Core::query("UPDATE ssh_users SET expires_at=?,status='active' WHERE id=?",[$expires,$id]);
            Operations::reconcile(userById($id)); Core::resolve('expired:'.$id); Core::resolve('soon:'.$id);
            Core::event('renew','info','Cuenta renovada: '.$u['username']); Core::db()->commit();
            reply(['ok'=>true,'msg'=>'Renovación en cola.','expires_at'=>Core::stamp($expires)]); break;
        case 'users_delete':
        case 'users_delete_all':
            if ($action==='users_delete_all' && ($in['confirmation']??'')!=='ELIMINAR TODOS') throw new InvalidArgumentException('Escribí ELIMINAR TODOS para confirmar');
            $ids=$action==='users_delete_all'?Core::query('SELECT id FROM ssh_users WHERE delete_requested=0')->fetchAll(PDO::FETCH_COLUMN):[$id];
            $n=0;
            foreach ($ids as $uid) {
                lockUser((int)$uid); $u=userById((int)$uid);
                Core::db()->beginTransaction();
                Core::query("UPDATE ssh_users SET delete_requested=1,status='disabled' WHERE id=?",[$uid]);
                Operations::reconcile(userById((int)$uid)); Core::event('delete','warning','Baja solicitada: '.$u['username']); Core::db()->commit(); $n++;
                Core::query('SELECT RELEASE_LOCK(?)',['ceossh_user_'.$uid]);
            }
            Operations::finalizeDeletes(); reply(['ok'=>true,'deleted'=>$n,'msg'=>"$n bajas solicitadas. Se conservará el registro hasta confirmar cada VPS."]); break;
        case 'vps_get': case 'groups_get':
            $table=$action==='vps_get'?'vps':'vps_groups'; $row=Core::query("SELECT * FROM $table WHERE id=?",[$id])->fetch();
            if (!$row) throw new InvalidArgumentException('Registro no encontrado'); unset($row['ssh_pass']); reply(['ok'=>true,$action==='vps_get'?'vps':'group'=>$row]); break;
        case 'groups_save':
            $name=trim($in['name']??''); $desc=trim($in['description']??'');
            if ($name==='' || strlen($name)>64 || strlen($desc)>255) throw new InvalidArgumentException('Nombre hasta 64 y descripción hasta 255 caracteres');
            if ($id) { if (!Core::query('SELECT id FROM vps_groups WHERE id=?',[$id])->fetchColumn()) throw new InvalidArgumentException('Grupo no encontrado'); Core::query('UPDATE vps_groups SET name=?,description=? WHERE id=?',[$name,$desc,$id]); }
            else Core::query('INSERT INTO vps_groups(name,description) VALUES(?,?)',[$name,$desc]);
            Core::event('group','info','Grupo guardado: '.$name); reply(['ok'=>true,'msg'=>'Grupo guardado']); break;
        case 'groups_delete':
            if (Core::query('SELECT id FROM ssh_users WHERE group_id=? LIMIT 1',[$id])->fetchColumn() || Core::query('SELECT id FROM vps WHERE group_id=? LIMIT 1',[$id])->fetchColumn()) throw new InvalidArgumentException('Reasigná los usuarios y VPS antes de eliminar este grupo');
            Core::query('DELETE FROM vps_groups WHERE id=?',[$id]); reply(['ok'=>true,'msg'=>'Grupo eliminado']); break;
        case 'vps_save':
            $name=trim($in['name']??''); $host=trim($in['host']??''); $user=trim($in['ssh_user']??'');
            if ($name==='' || strlen($name)>64 || !preg_match('/^(?:[a-zA-Z0-9][a-zA-Z0-9.\-]*|[a-fA-F0-9:]+)$/D',$host) || strlen($host)>128 || !preg_match('/^[a-z_][a-z0-9_-]{0,31}$/D',$user)) throw new InvalidArgumentException('Nombre, host o usuario SSH inválido');
            $port=Core::bounded($in['ssh_port']??22,1,65535,'Puerto'); $group=!empty($in['group_id'])?(int)$in['group_id']:null;
            if ($group && !Core::query('SELECT id FROM vps_groups WHERE id=?',[$group])->fetchColumn()) throw new InvalidArgumentException('Grupo no encontrado');
            $pass=(string)($in['ssh_pass']??'');
            if (strlen($pass)>128) throw new InvalidArgumentException('Contraseña SSH hasta 128 caracteres');
            if ($id) {
                $old=Core::query('SELECT * FROM vps WHERE id=?',[$id])->fetch(); if (!$old) throw new InvalidArgumentException('VPS no encontrada');
                if (($old['host']!==$host || (int)$old['ssh_port']!==$port || $old['group_id']!=$group) && Core::query('SELECT user_id FROM user_vps WHERE vps_id=? LIMIT 1',[$id])->fetchColumn()) throw new InvalidArgumentException('Esta VPS tiene cuentas asociadas. Conservá host, puerto y grupo hasta completar las bajas.');
                $enc=$pass!==''?Core::encrypt($pass):$old['ssh_pass'];
                Core::query('UPDATE vps SET name=?,host=?,ssh_port=?,ssh_user=?,ssh_pass=?,group_id=? WHERE id=?',[$name,$host,$port,$user,$enc,$group,$id]);
            } else {
                Core::query("INSERT INTO vps(name,host,ssh_port,ssh_user,ssh_pass,group_id,status) VALUES(?,?,?,?,?,?,'active')",[$name,$host,$port,$user,$pass!==''?Core::encrypt($pass):null,$group]); $id=(int)Core::db()->lastInsertId();
            }
            Core::event('vps','info','VPS guardada: '.$name); reply(['ok'=>true,'id'=>$id,'msg'=>'VPS guardada. Probá la conexión y luego sincronizá el grupo.']); break;
        case 'vps_delete':
            if (Core::query('SELECT user_id FROM user_vps WHERE vps_id=? LIMIT 1',[$id])->fetchColumn() || Core::query("SELECT id FROM jobs WHERE vps_id=? AND status IN ('pending','failed','running') LIMIT 1",[$id])->fetchColumn()) throw new InvalidArgumentException('No se puede quitar: hay cuentas o tareas pendientes en esta VPS. Completá las bajas primero.');
            Core::query('DELETE FROM vps WHERE id=?',[$id]); reply(['ok'=>true,'msg'=>'VPS quitada del panel']); break;
        case 'vps_toggle':
            Core::query("UPDATE vps SET status=IF(status='active','disabled','active') WHERE id=?",[$id]);
            reply(['ok'=>true,'msg'=>'Participación en sincronizaciones cambiada. Esto no apaga la VPS ni corta sus cuentas.']); break;
        case 'vps_test': case 'vps_refresh':
            if ($id) $vps=Core::query('SELECT * FROM vps WHERE id=?',[$id])->fetch();
            else $vps=['host'=>$in['host']??'','ssh_user'=>$in['ssh_user']??'','ssh_port'=>$in['ssh_port']??22,'ssh_pass'=>Core::encrypt($in['ssh_pass']??'')];
            if (!$vps) throw new InvalidArgumentException('VPS no encontrada');
            session_write_close(); $r=$action==='vps_refresh'?Operations::monitor($vps):SshManager::testConnection($vps);
            reply(['ok'=>$r['ok'],'msg'=>$r['ok']?'Conexión verificada':$r['error']]); break;
        case 'vps_sync':
            $id=(int)($in['vps_id']??$id); $vps=Core::query('SELECT * FROM vps WHERE id=?',[$id])->fetch();
            if (!$vps || !$vps['group_id'] || $vps['status']!=='active') throw new InvalidArgumentException('VPS sin grupo o deshabilitada');
            $users=Core::query("SELECT * FROM ssh_users WHERE group_id=? AND status='active' AND delete_requested=0 AND expires_at>UTC_TIMESTAMP()",[$vps['group_id']])->fetchAll();
            foreach ($users as $u) { lockUser((int)$u['id']); Core::db()->beginTransaction(); Operations::queue(userById((int)$u['id']),$id,'upsert'); Core::db()->commit(); Core::query('SELECT RELEASE_LOCK(?)',['ceossh_user_'.$u['id']]); }
            reply(['ok'=>true,'msg'=>count($users).' cuentas en cola','total'=>count($users),'vps'=>$vps['name']]); break;
        case 'vps_users':
            // No devolver usuarios del sistema ajenos al panel.
            reply(['ok'=>true,'users'=>Core::query('SELECT u.username,m.state,m.last_sync FROM user_vps m JOIN ssh_users u ON u.id=m.user_id WHERE m.vps_id=?',[$id])->fetchAll()]); break;
        case 'jobs_list':
            $rows=Core::query("SELECT j.id,j.user_id,j.vps_id,j.kind,j.status,j.attempts,j.last_error,j.created_at,j.next_attempt,u.username,v.name AS vps_name FROM jobs j LEFT JOIN ssh_users u ON u.id=j.user_id LEFT JOIN vps v ON v.id=j.vps_id WHERE j.status<>'superseded' ORDER BY j.id DESC LIMIT 100")->fetchAll();
            foreach ($rows as &$r) $r['created_display']=Core::stamp($r['created_at']); unset($r); reply(['ok'=>true,'jobs'=>$rows]); break;
        case 'jobs_retry':
            $j=Core::query('SELECT * FROM jobs WHERE id=?',[$id])->fetch(); if (!$j || $j['status']!=='failed') throw new InvalidArgumentException('Solo se reintentan tareas fallidas');
            Core::query("UPDATE jobs SET status='pending',next_attempt=UTC_TIMESTAMP() WHERE id=? AND status='failed'",[$id]); reply(['ok'=>true,'msg'=>'Reintento en cola']); break;
        case 'alerts_list':
            reply(['ok'=>true,'events'=>Core::query('SELECT * FROM events ORDER BY id DESC LIMIT 100')->fetchAll(),'unread'=>(int)Core::query("SELECT COUNT(*) FROM events WHERE read_at IS NULL AND resolved_at IS NULL AND severity IN ('warning','error')")->fetchColumn()]); break;
        case 'alerts_read':
            if ($id) Core::query('UPDATE events SET read_at=UTC_TIMESTAMP() WHERE id=?',[$id]); else Core::query('UPDATE events SET read_at=UTC_TIMESTAMP() WHERE read_at IS NULL'); reply(['ok'=>true]); break;
        case 'dashboard_data':
            $stats=[
                'users'=>(int)Core::query('SELECT COUNT(*) FROM ssh_users WHERE delete_requested=0')->fetchColumn(),
                'active'=>(int)Core::query("SELECT COUNT(*) FROM ssh_users WHERE status='active' AND delete_requested=0 AND expires_at>UTC_TIMESTAMP()")->fetchColumn(),
                'expired'=>(int)Core::query("SELECT COUNT(*) FROM ssh_users WHERE delete_requested=0 AND (status='expired' OR expires_at<=UTC_TIMESTAMP())")->fetchColumn(),
                'pending'=>(int)Core::query("SELECT COUNT(*) FROM jobs WHERE status IN ('pending','failed','running')")->fetchColumn(),
                'vps'=>(int)Core::query('SELECT COUNT(*) FROM vps')->fetchColumn(),
                'groups'=>(int)Core::query('SELECT COUNT(*) FROM vps_groups')->fetchColumn(),
            ];
            $servers=Core::query('SELECT id,name,host,status,health,last_checked,metrics FROM vps ORDER BY name')->fetchAll();
            foreach ($servers as &$s) { $s['metrics']=$s['metrics']?json_decode($s['metrics'],true):null; $s['checked_display']=Core::stamp($s['last_checked']); $s['stale']=!$s['last_checked'] || time()-strtotime($s['last_checked'].' UTC')>180; } unset($s);
            $heartbeat=Core::query("SELECT value FROM app_meta WHERE name='worker_heartbeat'")->fetchColumn();
            reply(['ok'=>true,'stats'=>$stats,'vps'=>$servers,'worker_ok'=>$heartbeat && time()-strtotime($heartbeat.' UTC')<180,'worker_last'=>Core::stamp($heartbeat?:null)]); break;
        case 'demo_create':
            $group=(int)($in['group_id']??0); $minutes=Core::bounded($in['minutes']??60,5,1440,'Minutos');
            if (!$group || !Core::query("SELECT id FROM vps WHERE group_id=? AND status='active' LIMIT 1",[$group])->fetchColumn()) throw new InvalidArgumentException('Elegí un grupo con VPS habilitadas');
            $name='demo_'.bin2hex(random_bytes(4)); $pass=bin2hex(random_bytes(8)); $expires=gmdate('Y-m-d H:i:s',time()+60*$minutes);
            Core::db()->beginTransaction(); Core::query("INSERT INTO ssh_users(username,password,connection_limit,expires_at,status,group_id) VALUES(?,?,1,?,'active',?)",[$name,Core::encrypt($pass),$expires,$group]);
            $id=(int)Core::db()->lastInsertId(); Operations::reconcile(userById($id)); Core::event('demo','info','Demo creada: '.$name); Core::db()->commit();
            reply(['ok'=>true,'msg'=>'Demo en cola','credentials'=>['username'=>$name,'password'=>$pass,'expires_at'=>Core::stamp($expires),'connection_limit'=>1]]); break;
        case 'password_change':
            $old=(string)($in['current']??''); $new=(string)($in['new']??'');
            $hash=Core::query('SELECT password FROM panel_admins WHERE id=?',[$_SESSION['admin_id']])->fetchColumn();
            if (!$hash || !password_verify($old,$hash)) throw new InvalidArgumentException('Contraseña actual incorrecta');
            if (strlen($new)<12 || strlen($new)>128) throw new InvalidArgumentException('Usá 12–128 caracteres');
            Core::query('UPDATE panel_admins SET password=? WHERE id=?',[password_hash($new,PASSWORD_DEFAULT),$_SESSION['admin_id']]); session_regenerate_id(true);
            Core::event('security','info','Contraseña del administrador actualizada'); reply(['ok'=>true,'msg'=>'Contraseña actualizada']); break;
        default: http_response_code(404); reply(['ok'=>false,'msg'=>'Acción no encontrada']);
        }
    } catch (InvalidArgumentException|JsonException $e) {
        if (Core::db()->inTransaction()) Core::db()->rollBack(); http_response_code(422); reply(['ok'=>false,'msg'=>$e->getMessage()]);
    } catch (Throwable $e) {
        try { if (Core::db()->inTransaction()) Core::db()->rollBack(); } catch (Throwable $ignored) {}
        error_log('CEOSSH API '.$action.': '.$e->getMessage()); http_response_code(500);
        $message=$e instanceof PDOException?'No se pudo guardar. Verificá duplicados, configuración y logs.':$e->getMessage();
        reply(['ok'=>false,'msg'=>$message]);
    }
}
