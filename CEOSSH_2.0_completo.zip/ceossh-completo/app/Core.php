<?php
final class Core {
    private static ?PDO $connection = null;
    public static function db(): PDO {
        if (!self::$connection) {
            self::$connection = new PDO('mysql:host='.DB_HOST.';dbname='.DB_NAME.';charset=utf8mb4',DB_USER,DB_PASS,[PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION,PDO::ATTR_DEFAULT_FETCH_MODE=>PDO::FETCH_ASSOC,PDO::ATTR_EMULATE_PREPARES=>false]);
            self::$connection->exec("SET time_zone = '+00:00'");
        }
        return self::$connection;
    }
    public static function query(string $sql, array $args=[]): PDOStatement {
        $s=self::db()->prepare($sql); $s->execute($args); return $s;
    }
    public static function key(): string {
        $path=CEOSSH_ROOT.'/config/secret.key';
        if (!is_file($path)) throw new RuntimeException('Falta secret.key; ejecutar scripts/migrate.php.');
        $key=base64_decode(trim((string)file_get_contents($path)),true);
        if ($key===false || strlen($key)!==32) throw new RuntimeException('Clave de cifrado inválida');
        return $key;
    }
    public static function encrypt(string $value): string {
        $iv=random_bytes(12); $tag='';
        $out=openssl_encrypt($value,'aes-256-gcm',self::key(),OPENSSL_RAW_DATA,$iv,$tag);
        if ($out===false) throw new RuntimeException('No se pudo cifrar');
        return 'enc:v1:'.base64_encode($iv.$tag.$out);
    }
    public static function decrypt(?string $value): string {
        if (!$value) return '';
        if (!str_starts_with($value,'enc:v1:')) {
            $plain=base64_decode($value,true);
            if ($plain===false) throw new RuntimeException('Credencial anterior inválida');
            return $plain;
        }
        $raw=base64_decode(substr($value,7),true);
        if ($raw===false || strlen($raw)<28) throw new RuntimeException('Credencial inválida');
        $out=openssl_decrypt(substr($raw,28),'aes-256-gcm',self::key(),OPENSSL_RAW_DATA,substr($raw,0,12),substr($raw,12,16));
        if ($out===false) throw new RuntimeException('No se pudo descifrar; verificar secret.key');
        return $out;
    }
    public static function event(string $type,string $severity,string $message,?string $dedup=null): void {
        if ($dedup && self::query('SELECT id FROM events WHERE dedup_key=? AND resolved_at IS NULL',[$dedup])->fetchColumn()) return;
        self::query('INSERT INTO events(type,severity,message,dedup_key,actor,created_at) VALUES(?,?,?,?,?,UTC_TIMESTAMP())',[$type,$severity,$message,$dedup,$_SESSION['admin']??'sistema']);
    }
    public static function resolve(string $dedup): void { self::query('UPDATE events SET resolved_at=UTC_TIMESTAMP() WHERE dedup_key=? AND resolved_at IS NULL',[$dedup]); }
    public static function username(string $name): void {
        if (!preg_match('/^[a-zA-Z0-9_]{3,32}$/D',$name) || in_array(strtolower($name),['root','admin','ubuntu','debian','nobody','www_data','daemon','bin','sys','sync','games','mail','backup','sshd'],true)) throw new InvalidArgumentException('Usuario: 3–32 caracteres, empieza con letra minúscula. No se permiten cuentas del sistema.');
    }
    public static function stamp(?string $date): ?string { return $date ? (new DateTimeImmutable($date,new DateTimeZone('UTC')))->setTimezone(new DateTimeZone(date_default_timezone_get()))->format('d/m/Y H:i') : null; }
    public static function bounded($value,int $min,int $max,string $label): int {
        $n=filter_var($value,FILTER_VALIDATE_INT);
        if ($n===false || $n<$min || $n>$max) throw new InvalidArgumentException("$label debe estar entre $min y $max");
        return $n;
    }
}
function h($v): string { return htmlspecialchars((string)$v,ENT_QUOTES|ENT_SUBSTITUTE,'UTF-8'); }
function require_admin(bool $api=false): void {
    if (empty($_SESSION['admin'])) {
        if ($api) { http_response_code(401); echo json_encode(['ok'=>false,'msg'=>'La sesión venció. Ingresá nuevamente.']); }
        else header('Location: index.php');
        exit;
    }
}
