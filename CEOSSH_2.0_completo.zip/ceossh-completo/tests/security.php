<?php
// Pruebas aisladas: no usa la base de datos ni modifica usuarios reales.
declare(strict_types=1);
$root=sys_get_temp_dir().'/ceossh-tests-'.bin2hex(random_bytes(6));
mkdir($root.'/config',0700,true);mkdir($root.'/scripts',0700,true);mkdir($root.'/bin',0700,true);
define('CEOSSH_ROOT',$root);
file_put_contents($root.'/config/secret.key',base64_encode(random_bytes(32)));
require dirname(__DIR__).'/app/Core.php';require dirname(__DIR__).'/app/SshManager.php';
function check(bool $value,string $label): void {if(!$value)throw new RuntimeException($label);echo "OK $label\n";}
try {
 $value='Literal $() `backticks` "quotes" \\ unicode ñ';
 $enc=Core::encrypt($value);check($enc!==$value && Core::decrypt($enc)===$value,'Cifrado autenticado y descifrado');
 check(Core::decrypt(base64_encode('anterior'))==='anterior','Lectura de Base64 anterior');
 $raw=base64_decode(substr($enc,7));$raw[30]=chr(ord($raw[30])^1);$bad=false;
 try{Core::decrypt('enc:v1:'.base64_encode($raw));}catch(RuntimeException $e){$bad=true;}check($bad,'Rechazo de credencial manipulada');
 $blocked=false;try{Core::username('root');}catch(InvalidArgumentException $e){$blocked=true;}check($blocked,'Protección de root');
 $blocked=false;try{Core::username('user;command');}catch(InvalidArgumentException $e){$blocked=true;}check($blocked,'Rechazo de nombre con comandos');
 file_put_contents($root.'/scripts/remote-upsert.sh',"printf '%s' \"\$PASSWORD\"\n");
 $marker=$root.'/INJECTION';$password='$(touch '.$marker.')`touch '.$marker.'`"\\literal';
 $script=SshManager::script('upsert',['username'=>'test_user','password'=>$password,'expires_at'=>'2030-01-01 00:00:00','connection_limit'=>2]);
 $pipes=[];$p=proc_open(['bash'],[0=>['pipe','r'],1=>['pipe','w'],2=>['pipe','w']],$pipes);fwrite($pipes[0],$script);fclose($pipes[0]);$out=stream_get_contents($pipes[1]);fclose($pipes[1]);$err=stream_get_contents($pipes[2]);fclose($pipes[2]);$code=proc_close($p);
 check($code===0&&$out===$password&&!file_exists($marker),'Contraseña literal sin ejecutar sustituciones de shell');
 file_put_contents($root.'/bin/ssh',"#!/bin/sh\ncat >/dev/null\nprintf 'fallo sin palabras especiales'\nexit 7\n");chmod($root.'/bin/ssh',0700);
 $oldPath=getenv('PATH');putenv('PATH='.$root.'/bin:'.$oldPath);
 $r=SshManager::exec(['host'=>'127.0.0.1','ssh_port'=>22,'ssh_user'=>'root','ssh_pass'=>null],'printf test');
 check(!$r['ok']&&$r['error']!=='','SSH usa código de salida para detectar fallos');
 file_put_contents($root.'/bin/ssh',"#!/bin/sh\ncat >/dev/null\nprintf 'CEOSSH_OK\\n'\nexit 0\n");
 check(SshManager::testConnection(['host'=>'127.0.0.1','ssh_port'=>22,'ssh_user'=>'root','ssh_pass'=>null])['ok'],'SSH exige confirmación para prueba positiva (doble de prueba)');
 putenv('PATH='.$oldPath);
 echo "Todas las pruebas aisladas pasaron.\n";
} finally {
 foreach (['config/secret.key','scripts/remote-upsert.sh','bin/ssh','INJECTION'] as $file) if(is_file($root.'/'.$file))unlink($root.'/'.$file);
 foreach (['config','scripts','bin'] as $dir)rmdir($root.'/'.$dir);rmdir($root);
}
