#!/usr/bin/env bash
# Compatibilidad con el cron anterior. El worker tiene bloqueo contra ejecuciones simultáneas.
set -euo pipefail
ROOT=$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)
exec php "$ROOT/scripts/worker.php"
