#!/usr/bin/env bash
set -euo pipefail
[[ $(id -u) == 0 ]] || { echo 'Ejecutar con sudo'; exit 1; }
HOST=${1:-}; PORT=${2:-22}
[[ "$HOST" =~ ^[a-zA-Z0-9][a-zA-Z0-9.:-]*$ && "$PORT" =~ ^[0-9]+$ && "$PORT" -ge 1 && "$PORT" -le 65535 ]] || { echo 'Uso: trust-vps.sh HOST PUERTO'; exit 1; }
ROOT=$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)
TEMP=$(mktemp);trap 'rm -f "$TEMP"' EXIT
ssh-keyscan -T 8 -p "$PORT" -t ed25519,rsa "$HOST" > "$TEMP" 2>/dev/null
[[ -s "$TEMP" ]] || { echo 'No se pudo obtener la clave pública'; exit 1; }
echo 'Compará estas huellas con las de la consola de tu proveedor / VPS:'
ssh-keygen -lf "$TEMP"
echo 'En la VPS: ssh-keygen -lf /etc/ssh/ssh_host_ed25519_key.pub'
read -r -p 'Escribí CONFIRMO si coinciden: ' CONFIRM
[[ "$CONFIRM" == CONFIRMO ]] || exit 1
mkdir -p "$ROOT/config"
touch "$ROOT/config/known_hosts"
HOSTKEY="$HOST";[[ "$PORT" != 22 ]] && HOSTKEY="[$HOST]:$PORT"
ssh-keygen -R "$HOSTKEY" -f "$ROOT/config/known_hosts" >/dev/null 2>&1 || true
cat "$TEMP" >> "$ROOT/config/known_hosts"
chown root:www-data "$ROOT/config/known_hosts";chmod 0640 "$ROOT/config/known_hosts"
echo 'Identidad SSH registrada. Ya podés probar desde el panel.'
