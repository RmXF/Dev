<?php
require dirname(__DIR__).'/app/bootstrap.php';
if(PHP_SAPI!=='cli')exit;
$name=getenv('CEOSSH_ADMIN_NAME')?:'';$password=getenv('CEOSSH_ADMIN_PASSWORD')?:'';
if(!preg_match('/^[a-zA-Z0-9_]{3,64}$/D',$name)||strlen($password)<12||strlen($password)>128)exit("Administrador inválido o contraseña menor a 12 caracteres\n");
if(Core::query('SELECT id FROM panel_admins WHERE username=?',[$name])->fetchColumn())exit("El administrador ya existe. No se cambió su contraseña.\n");
Core::query('INSERT INTO panel_admins(username,password) VALUES(?,?)',[$name,password_hash($password,PASSWORD_DEFAULT)]);
echo "Administrador creado\n";
