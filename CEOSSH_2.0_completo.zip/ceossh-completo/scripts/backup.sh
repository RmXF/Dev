#!/usr/bin/env bash
set -euo pipefail
[[ $(id -u) == 0 ]] || { echo 'Ejecutar con sudo'; exit 1; }
TARGET=${1:-/opt/ceossh}
OUT="/root/ceossh-backups/$(date +%Y%m%d-%H%M%S)"
umask 077
mkdir -p "$OUT"
php "$TARGET/scripts/backup.php" "$OUT/database.sql"
tar -czf "$OUT/panel.tar.gz" -C "$(dirname "$TARGET")" "$(basename "$TARGET")"
printf 'Respaldo: %s\n' "$OUT"
