<?php
require dirname(__DIR__).'/app/bootstrap.php';
if (PHP_SAPI!=='cli') exit;
$db=Core::db();
$lock=$db->query("SELECT GET_LOCK('ceossh_migrate',10)")->fetchColumn();
if (!$lock) exit("Otra migración está ejecutándose\n");
try {
    $keyPath=CEOSSH_ROOT.'/config/secret.key';
    if (!is_file($keyPath)) {
        $f=fopen($keyPath,'x'); if (!$f) throw new RuntimeException('No se pudo crear secret.key');
        fwrite($f,base64_encode(random_bytes(32))); fclose($f); chmod($keyPath,0640);
    }
    $db->exec(file_get_contents(CEOSSH_ROOT.'/database/schema.sql'));
    $columns=[
        'ssh_users'=>['delete_requested'=>'TINYINT NOT NULL DEFAULT 0'],
        'vps'=>['health'=>"VARCHAR(16) NOT NULL DEFAULT 'unknown'",'last_checked'=>'DATETIME NULL','last_error'=>'TEXT NULL','metrics'=>'LONGTEXT NULL'],
    ];
    foreach ($columns as $table=>$items) foreach ($items as $name=>$definition) {
        $stmt=$db->prepare('SELECT COUNT(*) FROM information_schema.columns WHERE table_schema=? AND table_name=? AND column_name=?'); $stmt->execute([DB_NAME,$table,$name]);
        if (!(int)$stmt->fetchColumn()) $db->exec("ALTER TABLE `$table` ADD COLUMN `$name` $definition");
    }
    foreach (['ssh_users'=>'password','vps'=>'ssh_pass'] as $table=>$field) {
        $type=Core::query('SELECT DATA_TYPE FROM information_schema.columns WHERE table_schema=? AND table_name=? AND column_name=?',[DB_NAME,$table,$field])->fetchColumn();
        if ($type!=='text') $db->exec("ALTER TABLE `$table` MODIFY `$field` TEXT ".($table==='ssh_users'?'NOT NULL':'NULL'));
    }
    $db->exec("CREATE TABLE IF NOT EXISTS app_meta (name VARCHAR(64) PRIMARY KEY,value TEXT NOT NULL)");
    $db->exec("CREATE TABLE IF NOT EXISTS user_vps (user_id INT NOT NULL,vps_id INT NOT NULL,state VARCHAR(16) NOT NULL DEFAULT 'unknown',last_sync DATETIME NULL,PRIMARY KEY(user_id,vps_id))");
    $db->exec("CREATE TABLE IF NOT EXISTS jobs (id BIGINT AUTO_INCREMENT PRIMARY KEY,user_id INT NOT NULL,vps_id INT NOT NULL,kind VARCHAR(16) NOT NULL,payload LONGTEXT NOT NULL,status VARCHAR(16) NOT NULL DEFAULT 'pending',attempts INT NOT NULL DEFAULT 0,last_error TEXT NULL,created_at DATETIME NOT NULL,started_at DATETIME NULL,completed_at DATETIME NULL,next_attempt DATETIME NOT NULL,INDEX queue_idx(status,next_attempt),INDEX user_idx(user_id,vps_id))");
    $db->exec("CREATE TABLE IF NOT EXISTS events (id BIGINT AUTO_INCREMENT PRIMARY KEY,type VARCHAR(32) NOT NULL,severity VARCHAR(16) NOT NULL,message TEXT NOT NULL,dedup_key VARCHAR(128) NULL,actor VARCHAR(64) NOT NULL,created_at DATETIME NOT NULL,read_at DATETIME NULL,resolved_at DATETIME NULL,INDEX alert_idx(resolved_at,severity),INDEX dedup_idx(dedup_key))");
    $db->exec("CREATE TABLE IF NOT EXISTS login_attempts (id BIGINT AUTO_INCREMENT PRIMARY KEY,ip_hash VARCHAR(64) NOT NULL,created_at DATETIME NOT NULL,INDEX attempts_idx(ip_hash,created_at))");
    if (!Core::query("SELECT value FROM app_meta WHERE name='membership_seeded'")->fetchColumn()) {
        $db->exec("INSERT IGNORE INTO user_vps(user_id,vps_id,state) SELECT u.id,v.id,'unknown' FROM ssh_users u JOIN vps v ON v.group_id=u.group_id");
        Core::query("INSERT INTO app_meta(name,value) VALUES('membership_seeded','1')");
        echo "Asociaciones anteriores conservadas. Para cuentas existentes ver scripts/adopt.php.\n";
    }
    $db->beginTransaction();
    foreach (['vps'=>'ssh_pass','ssh_users'=>'password'] as $table=>$field) {
        foreach (Core::query("SELECT id,`$field` AS secret FROM `$table` WHERE `$field` IS NOT NULL")->fetchAll() as $row) {
            if ($row['secret']!=='' && !str_starts_with($row['secret'],'enc:v1:')) Core::query("UPDATE `$table` SET `$field`=? WHERE id=?",[Core::encrypt(Core::decrypt($row['secret'])),$row['id']]);
        }
    }
    if (!Core::query("SELECT value FROM app_meta WHERE name='utc_dates'")->fetchColumn()) {
        $zone=new DateTimeZone(defined('LEGACY_DATA_TIMEZONE')?LEGACY_DATA_TIMEZONE:CEOSSH_PREVIOUS_TIMEZONE);
        foreach (['ssh_users'=>['expires_at','created_at'],'demo_users'=>['expires_at','created_at'],'vps'=>['created_at','last_sync'],'vps_groups'=>['created_at'],'panel_admins'=>['created_at','last_login']] as $table=>$fields) {
            foreach (Core::query("SELECT * FROM `$table`")->fetchAll() as $row) foreach ($fields as $field) if (!empty($row[$field])) {
                $utc=(new DateTimeImmutable($row[$field],$zone))->setTimezone(new DateTimeZone('UTC'))->format('Y-m-d H:i:s');
                Core::query("UPDATE `$table` SET `$field`=? WHERE id=?",[$utc,$row['id']]);
            }
        }
        Core::query("INSERT INTO app_meta(name,value) VALUES('utc_dates','1')");
    }
    $db->commit();
    Core::query("INSERT INTO app_meta(name,value) VALUES('version','2.0.0') ON DUPLICATE KEY UPDATE value='2.0.0'");
    echo "Migración 2.0.0 completada sin eliminar datos.\n";
} finally { $db->query("SELECT RELEASE_LOCK('ceossh_migrate')"); }
