# Recibe variables seguras a través de app/SshManager.php
[[ $(id -u) == 0 ]] || { echo 'Se necesita root en la VPS'; exit 1; }
[[ "$USERNAME" =~ ^[a-zA-Z0-9_]{3,32}$ ]] || exit 1
mkdir -p /etc/ceossh-managed
if id "$USERNAME" >/dev/null 2>&1; then
    USER_UID=$(id -u "$USERNAME")
    [[ "$USER_UID" -ge 1000 && "$USER_UID" -lt 65534 ]] || { echo 'Cuenta del sistema protegida'; exit 1; }
    [[ -f "/etc/ceossh-managed/$USERNAME" ]] || { echo 'Cuenta existente sin registro CEOSSH. Usar scripts/adopt.php'; exit 1; }
else
    useradd -m -s /bin/bash "$USERNAME"
    touch "/etc/ceossh-managed/$USERNAME"
fi
[[ "$PASSWORD" != *$'\n'* && "$PASSWORD" != *:* && "$PASSWORD" != *$'\r'* ]] || { echo 'Contraseña inválida'; exit 1; }
printf '%s:%s\n' "$USERNAME" "$PASSWORD" | chpasswd
# chage tiene precisión de día. El worker central corta al vencer (cada minuto).
EXPIRY_DAY=$(date -u -d "$EXPIRES_AT UTC +1 day" +%Y-%m-%d)
chage -M -1 -E "$EXPIRY_DAY" "$USERNAME"
usermod -U "$USERNAME"
usermod -s /bin/bash "$USERNAME"
[[ "$CONNECTION_LIMIT" =~ ^[0-9]+$ ]] || exit 1
sed -i "/^$USERNAME[[:space:]]/d" /etc/security/limits.conf
printf '%s hard maxlogins %s\n' "$USERNAME" "$CONNECTION_LIMIT" > "/etc/security/limits.d/ceossh-$USERNAME.conf"
printf 'CEOSSH_APPLIED\n'
