#!/usr/bin/env bash
set -euo pipefail
ROOT=$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)
USERNAME=${1:?Usuario}; PASSWORD=${2:?Contraseña}; DAYS=${3:?Días}; CONNECTION_LIMIT=${4:?Límite}
[[ "$DAYS" =~ ^[0-9]+$ && "$DAYS" -ge 1 && "$DAYS" -le 3650 ]] || exit 1
[[ "$CONNECTION_LIMIT" =~ ^[0-9]+$ && "$CONNECTION_LIMIT" -ge 1 && "$CONNECTION_LIMIT" -le 100 ]] || exit 1
EXPIRES_AT=$(date -u -d "+$DAYS days" '+%Y-%m-%d %H:%M:%S')
source "$ROOT/scripts/remote-upsert.sh"
