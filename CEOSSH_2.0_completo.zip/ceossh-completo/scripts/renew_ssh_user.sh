#!/usr/bin/env bash
# Las renovaciones deben conservar fechas y recrear cuentas eliminadas: usar el panel.
echo 'Renová desde usuarios.php para mantener sincronización y vencimiento correctos.' >&2
exit 1
