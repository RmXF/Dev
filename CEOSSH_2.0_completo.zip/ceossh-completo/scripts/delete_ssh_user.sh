#!/usr/bin/env bash
set -euo pipefail
ROOT=$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)
USERNAME=${1:?Usuario}
source "$ROOT/scripts/remote-delete.sh"
