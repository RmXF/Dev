<?php
require dirname(__DIR__).'/app/bootstrap.php';
if (PHP_SAPI!=='cli') exit;
$lock=fopen(CEOSSH_ROOT.'/storage/worker.lock','c');
if (!$lock || !flock($lock,LOCK_EX|LOCK_NB)) exit;
try {
    Operations::expire();
    $count=Operations::runJobs(8);
    // Monitorear las 3 VPS menos recientes por ciclo para no bloquear toda la cola.
    foreach (Core::query("SELECT * FROM vps WHERE status='active' AND (last_checked IS NULL OR last_checked<DATE_SUB(UTC_TIMESTAMP(),INTERVAL 60 SECOND)) ORDER BY last_checked LIMIT 3")->fetchAll() as $vps) Operations::monitor($vps);
    Core::query("INSERT INTO app_meta(name,value) VALUES('worker_heartbeat',?) ON DUPLICATE KEY UPDATE value=VALUES(value)",[gmdate('Y-m-d H:i:s')]);
    Core::query('DELETE FROM login_attempts WHERE created_at<DATE_SUB(UTC_TIMESTAMP(),INTERVAL 1 DAY)');
    echo date('Y-m-d H:i:s')." OK: $count operaciones completadas\n";
} catch (Throwable $e) { fwrite(STDERR,date('Y-m-d H:i:s').' ERROR: '.$e->getMessage()."\n"); exit(1); }
