[[ $(id -u) == 0 ]] || { echo 'Se necesita root en la VPS'; exit 1; }
[[ "$USERNAME" =~ ^[a-zA-Z0-9_]{3,32}$ ]] || exit 1
if id "$USERNAME" >/dev/null 2>&1; then
    USER_UID=$(id -u "$USERNAME")
    [[ "$USER_UID" -ge 1000 && "$USER_UID" -lt 65534 ]] || { echo 'Cuenta del sistema protegida'; exit 1; }
    [[ -f "/etc/ceossh-managed/$USERNAME" ]] || { echo 'Cuenta existente sin registro CEOSSH. Usar scripts/adopt.php'; exit 1; }
    passwd -l "$USERNAME"
    usermod -s /usr/sbin/nologin "$USERNAME"
    pkill -KILL -u "$USER_UID" 2>/dev/null || true
    userdel -r "$USERNAME"
fi
rm -f "/etc/security/limits.d/ceossh-$USERNAME.conf" "/etc/ceossh-managed/$USERNAME"
sed -i "/^$USERNAME[[:space:]]/d" /etc/security/limits.conf
printf 'CEOSSH_APPLIED\n'
