set -euo pipefail
read -r _ a b c d e f g h _ < /proc/stat
TOTAL1=$((a+b+c+d+e+f+g+h)); IDLE1=$((d+e))
sleep 1
read -r _ a b c d e f g h _ < /proc/stat
TOTAL2=$((a+b+c+d+e+f+g+h)); IDLE2=$((d+e))
CPU=$(awk -v t="$((TOTAL2-TOTAL1))" -v i="$((IDLE2-IDLE1))" 'BEGIN {if(t>0) printf "%.1f",100*(t-i)/t; else print 0}')
RAM=$(awk '/MemTotal:/{t=$2} /MemAvailable:/{a=$2} END{if(t>0) printf "%.1f",100*(t-a)/t; else print 0}' /proc/meminfo)
DISK=$(df -P / | awk 'NR==2{gsub(/%/,"",$5);print $5}')
UPTIME=$(cut -d' ' -f1 /proc/uptime)
LOAD=$(cut -d' ' -f1 /proc/loadavg)
printf 'cpu=%s\nram=%s\ndisk=%s\nuptime=%s\nload=%s\n' "$CPU" "$RAM" "$DISK" "$UPTIME" "$LOAD"
ps -eo args | awk '/^sshd: [a-zA-Z0-9_]+@/{split($2,a,"@");print "session=" a[1]}'
