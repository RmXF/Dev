<?php
if (PHP_SAPI!=='cli') exit;
$config=getenv('CEOSSH_BACKUP_CONFIG') ?: dirname(__DIR__).'/config/config.php';
require $config;
if(PHP_SAPI!=='cli')exit;
$file=$argv[1]??'';if(!$file)exit("Uso: php backup.php /ruta/respaldo.sql\n");
$tmp=tempnam(sys_get_temp_dir(),'ceossh-db-');chmod($tmp,0600);
$escape=fn($v)=>'"'.str_replace(["\\",'"',"\n","\r"],["\\\\",'\\"','\\n','\\r'],(string)$v).'"';
file_put_contents($tmp,"[client]\nhost=".$escape(DB_HOST)."\nuser=".$escape(DB_USER)."\npassword=".$escape(DB_PASS)."\n");
try {
    $p=proc_open(['mysqldump','--defaults-extra-file='.$tmp,'--single-transaction','--routines','--triggers','--no-tablespaces',DB_NAME],[0=>['file','/dev/null','r'],1=>['file',$file,'w'],2=>['pipe','w']],$pipes);
    if(!is_resource($p))throw new RuntimeException('No se pudo iniciar mysqldump');$error=stream_get_contents($pipes[2]);fclose($pipes[2]);$code=proc_close($p);
    if($code!==0)throw new RuntimeException('Backup falló: '.$error);chmod($file,0600);echo "Base de datos respaldada\n";
} finally {unlink($tmp);}
