<?php
require dirname(__DIR__).'/app/bootstrap.php';
if(PHP_SAPI!=='cli')exit;
$id=(int)($argv[1]??0);$confirm=$argv[2]??'';
if($id<1||$confirm!=='CONFIRMO')exit("Uso: php scripts/adopt.php ID_VPS CONFIRMO\nRegistra como administradas las cuentas previas asociadas a esta VPS; revisá previamente la BD.\n");
$vps=Core::query('SELECT * FROM vps WHERE id=?',[$id])->fetch();if(!$vps)exit("VPS no encontrada\n");
$users=Core::query('SELECT u.username FROM ssh_users u JOIN user_vps m ON m.user_id=u.id WHERE m.vps_id=?',[$id])->fetchAll();
foreach($users as $u){
 Core::username($u['username']);$name=base64_encode($u['username']);
 $script="set -euo pipefail\nNAME=\$(printf %s '$name' | base64 -d)\n".'
[[ $(id -u) == 0 ]] || exit 1
if id "$NAME" >/dev/null 2>&1; then
 U=$(id -u "$NAME")
 [[ "$U" -ge 1000 && "$U" -lt 65534 ]] || { echo "Cuenta del sistema protegida"; exit 1; }
 mkdir -p /etc/ceossh-managed
 touch "/etc/ceossh-managed/$NAME"
fi
printf "Registrada\\n"
';
 $r=SshManager::exec($vps,$script);echo $u['username'].': '.($r['ok']?'OK':$r['error'])."\n";
}
