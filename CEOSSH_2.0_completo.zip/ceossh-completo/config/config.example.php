<?php
// install.sh crea config.php. En actualización, se conserva el config.php existente.
define('DB_HOST', 'localhost');
define('DB_NAME', 'ceossh');
define('DB_USER', 'ceossh');
define('DB_PASS', 'CAMBIAR');
define('APP_TIMEZONE', 'America/Argentina/Buenos_Aires');
// Para convertir fechas de la versión anterior UNA sola vez durante migrate.php.
// Usar la zona con la que se guardaron las fechas originales (PHP anterior).
define('LEGACY_DATA_TIMEZONE', 'UTC');
define('SERVER_IP', '127.0.0.1');
define('CEOSSH_VERSION', '2.0.0');
