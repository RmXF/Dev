console.log("Panel cargado correctamente.");
document.addEventListener("DOMContentLoaded", ()=>{
    const cards = document.querySelectorAll('.card');
    cards.forEach(card=>{
        card.style.opacity=0;
        setTimeout(()=>{ card.style.opacity=1; card.style.transition="opacity 0.8s ease"; }, 300);
    });
});