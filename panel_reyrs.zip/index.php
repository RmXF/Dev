<?php
session_start();
include("config.php");

if(isset($_SESSION['usuario'])){
    header("Location: dashboard.php");
    exit();
}

$error = "";
if($_SERVER["REQUEST_METHOD"]=="POST"){
    $user = $_POST['usuario'];
    $pass = $_POST['contrasena'];
    if($user === $usuario_panel && $pass === $contrasena_panel){
        $_SESSION['usuario'] = $user;
        header("Location: dashboard.php");
        exit();
    }else{
        $error="Usuario o contraseña incorrectos";
    }
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<title>Login Panel</title>
<link rel="stylesheet" href="assets/style.css">
</head>
<body class="login-body">
<div class="login-box">
    <img src="assets/logo.png" alt="Logo" class="logo">
    <h2>Panel Web</h2>
    <form method="POST">
        <input type="text" name="usuario" placeholder="Usuario" value="<?= isset($_POST['usuario']) ? htmlspecialchars($_POST['usuario']) : '' ?>" required>
        <input type="password" name="contrasena" placeholder="Contraseña" required>
        <button type="submit">Ingresar</button>
        <?php if($error): ?>
            <p class="error"><?= $error ?></p>
        <?php endif; ?>
    </form>
</div>
<script src="assets/script.js"></script>
</body>
</html>