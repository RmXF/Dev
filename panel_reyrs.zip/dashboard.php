<?php
session_start();
if(!isset($_SESSION['usuario'])){
    header("Location: index.php");
    exit();
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<title>Dashboard</title>
<link rel="stylesheet" href="assets/style.css">
</head>
<body>
<nav class="navbar">
    <h1>Dashboard</h1>
    <a href="logout.php">Cerrar sesión</a>
</nav>
<main class="content">
    <div class="card">
        <h2>Bienvenido, <?= $_SESSION['usuario'] ?> 👋</h2>
        <p>Has iniciado sesión correctamente.</p>
    </div>
    <div class="card">
        <h3>Información del servidor</h3>
        <ul>
            <li>PHP: <?= phpversion() ?></li>
            <li>Servidor: <?= $_SERVER['SERVER_SOFTWARE'] ?></li>
            <li>IP: <?= $_SERVER['SERVER_ADDR'] ?></li>
        </ul>
    </div>
</main>
<script src="assets/script.js"></script>
</body>
</html>