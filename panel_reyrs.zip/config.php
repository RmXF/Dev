<?php
$usuario_panel = "admin";
$contrasena_panel = "admin123";
?>