// Datos de ejemplo
const servers = [
    { name: 'VPS-Web-01', ip: '192.168.1.101', cpu: 45, ram: 62, disk: 38, status: 'active' },
    { name: 'VPS-DB-01', ip: '192.168.1.102', cpu: 78, ram: 84, disk: 56, status: 'active' },
    { name: 'VPS-Cache-01', ip: '192.168.1.103', cpu: 23, ram: 34, disk: 22, status: 'active' },
    { name: 'VPS-Backup-01', ip: '192.168.1.104', cpu: 12, ram: 18, disk: 67, status: 'inactive' },
    { name: 'VPS-Test-01', ip: '192.168.1.105', cpu: 34, ram: 45, disk: 28, status: 'active' },
];

const activities = [
    { icon: 'fa-server', text: 'Servidor VPS-Web-01 reiniciado', time: 'Hace 5 minutos', color: '#6c5ce7' },
    { icon: 'fa-database', text: 'Backup completado en VPS-DB-01', time: 'Hace 15 minutos', color: '#00b894' },
    { icon: 'fa-shield-alt', text: 'Actualización de seguridad aplicada', time: 'Hace 1 hora', color: '#fdcb6e' },
    { icon: 'fa-users', text: 'Nuevo usuario conectado', time: 'Hace 2 horas', color: '#6c5ce7' },
    { icon: 'fa-chart-line', text: 'Pico de tráfico detectado', time: 'Hace 3 horas', color: '#d63031' },
];

// Inicialización
document.addEventListener('DOMContentLoaded', () => {
    loadServers();
    loadActivities();
    setupDate();
    initializeCharts();
    setupEventListeners();
    startRealTimeUpdates();
});

// Cargar servidores en la tabla
function loadServers() {
    const tbody = document.getElementById('serversTableBody');
    tbody.innerHTML = '';

    servers.forEach(server => {
        const row = document.createElement('tr');
        row.innerHTML = `
            <td>${server.name}</td>
            <td>${server.ip}</td>
            <td>
                <div style="display: flex; align-items: center; gap: 8px;">
                    <div class="progress-bar" style="width: 80px; height: 6px;">
                        <div class="progress" style="width: ${server.cpu}%; background: ${getCpuColor(server.cpu)};"></div>
                    </div>
                    <span>${server.cpu}%</span>
                </div>
            </td>
            <td>
                <div style="display: flex; align-items: center; gap: 8px;">
                    <div class="progress-bar" style="width: 80px; height: 6px;">
                        <div class="progress" style="width: ${server.ram}%; background: ${getRamColor(server.ram)};"></div>
                    </div>
                    <span>${server.ram}%</span>
                </div>
            </td>
            <td>${server.disk}%</td>
            <td>
                <span class="status-badge ${server.status}">
                    ${server.status === 'active' ? 'Activo' : 'Inactivo'}
                </span>
            </td>
            <td>
                <div class="action-buttons">
                    <button class="table-action-btn" onclick="restartServer('${server.name}')">
                        <i class="fas fa-redo-alt"></i>
                    </button>
                    <button class="table-action-btn" onclick="viewServerDetails('${server.name}')">
                        <i class="fas fa-chart-line"></i>
                    </button>
                    <button class="table-action-btn" onclick="configureServer('${server.name}')">
                        <i class="fas fa-cog"></i>
                    </button>
                </div>
            </td>
        `;
        tbody.appendChild(row);
    });
}

// Color según uso de CPU
function getCpuColor(value) {
    if (value < 50) return '#00b894';
    if (value < 80) return '#fdcb6e';
    return '#d63031';
}

// Color según uso de RAM
function getRamColor(value) {
    if (value < 60) return '#00b894';
    if (value < 85) return '#fdcb6e';
    return '#d63031';
}

// Cargar actividades
function loadActivities() {
    const activityList = document.getElementById('activityList');
    activityList.innerHTML = '';

    activities.forEach(activity => {
        const item = document.createElement('div');
        item.className = 'activity-item';
        item.innerHTML = `
            <div class="activity-icon" style="background: ${activity.color}20; color: ${activity.color};">
                <i class="fas ${activity.icon}"></i>
            </div>
            <div class="activity-details">
                <div class="activity-text">${activity.text}</div>
                <div class="activity-time">${activity.time}</div>
            </div>
        `;
        activityList.appendChild(item);
    });
}

// Configurar fecha actual
function setupDate() {
    const dateElement = document.getElementById('currentDate');
    const options = { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' };
    const today = new Date().toLocaleDateString('es-ES', options);
    dateElement.textContent = today.charAt(0).toUpperCase() + today.slice(1);
}

// Inicializar gráficos
function initializeCharts() {
    // CPU Chart
    const cpuCtx = document.getElementById('cpuChart').getContext('2d');
    new Chart(cpuCtx, {
        type: 'line',
        data: {
            labels: ['00:00', '04:00', '08:00', '12:00', '16:00', '20:00', 'Ahora'],
            datasets: [{
                label: 'Uso de CPU %',
                data: [45, 52, 48, 63, 58, 72, 43],
                borderColor: '#6c5ce7',
                backgroundColor: 'rgba(108, 92, 231, 0.1)',
                tension: 0.4,
                fill: true
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    display: false
                }
            },
            scales: {
                y: {
                    beginAtZero: true,
                    max: 100,
                    grid: {
                        display: true,
                        color: 'rgba(0, 0, 0, 0.05)'
                    }
                },
                x: {
                    grid: {
                        display: false
                    }
                }
            }
        }
    });

    // Network Chart
    const networkCtx = document.getElementById('networkChart').getContext('2d');
    new Chart(networkCtx, {
        type: 'bar',
        data: {
            labels: ['Lun', 'Mar', 'Mié', 'Jue', 'Vie', 'Sáb', 'Dom'],
            datasets: [{
                label: 'Tráfico Entrante',
                data: [120, 145, 132, 168, 189, 210, 156],
                backgroundColor: '#6c5ce7',
                borderRadius: 6
            }, {
                label: 'Tráfico Saliente',
                data: [98, 112, 108, 134, 145, 178, 132],
                backgroundColor: '#00d2d3',
                borderRadius: 6
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    position: 'top',
                    labels: {
                        usePointStyle: true,
                        boxWidth: 6
                    }
                }
            },
            scales: {
                y: {
                    beginAtZero: true,
                    grid: {
                        display: true,
                        color: 'rgba(0, 0, 0, 0.05)'
                    }
                },
                x: {
                    grid: {
                        display: false
                    }
                }
            }
        }
    });
}

// Configurar event listeners
function setupEventListeners() {
    // Menu toggle
    document.getElementById('menuToggle').addEventListener('click', () => {
        document.getElementById('sidebar').classList.add('active');
    });

    document.getElementById('closeSidebar').addEventListener('click', () => {
        document.getElementById('sidebar').classList.remove('active');
    });

    // Theme toggle
    document.getElementById('themeToggle').addEventListener('click', () => {
        document.body.classList.toggle('dark-theme');
        const icon = document.querySelector('#themeToggle i');
        icon.className = document.body.classList.contains('dark-theme') ? 'fas fa-sun' : 'fas fa-moon';
    });

    // Click outside sidebar to close (mobile)
    document.addEventListener('click', (e) => {
        const sidebar = document.getElementById('sidebar');
        const menuToggle = document.getElementById('menuToggle');
        
        if (window.innerWidth <= 768) {
            if (!sidebar.contains(e.target) && !menuToggle.contains(e.target) && sidebar.classList.contains('active')) {
                sidebar.classList.remove('active');
            }
        }
    });

    // Resize handler
    window.addEventListener('resize', () => {
        if (window.innerWidth > 768) {
            document.getElementById('sidebar').classList.remove('active');
        }
    });
}

// Actualizaciones en tiempo real
function startRealTimeUpdates() {
    setInterval(() => {
        // Actualizar estadísticas aleatoriamente
        document.getElementById('activeServers').textContent = Math.floor(Math.random() * 5 + 10);
        document.getElementById('connectedUsers').textContent = Math.floor(Math.random() * 500 + 1200);
        document.getElementById('avgCpu').textContent = Math.floor(Math.random() * 30 + 30) + '%';
        
        // Actualizar uso de CPU en servidores
        servers.forEach(server => {
            server.cpu = Math.floor(Math.random() * 60 + 20);
            server.ram = Math.floor(Math.random() * 40 + 40);
        });
        loadServers();
    }, 5000);
}

// Funciones de acción
function restartServer(serverName) {
    showModal('Reiniciar Servidor', `¿Estás seguro de que quieres reiniciar ${serverName}?`, () => {
        showNotification('Servidor reiniciado', `${serverName} se está reiniciando...`, 'success');
    });
}

function viewServerDetails(serverName) {
    showModal('Detalles del Servidor', `Mostrando estadísticas detalladas de ${serverName}`, null);
}

function configureServer(serverName) {
    showModal('Configurar Servidor', `Configuración avanzada de ${serverName}`, null);
}

function restartService(service) {
    showModal('Reiniciar Servicio', `Reiniciando ${service}...`, () => {
        showNotification('Servicio reiniciado', `${service} se ha reiniciado correctamente`, 'success');
    });
}

function backupNow() {
    showModal('Backup', 'Iniciando copia de seguridad...', () => {
        showNotification('Backup completado', 'La copia de seguridad se ha completado exitosamente', 'success');
    });
}

function clearCache() {
    showModal('Limpiar Cache', 'Eliminando archivos temporales...', () => {
        showNotification('Cache limpiado', 'Se han eliminado 2.3 GB de archivos temporales', 'success');
    });
}

function checkServer() {
    showNotification('Verificación completa', 'Todos los sistemas funcionando correctamente', 'info');
}

// Modal functions
function showModal(title, message, onConfirm) {
    const modal = document.getElementById('modal');
    document.getElementById('modalTitle').textContent = title;
    document.getElementById('modalMessage').textContent = message;
    
    const confirmBtn = document.getElementById('modalConfirmBtn');
    if (onConfirm) {
        confirmBtn.onclick = () => {
            onConfirm();
            closeModal();
        };
        confirmBtn.style.display = 'block';
    } else {
        confirmBtn.style.display = 'none';
    }
    
    modal.classList.add('active');
}

function closeModal() {
    document.getElementById('modal').classList.remove('active');
}

// Notificaciones personalizadas
function showNotification(title, message, type = 'info') {
    // Crear elemento de notificación
    const notification = document.createElement('div');
    notification.className = `notification notification-${type}`;
    notification.innerHTML = `
        <div class="notification-content">
            <i class="fas ${type === 'success' ? 'fa-check-circle' : 'fa-info-circle'}"></i>
            <div>
                <div class="notification-title">${title}</div>
                <div class="notification-message">${message}</div>
            </div>
        </div>
        <button class="notification-close">
            <i class="fas fa-times"></i>
        </button>
    `;

    // Estilos para la notificación
    notification.style.cssText = `
        position: fixed;
        top: 20px;
        right: 20px;
        background: white;
        padding: 16px 20px;
        border-radius: 12px;
        box-shadow: 0 10px 30px rgba(0,0,0,0.15);
        display: flex;
        align-items: center;
        justify-content: space-between;
        gap: 20px;
        z-index: 3000;
        animation: slideIn 0.3s ease;
        border-left: 4px solid ${type === 'success' ? '#00b894' : type === 'warning' ? '#fdcb6e' : '#6c5ce7'};
    `;

    document.body.appendChild(notification);

    // Cerrar notificación
    notification.querySelector('.notification-close').addEventListener('click', () => {
        notification.remove();
    });

    // Auto-cerrar después de 5 segundos
    setTimeout(() => {
        if (notification.parentNode) {
            notification.remove();
        }
    }, 5000);
}

// Agregar estilos para notificaciones
const style = document.createElement('style');
style.textContent = `
    @keyframes slideIn {
        from {
            transform: translateX(100%);
            opacity: 0;
        }
        to {
            transform: translateX(0);
            opacity: 1;
        }
    }

    .notification {
        transition: transform 0.3s ease;
    }

    .notification-content {
        display: flex;
        align-items: center;
        gap: 12px;
    }

    .notification-content i {
        font-size: 24px;
    }

    .notification-success i {
        color: #00b894;
    }

    .notification-warning i {
        color: #fdcb6e;
    }

    .notification-info i {
        color: #6c5ce7;
    }

    .notification-title {
        font-weight: 600;
        color: #2d3436;
        margin-bottom: 4px;
    }

    .notification-message {
        font-size: 13px;
        color: #b2bec3;
    }

    .notification-close {
        background: none;
        border: none;
        color: #b2bec3;
        cursor: pointer;
        font-size: 16px;
    }

    body.dark-theme .notification {
        background: #16213e;
    }

    body.dark-theme .notification-title {
        color: white;
    }
`;
document.head.appendChild(style);