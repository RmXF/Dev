# utils para cargar modelo y generar texto (usando transformers)
from transformers import AutoTokenizer, AutoModelForCausalLM
import torch
import os

def load_generation_model(model_name_or_path, checkpoint_dir=None):
    # Si hay checkpoint en checkpoint_dir/latest, cargarlo
    path = model_name_or_path
    if checkpoint_dir:
        candidate = os.path.join(checkpoint_dir, "latest")
        if os.path.isdir(candidate):
            path = candidate
    tokenizer = AutoTokenizer.from_pretrained(path, use_fast=True)
    model = AutoModelForCausalLM.from_pretrained(path)
    model.eval()
    return model, tokenizer

def generate_reply(model, tokenizer, prompt, max_new_tokens=128):
    inputs = tokenizer(prompt, return_tensors="pt")
    with torch.no_grad():
        outputs = model.generate(**inputs, max_new_tokens=max_new_tokens, do_sample=True, top_p=0.9, temperature=0.8)
    text = tokenizer.decode(outputs[0], skip_special_tokens=True)
    # El texto contendrá prompt + respuesta: intentar extraer sólo la continuidad
    if text.startswith(prompt):
        reply = text[len(prompt):].strip()
    else:
        reply = text.strip()
    # Fallback si vacío
    if not reply:
        reply = "Lo siento, no entendí. ¿Puedes decirlo de otra forma?"
    return reply
