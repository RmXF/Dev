#!/usr/bin/env python3
import sqlite3, json, os, time, logging, shutil
from datasets import Dataset
from transformers import AutoTokenizer, AutoModelForCausalLM, Trainer, TrainingArguments, DataCollatorForLanguageModeling
import torch
from sklearn.model_selection import train_test_split

# Logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger("trainer")

with open("config.example.json","r") as f:
    CFG = json.load(f)

DB_PATH = CFG["DB_PATH"]
MIN_EXAMPLES = CFG.get("MIN_EXAMPLES_TO_TRAIN", 50)
CHECKPOINT_DIR = CFG["CHECKPOINT_DIR"]
MODEL_BASE = CFG["MODEL_NAME_OR_PATH"]
TOXICITY_THRESHOLD = CFG.get("TOXICITY_THRESHOLD", 0.5)
MAX_EPOCHS = CFG.get("MAX_TRAIN_EPOCHS", 1)
RETRAIN_MIN_IMPROV = CFG.get("RETRAIN_METRIC_MIN_IMPROV", 0.01)

# Simple filter function — placeholder: en producción usar classifier de toxicidad
def is_toxic(text):
    lower = text.lower()
    bad = ["kill","bomb","suicide","fuck","die"]
    return any(w in lower for w in bad)

# Leer interacciones sin procesar
def load_interactions():
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    c.execute("SELECT id, user_message, bot_reply FROM interactions ORDER BY id DESC")
    rows = c.fetchall()
    conn.close()
    return rows

def prepare_dataset(rows):
    examples = []
    for _id, user_msg, bot_reply in rows:
        text = f"User: {user_msg}\nBot: {bot_reply}\n"
        # Filter toxicity
        if is_toxic(user_msg) or is_toxic(bot_reply):
            continue
        examples.append({"text": text})
    return Dataset.from_list(examples) if examples else None

def train_and_publish(dataset):
    # dividir
    ds = dataset.train_test_split(test_size=0.1)
    tokenizer = AutoTokenizer.from_pretrained(MODEL_BASE, use_fast=True)
    def tokenize(batch):
        return tokenizer(batch["text"], truncation=True, padding="max_length", max_length=256)
    ds = ds.map(tokenize, batched=True, remove_columns=["text"])
    data_collator = DataCollatorForLanguageModeling(tokenizer=tokenizer, mlm=False)
    model = AutoModelForCausalLM.from_pretrained(MODEL_BASE)

    training_args = TrainingArguments(
        output_dir="./tmp_train",
        per_device_train_batch_size=4,
        per_device_eval_batch_size=4,
        num_train_epochs=MAX_EPOCHS,
        logging_steps=50,
        save_strategy="epoch",
        evaluation_strategy="epoch",
        fp16=torch.cuda.is_available(),
        learning_rate=5e-5,
        report_to="none"
    )
    trainer = Trainer(model=model, args=training_args, train_dataset=ds["train"], eval_dataset=ds["test"], data_collator=data_collator)
    trainer.train()
    eval_results = trainer.evaluate()
    logger.info(f"Eval results: {eval_results}")

    # Simple metric: decrease in loss
    eval_loss = eval_results.get("eval_loss", None)
    # Leer loss del modelo publicado (si existe)
    last_metrics_path = os.path.join(CHECKPOINT_DIR, "last_metrics.json")
    last_loss = None
    if os.path.exists(last_metrics_path):
        with open(last_metrics_path, "r") as f:
            last_loss = json.load(f).get("eval_loss")

    # Si mejora (o no existía), publicar
    if last_loss is None or (last_loss - eval_loss) >= RETRAIN_MIN_IMPROV:
        target = os.path.join(CHECKPOINT_DIR, "latest")
        if os.path.exists(target):
            shutil.rmtree(target)
        os.makedirs(target, exist_ok=True)
        logger.info("Publicando nuevo checkpoint...")
        trainer.save_model(target)
        with open(last_metrics_path, "w") as f:
            json.dump({"eval_loss": eval_loss, "timestamp": int(time.time())}, f)
        return True
    else:
        logger.info("No hubo mejora suficiente; no se publica.")
        return False

def main():
    rows = load_interactions()
    logger.info(f"Interacciones totales: {len(rows)}")
    if len(rows) < MIN_EXAMPLES:
        logger.info(f"No hay suficientes ejemplos ({len(rows)}/{MIN_EXAMPLES}).")
        return

    # Tomar solo N últimas interacciones (p. ej. 2000) para evitar dataset gigante
    rows = rows[:2000]
    dataset = prepare_dataset(rows)
    if dataset is None or len(dataset) < MIN_EXAMPLES:
        logger.info("Dataset filtrado demasiado pequeño tras moderación.")
        return
    try:
        published = train_and_publish(dataset)
        logger.info(f"Publicado?: {published}")
    except Exception as e:
        logger.exception("Error en entrenamiento: %s", e)

if __name__ == "__main__":
    main()
