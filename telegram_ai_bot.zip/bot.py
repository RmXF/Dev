#!/usr/bin/env python3
import logging, json, sqlite3, time, os
from telegram import Update
from telegram.ext import ApplicationBuilder, CommandHandler, MessageHandler, filters, ContextTypes
from model_utils import load_generation_model, generate_reply

# Cargar configuración
with open("config.example.json", "r") as f:
    CFG = json.load(f)

TELEGRAM_TOKEN = CFG["TELEGRAM_TOKEN"]
DB_PATH = CFG["DB_PATH"]

# Logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Inicializar DB (si no existe)
def init_db():
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    c.execute("""CREATE TABLE IF NOT EXISTS interactions (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER,
        username TEXT,
        user_message TEXT,
        bot_reply TEXT,
        timestamp INTEGER
    )""")
    conn.commit()
    conn.close()

init_db()

# Cargar modelo (puede ser pesado; caching)
model, tokenizer = load_generation_model(CFG["MODEL_NAME_OR_PATH"], CFG["CHECKPOINT_DIR"])

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text("Hola — soy el bot AI. Escribe algo y aprenderé con el tiempo (bajo supervisión).")

async def handle_message(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = update.effective_user
    text = update.message.text or ""
    logger.info(f"Mensaje de {user.id}: {text}")

    # Generar respuesta con el modelo actual
    reply = generate_reply(model, tokenizer, text)

    # Guardar interacción en DB
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    c.execute("INSERT INTO interactions (user_id, username, user_message, bot_reply, timestamp) VALUES (?, ?, ?, ?, ?)",
              (user.id, user.username, text, reply, int(time.time())))
    conn.commit()
    conn.close()

    # Responder al usuario
    await update.message.reply_text(reply)

async def admin_stats(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = update.effective_user
    if user.id not in CFG["ADMIN_USER_IDS"]:
        await update.message.reply_text("No autorizado.")
        return
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    c.execute("SELECT COUNT(*) FROM interactions")
    total = c.fetchone()[0]
    conn.close()
    await update.message.reply_text(f"Interacciones guardadas: {total}")

def main():
    app = ApplicationBuilder().token(TELEGRAM_TOKEN).build()
    app.add_handler(CommandHandler("start", start))
    app.add_handler(CommandHandler("stats", admin_stats))
    app.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, handle_message))
    logger.info("Bot iniciado.")
    app.run_polling()

if __name__ == "__main__":
    main()
