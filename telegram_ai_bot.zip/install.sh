#!/usr/bin/env bash
set -e
echo "Instalador mínimo para telegram_ai_bot"
if [ -z "$(command -v python3)" ]; then
  echo "Python3 no encontrado. Instala Python 3.10+ primero."
  exit 1
fi
python3 -m pip install --upgrade pip
if [ -f requirements.txt ]; then
  python3 -m pip install -r requirements.txt
fi
echo "Creando DB inicial..."
python3 - <<'PY'
import sqlite3, json
with open('config.example.json') as f:
    cfg = json.load(f)
conn = sqlite3.connect(cfg['DB_PATH'])
c = conn.cursor()
c.execute('''CREATE TABLE IF NOT EXISTS interactions (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER,
    username TEXT,
    user_message TEXT,
    bot_reply TEXT,
    timestamp INTEGER
)''')
conn.commit()
conn.close()
print('DB creada en', cfg['DB_PATH'])
PY
echo "Listo. Rellena config.example.json con tu TELEGRAM_TOKEN y ADMIN_USER_IDS antes de ejecutar bot.py"
