<?php
// ssh_connect.php - VERSIÓN FINAL CORREGIDA
error_reporting(E_ALL);
ini_set('display_errors', 0);

header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST, GET, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

// Manejar preflight OPTIONS
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

// Verificar que sea POST
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode([
        'success' => false,
        'message' => 'Método no permitido. Usa POST.'
    ]);
    exit();
}

// Obtener datos JSON
$input_json = file_get_contents('php://input');
if (empty($input_json)) {
    echo json_encode([
        'success' => false,
        'message' => 'No se recibieron datos'
    ]);
    exit();
}

$input = json_decode($input_json, true);
if (json_last_error() !== JSON_ERROR_NONE) {
    echo json_encode([
        'success' => false,
        'message' => 'JSON inválido: ' . json_last_error_msg()
    ]);
    exit();
}

// Verificar extensión SSH2
if (!function_exists('ssh2_connect')) {
    echo json_encode([
        'success' => false,
        'message' => 'La extensión SSH2 no está instalada en el servidor'
    ]);
    exit();
}

// Obtener acción
$action = $input['action'] ?? '';

// Verificar credenciales básicas
if (!isset($input['ip']) || empty($input['ip'])) {
    echo json_encode(['success' => false, 'message' => 'IP requerida']);
    exit();
}
if (!isset($input['user']) || empty($input['user'])) {
    echo json_encode(['success' => false, 'message' => 'Usuario requerido']);
    exit();
}
if (!isset($input['pass']) || empty($input['pass'])) {
    echo json_encode(['success' => false, 'message' => 'Contraseña requerida']);
    exit();
}

// Función para ejecutar comandos SSH
function execSSHCommand($connection, $command) {
    $stream = ssh2_exec($connection, $command . ' 2>&1');
    if (!$stream) {
        return ['success' => false, 'output' => 'Error ejecutando comando'];
    }
    stream_set_blocking($stream, true);
    $output = stream_get_contents($stream);
    fclose($stream);
    return ['success' => true, 'output' => trim($output)];
}

// Función para obtener fecha de expiración
function getUserExpiry($connection, $username) {
    $result = execSSHCommand($connection, "chage -l " . escapeshellarg($username) . " 2>/dev/null | grep 'Account expires' | cut -d: -f2");
    if ($result['success'] && !empty($result['output'])) {
        $expiry = trim($result['output']);
        if (strtolower($expiry) === 'never' || empty($expiry)) {
            return '2099-12-31';
        }
        $parsed_date = strtotime($expiry);
        if ($parsed_date) {
            return date('Y-m-d', $parsed_date);
        }
    }
    return '2099-12-31';
}

// Procesar según la acción
try {
    // Conectar SSH
    $connection = ssh2_connect($input['ip'], $input['port'] ?? 22, ['timeout' => 10]);
    if (!$connection) {
        echo json_encode([
            'success' => false,
            'message' => 'No se pudo conectar al servidor ' . $input['ip']
        ]);
        exit();
    }

    // Autenticar
    if (!ssh2_auth_password($connection, $input['user'], $input['pass'])) {
        ssh2_disconnect($connection);
        echo json_encode([
            'success' => false,
            'message' => 'Error de autenticación. Usuario/contraseña incorrectos'
        ]);
        exit();
    }

    switch ($action) {
        case 'test_connection':
            ssh2_disconnect($connection);
            echo json_encode([
                'success' => true,
                'message' => 'Conexión SSH exitosa'
            ]);
            break;

        case 'list_users':
            // Obtener usuarios con shell bash
            $result = execSSHCommand($connection, "cat /etc/passwd | grep -E ':/bin/(bash|sh)' | cut -d: -f1");
            
            if (!$result['success']) {
                throw new Exception('Error listando usuarios');
            }

            $users = array_filter(explode("\n", $result['output']));
            $userList = [];

            foreach ($users as $username) {
                $username = trim($username);
                if (empty($username) || $username === 'root') continue;
                
                $userList[] = [
                    'username' => $username,
                    'password' => '••••••••',
                    'expiry_date' => getUserExpiry($connection, $username),
                    'status' => 'activo'
                ];
            }

            ssh2_disconnect($connection);
            echo json_encode([
                'success' => true,
                'message' => 'Usuarios obtenidos',
                'users' => $userList
            ]);
            break;

        case 'add_user':
            $username = $input['username'] ?? '';
            $password = $input['password'] ?? '';
            $expiry_date = $input['expiry_date'] ?? '';

            if (empty($username) || empty($password)) {
                throw new Exception('Usuario y contraseña requeridos');
            }

            // Validar formato de usuario
            if (!preg_match('/^[a-z_][a-z0-9_-]*$/', $username)) {
                throw new Exception('Usuario inválido. Solo minúsculas, números, - y _');
            }

            // Crear usuario
            $result = execSSHCommand($connection, "useradd -m -s /bin/bash " . escapeshellarg($username));
            if (!$result['success']) {
                throw new Exception('Error creando usuario: ' . $result['output']);
            }

            // Establecer contraseña
            $result = execSSHCommand($connection, "echo " . escapeshellarg("$username:$password") . " | chpasswd");
            if (!$result['success']) {
                execSSHCommand($connection, "userdel -r " . escapeshellarg($username));
                throw new Exception('Error estableciendo contraseña');
            }

            // Establecer expiración
            if (!empty($expiry_date) && $expiry_date !== '2099-12-31') {
                execSSHCommand($connection, "chage -E " . escapeshellarg($expiry_date) . " " . escapeshellarg($username));
            }

            ssh2_disconnect($connection);
            echo json_encode([
                'success' => true,
                'message' => 'Usuario creado exitosamente'
            ]);
            break;

        case 'delete_user':
            $username = $input['username'] ?? '';
            if (empty($username)) {
                throw new Exception('Usuario requerido');
            }

            execSSHCommand($connection, "userdel -r " . escapeshellarg($username));
            
            ssh2_disconnect($connection);
            echo json_encode([
                'success' => true,
                'message' => 'Usuario eliminado'
            ]);
            break;

        case 'update_user':
            $username = $input['username'] ?? '';
            $password = $input['password'] ?? '';
            $expiry_date = $input['expiry_date'] ?? '';

            if (empty($username)) {
                throw new Exception('Usuario requerido');
            }

            // Cambiar contraseña si se proporciona
            if (!empty($password)) {
                execSSHCommand($connection, "echo " . escapeshellarg("$username:$password") . " | chpasswd");
            }

            // Actualizar expiración
            if (!empty($expiry_date) && $expiry_date !== '2099-12-31') {
                execSSHCommand($connection, "chage -E " . escapeshellarg($expiry_date) . " " . escapeshellarg($username));
            }

            ssh2_disconnect($connection);
            echo json_encode([
                'success' => true,
                'message' => 'Usuario actualizado'
            ]);
            break;

        default:
            ssh2_disconnect($connection);
            echo json_encode([
                'success' => false,
                'message' => 'Acción no válida: ' . $action
            ]);
    }

} catch (Exception $e) {
    if (isset($connection)) {
        ssh2_disconnect($connection);
    }
    echo json_encode([
        'success' => false,
        'message' => 'Error: ' . $e->getMessage()
    ]);
}
?>