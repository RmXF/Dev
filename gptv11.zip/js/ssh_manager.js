class SSHManager {
    constructor() {
        this.users = [];
        this.currentUser = null;
        this.sshConnected = false;
        this.credentials = null;
        
        this.initializeEventListeners();
        console.log('✅ SSHManager inicializado');
    }

    initializeEventListeners() {
        // Botones principales
        document.getElementById('btnAddUser')?.addEventListener('click', () => this.showModal());
        document.getElementById('btnRefresh')?.addEventListener('click', () => this.loadUsers());
        
        // Modal de usuario
        document.getElementById('closeModal')?.addEventListener('click', () => this.hideModal());
        document.getElementById('cancelModal')?.addEventListener('click', () => this.hideModal());
        document.getElementById('saveUser')?.addEventListener('click', () => this.saveUser());
        
        // Búsqueda
        document.getElementById('searchInput')?.addEventListener('input', (e) => this.filterUsers(e.target.value));
        
        // Tema
        document.getElementById('themeToggle')?.addEventListener('click', () => this.toggleTheme());
        
        // Auto-calcular fecha
        document.getElementById('expiryDays')?.addEventListener('change', (e) => this.calculateExpiryDate(e.target.value));

        console.log('✅ Event listeners configurados');
    }

    setCredentials(ip, user, pass, port = 22) {
        console.log('🔑 Configurando credenciales:', {ip, user, port});
        this.credentials = {
            ip: ip,
            user: user,
            pass: pass,
            port: port
        };
        this.testConnection();
    }

    async testConnection() {
        console.log('🔌 Probando conexión SSH...');
        
        if (!this.credentials) {
            this.updateConnectionStatus('disconnected', '⚠️ Esperando credenciales');
            return;
        }

        try {
            const response = await this.makeRequest('test_connection');
            console.log('✅ Conexión exitosa:', response);
            
            if (response.success) {
                this.sshConnected = true;
                this.updateConnectionStatus('connected', '✅ Conectado al VPS');
                this.loadUsers();
            } else {
                throw new Error(response.message);
            }
        } catch (error) {
            console.error('❌ Error de conexión:', error);
            this.sshConnected = false;
            this.updateConnectionStatus('disconnected', '❌ Error: ' + error.message);
            this.showNotification('Error de conexión: ' + error.message, true);
        }
    }

    updateConnectionStatus(status, message) {
        const statusElement = document.getElementById('connectionStatus');
        if (!statusElement) return;
        
        statusElement.className = 'connection-status status-' + status;
        statusElement.innerHTML = `<div class="status-icon"></div><span>${message}</span>`;
    }

    async makeRequest(action, data = {}) {
        if (!this.credentials) {
            throw new Error('Credenciales no configuradas');
        }

        // Usar la ruta correcta - MISMA CARPETA
        const url = 'ssh_connect.php';
        
        const requestData = {
            action: action,
            ip: this.credentials.ip,
            user: this.credentials.user,
            pass: this.credentials.pass,
            port: this.credentials.port,
            ...data
        };

        console.log(`📤 Enviando petición ${action}:`, requestData);

        try {
            const response = await fetch(url, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify(requestData)
            });
            
            console.log('📥 Response status:', response.status);
            
            if (!response.ok) {
                const text = await response.text();
                console.error('❌ Error response:', text);
                throw new Error(`Error HTTP ${response.status}`);
            }
            
            const result = await response.json();
            console.log('📥 Respuesta:', result);
            
            if (!result.success) {
                throw new Error(result.message || 'Error desconocido');
            }
            
            return result;
            
        } catch (error) {
            console.error('❌ Error en makeRequest:', error);
            throw error;
        }
    }

    async loadUsers() {
        console.log('📋 Cargando usuarios...');
        
        if (!this.sshConnected) {
            this.showNotification('No hay conexión al VPS', true);
            return;
        }

        try {
            const response = await this.makeRequest('list_users');
            this.users = response.users || [];
            console.log(`✅ ${this.users.length} usuarios cargados`);
            this.renderUsers();
        } catch (error) {
            console.error('❌ Error cargando usuarios:', error);
            this.showNotification('Error al cargar usuarios: ' + error.message, true);
        }
    }

    renderUsers() {
        const usersList = document.getElementById('usersList');
        if (!usersList) return;
        
        if (this.users.length === 0) {
            usersList.innerHTML = '<div class="no-users">No hay usuarios SSH configurados</div>';
            return;
        }
        
        usersList.innerHTML = this.users.map(user => {
            const timeRemaining = this.calculateTimeRemaining(user.expiry_date);
            const statusClass = this.getStatusClass(timeRemaining);
            
            return `
                <div class="user-item ${timeRemaining.includes('Expirado') ? 'expired' : ''}">
                    <div class="user-username">
                        <div class="user-icon"></div>
                        ${this.escapeHtml(user.username)}
                    </div>
                    <div>••••••••</div>
                    <div>${user.expiry_date}</div>
                    <div>
                        <span class="time-remaining ${statusClass}">
                            ${timeRemaining}
                        </span>
                    </div>
                    <div>${user.status || 'activo'}</div>
                    <div class="user-actions">
                        <button class="btn-action btn-edit" onclick="sshManager.editUser('${this.escapeHtml(user.username)}')">Editar</button>
                        <button class="btn-action btn-extend" onclick="sshManager.extendUser('${this.escapeHtml(user.username)}')">Extender</button>
                        <button class="btn-action btn-delete" onclick="sshManager.deleteUser('${this.escapeHtml(user.username)}')">Eliminar</button>
                    </div>
                </div>
            `;
        }).join('');
    }

    calculateTimeRemaining(expiryDate) {
        if (expiryDate === '2099-12-31') return 'Nunca expira';
        
        const now = new Date();
        const expiry = new Date(expiryDate);
        const diffTime = expiry - now;
        const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
        
        if (diffDays < 0) return 'Expirado';
        if (diffDays === 0) return 'Hoy expira';
        if (diffDays === 1) return '1 día';
        return `${diffDays} días`;
    }

    getStatusClass(timeRemaining) {
        if (timeRemaining === 'Expirado' || timeRemaining === 'Hoy expira') return 'time-danger';
        if (timeRemaining.includes('1 día') || (timeRemaining.includes(' días') && parseInt(timeRemaining) <= 7)) return 'time-warning';
        return 'time-normal';
    }

    showModal(username = null) {
        console.log('📝 Mostrando modal, usuario:', username);
        
        if (!this.sshConnected) {
            this.showNotification('Primero conecta al servidor SSH', true);
            return;
        }

        this.currentUser = username;
        const modal = document.getElementById('userModal');
        const title = document.getElementById('modalTitle');
        
        if (modal) {
            if (username) {
                title.textContent = 'Editar Usuario SSH';
                this.loadUserData(username);
            } else {
                title.textContent = 'Agregar Usuario SSH';
                document.getElementById('userForm').reset();
                this.calculateExpiryDate(30);
            }
            modal.classList.add('show');
        }
    }

    hideModal() {
        const modal = document.getElementById('userModal');
        if (modal) {
            modal.classList.remove('show');
        }
        this.currentUser = null;
    }

    async loadUserData(username) {
        try {
            const user = this.users.find(u => u.username === username);
            if (user) {
                document.getElementById('username').value = user.username;
                document.getElementById('password').value = '';
                document.getElementById('expiryDate').value = user.expiry_date;
            }
        } catch (error) {
            this.showNotification('Error: ' + error.message, true);
            this.hideModal();
        }
    }

    calculateExpiryDate(days) {
        const today = new Date();
        const expiryDate = new Date(today);
        expiryDate.setDate(today.getDate() + parseInt(days));
        
        const expiryInput = document.getElementById('expiryDate');
        if (expiryInput) {
            expiryInput.value = expiryDate.toISOString().split('T')[0];
        }
    }

    async saveUser() {
        const username = document.getElementById('username')?.value;
        const password = document.getElementById('password')?.value;
        const expiryDate = document.getElementById('expiryDate')?.value;
        
        console.log('💾 Guardando usuario:', {username, expiryDate});
        
        if (!username) {
            this.showNotification('Usuario requerido', true);
            return;
        }

        if (!this.currentUser && !password) {
            this.showNotification('Contraseña requerida para nuevos usuarios', true);
            return;
        }

        const action = this.currentUser ? 'update_user' : 'add_user';
        const data = {
            username: username,
            expiry_date: expiryDate || '2099-12-31'
        };

        if (password) {
            data.password = password;
        }

        try {
            const response = await this.makeRequest(action, data);
            this.showNotification(response.message || 'Operación exitosa');
            this.hideModal();
            this.loadUsers();
        } catch (error) {
            this.showNotification('Error: ' + error.message, true);
        }
    }

    async deleteUser(username) {
        if (!confirm(`¿Eliminar usuario "${username}"?`)) return;

        try {
            const response = await this.makeRequest('delete_user', { username: username });
            this.showNotification(response.message || 'Usuario eliminado');
            this.loadUsers();
        } catch (error) {
            this.showNotification('Error: ' + error.message, true);
        }
    }

    async extendUser(username) {
        const newDate = new Date();
        newDate.setDate(newDate.getDate() + 30);
        
        try {
            const response = await this.makeRequest('update_user', {
                username: username,
                expiry_date: newDate.toISOString().split('T')[0]
            });
            this.showNotification('Usuario extendido 30 días');
            this.loadUsers();
        } catch (error) {
            this.showNotification('Error: ' + error.message, true);
        }
    }

    editUser(username) {
        this.showModal(username);
    }

    filterUsers(searchTerm) {
        if (!searchTerm) {
            this.renderUsers();
            return;
        }

        const filtered = this.users.filter(user => 
            user.username.toLowerCase().includes(searchTerm.toLowerCase())
        );
        
        const usersList = document.getElementById('usersList');
        if (!usersList) return;
        
        if (filtered.length === 0) {
            usersList.innerHTML = '<div class="no-users">No se encontraron usuarios</div>';
            return;
        }
        
        usersList.innerHTML = filtered.map(user => {
            const timeRemaining = this.calculateTimeRemaining(user.expiry_date);
            const statusClass = this.getStatusClass(timeRemaining);
            
            return `
                <div class="user-item ${timeRemaining.includes('Expirado') ? 'expired' : ''}">
                    <div class="user-username">
                        <div class="user-icon"></div>
                        ${this.escapeHtml(user.username)}
                    </div>
                    <div>••••••••</div>
                    <div>${user.expiry_date}</div>
                    <div>
                        <span class="time-remaining ${statusClass}">
                            ${timeRemaining}
                        </span>
                    </div>
                    <div>${user.status || 'activo'}</div>
                    <div class="user-actions">
                        <button class="btn-action btn-edit" onclick="sshManager.editUser('${this.escapeHtml(user.username)}')">Editar</button>
                        <button class="btn-action btn-extend" onclick="sshManager.extendUser('${this.escapeHtml(user.username)}')">Extender</button>
                        <button class="btn-action btn-delete" onclick="sshManager.deleteUser('${this.escapeHtml(user.username)}')">Eliminar</button>
                    </div>
                </div>
            `;
        }).join('');
    }

    showNotification(message, isError = false) {
        const notification = document.getElementById('notification');
        if (!notification) return;
        
        notification.textContent = message;
        notification.className = `notification ${isError ? 'error' : ''} show`;
        
        setTimeout(() => {
            notification.classList.remove('show');
        }, 3000);
    }

    toggleTheme() {
        const currentTheme = document.documentElement.getAttribute('data-theme');
        const newTheme = currentTheme === 'dark' ? 'light' : 'dark';
        document.documentElement.setAttribute('data-theme', newTheme);
        localStorage.setItem('theme', newTheme);
    }

    escapeHtml(text) {
        const div = document.createElement('div');
        div.textContent = text;
        return div.innerHTML;
    }
}

// Variable global
let sshManager;

// Inicialización
document.addEventListener('DOMContentLoaded', () => {
    console.log('🚀 Inicializando aplicación...');
    
    // Crear instancia
    sshManager = new SSHManager();
    
    // Cargar tema guardado
    const savedTheme = localStorage.getItem('theme');
    if (savedTheme) {
        document.documentElement.setAttribute('data-theme', savedTheme);
    }
    
    // Modal de credenciales SSH
    const openBtn = document.getElementById('openmodalCred');
    if (openBtn) {
        openBtn.addEventListener('click', () => {
            document.getElementById('modalCred').style.display = 'flex';
        });
    }

    // Conectar SSH
    const connectBtn = document.getElementById('sshcon');
    if (connectBtn) {
        connectBtn.addEventListener('click', () => {
            const ip = document.getElementById('input1')?.value.trim();
            const user = document.getElementById('input2')?.value.trim();
            const pass = document.getElementById('input3')?.value.trim();
            const port = document.getElementById('input4')?.value.trim() || '22';

            if (!ip || !user || !pass) {
                alert('Completa todos los campos');
                return;
            }

            console.log('🔌 Conectando a:', ip);
            sshManager.setCredentials(ip, user, pass, port);
            document.getElementById('modalCred').style.display = 'none';
        });
    }

    // Cancelar
    const cancelBtn = document.getElementById('canceladdsssh');
    if (cancelBtn) {
        cancelBtn.addEventListener('click', () => {
            document.getElementById('modalCred').style.display = 'none';
        });
    }

    // Cerrar con ESC
    document.addEventListener('keydown', (e) => {
        if (e.key === 'Escape') {
            document.getElementById('modalCred').style.display = 'none';
            sshManager?.hideModal();
        }
    });

    console.log('✅ Aplicación inicializada');
});