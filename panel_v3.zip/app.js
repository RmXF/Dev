const express = require('express');
const session = require('express-session');
const bodyParser = require('body-parser');
const path = require('path');
const mysql = require('mysql2/promise');
const fs = require('fs');
const fetch = require('node-fetch');
const AdmZip = require('adm-zip');
require('dotenv').config();
const app = express();
const PORT = process.env.PORT || 80;
const pool = mysql.createPool({
  host: process.env.DB_HOST || 'localhost',
  user: process.env.DB_USER || 'root',
  password: process.env.DB_PASS || '',
  database: process.env.DB_NAME || 'panel_v3_db'
});
app.set('views', path.join(__dirname, 'views'));
app.set('view engine', 'ejs');
app.use(express.static(path.join(__dirname, 'public')));
app.use(bodyParser.urlencoded({ extended:true }));
app.use(bodyParser.json());
app.use(session({ secret: process.env.SESSION_SECRET || 'secret', resave:false, saveUninitialized:false }));
function requireAuth(req,res,next){ if(req.session && req.session.user) return next(); res.redirect('/login'); }
app.get('/login', (req,res)=> res.render('login',{error:null}));
app.post('/login', async (req,res)=>{
  const {username,password} = req.body;
  try{
    const [rows] = await pool.query('SELECT * FROM users WHERE username=?',[username]);
    if(rows.length && rows[0].password === password){
      req.session.user = { id: rows[0].id, username: rows[0].username, role: rows[0].role };
      return res.redirect('/dashboard');
    }
    res.render('login',{error:'Credenciales inválidas'});
  }catch(err){ console.error(err); res.render('login',{error:'Error DB'}); }
});
app.get('/dashboard', requireAuth, async (req,res)=>{ res.render('dashboard',{user:req.session.user, stats:{users:124,sessions:18,visits:3421,status:'Estable'}}); });
app.get('/logout',(req,res)=>{ req.session.destroy(()=>res.redirect('/login')); });
app.post('/update', requireAuth, async (req,res)=>{
  if(req.session.user.role !== 'admin') return res.status(403).json({error:'forbidden'});
  const url = req.body.url;
  if(!url) return res.status(400).json({error:'missing_url'});
  const tmpZip = '/tmp/panel_update.zip';
  const backup = `/tmp/panel_backup_${Date.now()}.zip`;
  try{
    const response = await fetch(url);
    if(!response.ok) return res.status(400).json({error:'download_failed'});
    const buffer = await response.arrayBuffer();
    fs.writeFileSync(tmpZip, Buffer.from(buffer));
    const zip = new AdmZip(tmpZip);
    const zipBackup = new AdmZip();
    const addFolder = (dir)=>{
      const files = fs.readdirSync(dir,{withFileTypes:true});
      files.forEach(f=>{
        const full = path.join(dir,f.name);
        const rel = path.relative(__dirname, full);
        if(rel.startsWith('data')) return;
        if(f.isDirectory()) addFolder(full); else zipBackup.addLocalFile(full, path.dirname(rel));
      });
    };
    addFolder(__dirname);
    zipBackup.writeZip(backup);
    const extractDir = '/tmp/panel_update_extract';
    if(fs.existsSync(extractDir)) fs.rmSync(extractDir,{recursive:true,force:true});
    fs.mkdirSync(extractDir,{recursive:true});
    zip.extractAllTo(extractDir,true);
    const copyRec = (src,dest)=>{
      fs.readdirSync(src,{withFileTypes:true}).forEach(ent=>{
        const s = path.join(src,ent.name); const d = path.join(dest,ent.name);
        if(ent.isDirectory()){ if(!fs.existsSync(d)) fs.mkdirSync(d); copyRec(s,d); } else { fs.copyFileSync(s,d); }
      });
    };
    copyRec(extractDir,__dirname);
    fs.unlinkSync(tmpZip); fs.rmSync(extractDir,{recursive:true,force:true});
    return res.json({ok:true, backup});
  }catch(err){ console.error(err); return res.status(500).json({error:err.message}); }
});
app.listen(PORT, ()=> console.log('Panel v3 running on port', PORT));
