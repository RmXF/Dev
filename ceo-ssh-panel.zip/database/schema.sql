-- CEO SSH Panel Database Schema
-- Version: 1.0.0

-- Create database
CREATE DATABASE IF NOT EXISTS ceo_ssh CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE ceo_ssh;

-- Users table
CREATE TABLE IF NOT EXISTS `users` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `username` VARCHAR(50) UNIQUE NOT NULL,
    `password` VARCHAR(255) NOT NULL,
    `email` VARCHAR(100),
    `role` ENUM('admin', 'user') DEFAULT 'user',
    `status` ENUM('active', 'inactive', 'suspended') DEFAULT 'active',
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    `last_login` TIMESTAMP NULL,
    INDEX idx_username (username),
    INDEX idx_status (status),
    INDEX idx_role (role)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Sessions table
CREATE TABLE IF NOT EXISTS `sessions` (
    `id` VARCHAR(128) PRIMARY KEY,
    `user_id` INT NOT NULL,
    `ip_address` VARCHAR(45),
    `user_agent` TEXT,
    `payload` TEXT,
    `last_activity` INT,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    INDEX idx_last_activity (last_activity),
    INDEX idx_user_id (user_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- SSH Tokens table
CREATE TABLE IF NOT EXISTS `ssh_tokens` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `username` VARCHAR(50) UNIQUE NOT NULL,
    `password` VARCHAR(255) NOT NULL,
    `expires_at` DATE NOT NULL,
    `status` ENUM('active', 'expired', 'suspended') DEFAULT 'active',
    `traffic_limit` BIGINT DEFAULT NULL,
    `traffic_used` BIGINT DEFAULT 0,
    `created_by` INT,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (created_by) REFERENCES users(id),
    INDEX idx_username (username),
    INDEX idx_status (status),
    INDEX idx_expires (expires_at),
    INDEX idx_created_by (created_by)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Logs table
CREATE TABLE IF NOT EXISTS `logs` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `user_id` INT,
    `action` VARCHAR(100),
    `details` TEXT,
    `ip_address` VARCHAR(45),
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL,
    INDEX idx_user (user_id),
    INDEX idx_created (created_at),
    INDEX idx_action (action)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Settings table
CREATE TABLE IF NOT EXISTS `settings` (
    `key` VARCHAR(100) PRIMARY KEY,
    `value` TEXT,
    `description` TEXT,
    `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Insert default admin user (password: admin123)
INSERT INTO `users` (username, password, email, role, status) 
VALUES ('admin', '$2a$10$YourHashedPasswordHere', 'admin@ceo-ssh.com', 'admin', 'active')
ON DUPLICATE KEY UPDATE password = VALUES(password);

-- Insert default settings
INSERT INTO `settings` (`key`, `value`, `description`) VALUES
('panel_name', 'CEO SSH', 'Nombre del panel'),
('panel_version', '1.0.0', 'Versión del panel'),
('maintenance_mode', '0', 'Modo mantenimiento'),
('dark_mode_default', 'dark', 'Tema por defecto'),
('session_timeout', '3600', 'Tiempo de sesión en segundos'),
('max_login_attempts', '5', 'Intentos máximos de login'),
('login_lockout_time', '900', 'Tiempo de bloqueo en segundos'),
('default_expiration_days', '30', 'Días de expiración por defecto'),
('notifications_enabled', '1', 'Notificaciones habilitadas'),
('backup_enabled', '1', 'Backups automáticos habilitados')
ON DUPLICATE KEY UPDATE `value` = VALUES(`value`);

-- Create indexes for better performance
CREATE INDEX idx_logs_created_at ON logs(created_at);
CREATE INDEX idx_ssh_tokens_expires_at ON ssh_tokens(expires_at);
CREATE INDEX idx_users_created_at ON users(created_at);