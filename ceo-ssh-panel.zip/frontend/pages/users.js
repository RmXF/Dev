import { useState, useEffect } from 'react'
import MainLayout from '../components/Layout/MainLayout'
import UsersTable from '../components/UI/UsersTable'
import Modal from '../components/UI/Modal'
import toast from 'react-hot-toast'
import { FiPlus, FiSearch, FiFilter } from 'react-icons/fi'
import { useApi } from '../hooks/useApi'

export default function Users() {
  const [users, setUsers] = useState([])
  const [loading, setLoading] = useState(true)
  const [showCreateModal, setShowCreateModal] = useState(false)
  const [searchTerm, setSearchTerm] = useState('')
  const [filterStatus, setFilterStatus] = useState('all')
  const [newUser, setNewUser] = useState({
    username: '',
    password: '',
    email: '',
    days: 30
  })
  const { get, post, del, put } = useApi()
  
  useEffect(() => {
    fetchUsers()
  }, [])
  
  const fetchUsers = async () => {
    try {
      const response = await get('/ssh-tokens')
      if (response.success) {
        setUsers(response.data)
      }
    } catch (error) {
      toast.error('Error al cargar usuarios')
    } finally {
      setLoading(false)
    }
  }
  
  const handleCreateUser = async () => {
    if (!newUser.username || !newUser.password) {
      toast.error('Usuario y contraseña son requeridos')
      return
    }
    
    try {
      const response = await post('/ssh-tokens', newUser)
      if (response.success) {
        toast.success(`Usuario ${newUser.username} creado exitosamente`)
        setShowCreateModal(false)
        setNewUser({ username: '', password: '', email: '', days: 30 })
        fetchUsers()
      }
    } catch (error) {
      toast.error(error.response?.data?.error || 'Error al crear usuario')
    }
  }
  
  const handleDeleteUser = async (id, username) => {
    if (confirm(`¿Estás seguro de eliminar al usuario ${username}?`)) {
      try {
        const response = await del(`/ssh-tokens/${id}`)
        if (response.success) {
          toast.success('Usuario eliminado')
          fetchUsers()
        }
      } catch (error) {
        toast.error('Error al eliminar usuario')
      }
    }
  }
  
  const handleExtendUser = async (id, days) => {
    try {
      const response = await put(`/ssh-tokens/${id}`, { days })
      if (response.success) {
        toast.success(`Usuario extendido por ${days} días`)
        fetchUsers()
      }
    } catch (error) {
      toast.error('Error al extender usuario')
    }
  }
  
  const filteredUsers = users.filter(user => {
    const matchesSearch = user.username.toLowerCase().includes(searchTerm.toLowerCase())
    const matchesFilter = filterStatus === 'all' || user.status === filterStatus
    return matchesSearch && matchesFilter
  })
  
  return (
    <MainLayout>
      <div className="mb-8">
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between">
          <div>
            <h1 className="text-2xl font-bold text-white mb-2">Gestión de Usuarios</h1>
            <p className="text-gray-400">Administra todos los tokens SSH de tu servidor</p>
          </div>
          <button
            onClick={() => setShowCreateModal(true)}
            className="mt-4 sm:mt-0 flex items-center px-4 py-2 bg-gradient-to-r from-primary-500 to-primary-600 rounded-lg text-white font-medium hover:from-primary-600 hover:to-primary-700 transition-all"
          >
            <FiPlus className="w-5 h-5 mr-2" />
            Crear Usuario
          </button>
        </div>
      </div>

      {/* Filters */}
      <div className="bg-dark-100 rounded-xl p-4 mb-6 border border-gray-700">
        <div className="flex flex-col sm:flex-row gap-4">
          <div className="flex-1 relative">
            <FiSearch className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
            <input
              type="text"
              placeholder="Buscar usuario..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-10 pr-3 py-2 bg-dark-200 border border-gray-600 rounded-lg text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-primary-500"
            />
          </div>
          <div className="sm:w-48 relative">
            <FiFilter className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
            <select
              value={filterStatus}
              onChange={(e) => setFilterStatus(e.target.value)}
              className="w-full pl-10 pr-3 py-2 bg-dark-200 border border-gray-600 rounded-lg text-white focus:outline-none focus:ring-2 focus:ring-primary-500"
            >
              <option value="all">Todos</option>
              <option value="active">Activos</option>
              <option value="expired">Expirados</option>
              <option value="suspended">Suspendidos</option>
            </select>
          </div>
        </div>
      </div>

      {/* Users table */}
      <UsersTable
        users={filteredUsers}
        loading={loading}
        onDelete={handleDeleteUser}
        onExtend={handleExtendUser}
      />

      {/* Create user modal */}
      <Modal
        isOpen={showCreateModal}
        onClose={() => setShowCreateModal(false)}
        title="Crear Nuevo Usuario"
      >
        <div className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-gray-300 mb-2">
              Usuario *
            </label>
            <input
              type="text"
              value={newUser.username}
              onChange={(e) => setNewUser({ ...newUser, username: e.target.value })}
              className="w-full px-3 py-2 bg-dark-200 border border-gray-600 rounded-lg text-white focus:outline-none focus:ring-2 focus:ring-primary-500"
              placeholder="ejemplo_usuario"
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-300 mb-2">
              Contraseña *
            </label>
            <input
              type="text"
              value={newUser.password}
              onChange={(e) => setNewUser({ ...newUser, password: e.target.value })}
              className="w-full px-3 py-2 bg-dark-200 border border-gray-600 rounded-lg text-white focus:outline-none focus:ring-2 focus:ring-primary-500"
              placeholder="contraseña_segura"
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-300 mb-2">
              Email (opcional)
            </label>
            <input
              type="email"
              value={newUser.email}
              onChange={(e) => setNewUser({ ...newUser, email: e.target.value })}
              className="w-full px-3 py-2 bg-dark-200 border border-gray-600 rounded-lg text-white focus:outline-none focus:ring-2 focus:ring-primary-500"
              placeholder="usuario@ejemplo.com"
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-300 mb-2">
              Días de expiración
            </label>
            <select
              value={newUser.days}
              onChange={(e) => setNewUser({ ...newUser, days: parseInt(e.target.value) })}
              className="w-full px-3 py-2 bg-dark-200 border border-gray-600 rounded-lg text-white focus:outline-none focus:ring-2 focus:ring-primary-500"
            >
              <option value="7">7 días</option>
              <option value="15">15 días</option>
              <option value="30">30 días</option>
              <option value="60">60 días</option>
              <option value="90">90 días</option>
              <option value="180">180 días</option>
              <option value="365">365 días</option>
            </select>
          </div>
          <div className="flex gap-3 pt-4">
            <button
              onClick={handleCreateUser}
              className="flex-1 px-4 py-2 bg-primary-500 rounded-lg text-white font-medium hover:bg-primary-600 transition-colors"
            >
              Crear Usuario
            </button>
            <button
              onClick={() => setShowCreateModal(false)}
              className="flex-1 px-4 py-2 bg-gray-600 rounded-lg text-white font-medium hover:bg-gray-700 transition-colors"
            >
              Cancelar
            </button>
          </div>
        </div>
      </Modal>
    </MainLayout>
  )
}