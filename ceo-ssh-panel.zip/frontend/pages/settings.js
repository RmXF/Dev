import { useState, useEffect } from 'react'
import MainLayout from '../components/Layout/MainLayout'
import { useAuth } from '../context/AuthContext'
import { useApi } from '../hooks/useApi'
import toast from 'react-hot-toast'
import { FiSave, FiRefreshCw, FiDatabase, FiBell, FiGlobe } from 'react-icons/fi'

export default function Settings() {
  const { user } = useAuth()
  const { get, put } = useApi()
  const [loading, setLoading] = useState(false)
  const [settings, setSettings] = useState({
    panel_name: 'CEO SSH',
    maintenance_mode: '0',
    session_timeout: '3600',
    default_expiration_days: '30',
    notifications_enabled: '1',
    backup_enabled: '1'
  })
  
  useEffect(() => {
    fetchSettings()
  }, [])
  
  const fetchSettings = async () => {
    try {
      const response = await get('/settings')
      if (response.success) {
        setSettings(prev => ({ ...prev, ...response.data }))
      }
    } catch (error) {
      console.error('Error fetching settings:', error)
    }
  }
  
  const handleSave = async () => {
    setLoading(true)
    try {
      const response = await put('/settings', settings)
      if (response.success) {
        toast.success('Configuración guardada')
      }
    } catch (error) {
      toast.error('Error al guardar configuración')
    } finally {
      setLoading(false)
    }
  }
  
  if (user?.role !== 'admin') {
    return (
      <MainLayout>
        <div className="text-center py-12">
          <p className="text-red-400">Acceso denegado. Solo administradores.</p>
        </div>
      </MainLayout>
    )
  }
  
  return (
    <MainLayout>
      <div className="mb-8">
        <h1 className="text-2xl font-bold text-white mb-2">Configuración</h1>
        <p className="text-gray-400">Configuración general del panel CEO SSH</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* General settings */}
        <div className="bg-dark-100 rounded-xl p-6 border border-gray-700">
          <h2 className="text-lg font-semibold text-white mb-4 flex items-center">
            <FiGlobe className="w-5 h-5 mr-2 text-primary-500" />
            Configuración General
          </h2>
          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-300 mb-2">
                Nombre del Panel
              </label>
              <input
                type="text"
                value={settings.panel_name}
                onChange={(e) => setSettings({ ...settings, panel_name: e.target.value })}
                className="w-full px-3 py-2 bg-dark-200 border border-gray-600 rounded-lg text-white focus:outline-none focus:ring-2 focus:ring-primary-500"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-300 mb-2">
                Modo Mantenimiento
              </label>
              <select
                value={settings.maintenance_mode}
                onChange={(e) => setSettings({ ...settings, maintenance_mode: e.target.value })}
                className="w-full px-3 py-2 bg-dark-200 border border-gray-600 rounded-lg text-white focus:outline-none focus:ring-2 focus:ring-primary-500"
              >
                <option value="0">Desactivado</option>
                <option value="1">Activado</option>
              </select>
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-300 mb-2">
                Tiempo de Sesión (segundos)
              </label>
              <input
                type="number"
                value={settings.session_timeout}
                onChange={(e) => setSettings({ ...settings, session_timeout: e.target.value })}
                className="w-full px-3 py-2 bg-dark-200 border border-gray-600 rounded-lg text-white focus:outline-none focus:ring-2 focus:ring-primary-500"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-300 mb-2">
                Días de Expiración por Defecto
              </label>
              <input
                type="number"
                value={settings.default_expiration_days}
                onChange={(e) => setSettings({ ...settings, default_expiration_days: e.target.value })}
                className="w-full px-3 py-2 bg-dark-200 border border-gray-600 rounded-lg text-white focus:outline-none focus:ring-2 focus:ring-primary-500"
              />
            </div>
          </div>
        </div>

        {/* Notification settings */}
        <div className="bg-dark-100 rounded-xl p-6 border border-gray-700">
          <h2 className="text-lg font-semibold text-white mb-4 flex items-center">
            <FiBell className="w-5 h-5 mr-2 text-primary-500" />
            Notificaciones
          </h2>
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-white font-medium">Notificaciones por Email</p>
                <p className="text-sm text-gray-500">Recibir alertas por correo electrónico</p>
              </div>
              <label className="relative inline-flex items-center cursor-pointer">
                <input
                  type="checkbox"
                  checked={settings.notifications_enabled === '1'}
                  onChange={(e) => setSettings({ ...settings, notifications_enabled: e.target.checked ? '1' : '0' })}
                  className="sr-only peer"
                />
                <div className="w-11 h-6 bg-gray-600 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-primary-500"></div>
              </label>
            </div>
            <div className="flex items-center justify-between">
              <div>
                <p className="text-white font-medium">Backups Automáticos</p>
                <p className="text-sm text-gray-500">Realizar backups diarios del sistema</p>
              </div>
              <label className="relative inline-flex items-center cursor-pointer">
                <input
                  type="checkbox"
                  checked={settings.backup_enabled === '1'}
                  onChange={(e) => setSettings({ ...settings, backup_enabled: e.target.checked ? '1' : '0' })}
                  className="sr-only peer"
                />
                <div className="w-11 h-6 bg-gray-600 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-primary-500"></div>
              </label>
            </div>
          </div>
        </div>

        {/* Database settings */}
        <div className="bg-dark-100 rounded-xl p-6 border border-gray-700 lg:col-span-2">
          <h2 className="text-lg font-semibold text-white mb-4 flex items-center">
            <FiDatabase className="w-5 h-5 mr-2 text-primary-500" />
            Mantenimiento
          </h2>
          <div className="flex gap-4">
            <button className="px-4 py-2 bg-primary-500 rounded-lg text-white font-medium hover:bg-primary-600 transition-colors flex items-center">
              <FiRefreshCw className="w-4 h-4 mr-2" />
              Limpiar Cache
            </button>
            <button className="px-4 py-2 bg-yellow-500 rounded-lg text-white font-medium hover:bg-yellow-600 transition-colors flex items-center">
              <FiDatabase className="w-4 h-4 mr-2" />
              Backup Manual
            </button>
          </div>
        </div>
      </div>

      {/* Save button */}
      <div className="mt-6 flex justify-end">
        <button
          onClick={handleSave}
          disabled={loading}
          className="px-6 py-2 bg-gradient-to-r from-primary-500 to-primary-600 rounded-lg text-white font-medium hover:from-primary-600 hover:to-primary-700 transition-all disabled:opacity-50 flex items-center"
        >
          {loading ? (
            <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
          ) : (
            <>
              <FiSave className="w-4 h-4 mr-2" />
              Guardar Cambios
            </>
          )}
        </button>
      </div>
    </MainLayout>
  )
}