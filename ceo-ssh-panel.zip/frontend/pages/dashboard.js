import { useState, useEffect } from 'react'
import { useAuth } from '../context/AuthContext'
import MainLayout from '../components/Layout/MainLayout'
import StatsCard from '../components/UI/StatsCard'
import Chart from '../components/UI/Chart'
import { 
  FiUsers, 
  FiUserCheck, 
  FiUserX, 
  FiActivity, 
  FiHardDrive, 
  FiCpu,
  FiTrendingUp,
  FiShield
} from 'react-icons/fi'
import { useWebSocket } from '../hooks/useWebSocket'
import { useApi } from '../hooks/useApi'

export default function Dashboard() {
  const { user } = useAuth()
  const { get } = useApi()
  const [stats, setStats] = useState({
    total_users: 0,
    active_tokens: 0,
    expired_tokens: 0,
    online_users: 0,
    server_load: 0,
    disk_usage: 0,
    memory_usage: 0
  })
  const [loading, setLoading] = useState(true)
  const [chartData, setChartData] = useState(null)

  // WebSocket for real-time updates
  const wsData = useWebSocket()

  useEffect(() => {
    fetchStats()
    fetchChartData()
  }, [])

  useEffect(() => {
    if (wsData) {
      setStats(prev => ({
        ...prev,
        online_users: wsData.online_users || prev.online_users,
        server_load: wsData.load_average || prev.server_load
      }))
    }
  }, [wsData])

  const fetchStats = async () => {
    try {
      const response = await get('/stats')
      if (response.success) {
        setStats(response.data)
      }
    } catch (error) {
      console.error('Error fetching stats:', error)
    } finally {
      setLoading(false)
    }
  }

  const fetchChartData = async () => {
    // Simulate chart data - in production, fetch from API
    setChartData({
      labels: ['Ene', 'Feb', 'Mar', 'Abr', 'May', 'Jun', 'Jul', 'Ago', 'Sep', 'Oct', 'Nov', 'Dic'],
      datasets: [
        {
          label: 'Usuarios Activos',
          data: [65, 78, 90, 85, 102, 115, 130, 145, 160, 175, 190, 210],
          borderColor: '#0087ff',
          backgroundColor: 'rgba(0, 135, 255, 0.1)',
          fill: true,
          tension: 0.4
        }
      ]
    })
  }

  const statsCards = [
    {
      title: 'Total Usuarios',
      value: stats.total_users,
      icon: FiUsers,
      color: 'from-blue-500 to-blue-600',
      trend: '+12%'
    },
    {
      title: 'Tokens Activos',
      value: stats.active_tokens,
      icon: FiUserCheck,
      color: 'from-green-500 to-green-600',
      trend: '+5%'
    },
    {
      title: 'Tokens Expirados',
      value: stats.expired_tokens,
      icon: FiUserX,
      color: 'from-red-500 to-red-600',
      trend: '-3%'
    },
    {
      title: 'Usuarios Online',
      value: stats.online_users,
      icon: FiActivity,
      color: 'from-purple-500 to-purple-600',
      trend: 'Ahora'
    },
    {
      title: 'Carga del Servidor',
      value: stats.server_load,
      icon: FiCpu,
      color: 'from-yellow-500 to-yellow-600',
      suffix: ' avg',
      decimals: 2
    },
    {
      title: 'Uso de Disco',
      value: stats.disk_usage,
      icon: FiHardDrive,
      color: 'from-orange-500 to-orange-600',
      suffix: '%'
    }
  ]

  if (loading) {
    return (
      <MainLayout>
        <div className="flex items-center justify-center h-96">
          <div className="w-12 h-12 border-4 border-primary-500 border-t-transparent rounded-full animate-spin"></div>
        </div>
      </MainLayout>
    )
  }

  return (
    <MainLayout>
      {/* Welcome section */}
      <div className="mb-8 animate-fade-in">
        <h1 className="text-2xl font-bold text-white mb-2">
          Bienvenido, {user?.username}
        </h1>
        <p className="text-gray-400">
          Panel de control de CEO SSH - Gestión profesional de usuarios
        </p>
      </div>

      {/* Stats grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-6 gap-6 mb-8">
        {statsCards.map((stat, index) => (
          <StatsCard key={index} {...stat} />
        ))}
      </div>

      {/* Charts row */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
        {/* User growth chart */}
        <div className="bg-dark-100 rounded-xl p-6 border border-gray-700">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-lg font-semibold text-white">Crecimiento de Usuarios</h3>
            <FiTrendingUp className="w-5 h-5 text-green-500" />
          </div>
          {chartData && <Chart data={chartData} type="line" height={300} />}
        </div>

        {/* System resources */}
        <div className="bg-dark-100 rounded-xl p-6 border border-gray-700">
          <h3 className="text-lg font-semibold text-white mb-4">Recursos del Sistema</h3>
          <div className="space-y-4">
            <div>
              <div className="flex justify-between text-sm mb-1">
                <span className="text-gray-400">CPU Usage</span>
                <span className="text-white">{Math.floor(Math.random() * 40) + 20}%</span>
              </div>
              <div className="w-full bg-dark-200 rounded-full h-2">
                <div className="bg-primary-500 h-2 rounded-full" style={{ width: `${Math.floor(Math.random() * 40) + 20}%` }}></div>
              </div>
            </div>
            <div>
              <div className="flex justify-between text-sm mb-1">
                <span className="text-gray-400">Memory Usage</span>
                <span className="text-white">{stats.memory_usage || 45}%</span>
              </div>
              <div className="w-full bg-dark-200 rounded-full h-2">
                <div className="bg-green-500 h-2 rounded-full" style={{ width: `${stats.memory_usage || 45}%` }}></div>
              </div>
            </div>
            <div>
              <div className="flex justify-between text-sm mb-1">
                <span className="text-gray-400">Disk Usage</span>
                <span className="text-white">{stats.disk_usage}%</span>
              </div>
              <div className="w-full bg-dark-200 rounded-full h-2">
                <div className="bg-yellow-500 h-2 rounded-full" style={{ width: `${stats.disk_usage}%` }}></div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Recent activity */}
      <div className="bg-dark-100 rounded-xl p-6 border border-gray-700">
        <h3 className="text-lg font-semibold text-white mb-4">Actividad Reciente</h3>
        <div className="space-y-3">
          {[1, 2, 3, 4, 5].map((_, i) => (
            <div key={i} className="flex items-center justify-between py-2 border-b border-gray-700 last:border-0">
              <div className="flex items-center space-x-3">
                <div className="w-8 h-8 bg-primary-500/20 rounded-full flex items-center justify-center">
                  <FiShield className="w-4 h-4 text-primary-500" />
                </div>
                <div>
                  <p className="text-white text-sm">Usuario creado: <span className="text-primary-400">client_{i+1}</span></p>
                  <p className="text-gray-500 text-xs">Hace {i+1} minutos</p>
                </div>
              </div>
              <span className="text-green-500 text-xs">Completado</span>
            </div>
          ))}
        </div>
      </div>
    </MainLayout>
  )
}