import { useState } from 'react'
import MainLayout from '../components/Layout/MainLayout'
import { useAuth } from '../context/AuthContext'
import { useApi } from '../hooks/useApi'
import toast from 'react-hot-toast'
import { FiUser, FiMail, FiShield, FiLock, FiSave } from 'react-icons/fi'

export default function Profile() {
  const { user } = useAuth()
  const { put } = useApi()
  const [loading, setLoading] = useState(false)
  const [passwordData, setPasswordData] = useState({
    current_password: '',
    new_password: '',
    confirm_password: ''
  })
  
  const handlePasswordChange = async (e) => {
    e.preventDefault()
    
    if (passwordData.new_password !== passwordData.confirm_password) {
      toast.error('Las contraseñas no coinciden')
      return
    }
    
    if (passwordData.new_password.length < 6) {
      toast.error('La contraseña debe tener al menos 6 caracteres')
      return
    }
    
    setLoading(true)
    try {
      const response = await put('/change-password', {
        current_password: passwordData.current_password,
        new_password: passwordData.new_password
      })
      
      if (response.success) {
        toast.success('Contraseña actualizada correctamente')
        setPasswordData({
          current_password: '',
          new_password: '',
          confirm_password: ''
        })
      }
    } catch (error) {
      toast.error(error.response?.data?.error || 'Error al cambiar contraseña')
    } finally {
      setLoading(false)
    }
  }
  
  return (
    <MainLayout>
      <div className="mb-8">
        <h1 className="text-2xl font-bold text-white mb-2">Mi Perfil</h1>
        <p className="text-gray-400">Gestiona tu información personal y seguridad</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Profile info */}
        <div className="bg-dark-100 rounded-xl p-6 border border-gray-700">
          <h2 className="text-lg font-semibold text-white mb-4">Información de la Cuenta</h2>
          <div className="space-y-4">
            <div className="flex items-center space-x-3 p-3 bg-dark-200 rounded-lg">
              <FiUser className="w-5 h-5 text-primary-500" />
              <div>
                <p className="text-xs text-gray-500">Usuario</p>
                <p className="text-white font-medium">{user?.username}</p>
              </div>
            </div>
            <div className="flex items-center space-x-3 p-3 bg-dark-200 rounded-lg">
              <FiMail className="w-5 h-5 text-primary-500" />
              <div>
                <p className="text-xs text-gray-500">Email</p>
                <p className="text-white font-medium">{user?.email || 'No especificado'}</p>
              </div>
            </div>
            <div className="flex items-center space-x-3 p-3 bg-dark-200 rounded-lg">
              <FiShield className="w-5 h-5 text-primary-500" />
              <div>
                <p className="text-xs text-gray-500">Rol</p>
                <p className="text-white font-medium capitalize">{user?.role}</p>
              </div>
            </div>
          </div>
        </div>

        {/* Change password */}
        <div className="bg-dark-100 rounded-xl p-6 border border-gray-700">
          <h2 className="text-lg font-semibold text-white mb-4">Cambiar Contraseña</h2>
          <form onSubmit={handlePasswordChange} className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-300 mb-2">
                Contraseña Actual
              </label>
              <input
                type="password"
                value={passwordData.current_password}
                onChange={(e) => setPasswordData({ ...passwordData, current_password: e.target.value })}
                className="w-full px-3 py-2 bg-dark-200 border border-gray-600 rounded-lg text-white focus:outline-none focus:ring-2 focus:ring-primary-500"
                required
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-300 mb-2">
                Nueva Contraseña
              </label>
              <input
                type="password"
                value={passwordData.new_password}
                onChange={(e) => setPasswordData({ ...passwordData, new_password: e.target.value })}
                className="w-full px-3 py-2 bg-dark-200 border border-gray-600 rounded-lg text-white focus:outline-none focus:ring-2 focus:ring-primary-500"
                required
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-300 mb-2">
                Confirmar Nueva Contraseña
              </label>
              <input
                type="password"
                value={passwordData.confirm_password}
                onChange={(e) => setPasswordData({ ...passwordData, confirm_password: e.target.value })}
                className="w-full px-3 py-2 bg-dark-200 border border-gray-600 rounded-lg text-white focus:outline-none focus:ring-2 focus:ring-primary-500"
                required
              />
            </div>
            <button
              type="submit"
              disabled={loading}
              className="w-full flex items-center justify-center px-4 py-2 bg-primary-500 rounded-lg text-white font-medium hover:bg-primary-600 transition-colors disabled:opacity-50"
            >
              {loading ? (
                <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
              ) : (
                <>
                  <FiSave className="w-4 h-4 mr-2" />
                  Actualizar Contraseña
                </>
              )}
            </button>
          </form>
        </div>
      </div>
    </MainLayout>
  )
}