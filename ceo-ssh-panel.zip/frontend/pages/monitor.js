import { useState, useEffect } from 'react'
import MainLayout from '../components/Layout/MainLayout'
import { useWebSocket } from '../hooks/useWebSocket'
import { FiCpu, FiHardDrive, FiActivity, FiUsers, FiServer, FiTrendingUp } from 'react-icons/fi'

export default function Monitor() {
  const wsData = useWebSocket()
  const [logs, setLogs] = useState([])
  
  // Simulated real-time logs
  useEffect(() => {
    const interval = setInterval(() => {
      setLogs(prev => [
        {
          id: Date.now(),
          timestamp: new Date().toLocaleTimeString(),
          message: `Conexión SSH desde IP ${Math.floor(Math.random() * 255)}.${Math.floor(Math.random() * 255)}.${Math.floor(Math.random() * 255)}.${Math.floor(Math.random() * 255)}`,
          type: 'info'
        },
        ...prev.slice(0, 49)
      ])
    }, 5000)
    return () => clearInterval(interval)
  }, [])
  
  const metrics = [
    { label: 'CPU Usage', value: wsData?.cpu_usage || 45, icon: FiCpu, unit: '%', color: 'from-blue-500 to-blue-600' },
    { label: 'Memory Usage', value: wsData?.memory_usage || 62, icon: FiHardDrive, unit: '%', color: 'from-green-500 to-green-600' },
    { label: 'Network Traffic', value: '124', icon: FiActivity, unit: 'Mbps', color: 'from-purple-500 to-purple-600' },
    { label: 'Active Connections', value: wsData?.online_users || 23, icon: FiUsers, unit: '', color: 'from-orange-500 to-orange-600' },
  ]
  
  return (
    <MainLayout>
      <div className="mb-8">
        <h1 className="text-2xl font-bold text-white mb-2">Monitor del Sistema</h1>
        <p className="text-gray-400">Monitoreo en tiempo real del servidor y conexiones activas</p>
      </div>

      {/* Metrics grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        {metrics.map((metric, index) => (
          <div key={index} className="bg-dark-100 rounded-xl p-6 border border-gray-700">
            <div className="flex items-center justify-between mb-4">
              <div className={`p-3 bg-gradient-to-br ${metric.color} rounded-lg bg-opacity-10`}>
                <metric.icon className="w-6 h-6 text-white" />
              </div>
              <span className="text-2xl font-bold text-white">{metric.value}{metric.unit}</span>
            </div>
            <h3 className="text-gray-400 text-sm font-medium">{metric.label}</h3>
          </div>
        ))}
      </div>

      {/* Real-time logs */}
      <div className="bg-dark-100 rounded-xl border border-gray-700">
        <div className="px-6 py-4 border-b border-gray-700">
          <h3 className="text-lg font-semibold text-white">Logs en Tiempo Real</h3>
        </div>
        <div className="p-4 h-96 overflow-y-auto font-mono text-sm">
          {logs.map(log => (
            <div key={log.id} className="mb-2 text-gray-300">
              <span className="text-gray-500">[{log.timestamp}]</span>{' '}
              <span className={log.type === 'error' ? 'text-red-400' : 'text-green-400'}>
                {log.message}
              </span>
            </div>
          ))}
          {logs.length === 0 && (
            <div className="text-center text-gray-500 py-8">
              Esperando eventos...
            </div>
          )}
        </div>
      </div>
    </MainLayout>
  )
}