import { createContext, useContext, useState, useEffect } from 'react'
import { useRouter } from 'next/router'
import api from '../utils/api'
import toast from 'react-hot-toast'

const AuthContext = createContext({})

export function AuthProvider({ children }) {
  const [user, setUser] = useState(null)
  const [loading, setLoading] = useState(true)
  const router = useRouter()
  
  useEffect(() => {
    checkAuth()
  }, [])
  
  const checkAuth = async () => {
    const token = localStorage.getItem('token')
    if (token) {
      try {
        const response = await api.get('/auth/verify')
        if (response.success) {
          setUser(response.data.user)
        } else {
          localStorage.removeItem('token')
        }
      } catch (error) {
        localStorage.removeItem('token')
      }
    }
    setLoading(false)
  }
  
  const login = async (username, password) => {
    try {
      const response = await api.post('/auth/login', { username, password })
      if (response.success) {
        localStorage.setItem('token', response.data.token)
        setUser(response.data.user)
        return true
      }
      throw new Error(response.error || 'Login failed')
    } catch (error) {
      throw error
    }
  }
  
  const logout = async () => {
    try {
      await api.post('/auth/logout')
    } catch (error) {
      console.error('Logout error:', error)
    } finally {
      localStorage.removeItem('token')
      setUser(null)
      router.push('/login')
    }
  }
  
  return (
    <AuthContext.Provider value={{ user, loading, login, logout, isAuthenticated: !!user }}>
      {children}
    </AuthContext.Provider>
  )
}

export const useAuth = () => useContext(AuthContext)