import { useState } from 'react'
import { FiMoreVertical, FiTrash2, FiCalendar, FiCopy } from 'react-icons/fi'
import { formatDate, copyToClipboard, getStatusColor, getStatusText } from '../../utils/helpers'
import toast from 'react-hot-toast'

export default function UsersTable({ users, loading, onDelete, onExtend }) {
  const [expandedRow, setExpandedRow] = useState(null)
  
  if (loading) {
    return (
      <div className="bg-dark-100 rounded-xl p-8 border border-gray-700">
        <div className="flex items-center justify-center">
          <div className="w-8 h-8 border-2 border-primary-500 border-t-transparent rounded-full animate-spin"></div>
        </div>
      </div>
    )
  }
  
  if (users.length === 0) {
    return (
      <div className="bg-dark-100 rounded-xl p-8 border border-gray-700 text-center">
        <p className="text-gray-400">No hay usuarios registrados</p>
      </div>
    )
  }
  
  const handleCopyPassword = async (password) => {
    const success = await copyToClipboard(password)
    if (success) {
      toast.success('Contraseña copiada al portapapeles')
    }
  }
  
  return (
    <div className="bg-dark-100 rounded-xl border border-gray-700 overflow-hidden">
      <div className="overflow-x-auto">
        <table className="w-full">
          <thead className="bg-dark-200 border-b border-gray-700">
            <tr>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-400 uppercase tracking-wider">Usuario</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-400 uppercase tracking-wider">Contraseña</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-400 uppercase tracking-wider">Expiración</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-400 uppercase tracking-wider">Estado</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-400 uppercase tracking-wider">Uso</th>
              <th className="px-6 py-3 text-right text-xs font-medium text-gray-400 uppercase tracking-wider">Acciones</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-gray-700">
            {users.map((user) => (
              <tr key={user.id} className="hover:bg-dark-200/50 transition-colors">
                <td className="px-6 py-4 whitespace-nowrap">
                  <div className="text-sm font-medium text-white">{user.username}</div>
                  <div className="text-xs text-gray-500">ID: {user.id}</div>
                </td>
                <td className="px-6 py-4 whitespace-nowrap">
                  <div className="flex items-center space-x-2">
                    <code className="text-sm text-gray-300 bg-dark-200 px-2 py-1 rounded">{user.password || '••••••••'}</code>
                    {user.password && (
                      <button
                        onClick={() => handleCopyPassword(user.password)}
                        className="p-1 hover:bg-dark-300 rounded transition-colors"
                      >
                        <FiCopy className="w-4 h-4 text-gray-400" />
                      </button>
                    )}
                  </div>
                </td>
                <td className="px-6 py-4 whitespace-nowrap">
                  <div className="text-sm text-gray-300">{formatDate(user.expires_at)}</div>
                </td>
                <td className="px-6 py-4 whitespace-nowrap">
                  <span className={`text-xs font-medium px-2 py-1 rounded-full ${getStatusColor(user.status)} bg-opacity-10 bg-current`}>
                    {getStatusText(user.status)}
                  </span>
                </td>
                <td className="px-6 py-4 whitespace-nowrap">
                  <div className="text-sm text-gray-300">
                    {user.traffic_used ? `${((user.traffic_used / 1024 / 1024 / 1024)).toFixed(2)} GB` : '0 GB'} / 
                    {user.traffic_limit ? `${(user.traffic_limit / 1024 / 1024 / 1024).toFixed(2)} GB` : ' Ilimitado'}
                  </div>
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-right">
                  <div className="flex items-center justify-end space-x-2">
                    <button
                      onClick={() => onExtend(user.id, 30)}
                      className="px-3 py-1 text-xs bg-green-500/20 text-green-500 rounded-lg hover:bg-green-500/30 transition-colors"
                    >
                      <FiCalendar className="w-3 h-3 inline mr-1" />
                      Extender
                    </button>
                    <button
                      onClick={() => onDelete(user.id, user.username)}
                      className="px-3 py-1 text-xs bg-red-500/20 text-red-500 rounded-lg hover:bg-red-500/30 transition-colors"
                    >
                      <FiTrash2 className="w-3 h-3 inline mr-1" />
                      Eliminar
                    </button>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  )
}