import { useEffect, useRef } from 'react'
import Chart from 'chart.js/auto'

export default function ChartComponent({ data, type = 'line', height = 300 }) {
  const chartRef = useRef(null)
  const chartInstance = useRef(null)
  
  useEffect(() => {
    if (chartRef.current) {
      if (chartInstance.current) {
        chartInstance.current.destroy()
      }
      
      chartInstance.current = new Chart(chartRef.current, {
        type: type,
        data: data,
        options: {
          responsive: true,
          maintainAspectRatio: false,
          plugins: {
            legend: {
              labels: {
                color: '#a1a1aa',
                font: {
                  size: 12
                }
              }
            }
          },
          scales: {
            y: {
              grid: {
                color: '#27272a'
              },
              ticks: {
                color: '#a1a1aa'
              }
            },
            x: {
              grid: {
                color: '#27272a'
              },
              ticks: {
                color: '#a1a1aa'
              }
            }
          }
        }
      })
    }
    
    return () => {
      if (chartInstance.current) {
        chartInstance.current.destroy()
      }
    }
  }, [data, type])
  
  return (
    <div style={{ height: `${height}px` }}>
      <canvas ref={chartRef}></canvas> <
    /div>
  )
}