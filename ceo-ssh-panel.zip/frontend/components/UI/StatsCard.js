import { FiTrendingUp, FiTrendingDown } from 'react-icons/fi'

export default function StatsCard({ title, value, icon: Icon, color, trend, suffix = '', decimals = 0 }) {
  const formattedValue = decimals > 0 ? Number(value).toFixed(decimals) : value
  const isPositive = trend && !trend.includes('-')
  
  return (
    <div className="bg-dark-100 rounded-xl p-6 border border-gray-700 hover:border-primary-500/50 transition-all group">
      <div className="flex items-center justify-between mb-4">
        <div className={`p-3 bg-gradient-to-br ${color} rounded-lg bg-opacity-10`}>
          <Icon className={`w-6 h-6 text-white`} />
        </div>
        {trend && (
          <div className={`flex items-center ${isPositive ? 'text-green-500' : 'text-red-500'}`}>
            {isPositive ? <FiTrendingUp className="w-4 h-4 mr-1" /> : <FiTrendingDown className="w-4 h-4 mr-1" />}
            <span className="text-xs font-medium">{trend}</span>
          </div>
        )}
      </div>
      <h3 className="text-gray-400 text-sm font-medium mb-1">{title}</h3>
      <p className="text-2xl font-bold text-white">
        {formattedValue}{suffix}
      </p>
    </div>
  )
}