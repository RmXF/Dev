import Link from 'next/link'
import { useRouter } from 'next/router'
import { useTheme } from '../../context/ThemeContext'
import {
  FiGrid,
  FiUsers,
  FiActivity,
  FiSettings,
  FiUser,
  FiLogOut,
  FiShield,
  FiChevronLeft,
  FiChevronRight,
  FiSun,
  FiMoon
} from 'react-icons/fi'
import { useAuth } from '../../context/AuthContext'

const menuItems = [
  { path: '/dashboard', name: 'Dashboard', icon: FiGrid },
  { path: '/users', name: 'Usuarios', icon: FiUsers },
  { path: '/monitor', name: 'Monitor', icon: FiActivity },
  { path: '/profile', name: 'Perfil', icon: FiUser },
  { path: '/settings', name: 'Configuración', icon: FiSettings },
]

export default function Sidebar({ isOpen, setIsOpen }) {
  const router = useRouter()
  const { theme, toggleTheme } = useTheme()
  const { logout } = useAuth()
  
  const handleLogout = async () => {
    await logout()
    router.push('/login')
  }
  
  return (
    <aside className={`fixed left-0 top-0 h-full bg-dark-100 border-r border-gray-700 transition-all duration-300 z-20 ${isOpen ? 'w-64' : 'w-20'}`}>
      {/* Logo */}
      <div className="flex items-center justify-between h-16 px-4 border-b border-gray-700">
        {isOpen ? (
          <div className="flex items-center space-x-2">
            <FiShield className="w-8 h-8 text-primary-500" />
            <span className="text-white font-bold text-lg">CEO SSH</span>
          </div>
        ) : (
          <FiShield className="w-8 h-8 text-primary-500 mx-auto" />
        )}
        <button
          onClick={() => setIsOpen(!isOpen)}
          className="p-1 rounded-lg hover:bg-dark-200 transition-colors"
        >
          {isOpen ? <FiChevronLeft className="w-5 h-5 text-gray-400" /> : <FiChevronRight className="w-5 h-5 text-gray-400" />}
        </button>
      </div>

      {/* Navigation */}
      <nav className="mt-6 px-2">
        {menuItems.map((item) => {
          const isActive = router.pathname === item.path
          return (
            <Link key={item.path} href={item.path}>
              <div className={`flex items-center px-3 py-2 mb-1 rounded-lg cursor-pointer transition-all group ${
                isActive 
                  ? 'bg-primary-500/20 text-primary-500' 
                  : 'text-gray-400 hover:bg-dark-200 hover:text-white'
              }`}>
                <item.icon className={`w-5 h-5 ${isOpen ? 'mr-3' : 'mx-auto'}`} />
                {isOpen && <span className="text-sm font-medium">{item.name}</span>}
                {!isOpen && (
                  <div className="absolute left-20 ml-2 px-2 py-1 bg-gray-800 text-white text-sm rounded opacity-0 group-hover:opacity-100 transition-opacity whitespace-nowrap z-30">
                    {item.name}
                  </div>
                )}
              </div>
            </Link>
          )
        })}
      </nav>

      {/* Footer */}
      <div className="absolute bottom-0 left-0 right-0 p-4 border-t border-gray-700">
        <button
          onClick={toggleTheme}
          className={`flex items-center w-full px-3 py-2 mb-2 rounded-lg text-gray-400 hover:bg-dark-200 hover:text-white transition-colors ${!isOpen && 'justify-center'}`}
        >
          {theme === 'dark' ? <FiSun className="w-5 h-5" /> : <FiMoon className="w-5 h-5" />}
          {isOpen && <span className="ml-3 text-sm">Modo {theme === 'dark' ? 'Claro' : 'Oscuro'}</span>}
        </button>
        <button
          onClick={handleLogout}
          className={`flex items-center w-full px-3 py-2 rounded-lg text-red-400 hover:bg-red-500/10 hover:text-red-300 transition-colors ${!isOpen && 'justify-center'}`}
        >
          <FiLogOut className="w-5 h-5" />
          {isOpen && <span className="ml-3 text-sm">Cerrar Sesión</span>}
        </button>
      </div>
    </aside>
  )
}