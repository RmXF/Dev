import { useAuth } from '../../context/AuthContext'
import { FiMenu, FiBell } from 'react-icons/fi'

export default function Header({ sidebarOpen, setSidebarOpen }) {
  const { user } = useAuth()
  
  return (
    <header className="bg-dark-100 border-b border-gray-700 h-16 flex items-center justify-between px-6">
      <div className="flex items-center">
        <button
          onClick={() => setSidebarOpen(!sidebarOpen)}
          className="p-2 rounded-lg hover:bg-dark-200 transition-colors lg:hidden"
        >
          <FiMenu className="w-5 h-5 text-gray-400" />
        </button>
      </div>

      <div className="flex items-center space-x-4">
        <button className="p-2 rounded-lg hover:bg-dark-200 transition-colors relative">
          <FiBell className="w-5 h-5 text-gray-400" />
          <span className="absolute top-1 right-1 w-2 h-2 bg-red-500 rounded-full"></span>
        </button>
        <div className="flex items-center space-x-3">
          <div className="text-right hidden sm:block">
            <p className="text-white text-sm font-medium">{user?.username}</p>
            <p className="text-gray-400 text-xs">{user?.role === 'admin' ? 'Administrador' : 'Usuario'}</p>
          </div>
          <div className="w-8 h-8 bg-gradient-to-r from-primary-500 to-primary-600 rounded-full flex items-center justify-center">
            <span className="text-white text-sm font-bold">
              {user?.username?.charAt(0).toUpperCase()}
            </span>
          </div>
        </div>
      </div>
    </header>
  )
}