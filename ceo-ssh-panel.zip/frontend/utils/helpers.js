export const formatDate = (date) => {
  if (!date) return 'Nunca'
  return new Date(date).toLocaleDateString('es-ES', {
    year: 'numeric',
    month: 'long',
    day: 'numeric'
  })
}

export const formatBytes = (bytes) => {
  if (bytes === 0) return '0 Bytes'
  const k = 1024
  const sizes = ['Bytes', 'KB', 'MB', 'GB', 'TB']
  const i = Math.floor(Math.log(bytes) / Math.log(k))
  return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i]
}

export const getStatusColor = (status) => {
  switch (status) {
    case 'active':
      return 'text-green-500'
    case 'expired':
      return 'text-red-500'
    case 'suspended':
      return 'text-yellow-500'
    default:
      return 'text-gray-500'
  }
}

export const getStatusText = (status) => {
  switch (status) {
    case 'active':
      return 'Activo'
    case 'expired':
      return 'Expirado'
    case 'suspended':
      return 'Suspendido'
    default:
      return 'Desconocido'
  }
}

export const copyToClipboard = async (text) => {
  try {
    await navigator.clipboard.writeText(text)
    return true
  } catch (err) {
    console.error('Failed to copy:', err)
    return false
  }
}