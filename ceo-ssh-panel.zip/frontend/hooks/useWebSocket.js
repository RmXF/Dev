import { useEffect, useState, useRef } from 'react'
import { io } from 'socket.io-client'

export function useWebSocket() {
  const [data, setData] = useState(null)
  const socketRef = useRef(null)
  
  useEffect(() => {
    const token = localStorage.getItem('token')
    if (!token) return
    
    // Connect to WebSocket
    socketRef.current = io(process.env.NEXT_PUBLIC_WS_URL, {
      query: { token },
      transports: ['websocket']
    })
    
    socketRef.current.on('connect', () => {
      console.log('WebSocket connected')
    })
    
    socketRef.current.on('stats', (stats) => {
      setData(stats)
    })
    
    socketRef.current.on('disconnect', () => {
      console.log('WebSocket disconnected')
    })
    
    return () => {
      if (socketRef.current) {
        socketRef.current.disconnect()
      }
    }
  }, [])
  
  return data
}