import api from '../utils/api'

export function useApi() {
  const get = async (url, config = {}) => {
    try {
      const response = await api.get(url, config)
      return response
    } catch (error) {
      throw error
    }
  }
  
  const post = async (url, data, config = {}) => {
    try {
      const response = await api.post(url, data, config)
      return response
    } catch (error) {
      throw error
    }
  }
  
  const put = async (url, data, config = {}) => {
    try {
      const response = await api.put(url, data, config)
      return response
    } catch (error) {
      throw error
    }
  }
  
  const del = async (url, config = {}) => {
    try {
      const response = await api.delete(url, config)
      return response
    } catch (error) {
      throw error
    }
  }
  
  return { get, post, put, del }
}