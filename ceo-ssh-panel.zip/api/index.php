<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization, X-Requested-With');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

// Configuración
define('TOKEN_FILE', '/etc/token/BD');
define('CLIENT_FILE', '/etc/token/.clientes');
define('AUTH_FILE', '/etc/ceo-ssh-auth');
define('LOG_FILE', '/var/log/ceo-ssh-api.log');

// Función para loggear
function log_message($message) {
    $log = date('[Y-m-d H:i:s]') . " " . $message . PHP_EOL;
    file_put_contents(LOG_FILE, $log, FILE_APPEND);
}

// Autenticación
function authenticate() {
    $headers = getallheaders();
    $auth = isset($headers['Authorization']) ? $headers['Authorization'] : '';
    
    if (empty($auth) && isset($_SERVER['HTTP_AUTHORIZATION'])) {
        $auth = $_SERVER['HTTP_AUTHORIZATION'];
    }
    
    if (empty($auth)) {
        http_response_code(401);
        echo json_encode(['error' => 'No autorizado', 'code' => 'MISSING_AUTH']);
        exit;
    }
    
    $auth = str_replace('Basic ', '', $auth);
    $auth = base64_decode($auth);
    list($user, $pass) = explode(':', $auth);
    
    if (!file_exists(AUTH_FILE)) {
        http_response_code(500);
        echo json_encode(['error' => 'Error de configuración del servidor']);
        exit;
    }
    
    $creds = file(AUTH_FILE, FILE_IGNORE_NEW_LINES);
    if (count($creds) < 1) {
        http_response_code(500);
        echo json_encode(['error' => 'Credenciales no configuradas']);
        exit;
    }
    
    $valid = explode(':', $creds[0]);
    
    if ($user !== trim($valid[0]) || $pass !== trim($valid[1])) {
        log_message("Intento de autenticación fallido para usuario: $user");
        http_response_code(401);
        echo json_encode(['error' => 'Credenciales inválidas']);
        exit;
    }
    
    return true;
}

// Obtener todos los usuarios
function getUsers() {
    $users = [];
    if (file_exists(TOKEN_FILE)) {
        $tokens = array_filter(file(TOKEN_FILE, FILE_IGNORE_NEW_LINES));
        foreach ($tokens as $token) {
            $token = trim($token);
            if (empty($token)) continue;
            
            $user_info = getUserInfo($token);
            if ($user_info) {
                $users[] = $user_info;
            }
        }
    }
    return $users;
}

// Obtener información de un usuario
function getUserInfo($username) {
    $user_data = shell_exec("id $username 2>/dev/null");
    if (empty($user_data)) return null;
    
    $exp_data = shell_exec("chage -l $username 2>/dev/null");
    if (!$exp_data) return null;
    
    preg_match('/Account expires.*: (.+)$/m', $exp_data, $exp_match);
    $expires = trim($exp_match[1] ?? 'never');
    
    // Verificar si expiró
    $is_expired = false;
    if ($expires !== 'never') {
        $exp_timestamp = strtotime($expires);
        $is_expired = $exp_timestamp < time();
    }
    
    return [
        'username' => $username,
        'expiration' => $expires,
        'status' => $is_expired ? 'expired' : 'active',
        'is_active' => !$is_expired,
        'created_at' => date('Y-m-d H:i:s', filectime("/home/$username") ?? time())
    ];
}

// Crear usuario
function createUser($username, $days, $password = null) {
    $check = shell_exec("id $username 2>/dev/null");
    if (!empty($check)) {
        return ['error' => 'El usuario ya existe'];
    }
    
    $password = $password ?: substr(bin2hex(random_bytes(8)), 0, 12);
    $exp_date = date('Y-m-d', strtotime("+$days days"));
    
    $create = shell_exec("useradd -m -s /bin/false -e $exp_date $username 2>&1");
    if (!empty($create)) {
        return ['error' => "Error al crear usuario: $create"];
    }
    
    shell_exec("echo '$username:$password' | chpasswd 2>&1");
    
    // Guardar en archivo de tokens
    file_put_contents(TOKEN_FILE, $username . "\n", FILE_APPEND);
    
    // Guardar en archivo de clientes
    $date = date('d/m/Y');
    $time = date('H:i');
    file_put_contents(CLIENT_FILE, "$username $username $date $time\n", FILE_APPEND);
    
    log_message("Usuario creado: $username - Expira: $exp_date");
    
    return [
        'success' => true,
        'username' => $username,
        'password' => $password,
        'expiration' => $exp_date,
        'days' => $days
    ];
}

// Eliminar usuario
function deleteUser($username) {
    $check = shell_exec("id $username 2>/dev/null");
    if (empty($check)) {
        return ['error' => 'El usuario no existe'];
    }
    
    shell_exec("userdel -r -f $username 2>&1");
    
    // Eliminar de archivos
    if (file_exists(TOKEN_FILE)) {
        $tokens = file(TOKEN_FILE, FILE_IGNORE_NEW_LINES);
        $tokens = array_filter($tokens, function($t) use ($username) {
            return trim($t) !== $username;
        });
        file_put_contents(TOKEN_FILE, implode("\n", $tokens) . "\n");
    }
    
    if (file_exists(CLIENT_FILE)) {
        $clients = file(CLIENT_FILE, FILE_IGNORE_NEW_LINES);
        $clients = array_filter($clients, function($c) use ($username) {
            return strpos($c, $username) !== 0;
        });
        file_put_contents(CLIENT_FILE, implode("\n", $clients) . "\n");
    }
    
    log_message("Usuario eliminado: $username");
    
    return ['success' => true, 'message' => 'Usuario eliminado correctamente'];
}

// Extender expiración
function extendUser($username, $days) {
    $check = shell_exec("id $username 2>/dev/null");
    if (empty($check)) {
        return ['error' => 'El usuario no existe'];
    }
    
    $current_exp = shell_exec("chage -l $username | grep 'Account expires' | cut -d: -f2");
    $current_exp = trim($current_exp);
    
    if ($current_exp === 'never' || empty($current_exp)) {
        $new_exp = date('Y-m-d', strtotime("+$days days"));
    } else {
        $current_timestamp = strtotime($current_exp);
        $new_timestamp = max($current_timestamp, time()) + ($days * 86400);
        $new_exp = date('Y-m-d', $new_timestamp);
    }
    
    shell_exec("usermod -e $new_exp $username 2>&1");
    shell_exec("passwd -u $username 2>&1");
    
    log_message("Usuario extendido: $username +$days días. Nueva expiración: $new_exp");
    
    return [
        'success' => true,
        'username' => $username,
        'new_expiration' => $new_exp,
        'days_added' => $days
    ];
}

// Obtener estadísticas del servidor
function getStats() {
    $total_users = shell_exec("cat /etc/passwd | grep -c '/home' 2>/dev/null") ?: 0;
    $online_ssh = shell_exec("ps aux | grep -E 'sshd.*@' | grep -v grep | wc -l 2>/dev/null") ?: 0;
    $online_dropbear = shell_exec("ps aux | grep dropbear | grep -v grep | wc -l 2>/dev/null") ?: 0;
    $online_users = (int)$online_ssh + (int)$online_dropbear;
    
    $load = sys_getloadavg();
    $load_val = $load[0] ?? 0;
    
    $disk_total = disk_total_space('/');
    $disk_free = disk_free_space('/');
    $disk_usage = $disk_total > 0 ? round(100 - ($disk_free / $disk_total * 100), 2) : 0;
    
    $mem_total = shell_exec("free -m | grep Mem | awk '{print $2}'");
    $mem_used = shell_exec("free -m | grep Mem | awk '{print $3}'");
    $mem_usage = $mem_total > 0 ? round(($mem_used / $mem_total) * 100, 2) : 0;
    
    $uptime = shell_exec("cat /proc/uptime | awk '{print int($1/86400)}'") ?: 0;
    
    return [
        'total_users' => (int)$total_users,
        'online_users' => (int)$online_users,
        'server_load' => (float)$load_val,
        'disk_usage' => (float)$disk_usage,
        'memory_usage' => (float)$mem_usage,
        'uptime_days' => (int)$uptime,
        'timestamp' => date('c')
    ];
}

// Obtener logs recientes
function getLogs($lines = 50) {
    if (!file_exists(LOG_FILE)) {
        return [];
    }
    
    $logs = file(LOG_FILE, FILE_IGNORE_NEW_LINES);
    return array_slice(array_reverse($logs), 0, $lines);
}

// Router
$method = $_SERVER['REQUEST_METHOD'];
$path = isset($_SERVER['PATH_INFO']) ? $_SERVER['PATH_INFO'] : '/';
if ($path === '/') {
    $path = isset($_GET['route']) ? '/' . $_GET['route'] : '/';
}

// Endpoints públicos (sin autenticación)
$public_endpoints = ['/health', '/ping'];
$is_public = in_array($path, $public_endpoints);

if (!$is_public) {
    authenticate();
}

// Manejo de rutas
switch ($path) {
    case '/health':
    case '/ping':
        echo json_encode([
            'status' => 'ok',
            'service' => 'CEO SSH API',
            'version' => '2.0.0',
            'timestamp' => date('c')
        ]);
        break;
        
    case '/users':
        if ($method === 'GET') {
            echo json_encode(getUsers());
        } elseif ($method === 'POST') {
            $data = json_decode(file_get_contents('php://input'), true);
            echo json_encode(createUser($data['username'], $data['days'], $data['password'] ?? null));
        }
        break;
        
    case '/stats':
        echo json_encode(getStats());
        break;
        
    case '/logs':
        $lines = isset($_GET['lines']) ? (int)$_GET['lines'] : 50;
        echo json_encode(['logs' => getLogs($lines)]);
        break;
        
    default:
        if (preg_match('/^\/users\/(.+)$/', $path, $matches)) {
            $username = urldecode($matches[1]);
            if ($method === 'DELETE') {
                echo json_encode(deleteUser($username));
            } elseif ($method === 'PUT') {
                $data = json_decode(file_get_contents('php://input'), true);
                echo json_encode(extendUser($username, $data['days']));
            } elseif ($method === 'GET') {
                echo json_encode(getUserInfo($username));
            }
        } else {
            http_response_code(404);
            echo json_encode(['error' => 'Endpoint no encontrado', 'path' => $path]);
        }
}

log_message("API Request: $method $path");
?>