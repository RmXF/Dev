/** @type {import('next').NextConfig} */
const nextConfig = {
  output: 'standalone',
  reactStrictMode: true,
  swcMinify: true,
  images: {
    domains: ['localhost'],
  },
  env: {
    APP_NAME: 'CEO SSH VPN',
    APP_VERSION: '2.0.0'
  }
}

module.exports = nextConfig