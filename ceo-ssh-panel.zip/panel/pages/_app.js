import '../styles/globals.css'
import { Toaster } from 'react-hot-toast'
import { useEffect, useState } from 'react'
import { useRouter } from 'next/router'

function MyApp({ Component, pageProps }) {
  const [isAuthenticated, setIsAuthenticated] = useState(false)
  const router = useRouter()
  
  useEffect(() => {
    const auth = localStorage.getItem('ceo_auth')
    if (!auth && router.pathname !== '/login') {
      router.push('/login')
    } else {
      setIsAuthenticated(true)
    }
  }, [])
  
  if (!isAuthenticated && router.pathname !== '/login') {
    return null
  }
  
  return (
    <>
      <Component {...pageProps} />
      <Toaster 
        position="top-right"
        toastOptions={{
          style: {
            background: '#1a1a2e',
            color: '#fff',
            border: '1px solid #00ff88'
          }
        }}
      />
    </>
  )
}

export default MyApp