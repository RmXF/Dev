import { useState, useEffect } from 'react'
import Head from 'next/head'
import toast from 'react-hot-toast'
import { 
  FiUsers, 
  FiUserCheck, 
  FiHardDrive, 
  FiCpu,
  FiTrendingUp,
  FiActivity,
  FiServer
} from 'react-icons/fi'
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  BarElement,
  Title,
  Tooltip,
  Legend,
  ArcElement
} from 'chart.js'
import { Line, Bar, Doughnut } from 'react-chartjs-2'

ChartJS.register(
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  BarElement,
  Title,
  Tooltip,
  Legend,
  ArcElement
)

export default function Dashboard() {
  const [stats, setStats] = useState({
    total_users: 0,
    online_users: 0,
    server_load: 0,
    disk_usage: 0,
    memory_usage: 0,
    uptime_days: 0
  })
  const [loading, setLoading] = useState(true)
  const [lastUpdate, setLastUpdate] = useState(new Date())

  const API_URL = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:8080'

  const fetchStats = async () => {
    try {
      const auth = localStorage.getItem('ceo_auth')
      const res = await fetch(`${API_URL}/stats`, {
        headers: {
          'Authorization': `Basic ${auth}`
        }
      })
      const data = await res.json()
      setStats(data)
      setLastUpdate(new Date())
    } catch (error) {
      console.error('Error fetching stats:', error)
      toast.error('Error al cargar estadísticas')
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => {
    fetchStats()
    const interval = setInterval(fetchStats, 30000)
    return () => clearInterval(interval)
  }, [])

  // Gráfica de uso de disco y memoria
  const resourceData = {
    labels: ['Disco', 'Memoria'],
    datasets: [
      {
        data: [stats.disk_usage, stats.memory_usage],
        backgroundColor: ['#00ff88', '#ffaa00'],
        borderWidth: 0,
      },
    ],
  }

  // Datos de ejemplo para tráfico
  const trafficData = {
    labels: ['Lun', 'Mar', 'Mié', 'Jue', 'Vie', 'Sáb', 'Dom'],
    datasets: [
      {
        label: 'Usuarios Activos',
        data: [12, 19, 15, 17, 14, 22, 18],
        borderColor: '#00ff88',
        backgroundColor: 'rgba(0, 255, 136, 0.1)',
        fill: true,
        tension: 0.4,
      },
    ],
  }

  const chartOptions = {
    responsive: true,
    plugins: {
      legend: {
        labels: { color: '#fff' }
      }
    },
    scales: {
      y: {
        grid: { color: 'rgba(255,255,255,0.1)' },
        ticks: { color: '#fff' }
      },
      x: {
        grid: { color: 'rgba(255,255,255,0.1)' },
        ticks: { color: '#fff' }
      }
    }
  }

  const StatsCard = ({ title, value, icon, color, subtitle }) => (
    <div className="stat-card">
      <div className="stat-icon" style={{ background: color }}>
        {icon}
      </div>
      <div className="stat-info">
        <h3>{title}</h3>
        <p className="stat-value">{value}</p>
        {subtitle && <span className="stat-subtitle">{subtitle}</span>}
      </div>
    </div>
  )

  if (loading) {
    return (
      <div className="loading-container">
        <div className="loading-spinner"></div>
        <h2>Cargando CEO SSH Panel...</h2>
      </div>
    )
  }

  return (
    <>
      <Head>
        <title>CEO SSH VPN - Dashboard</title>
      </Head>

      <div className="dashboard">
        <div className="dashboard-header">
          <div>
            <h1>🚀 Dashboard CEO SSH</h1>
            <p>Panel de Control Avanzado - Última actualización: {lastUpdate.toLocaleTimeString()}</p>
          </div>
          <button className="refresh-btn" onClick={fetchStats}>
            <FiTrendingUp /> Actualizar
          </button>
        </div>

        <div className="stats-grid">
          <StatsCard 
            title="Total Usuarios" 
            value={stats.total_users} 
            icon={<FiUsers size={24} />}
            color="#00ff88"
            subtitle="usuarios registrados"
          />
          <StatsCard 
            title="Usuarios Online" 
            value={stats.online_users} 
            icon={<FiUserCheck size={24} />}
            color="#00aaff"
            subtitle="conectados ahora"
          />
          <StatsCard 
            title="Carga del Servidor" 
            value={stats.server_load.toFixed(2)} 
            icon={<FiCpu size={24} />}
            color="#ffaa00"
            subtitle="load average"
          />
          <StatsCard 
            title="Uptime" 
            value={`${stats.uptime_days}d`} 
            icon={<FiActivity size={24} />}
            color="#ff44aa"
            subtitle="días activo"
          />
        </div>

        <div className="charts-row">
          <div className="chart-card">
            <h3>📊 Tráfico de Usuarios</h3>
            <Line data={trafficData} options={chartOptions} />
          </div>
          <div className="chart-card">
            <h3>💾 Uso de Recursos</h3>
            <div className="doughnut-container">
              <Doughnut data={resourceData} options={{ responsive: true, maintainAspectRatio: true }} />
            </div>
            <div className="resource-labels">
              <span><span className="dot disk"></span> Disco: {stats.disk_usage}%</span>
              <span><span className="dot memory"></span> Memoria: {stats.memory_usage}%</span>
            </div>
          </div>
        </div>

        <div className="info-panel">
          <div className="info-card">
            <FiServer size={20} />
            <div>
              <strong>Sistema</strong>
              <p>CEO SSH VPN v2.0.0</p>
            </div>
          </div>
          <div className="info-card">
            <FiActivity size={20} />
            <div>
              <strong>Estado</strong>
              <p style={{ color: '#00ff88' }}>● Activo</p>
            </div>
          </div>
        </div>
      </div>

      <style jsx>{`
        .dashboard {
          padding: 20px;
          max-width: 1400px;
          margin: 0 auto;
        }
        .dashboard-header {
          display: flex;
          justify-content: space-between;
          align-items: center;
          margin-bottom: 30px;
          background: rgba(0,0,0,0.3);
          padding: 20px;
          border-radius: 15px;
        }
        .dashboard-header h1 {
          margin: 0;
          color: #00ff88;
        }
        .refresh-btn {
          background: #00ff88;
          border: none;
          padding: 10px 20px;
          border-radius: 8px;
          cursor: pointer;
          font-weight: bold;
          display: flex;
          align-items: center;
          gap: 8px;
        }
        .stats-grid {
          display: grid;
          grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
          gap: 20px;
          margin-bottom: 30px;
        }
        .stat-card {
          background: rgba(0,0,0,0.5);
          backdrop-filter: blur(10px);
          border-radius: 15px;
          padding: 20px;
          display: flex;
          align-items: center;
          gap: 15px;
          border: 1px solid rgba(255,255,255,0.1);
          transition: transform 0.3s;
        }
        .stat-card:hover {
          transform: translateY(-5px);
        }
        .stat-icon {
          width: 50px;
          height: 50px;
          border-radius: 12px;
          display: flex;
          align-items: center;
          justify-content: center;
          color: #fff;
        }
        .stat-info h3 {
          margin: 0;
          font-size: 14px;
          color: #888;
        }
        .stat-value {
          font-size: 28px;
          font-weight: bold;
          margin: 5px 0 0;
        }
        .stat-subtitle {
          font-size: 11px;
          color: #666;
        }
        .charts-row {
          display: grid;
          grid-template-columns: repeat(auto-fit, minmax(400px, 1fr));
          gap: 20px;
          margin-bottom: 30px;
        }
        .chart-card {
          background: rgba(0,0,0,0.5);
          backdrop-filter: blur(10px);
          border-radius: 15px;
          padding: 20px;
          border: 1px solid rgba(255,255,255,0.1);
        }
        .chart-card h3 {
          margin-top: 0;
          margin-bottom: 20px;
        }
        .doughnut-container {
          max-width: 200px;
          margin: 0 auto;
        }
        .resource-labels {
          display: flex;
          justify-content: center;
          gap: 20px;
          margin-top: 15px;
        }
        .dot {
          width: 10px;
          height: 10px;
          display: inline-block;
          border-radius: 50%;
          margin-right: 5px;
        }
        .dot.disk { background: #00ff88; }
        .dot.memory { background: #ffaa00; }
        .info-panel {
          display: flex;
          gap: 15px;
        }
        .info-card {
          background: rgba(0,0,0,0.3);
          border-radius: 10px;
          padding: 12px 20px;
          display: flex;
          align-items: center;
          gap: 12px;
        }
        .loading-container {
          display: flex;
          flex-direction: column;
          align-items: center;
          justify-content: center;
          height: 100vh;
          background: #0a0a0a;
        }
        .loading-spinner {
          width: 50px;
          height: 50px;
          border: 3px solid #1a1a2e;
          border-top-color: #00ff88;
          border-radius: 50%;
          animation: spin 1s linear infinite;
        }
        @keyframes spin {
          to { transform: rotate(360deg); }
        }
      `}</style>
    </>
  )
}