import { useState } from 'react'
import { useRouter } from 'next/router'
import toast from 'react-hot-toast'

export default function Login() {
  const [username, setUsername] = useState('')
  const [password, setPassword] = useState('')
  const [loading, setLoading] = useState(false)
  const router = useRouter()
  
  const API_URL = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:8080'
  
  const handleSubmit = async (e) => {
    e.preventDefault()
    setLoading(true)
    
    try {
      const auth = btoa(`${username}:${password}`)
      const res = await fetch(`${API_URL}/health`, {
        headers: {
          'Authorization': `Basic ${auth}`
        }
      })
      
      if (res.ok) {
        localStorage.setItem('ceo_auth', auth)
        localStorage.setItem('ceo_user', username)
        toast.success('Inicio de sesión exitoso')
        router.push('/')
      } else {
        toast.error('Usuario o contraseña incorrectos')
      }
    } catch (error) {
      toast.error('Error al conectar con el servidor')
    } finally {
      setLoading(false)
    }
  }
  
  return (
    <div className="login-container">
      <div className="login-card">
        <div className="login-header">
          <h1>🚀 CEO SSH VPN</h1>
          <p>Panel de Control</p>
        </div>
        
        <form onSubmit={handleSubmit}>
          <div className="input-group">
            <input
              type="text"
              placeholder="Usuario"
              value={username}
              onChange={(e) => setUsername(e.target.value)}
              required
            />
          </div>
          
          <div className="input-group">
            <input
              type="password"
              placeholder="Contraseña"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              required
            />
          </div>
          
          <button type="submit" disabled={loading}>
            {loading ? 'Ingresando...' : 'Ingresar'}
          </button>
        </form>
        
        <div className="login-footer">
          <p>CEO SSH VPN © 2024</p>
          <p className="dev">Desarrollado por @dankelthaher</p>
        </div>
      </div>

      <style jsx>{`
        .login-container {
          min-height: 100vh;
          display: flex;
          align-items: center;
          justify-content: center;
          background: linear-gradient(135deg, #0a0a0a 0%, #1a1a2e 100%);
        }
        .login-card {
          background: rgba(0,0,0,0.6);
          backdrop-filter: blur(10px);
          padding: 40px;
          border-radius: 20px;
          width: 100%;
          max-width: 400px;
          border: 1px solid rgba(0,255,136,0.3);
          box-shadow: 0 0 30px rgba(0,255,136,0.1);
        }
        .login-header {
          text-align: center;
          margin-bottom: 30px;
        }
        .login-header h1 {
          color: #00ff88;
          margin: 0;
        }
        .login-header p {
          color: #888;
          margin-top: 5px;
        }
        .input-group {
          margin-bottom: 20px;
        }
        input {
          width: 100%;
          padding: 12px 15px;
          background: rgba(255,255,255,0.1);
          border: 1px solid rgba(255,255,255,0.2);
          border-radius: 8px;
          color: #fff;
          font-size: 16px;
        }
        input:focus {
          outline: none;
          border-color: #00ff88;
        }
        button {
          width: 100%;
          padding: 12px;
          background: #00ff88;
          border: none;
          border-radius: 8px;
          font-size: 16px;
          font-weight: bold;
          cursor: pointer;
          transition: transform 0.3s;
        }
        button:hover:not(:disabled) {
          transform: scale(1.02);
        }
        button:disabled {
          opacity: 0.7;
          cursor: not-allowed;
        }
        .login-footer {
          text-align: center;
          margin-top: 20px;
          color: #666;
          font-size: 12px;
        }
        .dev {
          margin-top: 5px;
          color: #444;
        }
      `}</style>
    </div>
  )
}