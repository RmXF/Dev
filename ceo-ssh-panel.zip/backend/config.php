<?php
// ==============================================
// CEO SSH PANEL - CONFIGURACIÓN PRINCIPAL
// ==============================================

// Error Reporting
error_reporting(E_ALL);
ini_set('display_errors', 0);
ini_set('log_errors', 1);
ini_set('error_log', '/var/log/ceo-ssh-php.log');

// Timezone
date_default_timezone_set('America/Mexico_City');

// Database Configuration
define('DB_HOST', 'localhost');
define('DB_USER', 'ceo_ssh');
define('DB_PASS', '');
define('DB_NAME', 'ceo_ssh');

// Security Keys
define('JWT_SECRET', '');
define('ENCRYPTION_KEY', '');

// Panel Configuration
define('PANEL_NAME', 'CEO SSH');
define('PANEL_VERSION', '1.0.0');
define('PANEL_URL', 'http://localhost');

// API Configuration
define('API_PORT', 3001);
define('API_VERSION', 'v1');

// Session Configuration
define('SESSION_TIMEOUT', 3600);
define('MAX_LOGIN_ATTEMPTS', 5);
define('LOGIN_LOCKOUT_TIME', 900);

// SSH Configuration
define('SSH_BASE_PORT', 22);
define('DROPBEAR_PORT', 7300);
define('STUNNEL_PORT', 8000);
define('SQUID_PORT', 3128);

// Rate Limiting
define('RATE_LIMIT_WINDOW', 15 * 60);
define('RATE_LIMIT_MAX_REQUESTS', 100);

// Upload Configuration
define('MAX_UPLOAD_SIZE', 10 * 1024 * 1024);
define('ALLOWED_EXTENSIONS', ['zip', 'gz', 'conf']);

// Cache Configuration
define('CACHE_ENABLED', true);
define('CACHE_TTL', 300);

// Initialize Database Connection
function getDB() {
    static $conn = null;
    if ($conn === null) {
        try {
            $conn = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);
            if ($conn->connect_error) {
                throw new Exception("Connection failed: " . $conn->connect_error);
            }
            $conn->set_charset("utf8mb4");
        } catch (Exception $e) {
            error_log("Database connection error: " . $e->getMessage());
            return null;
        }
    }
    return $conn;
}

// Helper Functions
function isAjax() {
    return !empty($_SERVER['HTTP_X_REQUESTED_WITH']) && 
           strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest';
}

function jsonResponse($data, $status = 200) {
    http_response_code($status);
    header('Content-Type: application/json');
    echo json_encode($data);
    exit;
}

function errorResponse($message, $code = 400) {
    jsonResponse(['success' => false, 'error' => $message], $code);
}

function successResponse($data = null, $message = 'Success') {
    jsonResponse(['success' => true, 'message' => $message, 'data' => $data]);
}

// Start Session if not started
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// CORS Headers
header('Access-Control-Allow-Origin: ' . PANEL_URL);
header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization, X-Requested-With');
header('Access-Control-Allow-Credentials: true');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}
?>