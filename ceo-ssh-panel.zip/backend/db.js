const mysql = require('mysql2/promise');
const dotenv = require('dotenv');

dotenv.config();

const pool = mysql.createPool({
  host: process.env.DB_HOST || 'localhost',
  user: process.env.DB_USER || 'ceo_ssh',
  password: process.env.DB_PASS || '',
  database: process.env.DB_NAME || 'ceo_ssh',
  waitForConnections: true,
  connectionLimit: 10,
  queueLimit: 0,
  enableKeepAlive: true,
  keepAliveInitialDelay: 0
});

// Test connection
async function testConnection() {
  try {
    const connection = await pool.getConnection();
    console.log('✅ Database connected successfully');
    connection.release();
    return true;
  } catch (error) {
    console.error('❌ Database connection failed:', error.message);
    return false;
  }
}

// Query helper
async function query(sql, params = []) {
  try {
    const [rows] = await pool.execute(sql, params);
    return rows;
  } catch (error) {
    console.error('Query error:', error);
    throw error;
  }
}

// Transaction helper
async function transaction(callback) {
  const connection = await pool.getConnection();
  await connection.beginTransaction();
  
  try {
    const result = await callback(connection);
    await connection.commit();
    return result;
  } catch (error) {
    await connection.rollback();
    throw error;
  } finally {
    connection.release();
  }
}

// User helpers
async function getUserByUsername(username) {
  const users = await query(
    'SELECT * FROM users WHERE username = ? LIMIT 1',
    [username]
  );
  return users[0] || null;
}

async function getUserById(id) {
  const users = await query(
    'SELECT id, username, email, role, status, created_at, last_login FROM users WHERE id = ?',
    [id]
  );
  return users[0] || null;
}

async function updateLastLogin(userId) {
  return await query(
    'UPDATE users SET last_login = NOW() WHERE id = ?',
    [userId]
  );
}

async function createUser(userData) {
  const { username, password, email, role = 'user' } = userData;
  return await query(
    'INSERT INTO users (username, password, email, role, status) VALUES (?, ?, ?, ?, "active")',
    [username, password, email, role]
  );
}

// SSH Token helpers
async function getSSHTokens(filters = {}) {
  let sql = 'SELECT * FROM ssh_tokens WHERE 1=1';
  const params = [];
  
  if (filters.status) {
    sql += ' AND status = ?';
    params.push(filters.status);
  }
  
  if (filters.username) {
    sql += ' AND username LIKE ?';
    params.push(`%${filters.username}%`);
  }
  
  sql += ' ORDER BY created_at DESC';
  
  return await query(sql, params);
}

async function createSSHToken(tokenData) {
  const { username, password, expires_at, created_by } = tokenData;
  return await query(
    'INSERT INTO ssh_tokens (username, password, expires_at, created_by, status) VALUES (?, ?, ?, ?, "active")',
    [username, password, expires_at, created_by]
  );
}

async function updateSSHToken(id, updates) {
  const fields = [];
  const values = [];
  
  if (updates.expires_at) {
    fields.push('expires_at = ?');
    values.push(updates.expires_at);
  }
  
  if (updates.status) {
    fields.push('status = ?');
    values.push(updates.status);
  }
  
  if (updates.traffic_limit) {
    fields.push('traffic_limit = ?');
    values.push(updates.traffic_limit);
  }
  
  if (fields.length === 0) return null;
  
  values.push(id);
  return await query(
    `UPDATE ssh_tokens SET ${fields.join(', ')} WHERE id = ?`,
    values
  );
}

async function deleteSSHToken(id) {
  return await query('DELETE FROM ssh_tokens WHERE id = ?', [id]);
}

// Log helpers
async function addLog(logData) {
  const { user_id, action, details, ip_address } = logData;
  return await query(
    'INSERT INTO logs (user_id, action, details, ip_address) VALUES (?, ?, ?, ?)',
    [user_id, action, details, ip_address]
  );
}

async function getLogs(limit = 100, offset = 0) {
  return await query(
    `SELECT l.*, u.username 
         FROM logs l 
         LEFT JOIN users u ON l.user_id = u.id 
         ORDER BY l.created_at DESC 
         LIMIT ? OFFSET ?`,
    [limit, offset]
  );
}

// Settings helpers
async function getSetting(key) {
  const settings = await query(
    'SELECT value FROM settings WHERE `key` = ? LIMIT 1',
    [key]
  );
  return settings[0] ? settings[0].value : null;
}

async function setSetting(key, value, description = '') {
  return await query(
    `INSERT INTO settings (\`key\`, \`value\`, description) 
         VALUES (?, ?, ?) 
         ON DUPLICATE KEY UPDATE 
         \`value\` = VALUES(\`value\`), 
         description = VALUES(description)`,
    [key, value, description]
  );
}

module.exports = {
  pool,
  query,
  transaction,
  testConnection,
  getUserByUsername,
  getUserById,
  updateLastLogin,
  createUser,
  getSSHTokens,
  createSSHToken,
  updateSSHToken,
  deleteSSHToken,
  addLog,
  getLogs,
  getSetting,
  setSetting
};