const express = require('express');
const cors = require('cors');
const helmet = require('helmet');
const compression = require('compression');
const dotenv = require('dotenv');
const { body, validationResult } = require('express-validator');
const bcrypt = require('bcryptjs');

dotenv.config();

const db = require('./db');
const auth = require('./middleware/auth');
const rateLimit = require('./middleware/rateLimit');

const app = express();
const PORT = process.env.API_PORT || 3001;

// Middleware
app.use(helmet({
    contentSecurityPolicy: false,
    crossOriginEmbedderPolicy: false
}));
app.use(compression());
app.use(cors({
    origin: true,
    credentials: true
}));
app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ extended: true, limit: '10mb' }));

// Request logging
app.use((req, res, next) => {
    console.log(`[${new Date().toISOString()}] ${req.method} ${req.path}`);
    next();
});

// Health check endpoint
app.get('/health', (req, res) => {
    res.json({
        status: 'healthy',
        timestamp: new Date().toISOString(),
        version: '1.0.0'
    });
});

// Stats endpoint (no auth required for basic stats)
app.get('/api/stats', auth.optionalAuth, async (req, res) => {
    try {
        // Get system stats
        const { exec } = require('child_process');
        const util = require('util');
        const execPromise = util.promisify(exec);
        
        // Get total users
        const totalUsersResult = await db.query('SELECT COUNT(*) as count FROM users');
        const totalUsers = totalUsersResult[0].count;
        
        // Get active SSH tokens
        const activeTokens = await db.query(
            "SELECT COUNT(*) as count FROM ssh_tokens WHERE status = 'active' AND expires_at > NOW()"
        );
        
        // Get expired tokens
        const expiredTokens = await db.query(
            "SELECT COUNT(*) as count FROM ssh_tokens WHERE expires_at <= NOW() OR status = 'expired'"
        );
        
        // Get online users from system
        let onlineUsers = 0;
        try {
            const { stdout } = await execPromise("ps aux | grep -E 'sshd|dropbear' | grep -v grep | wc -l");
            onlineUsers = parseInt(stdout.trim()) || 0;
        } catch (e) {
            onlineUsers = 0;
        }
        
        // Get server load
        let serverLoad = 0;
        try {
            const { stdout } = await execPromise("uptime | awk -F'load average:' '{print $2}' | cut -d, -f1");
            serverLoad = parseFloat(stdout.trim()) || 0;
        } catch (e) {
            serverLoad = 0;
        }
        
        // Get disk usage
        let diskUsage = 0;
        try {
            const { stdout } = await execPromise("df -h / | awk 'NR==2 {print $5}' | sed 's/%//'");
            diskUsage = parseInt(stdout.trim()) || 0;
        } catch (e) {
            diskUsage = 0;
        }
        
        // Get memory usage
        let memoryUsage = 0;
        try {
            const { stdout } = await execPromise("free | grep Mem | awk '{print ($3/$2) * 100}'");
            memoryUsage = parseFloat(stdout.trim()) || 0;
        } catch (e) {
            memoryUsage = 0;
        }
        
        res.json({
            success: true,
            data: {
                total_users: totalUsers,
                active_tokens: activeTokens[0].count,
                expired_tokens: expiredTokens[0].count,
                online_users: onlineUsers,
                server_load: serverLoad,
                disk_usage: diskUsage,
                memory_usage: memoryUsage,
                timestamp: new Date().toISOString()
            }
        });
    } catch (error) {
        console.error('Stats error:', error);
        res.status(500).json({ success: false, error: error.message });
    }
});

// Login endpoint
app.post('/api/auth/login',
    rateLimit.loginLimiter,
    [
        body('username').notEmpty().trim().escape(),
        body('password').notEmpty()
    ],
    async (req, res) => {
        const errors = validationResult(req);
        if (!errors.isEmpty()) {
            return res.status(400).json({ 
                success: false, 
                errors: errors.array() 
            });
        }
        
        const { username, password } = req.body;
        
        try {
            const user = await db.getUserByUsername(username);
            
            if (!user) {
                return res.status(401).json({ 
                    success: false, 
                    error: 'Invalid credentials' 
                });
            }
            
            if (user.status !== 'active') {
                return res.status(401).json({ 
                    success: false, 
                    error: 'Account is not active' 
                });
            }
            
            const validPassword = await bcrypt.compare(password, user.password);
            
            if (!validPassword) {
                // Log failed attempt
                await db.addLog({
                    user_id: user.id,
                    action: 'login_failed',
                    details: 'Invalid password',
                    ip_address: req.ip
                });
                return res.status(401).json({ 
                    success: false, 
                    error: 'Invalid credentials' 
                });
            }
            
            // Update last login
            await db.updateLastLogin(user.id);
            
            // Generate token
            const token = auth.generateToken(user);
            
            // Log successful login
            await db.addLog({
                user_id: user.id,
                action: 'login',
                details: 'Successful login',
                ip_address: req.ip
            });
            
            res.json({
                success: true,
                data: {
                    token,
                    user: {
                        id: user.id,
                        username: user.username,
                        email: user.email,
                        role: user.role
                    }
                }
            });
        } catch (error) {
            console.error('Login error:', error);
            res.status(500).json({ success: false, error: 'Internal server error' });
        }
    }
);

// Verify token endpoint
app.get('/api/auth/verify', auth.authenticate, async (req, res) => {
    res.json({
        success: true,
        data: {
            user: req.user,
            valid: true
        }
    });
});

// Logout endpoint
app.post('/api/auth/logout', auth.authenticate, async (req, res) => {
    try {
        await db.addLog({
            user_id: req.user.id,
            action: 'logout',
            details: 'User logged out',
            ip_address: req.ip
        });
        
        res.json({ success: true, message: 'Logged out successfully' });
    } catch (error) {
        res.status(500).json({ success: false, error: error.message });
    }
});

// Get all users (admin only)
app.get('/api/users', auth.authenticate, auth.requireAdmin, async (req, res) => {
    try {
        const users = await db.query(
            'SELECT id, username, email, role, status, created_at, last_login FROM users'
        );
        res.json({ success: true, data: users });
    } catch (error) {
        res.status(500).json({ success: false, error: error.message });
    }
});

// Create user (admin only)
app.post('/api/users',
    auth.authenticate,
    auth.requireAdmin,
    rateLimit.createUserLimiter,
    [
        body('username').notEmpty().trim().escape().isLength({ min: 3, max: 50 }),
        body('email').optional().isEmail(),
        body('password').notEmpty().isLength({ min: 6 }),
        body('role').optional().isIn(['admin', 'user'])
    ],
    async (req, res) => {
        const errors = validationResult(req);
        if (!errors.isEmpty()) {
            return res.status(400).json({ success: false, errors: errors.array() });
        }
        
        const { username, email, password, role = 'user' } = req.body;
        
        try {
            const hashedPassword = await bcrypt.hash(password, 10);
            await db.createUser({
                username,
                password: hashedPassword,
                email,
                role
            });
            
            await db.addLog({
                user_id: req.user.id,
                action: 'create_user',
                details: `Created user: ${username}`,
                ip_address: req.ip
            });
            
            res.json({ success: true, message: 'User created successfully' });
        } catch (error) {
            if (error.code === 'ER_DUP_ENTRY') {
                res.status(400).json({ success: false, error: 'Username already exists' });
            } else {
                res.status(500).json({ success: false, error: error.message });
            }
        }
    }
);

// Delete user (admin only)
app.delete('/api/users/:id', auth.authenticate, auth.requireAdmin, async (req, res) => {
    const { id } = req.params;
    
    try {
        const user = await db.getUserById(id);
        if (!user) {
            return res.status(404).json({ success: false, error: 'User not found' });
        }
        
        await db.query('DELETE FROM users WHERE id = ?', [id]);
        
        await db.addLog({
            user_id: req.user.id,
            action: 'delete_user',
            details: `Deleted user: ${user.username}`,
            ip_address: req.ip
        });
        
        res.json({ success: true, message: 'User deleted successfully' });
    } catch (error) {
        res.status(500).json({ success: false, error: error.message });
    }
});

// Get SSH tokens
app.get('/api/ssh-tokens', auth.authenticate, async (req, res) => {
    try {
        const tokens = await db.getSSHTokens(req.query);
        res.json({ success: true, data: tokens });
    } catch (error) {
        res.status(500).json({ success: false, error: error.message });
    }
});

// Create SSH token
app.post('/api/ssh-tokens',
    auth.authenticate,
    [
        body('username').notEmpty().trim().escape().isLength({ min: 3, max: 50 }),
        body('password').notEmpty().isLength({ min: 6 }),
        body('expires_at').optional().isDate()
    ],
    async (req, res) => {
        const errors = validationResult(req);
        if (!errors.isEmpty()) {
            return res.status(400).json({ success: false, errors: errors.array() });
        }
        
        const { username, password, expires_at } = req.body;
        
        try {
            // Check if user exists in system
            const { exec } = require('child_process');
            const util = require('util');
            const execPromise = util.promisify(exec);
            
            // Create system user
            const expireDate = expires_at || new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString().split('T')[0];
            
            await execPromise(`useradd -m -s /bin/false -e ${expireDate} ${username}`);
            await execPromise(`echo "${username}:${password}" | chpasswd`);
            
            // Save to database
            await db.createSSHToken({
                username,
                password,
                expires_at: expireDate,
                created_by: req.user.id
            });
            
            await db.addLog({
                user_id: req.user.id,
                action: 'create_ssh_token',
                details: `Created SSH token: ${username}`,
                ip_address: req.ip
            });
            
            res.json({ 
                success: true, 
                message: 'SSH token created successfully',
                data: { username, password, expires_at: expireDate }
            });
        } catch (error) {
            res.status(500).json({ success: false, error: error.message });
        }
    }
);

// Delete SSH token
app.delete('/api/ssh-tokens/:id', auth.authenticate, async (req, res) => {
    const { id } = req.params;
    
    try {
        const token = await db.query('SELECT * FROM ssh_tokens WHERE id = ?', [id]);
        if (token.length === 0) {
            return res.status(404).json({ success: false, error: 'Token not found' });
        }
        
        // Delete system user
        const { exec } = require('child_process');
        const util = require('util');
        const execPromise = util.promisify(exec);
        
        await execPromise(`userdel -r -f ${token[0].username}`);
        
        await db.deleteSSHToken(id);
        
        await db.addLog({
            user_id: req.user.id,
            action: 'delete_ssh_token',
            details: `Deleted SSH token: ${token[0].username}`,
            ip_address: req.ip
        });
        
        res.json({ success: true, message: 'SSH token deleted successfully' });
    } catch (error) {
        res.status(500).json({ success: false, error: error.message });
    }
});

// Get logs
app.get('/api/logs', auth.authenticate, auth.requireAdmin, async (req, res) => {
    try {
        const limit = parseInt(req.query.limit) || 100;
        const offset = parseInt(req.query.offset) || 0;
        const logs = await db.getLogs(limit, offset);
        res.json({ success: true, data: logs });
    } catch (error) {
        res.status(500).json({ success: false, error: error.message });
    }
});

// Get settings
app.get('/api/settings', auth.authenticate, auth.requireAdmin, async (req, res) => {
    try {
        const settings = await db.query('SELECT * FROM settings');
        const settingsObj = {};
        settings.forEach(s => { settingsObj[s.key] = s.value; });
        res.json({ success: true, data: settingsObj });
    } catch (error) {
        res.status(500).json({ success: false, error: error.message });
    }
});

// Update settings
app.put('/api/settings', auth.authenticate, auth.requireAdmin, async (req, res) => {
    try {
        const updates = req.body;
        
        for (const [key, value] of Object.entries(updates)) {
            await db.setSetting(key, value);
        }
        
        await db.addLog({
            user_id: req.user.id,
            action: 'update_settings',
            details: 'Updated panel settings',
            ip_address: req.ip
        });
        
        res.json({ success: true, message: 'Settings updated successfully' });
    } catch (error) {
        res.status(500).json({ success: false, error: error.message });
    }
});

// Change password
app.post('/api/change-password',
    auth.authenticate,
    [
        body('current_password').notEmpty(),
        body('new_password').isLength({ min: 6 })
    ],
    async (req, res) => {
        const errors = validationResult(req);
        if (!errors.isEmpty()) {
            return res.status(400).json({ success: false, errors: errors.array() });
        }
        
        const { current_password, new_password } = req.body;
        
        try {
            const user = await db.getUserByUsername(req.user.username);
            const validPassword = await bcrypt.compare(current_password, user.password);
            
            if (!validPassword) {
                return res.status(401).json({ success: false, error: 'Current password is incorrect' });
            }
            
            const hashedPassword = await bcrypt.hash(new_password, 10);
            await db.query('UPDATE users SET password = ? WHERE id = ?', [hashedPassword, req.user.id]);
            
            await db.addLog({
                user_id: req.user.id,
                action: 'change_password',
                details: 'User changed password',
                ip_address: req.ip
            });
            
            res.json({ success: true, message: 'Password changed successfully' });
        } catch (error) {
            res.status(500).json({ success: false, error: error.message });
        }
    }
);

// Start server
async function startServer() {
    await db.testConnection();
    
    app.listen(PORT, () => {
        console.log(`🚀 CEO SSH API running on port ${PORT}`);
        console.log(`📊 Health check: http://localhost:${PORT}/health`);
    });
}

startServer().catch(console.error);