const WebSocket = require('ws');
const jwt = require('jsonwebtoken');
const { exec } = require('child_process');
const util = require('util');
const execPromise = util.promisify(exec);

const PORT = process.env.WS_PORT || 3002;
const JWT_SECRET = process.env.JWT_SECRET || 'your-super-secret-key-change-this';

const wss = new WebSocket.Server({ port: PORT });

// Store connected clients
const clients = new Map();

// Verify JWT token
function verifyToken(token) {
  try {
    return jwt.verify(token, JWT_SECRET);
  } catch (error) {
    return null;
  }
}

// Get system stats
async function getSystemStats() {
  try {
    const [loadAvg] = await Promise.all([
      execPromise("uptime | awk -F'load average:' '{print $2}'")
    ]);
    
    const onlineUsers = await execPromise("ps aux | grep -E 'sshd|dropbear' | grep -v grep | wc -l");
    const totalUsers = await execPromise("cat /etc/passwd | grep '/home' | wc -l");
    
    return {
      timestamp: new Date().toISOString(),
      load_average: loadAvg.stdout.trim(),
      online_users: parseInt(onlineUsers.stdout.trim()),
      total_users: parseInt(totalUsers.stdout.trim()),
      cpu_usage: Math.floor(Math.random() * 30) + 20, // Simulated, replace with real
      memory_usage: Math.floor(Math.random() * 40) + 30,
      disk_usage: Math.floor(Math.random() * 50) + 20
    };
  } catch (error) {
    console.error('Stats error:', error);
    return null;
  }
}

// Broadcast to all clients
function broadcast(data, excludeClient = null) {
  const message = JSON.stringify(data);
  clients.forEach((client, ws) => {
    if (ws !== excludeClient && ws.readyState === WebSocket.OPEN) {
      ws.send(message);
    }
  });
}

// Send stats to specific client
async function sendStats(ws) {
  const stats = await getSystemStats();
  if (stats && ws.readyState === WebSocket.OPEN) {
    ws.send(JSON.stringify({ type: 'stats', data: stats }));
  }
}

// Start stats interval
let statsInterval = null;

function startStatsBroadcast() {
  if (statsInterval) clearInterval(statsInterval);
  
  statsInterval = setInterval(async () => {
    const stats = await getSystemStats();
    if (stats) {
      broadcast({ type: 'stats', data: stats });
    }
  }, 5000); // Send every 5 seconds
}

// Handle new connections
wss.on('connection', (ws, req) => {
  console.log('New WebSocket connection');
  
  // Get token from query string
  const url = new URL(req.url, `http://${req.headers.host}`);
  const token = url.searchParams.get('token');
  
  if (!token) {
    ws.close(1008, 'No token provided');
    return;
  }
  
  const decoded = verifyToken(token);
  if (!decoded) {
    ws.close(1008, 'Invalid token');
    return;
  }
  
  // Store client
  clients.set(ws, {
    userId: decoded.id,
    username: decoded.username,
    connectedAt: new Date()
  });
  
  console.log(`Client ${decoded.username} connected`);
  
  // Send initial stats
  sendStats(ws);
  
  // Handle messages
  ws.on('message', async (message) => {
    try {
      const data = JSON.parse(message);
      
      switch (data.type) {
        case 'ping':
          ws.send(JSON.stringify({ type: 'pong', timestamp: new Date().toISOString() }));
          break;
          
        case 'get_stats':
          await sendStats(ws);
          break;
          
        case 'execute_command':
          // Only allow certain commands for security
          if (data.command && data.command.match(/^(ls|ps|uptime|df|free)/)) {
            try {
              const { stdout } = await execPromise(data.command);
              ws.send(JSON.stringify({
                type: 'command_result',
                command: data.command,
                output: stdout
              }));
            } catch (error) {
              ws.send(JSON.stringify({
                type: 'command_result',
                command: data.command,
                error: error.message
              }));
            }
          }
          break;
          
        default:
          console.log('Unknown message type:', data.type);
      }
    } catch (error) {
      console.error('Message parsing error:', error);
    }
  });
  
  // Handle disconnection
  ws.on('close', () => {
    const client = clients.get(ws);
    if (client) {
      console.log(`Client ${client.username} disconnected`);
    }
    clients.delete(ws);
  });
  
  // Handle errors
  ws.on('error', (error) => {
    console.error('WebSocket error:', error);
    clients.delete(ws);
  });
});

// Start stats broadcast when first client connects
let broadcastStarted = false;

const originalOnConnection = wss.on.bind(wss);
wss.on('connection', (...args) => {
  if (!broadcastStarted) {
    startStatsBroadcast();
    broadcastStarted = true;
  }
  originalOnConnection('connection', ...args);
});

console.log(`🔌 WebSocket server running on port ${PORT}`);

// Graceful shutdown
process.on('SIGTERM', () => {
  console.log('SIGTERM received, closing WebSocket server...');
  if (statsInterval) clearInterval(statsInterval);
  wss.close(() => {
    console.log('WebSocket server closed');
    process.exit(0);
  });
});