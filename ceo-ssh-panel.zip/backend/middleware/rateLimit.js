const rateLimit = require('express-rate-limit');

// General API rate limiter
const apiLimiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 minutes
  max: 100, // Limit each IP to 100 requests per windowMs
  message: {
    success: false,
    error: 'Too many requests, please try again later.'
  },
  standardHeaders: true,
  legacyHeaders: false,
});

// Login rate limiter (stricter)
const loginLimiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 minutes
  max: 5, // Limit each IP to 5 login requests per windowMs
  message: {
    success: false,
    error: 'Too many login attempts, please try again after 15 minutes.'
  },
  standardHeaders: true,
  legacyHeaders: false,
});

// Create user rate limiter
const createUserLimiter = rateLimit({
  windowMs: 60 * 60 * 1000, // 1 hour
  max: 50, // Limit each IP to 50 user creations per hour
  message: {
    success: false,
    error: 'User creation limit reached. Please try again later.'
  },
  standardHeaders: true,
  legacyHeaders: false,
});

// API key based rate limiter (for higher limits)
const apiKeyLimiter = (maxRequests = 1000) => rateLimit({
  windowMs: 60 * 60 * 1000, // 1 hour
  max: maxRequests,
  keyGenerator: (req) => req.headers['x-api-key'] || req.ip,
  message: {
    success: false,
    error: 'API rate limit exceeded.'
  },
  standardHeaders: true,
  legacyHeaders: false,
});

module.exports = {
  apiLimiter,
  loginLimiter,
  createUserLimiter,
  apiKeyLimiter
};