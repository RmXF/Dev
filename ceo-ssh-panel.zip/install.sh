#!/bin/bash
# Script de instalación interno del panel CEO SSH

set -e

GREEN='\033[0;32m'
RED='\033[0;31m'
YELLOW='\033[1;33m'
NC='\033[0m'

echo -e "${GREEN}========================================${NC}"
echo -e "${GREEN}   CEO SSH PANEL - INSTALACIÓN INTERNA   ${NC}"
echo -e "${GREEN}========================================${NC}"

# Variables
PANEL_DIR="/var/www/ceo-ssh"
API_DIR="/var/www/ceo-api"
ADMIN_USER=${1:-admin}
ADMIN_PASS=${2:-admin123}
API_PORT=${3:-8080}

echo -e "${YELLOW}📦 Instalando dependencias...${NC}"

# Crear directorios
mkdir -p $PANEL_DIR $API_DIR

# Copiar archivos del panel
cp -r panel/* $PANEL_DIR/
cp -r api/* $API_DIR/
cp -r data/* /var/lib/ceo-ssh/ 2>/dev/null || mkdir -p /var/lib/ceo-ssh

# Configurar credenciales
echo "$ADMIN_USER:$ADMIN_PASS" > /etc/ceo-ssh-auth
chmod 600 /etc/ceo-ssh-auth

# Crear .env.local
cat > $PANEL_DIR/.env.local << EOF
NEXT_PUBLIC_API_URL=http://localhost:$API_PORT
NEXT_PUBLIC_APP_NAME="CEO SSH VPN"
NEXT_PUBLIC_APP_VERSION="2.0.0"
EOF

# Instalar dependencias
cd $PANEL_DIR
npm install
npm run build

echo -e "${GREEN}✅ Instalación completada${NC}"