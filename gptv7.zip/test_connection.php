<?php
// test_connection.php - Probar la configuración
header('Content-Type: text/html; charset=utf-8');
?>
<!DOCTYPE html>
<html>
<head>
    <title>Test de Conexión VPS</title>
    <style>
        body { font-family: Arial; padding: 20px; background: #1a1a2e; color: #fff; }
        .test { background: #16213e; padding: 20px; margin: 10px 0; border-radius: 10px; }
        .success { color: #00b894; }
        .error { color: #d63031; }
        pre { background: #0f0f1f; padding: 10px; border-radius: 5px; }
    </style>
</head>
<body>
    <h1>🔍 Diagnóstico del Sistema VPS Panel</h1>
    
    <div class="test">
        <h2>📋 Información del Servidor</h2>
        <p><strong>PHP Version:</strong> <?php echo phpversion(); ?></p>
        <p><strong>Extensiones cargadas:</strong></p>
        <ul>
            <?php
            $extensions = get_loaded_extensions();
            sort($extensions);
            foreach ($extensions as $ext) {
                $color = in_array($ext, ['ssh2', 'json']) ? 'success' : '';
                echo "<li class='$color'>$ext</li>";
            }
            ?>
        </ul>
    </div>
    
    <div class="test">
        <h2>🔌 Extensión SSH2</h2>
        <?php
        if (function_exists('ssh2_connect')) {
            echo "<p class='success'>✅ SSH2 está instalado y funcionando</p>";
        } else {
            echo "<p class='error'>❌ SSH2 NO está instalado</p>";
            echo "<p>Para instalar SSH2 en Ubuntu/Debian:</p>";
            echo "<pre>sudo apt-get install libssh2-1-dev libssh2-1
sudo pecl install ssh2
echo 'extension=ssh2.so' | sudo tee /etc/php/8.1/cli/conf.d/20-ssh2.ini
sudo systemctl restart apache2</pre>";
        }
        ?>
    </div>
    
    <div class="test">
        <h2>📁 Permisos de archivos</h2>
        <?php
        $files = ['servers.json', 'connect.php', 'save_server.php'];
        foreach ($files as $file) {
            if (file_exists($file)) {
                echo "<p>✅ $file existe - Permisos: " . substr(sprintf('%o', fileperms($file)), -4) . "</p>";
            } else {
                if ($file === 'servers.json') {
                    file_put_contents($file, json_encode([]));
                    chmod($file, 0666);
                    echo "<p>✅ $file creado automáticamente</p>";
                } else {
                    echo "<p class='error'>❌ $file no encontrado</p>";
                }
            }
        }
        ?>
    </div>
    
    <div class="test">
        <h2>🌐 Probar conexión SSH manual</h2>
        <form method="POST">
            <input type="text" name="test_ip" placeholder="IP" required>
            <input type="number" name="test_port" placeholder="Puerto" value="22">
            <input type="text" name="test_user" placeholder="Usuario" required>
            <input type="password" name="test_pass" placeholder="Contraseña" required>
            <button type="submit">Probar Conexión</button>
        </form>
        
        <?php
        if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['test_ip'])) {
            $ip = $_POST['test_ip'];
            $port = intval($_POST['test_port']);
            $user = $_POST['test_user'];
            $pass = $_POST['test_pass'];
            
            echo "<h3>Resultado:</h3>";
            
            if (!function_exists('ssh2_connect')) {
                echo "<p class='error'>❌ SSH2 no está instalado</p>";
            } else {
                $conn = @ssh2_connect($ip, $port, ['timeout' => 5]);
                if (!$conn) {
                    echo "<p class='error'>❌ No se pudo conectar a $ip:$port</p>";
                } else {
                    echo "<p class='success'>✅ Conexión establecida</p>";
                    
                    if (@ssh2_auth_password($conn, $user, $pass)) {
                        echo "<p class='success'>✅ Autenticación exitosa</p>";
                        
                        // Probar comando
                        $stream = ssh2_exec($conn, 'hostname');
                        stream_set_blocking($stream, true);
                        $hostname = stream_get_contents($stream);
                        echo "<p>📌 Hostname: " . trim($hostname) . "</p>";
                        fclose($stream);
                        
                        ssh2_disconnect($conn);
                    } else {
                        echo "<p class='error'>❌ Error de autenticación</p>";
                    }
                }
            }
        }
        ?>
    </div>
</body>
</html>