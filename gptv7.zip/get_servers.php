<?php
// get_servers.php - Versión corregida
error_reporting(0);
ini_set('display_errors', 0);

header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET');
header('Access-Control-Allow-Headers: Content-Type');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

if ($_SERVER['REQUEST_METHOD'] !== 'GET') {
    echo json_encode(['success' => false, 'error' => 'Método no permitido']);
    exit();
}

$servers = [];
if (file_exists('servers.json')) {
    $content = file_get_contents('servers.json');
    $servers = json_decode($content, true);
    if (!is_array($servers)) $servers = [];
}

echo json_encode([
    'success' => true,
    'data' => $servers
]);
?>