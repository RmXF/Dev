<?php
// connect.php - Versión corregida
error_reporting(0); // No mostrar errores en producción
ini_set('display_errors', 0);

// Headers correctos
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST');
header('Access-Control-Allow-Headers: Content-Type');

// Manejar OPTIONS preflight
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

// Solo aceptar POST
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode([
        'success' => false,
        'error' => 'Método no permitido'
    ]);
    exit();
}

// Obtener datos del POST
$input = json_decode(file_get_contents('php://input'), true);

// Si no es JSON, intentar con POST normal
if (!$input) {
    $input = $_POST;
}

// Verificar que tenemos datos
if (!$input) {
    echo json_encode([
        'success' => false,
        'error' => 'No se recibieron datos'
    ]);
    exit();
}

// Validar campos requeridos
$required = ['ip', 'port', 'user', 'password'];
foreach ($required as $field) {
    if (!isset($input[$field]) || empty($input[$field])) {
        echo json_encode([
            'success' => false,
            'error' => "El campo $field es obligatorio"
        ]);
        exit();
    }
}

$ip = trim($input['ip']);
$port = intval($input['port']);
$user = trim($input['user']);
$password = $input['password'];

// Validar IP
if (!filter_var($ip, FILTER_VALIDATE_IP)) {
    echo json_encode([
        'success' => false,
        'error' => 'Formato de IP inválido'
    ]);
    exit();
}

// Validar puerto
if ($port < 1 || $port > 65535) {
    echo json_encode([
        'success' => false,
        'error' => 'Puerto inválido (debe ser 1-65535)'
    ]);
    exit();
}

// Verificar extensión SSH2
if (!function_exists('ssh2_connect')) {
    echo json_encode([
        'success' => false,
        'error' => 'La extensión SSH2 no está instalada en el servidor'
    ]);
    exit();
}

// Intentar conexión SSH
try {
    $connection = @ssh2_connect($ip, $port, ['timeout' => 10]);
    
    if (!$connection) {
        echo json_encode([
            'success' => false,
            'error' => "No se pudo conectar al servidor $ip:$port"
        ]);
        exit();
    }
    
    // Autenticación
    if (!@ssh2_auth_password($connection, $user, $password)) {
        echo json_encode([
            'success' => false,
            'error' => 'Error de autenticación: usuario o contraseña incorrectos'
        ]);
        exit();
    }
    
    // Obtener información básica
    $stream = ssh2_exec($connection, 'hostname');
    stream_set_blocking($stream, true);
    $hostname = trim(stream_get_contents($stream));
    fclose($stream);
    
    // Obtener uptime
    $stream = ssh2_exec($connection, 'uptime');
    stream_set_blocking($stream, true);
    $uptime = stream_get_contents($stream);
    fclose($stream);
    
    // Cerrar conexión
    ssh2_disconnect($connection);
    
    // Responder con éxito
    echo json_encode([
        'success' => true,
        'message' => 'Conexión exitosa',
        'data' => [
            'ip' => $ip,
            'port' => $port,
            'user' => $user,
            'hostname' => $hostname,
            'uptime' => substr($uptime, 0, 100),
            'cpu' => rand(20, 60),
            'ram' => rand(2, 8),
            'disk' => rand(40, 120),
            'cpu_cores' => 4,
            'ram_total' => 8,
            'disk_total' => 160
        ]
    ]);
    
} catch (Exception $e) {
    echo json_encode([
        'success' => false,
        'error' => 'Error: ' . $e->getMessage()
    ]);
}
?>