<?php
// test_debug.php - Diagnosticar problemas
error_reporting(E_ALL);
ini_set('display_errors', 1);

echo "<h1>🔍 Diagnóstico VPS Panel</h1>";

// Verificar PHP
echo "<h2>📋 Información PHP</h2>";
echo "<p>Versión PHP: " . phpversion() . "</p>";
echo "<p>Extensiones cargadas:</p><ul>";
foreach (get_loaded_extensions() as $ext) {
    echo "<li>" . $ext . (in_array($ext, ['ssh2', 'json']) ? " ✅" : "") . "</li>";
}
echo "</ul>";

// Verificar SSH2
echo "<h2>🔌 Extensión SSH2</h2>";
if (function_exists('ssh2_connect')) {
    echo "<p style='color:green'>✅ SSH2 está instalado</p>";
} else {
    echo "<p style='color:red'>❌ SSH2 NO está instalado</p>";
}

// Verificar archivos
echo "<h2>📁 Permisos de archivos</h2>";
$files = ['connect.php', 'save_server.php', 'get_servers.php', 'servers.json'];
foreach ($files as $file) {
    if (file_exists($file)) {
        echo "<p>✅ $file existe - Permisos: " . substr(sprintf('%o', fileperms($file)), -4) . "</p>";
    } else {
        echo "<p style='color:red'>❌ $file no encontrado</p>";
    }
}

// Verificar servers.json
if (!file_exists('servers.json')) {
    file_put_contents('servers.json', json_encode([]));
    chmod('servers.json', 0666);
    echo "<p>✅ servers.json creado automáticamente</p>";
}

// Probar conexión manual
if (isset($_POST['test'])) {
    echo "<h2>🔌 Prueba de conexión manual</h2>";
    $ip = $_POST['ip'];
    $port = $_POST['port'];
    $user = $_POST['user'];
    $pass = $_POST['pass'];
    
    echo "<p>Conectando a $ip:$port con usuario $user...</p>";
    
    $conn = @ssh2_connect($ip, $port, ['timeout' => 5]);
    if (!$conn) {
        echo "<p style='color:red'>❌ No se pudo conectar</p>";
    } else {
        echo "<p style='color:green'>✅ Conexión establecida</p>";
        if (@ssh2_auth_password($conn, $user, $pass)) {
            echo "<p style='color:green'>✅ Autenticación exitosa</p>";
            
            $stream = ssh2_exec($conn, 'hostname');
            stream_set_blocking($stream, true);
            $hostname = stream_get_contents($stream);
            echo "<p>Hostname: " . trim($hostname) . "</p>";
            fclose($stream);
            
            ssh2_disconnect($conn);
        } else {
            echo "<p style='color:red'>❌ Error de autenticación</p>";
        }
    }
}
?>

<h2>🧪 Probar conexión SSH manual</h2>
<form method="POST">
    <input type="hidden" name="test" value="1">
    <input type="text" name="ip" placeholder="IP" required><br>
    <input type="number" name="port" placeholder="Puerto" value="22" required><br>
    <input type="text" name="user" placeholder="Usuario" required><br>
    <input type="password" name="pass" placeholder="Contraseña" required><br>
    <button type="submit">Probar</button>
</form>