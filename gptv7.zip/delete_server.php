<?php
// delete_server.php - Eliminar servidor
require_once 'config.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['error' => 'Método no permitido']);
    exit();
}

$input = json_decode(file_get_contents('php://input'), true);

if (!isset($input['id'])) {
    echo json_encode(['success' => false, 'error' => 'ID requerido']);
    exit();
}

$serverId = $input['id'];

// Eliminar de JSON
$servers = [];
if (file_exists('servers.json')) {
    $servers = json_decode(file_get_contents('servers.json'), true) ?: [];
    $servers = array_filter($servers, function($s) use ($serverId) {
        return $s['id'] !== $serverId;
    });
    $servers = array_values($servers);
    file_put_contents('servers.json', json_encode($servers, JSON_PRETTY_PRINT));
}

// Opcional: Eliminar de MySQL
/*
try {
    $pdo = new PDO("mysql:host=".DB_HOST.";dbname=".DB_NAME, DB_USER, DB_PASS);
    $stmt = $pdo->prepare("DELETE FROM servers WHERE id = ?");
    $stmt->execute([$serverId]);
} catch (PDOException $e) {
    echo json_encode(['success' => false, 'error' => 'Error de base de datos']);
    exit();
}
*/

echo json_encode([
    'success' => true,
    'message' => 'Servidor eliminado'
]);
?>