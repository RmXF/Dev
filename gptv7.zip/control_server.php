<?php
// control_server.php - Controlar servidor (iniciar/detener/reiniciar)
require_once 'config.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['error' => 'Método no permitido']);
    exit();
}

$input = json_decode(file_get_contents('php://input'), true);

if (!isset($input['id']) || !isset($input['action'])) {
    echo json_encode(['success' => false, 'error' => 'ID y acción requeridos']);
    exit();
}

$serverId = $input['id'];
$action = $input['action'];

// Obtener servidor
$servers = [];
if (file_exists('servers.json')) {
    $servers = json_decode(file_get_contents('servers.json'), true) ?: [];
    $server = null;
    
    foreach ($servers as &$s) {
        if ($s['id'] === $serverId) {
            $server = &$s;
            break;
        }
    }
    
    if (!$server) {
        echo json_encode(['success' => false, 'error' => 'Servidor no encontrado']);
        exit();
    }
    
    // Intentar conectar por SSH para ejecutar comando
    try {
        $connection = ssh2_connect($server['ip'], $server['port'], ['timeout' => 5]);
        
        if (!$connection) {
            throw new Exception('No se pudo conectar al servidor');
        }
        
        // Decrypt password (en producción usar método seguro)
        $password = $server['password'] === '****' ? '' : base64_decode($server['password']);
        
        if (!ssh2_auth_password($connection, $server['user'], $password)) {
            throw new Exception('Error de autenticación');
        }
        
        // Ejecutar comando según acción
        switch ($action) {
            case 'restart':
                $cmd = 'sudo shutdown -r now';
                $message = 'Servidor reiniciándose...';
                break;
            case 'shutdown':
                $cmd = 'sudo shutdown -h now';
                $message = 'Servidor apagándose...';
                break;
            default:
                throw new Exception('Acción no válida');
        }
        
        $stream = ssh2_exec($connection, $cmd);
        stream_set_blocking($stream, true);
        $output = stream_get_contents($stream);
        fclose($stream);
        
        ssh2_disconnect($connection);
        
        // Actualizar estado en JSON
        if ($action === 'restart' || $action === 'shutdown') {
            $server['status'] = 'stopped';
            $server['last_checked'] = date('Y-m-d H:i:s');
            file_put_contents('servers.json', json_encode($servers, JSON_PRETTY_PRINT));
        }
        
        echo json_encode([
            'success' => true,
            'message' => $message,
            'output' => $output
        ]);
        
    } catch (Exception $e) {
        echo json_encode([
            'success' => false,
            'error' => $e->getMessage()
        ]);
    }
}
?>