import '../styles/globals.css'
import { Toaster } from 'react-hot-toast'
import { useState, useEffect } from 'react'
import { useRouter } from 'next/router'

function MyApp({ Component, pageProps }) {
  const router = useRouter()
  const [isAuthenticated, setIsAuthenticated] = useState(false)
  const [loading, setLoading] = useState(true)
  
  useEffect(() => {
    const checkAuth = () => {
      const auth = localStorage.getItem('panel_auth')
      if (!auth && router.pathname !== '/login') {
        router.push('/login')
      } else if (auth && router.pathname === '/login') {
        router.push('/')
      }
      setLoading(false)
    }
    
    checkAuth()
  }, [router.pathname])
  
  if (loading) {
    return (
      <div className="loading-container">
        <div className="loading-spinner"></div>
        <p>Cargando panel...</p>
      </div>
    )
  }
  
  return (
    <>
      <Component {...pageProps} />
      <Toaster 
        position="top-right"
        toastOptions={{
          style: {
            background: '#1a1a2e',
            color: '#fff',
            border: '1px solid #00ff88'
          }
        }}
      />
    </>
  )
}

export default MyApp