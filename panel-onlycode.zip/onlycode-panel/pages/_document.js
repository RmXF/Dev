import { Html, Head, Main, NextScript } from 'next/document'

export default function Document() {
  return (
    <Html lang="es">
      <Head>
        <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet" />
        <meta name="description" content="Onlycode VPN - Panel de Administración Profesional" />
      </Head>
      <body>
        <Main />
        <NextScript />
      </body>
    </Html>
  )
}