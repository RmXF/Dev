import { useState } from 'react'
import { useRouter } from 'next/router'
import toast from 'react-hot-toast'
import { FiKey, FiUser, FiShield, FiLock } from 'react-icons/fi'

export default function Login() {
  const [username, setUsername] = useState('')
  const [password, setPassword] = useState('')
  const [loading, setLoading] = useState(false)
  const router = useRouter()
  
  const handleLogin = async (e) => {
    e.preventDefault()
    setLoading(true)
    
    // Simular autenticación - En producción, esto llamaría a la API
    if (username && password) {
      // Guardar credenciales para usar con la API
      localStorage.setItem('panel_auth', btoa(`${username}:${password}`))
      localStorage.setItem('panel_user', username)
      toast.success('¡Bienvenido al panel!')
      router.push('/')
    } else {
      toast.error('Ingrese usuario y contraseña')
    }
    setLoading(false)
  }
  
  return (
    <div className="login-container">
      <div className="login-card">
        <div className="login-header">
          <div className="logo">
            <FiShield size={48} color="#00ff88" />
          </div>
          <h1>Onlycode VPN</h1>
          <p>Panel de Administración Profesional</p>
        </div>

        <form onSubmit={handleLogin} className="login-form">
          <div className="input-group">
            <FiUser className="input-icon" />
            <input
              type="text"
              placeholder="Usuario"
              value={username}
              onChange={(e) => setUsername(e.target.value)}
              required
            />
          </div>

          <div className="input-group">
            <FiLock className="input-icon" />
            <input
              type="password"
              placeholder="Contraseña"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              required
            />
          </div>

          <button type="submit" disabled={loading} className="login-btn">
            {loading ? 'Ingresando...' : 'Acceder al Panel'}
          </button>
        </form>

        <div className="login-footer">
          <p>© 2024 Onlycode VPN - Todos los derechos reservados</p>
        </div>
      </div>
    </div>
  )
}