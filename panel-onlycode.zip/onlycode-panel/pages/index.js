import { useState, useEffect } from 'react'
import Layout from '../components/Layout'
import StatCard from '../components/StatCard'
import UserTable from '../components/UserTable'
import UserModal from '../components/UserModal'
import ConnectionChart from '../components/ConnectionChart'
import toast from 'react-hot-toast'
import {
  FiUsers,
  FiWifi,
  FiHardDrive,
  FiCpu,
  FiTrendingUp,
  FiActivity
} from 'react-icons/fi'

export default function Dashboard() {
  const [users, setUsers] = useState([])
  const [stats, setStats] = useState({})
  const [loading, setLoading] = useState(true)
  const [showModal, setShowModal] = useState(false)
  const [editingUser, setEditingUser] = useState(null)
  
  const API_URL = typeof window !== 'undefined' ?
    `${window.location.protocol}//${window.location.hostname}:8080` :
    'http://localhost:8080'
  
  const getAuth = () => {
    const auth = localStorage.getItem('panel_auth')
    return auth || ''
  }
  
  const fetchData = async () => {
    try {
      const auth = getAuth()
      const [usersRes, statsRes] = await Promise.all([
        fetch(`${API_URL}/users`, {
          headers: { 'Authorization': `Basic ${auth}` }
        }),
        fetch(`${API_URL}/stats`, {
          headers: { 'Authorization': `Basic ${auth}` }
        })
      ])
      
      if (usersRes.status === 401 || statsRes.status === 401) {
        localStorage.removeItem('panel_auth')
        window.location.href = '/login'
        return
      }
      
      if (usersRes.ok) {
        const usersData = await usersRes.json()
        setUsers(usersData)
      }
      
      if (statsRes.ok) {
        const statsData = await statsRes.json()
        setStats(statsData)
      }
    } catch (error) {
      toast.error('Error al cargar datos')
    } finally {
      setLoading(false)
    }
  }
  
  useEffect(() => {
    fetchData()
    const interval = setInterval(fetchData, 30000)
    return () => clearInterval(interval)
  }, [])
  
  const handleCreateUser = async (userData) => {
    try {
      const auth = getAuth()
      const res = await fetch(`${API_URL}/users`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Basic ${auth}`
        },
        body: JSON.stringify(userData)
      })
      
      const data = await res.json()
      if (data.error) {
        toast.error(data.error)
      } else {
        toast.success(`Usuario ${data.username} creado exitosamente! Contraseña: ${data.password}`)
        setShowModal(false)
        fetchData()
      }
    } catch (error) {
      toast.error('Error al crear usuario')
    }
  }
  
  const handleDeleteUser = async (username) => {
    if (confirm(`¿Estás seguro de eliminar al usuario ${username}?`)) {
      try {
        const auth = getAuth()
        const res = await fetch(`${API_URL}/users/${username}`, {
          method: 'DELETE',
          headers: { 'Authorization': `Basic ${auth}` }
        })
        
        if (res.ok) {
          toast.success('Usuario eliminado')
          fetchData()
        } else {
          toast.error('Error al eliminar')
        }
      } catch (error) {
        toast.error('Error al eliminar')
      }
    }
  }
  
  const handleExtendUser = async (username, days) => {
    try {
      const auth = getAuth()
      const res = await fetch(`${API_URL}/users/${username}`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Basic ${auth}`
        },
        body: JSON.stringify({ days: parseInt(days) })
      })
      
      if (res.ok) {
        toast.success(`Usuario extendido por ${days} días`)
        fetchData()
      } else {
        toast.error('Error al extender')
      }
    } catch (error) {
      toast.error('Error al extender')
    }
  }
  
  const handleUpdateLimit = async (username, maxConnections) => {
    try {
      const auth = getAuth()
      const res = await fetch(`${API_URL}/users/${username}`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Basic ${auth}`
        },
        body: JSON.stringify({ max_connections: parseInt(maxConnections) })
      })
      
      if (res.ok) {
        toast.success(`Límite actualizado a ${maxConnections} conexiones`)
        fetchData()
      } else {
        toast.error('Error al actualizar límite')
      }
    } catch (error) {
      toast.error('Error al actualizar límite')
    }
  }
  
  const statCards = [
    { title: 'Usuarios Totales', value: stats.total_users || 0, icon: FiUsers, color: '#00ff88' },
    { title: 'Usuarios Online', value: stats.online_users || 0, icon: FiWifi, color: '#00aaff' },
    { title: 'Carga del Servidor', value: `${stats.server_load || 0}`, icon: FiCpu, color: '#ffaa00' },
    { title: 'Uso de Disco', value: `${stats.disk_usage || 0}%`, icon: FiHardDrive, color: '#ff44ff' },
  ]
  
  if (loading) {
    return (
      <Layout>
        <div className="loading-container">
          <div className="loading-spinner"></div>
          <p>Cargando dashboard...</p>
        </div>
      </Layout>
    )
  }
  
  return (
    <Layout>
      <div className="dashboard">
        <div className="dashboard-header">
          <div>
            <h1>Dashboard</h1>
            <p>Bienvenido de vuelta, {localStorage.getItem('panel_user') || 'Admin'}</p>
          </div>
          <button className="btn-primary" onClick={() => setShowModal(true)}>
            <FiTrendingUp /> Crear Usuario
          </button>
        </div>

        <div className="stats-grid">
          {statCards.map((stat, index) => (
            <StatCard key={index} {...stat} />
          ))}
        </div>

        <div className="chart-section">
          <ConnectionChart users={users} />
        </div>

        <div className="users-section">
          <div className="section-header">
            <h2><FiActivity /> Gestión de Usuarios</h2>
            <p>Administra todos los usuarios VPN desde aquí</p>
          </div>
          <UserTable 
            users={users}
            onDelete={handleDeleteUser}
            onExtend={handleExtendUser}
            onUpdateLimit={handleUpdateLimit}
          />
        </div>
      </div>

      <UserModal 
        isOpen={showModal}
        onClose={() => setShowModal(false)}
        onSubmit={handleCreateUser}
      />
    </Layout>
  )
}