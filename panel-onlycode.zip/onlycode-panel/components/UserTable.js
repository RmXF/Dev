import { useState } from 'react'
import { FiEdit2, FiTrash2, FiClock, FiTrendingUp, FiAlertCircle } from 'react-icons/fi'

export default function UserTable({ users, onDelete, onExtend, onUpdateLimit }) {
  const [extendUser, setExtendUser] = useState(null)
  const [extendDays, setExtendDays] = useState(30)
  const [limitUser, setLimitUser] = useState(null)
  const [limitValue, setLimitValue] = useState(1)
  
  const handleExtend = (username) => {
    onExtend(username, extendDays)
    setExtendUser(null)
    setExtendDays(30)
  }
  
  const handleUpdateLimit = (username) => {
    onUpdateLimit(username, limitValue)
    setLimitUser(null)
    setLimitValue(1)
  }
  
  const getStatusBadge = (status, expiration) => {
    if (status === 'active') {
      const daysLeft = Math.ceil((new Date(expiration) - new Date()) / (1000 * 60 * 60 * 24))
      if (daysLeft <= 3 && daysLeft > 0) {
        return <span className="badge warning">⚠️ Próximo a vencer ({daysLeft} días)</span>
      }
      return <span className="badge success">🟢 Activo</span>
    }
    return <span className="badge danger">🔴 Expirado</span>
  }
  
  return (
    <div className="user-table-container">
      <table className="user-table">
        <thead>
          <tr>
            <th>Usuario</th>
            <th>Expiración</th>
            <th>Estado</th>
            <th>Conexiones</th>
            <th>Límite</th>
            <th>Acciones</th>
          </tr>
        </thead>
        <tbody>
          {users.map((user) => (
            <tr key={user.username}>
              <td>
                <strong>{user.username}</strong>
                {user.limit_reached && (
                  <span className="limit-warning" title="Límite de conexiones alcanzado">
                    <FiAlertCircle size={14} />
                  </span>
                )}
              </td>
              <td>{user.expiration !== 'never' ? new Date(user.expiration).toLocaleDateString() : 'Nunca'}</td>
              <td>{getStatusBadge(user.status, user.expiration)}</td>
              <td>
                <span className={`connections ${user.limit_reached ? 'warning' : ''}`}>
                  {user.active_connections || 0}/{user.max_connections || 1}
                </span>
              </td>
              <td>
                <div className="limit-control">
                  <span>{user.max_connections || 1}</span>
                  <button 
                    className="icon-btn small"
                    onClick={() => {
                      setLimitUser(user.username)
                      setLimitValue(user.max_connections || 1)
                    }}
                  >
                    <FiTrendingUp size={14} />
                  </button>
                </div>
              </td>
              <td>
                <div className="action-buttons">
                  <button 
                    className="icon-btn extend"
                    onClick={() => setExtendUser(user.username)}
                    title="Extender expiración"
                  >
                    <FiClock size={18} />
                  </button>
                  <button 
                    className="icon-btn delete"
                    onClick={() => onDelete(user.username)}
                    title="Eliminar usuario"
                  >
                    <FiTrash2 size={18} />
                  </button>
                </div>
              </td>
            </tr>
          ))}
        </tbody>
      </table>

      {/* Modal Extender */}
      {extendUser && (
        <div className="modal-overlay" onClick={() => setExtendUser(null)}>
          <div className="modal" onClick={(e) => e.stopPropagation()}>
            <h3>Extender usuario: {extendUser}</h3>
            <div className="modal-body">
              <label>Días a agregar:</label>
              <select value={extendDays} onChange={(e) => setExtendDays(e.target.value)}>
                <option value="7">7 días</option>
                <option value="15">15 días</option>
                <option value="30">30 días</option>
                <option value="60">60 días</option>
                <option value="90">90 días</option>
                <option value="180">180 días</option>
                <option value="365">365 días</option>
              </select>
            </div>
            <div className="modal-footer">
              <button className="btn-secondary" onClick={() => setExtendUser(null)}>Cancelar</button>
              <button className="btn-primary" onClick={() => handleExtend(extendUser)}>Extender</button>
            </div>
          </div>
        </div>
      )}

      {/* Modal Límite */}
      {limitUser && (
        <div className="modal-overlay" onClick={() => setLimitUser(null)}>
          <div className="modal" onClick={(e) => e.stopPropagation()}>
            <h3>Límite de conexiones: {limitUser}</h3>
            <div className="modal-body">
              <label>Conexiones máximas:</label>
              <input 
                type="number" 
                min="1" 
                max="10"
                value={limitValue}
                onChange={(e) => setLimitValue(e.target.value)}
              />
            </div>
            <div className="modal-footer">
              <button className="btn-secondary" onClick={() => setLimitUser(null)}>Cancelar</button>
              <button className="btn-primary" onClick={() => handleUpdateLimit(limitUser)}>Guardar</button>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}