import { useState } from 'react'
import { useRouter } from 'next/router'
import {
  FiHome,
  FiUsers,
  FiSettings,
  FiLogOut,
  FiActivity,
  FiServer,
  FiMenu,
  FiX
} from 'react-icons/fi'

export default function Layout({ children }) {
  const [sidebarOpen, setSidebarOpen] = useState(true)
  const router = useRouter()
  
  const menuItems = [
    { name: 'Dashboard', icon: FiHome, path: '/' },
    { name: 'Usuarios', icon: FiUsers, path: '/users' },
    { name: 'Servidor', icon: FiServer, path: '/server' },
    { name: 'Actividad', icon: FiActivity, path: '/activity' },
    { name: 'Configuración', icon: FiSettings, path: '/settings' },
  ]
  
  const handleLogout = () => {
    localStorage.removeItem('panel_auth')
    localStorage.removeItem('panel_user')
    router.push('/login')
  }
  
  return (
    <div className="layout">
      <aside className={`sidebar ${sidebarOpen ? 'open' : 'closed'}`}>
        <div className="sidebar-header">
          <div className="logo">
            <FiServer size={32} color="#00ff88" />
            {sidebarOpen && <span>Onlycode VPN</span>}
          </div>
          <button className="toggle-btn" onClick={() => setSidebarOpen(!sidebarOpen)}>
            {sidebarOpen ? <FiX /> : <FiMenu />}
          </button>
        </div>

        <nav className="sidebar-nav">
          {menuItems.map((item) => (
            <a
              key={item.path}
              href={item.path}
              className={`nav-item ${router.pathname === item.path ? 'active' : ''}`}
              onClick={(e) => {
                e.preventDefault()
                router.push(item.path)
              }}
            >
              <item.icon size={20} />
              {sidebarOpen && <span>{item.name}</span>}
            </a>
          ))}
        </nav>

        <div className="sidebar-footer">
          <button className="logout-btn" onClick={handleLogout}>
            <FiLogOut size={20} />
            {sidebarOpen && <span>Cerrar Sesión</span>}
          </button>
        </div>
      </aside>

      <main className={`main-content ${sidebarOpen ? 'sidebar-open' : 'sidebar-closed'}`}>
        <div className="content-wrapper">
          {children}
        </div>
      </main>
    </div>
  )
}