import { useState } from 'react'
import { FiX } from 'react-icons/fi'

export default function UserModal({ isOpen, onClose, onSubmit }) {
  const [formData, setFormData] = useState({
    username: '',
    password: '',
    days: 30,
    max_connections: 1
  })
  const [generatedPassword, setGeneratedPassword] = useState('')
  
  const generatePassword = () => {
    const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789'
    let password = ''
    for (let i = 0; i < 12; i++) {
      password += chars.charAt(Math.floor(Math.random() * chars.length))
    }
    setGeneratedPassword(password)
    setFormData({ ...formData, password })
  }
  
  const handleSubmit = (e) => {
    e.preventDefault()
    if (!formData.password) {
      generatePassword()
      setTimeout(() => onSubmit(formData), 100)
    } else {
      onSubmit(formData)
    }
  }
  
  if (!isOpen) return null
  
  return (
    <div className="modal-overlay" onClick={onClose}>
      <div className="modal large" onClick={(e) => e.stopPropagation()}>
        <div className="modal-header">
          <h2>Crear Nuevo Usuario</h2>
          <button className="close-btn" onClick={onClose}>
            <FiX size={24} />
          </button>
        </div>

        <form onSubmit={handleSubmit}>
          <div className="modal-body">
            <div className="form-group">
              <label>Nombre de usuario *</label>
              <input
                type="text"
                placeholder="ejemplo: usuario123"
                value={formData.username}
                onChange={(e) => setFormData({ ...formData, username: e.target.value })}
                required
              />
            </div>

            <div className="form-group">
              <label>Contraseña</label>
              <div className="password-field">
                <input
                  type="text"
                  placeholder="Dejar vacío para generar automática"
                  value={formData.password}
                  onChange={(e) => setFormData({ ...formData, password: e.target.value })}
                />
                <button type="button" className="btn-secondary" onClick={generatePassword}>
                  Generar
                </button>
              </div>
              {generatedPassword && (
                <small className="password-hint">Contraseña generada: <strong>{generatedPassword}</strong></small>
              )}
            </div>

            <div className="form-row">
              <div className="form-group">
                <label>Días de duración</label>
                <select
                  value={formData.days}
                  onChange={(e) => setFormData({ ...formData, days: parseInt(e.target.value) })}
                >
                  <option value="7">7 días</option>
                  <option value="15">15 días</option>
                  <option value="30">30 días</option>
                  <option value="60">60 días</option>
                  <option value="90">90 días</option>
                  <option value="180">180 días</option>
                  <option value="365">365 días</option>
                </select>
              </div>

              <div className="form-group">
                <label>Conexiones máximas</label>
                <select
                  value={formData.max_connections}
                  onChange={(e) => setFormData({ ...formData, max_connections: parseInt(e.target.value) })}
                >
                  <option value="1">1 conexión</option>
                  <option value="2">2 conexiones</option>
                  <option value="3">3 conexiones</option>
                  <option value="4">4 conexiones</option>
                  <option value="5">5 conexiones</option>
                </select>
              </div>
            </div>
          </div>

          <div className="modal-footer">
            <button type="button" className="btn-secondary" onClick={onClose}>
              Cancelar
            </button>
            <button type="submit" className="btn-primary">
              Crear Usuario
            </button>
          </div>
        </form>
      </div>
    </div>
  )
}