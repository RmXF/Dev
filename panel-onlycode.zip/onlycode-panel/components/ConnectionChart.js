import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Area, AreaChart } from 'recharts'

export default function ConnectionChart({ users }) {
  // Datos simulados - En producción vendrían de la API
  const data = [
    { time: '00:00', connections: 4 },
    { time: '04:00', connections: 3 },
    { time: '08:00', connections: 7 },
    { time: '12:00', connections: 12 },
    { time: '16:00', connections: 15 },
    { time: '20:00', connections: 18 },
    { time: '23:00', connections: 14 },
  ]
  
  const activeUsers = users.filter(u => u.status === 'active').length
  const onlineUsers = users.filter(u => u.active_connections > 0).length
  
  return (
    <div className="chart-container">
      <div className="chart-header">
        <div>
          <h3>Actividad en Tiempo Real</h3>
          <p>Conexiones activas en las últimas 24 horas</p>
        </div>
        <div className="chart-stats">
          <div className="chart-stat">
            <span className="dot active"></span>
            <span>Usuarios Activos: {activeUsers}</span>
          </div>
          <div className="chart-stat">
            <span className="dot online"></span>
            <span>Conectados: {onlineUsers}</span>
          </div>
        </div>
      </div>
      <ResponsiveContainer width="100%" height={300}>
        <AreaChart data={data}>
          <defs>
            <linearGradient id="colorConnections" x1="0" y1="0" x2="0" y2="1">
              <stop offset="5%" stopColor="#00ff88" stopOpacity={0.3}/>
              <stop offset="95%" stopColor="#00ff88" stopOpacity={0}/>
            </linearGradient>
          </defs>
          <CartesianGrid strokeDasharray="3 3" stroke="#333" />
          <XAxis dataKey="time" stroke="#888" />
          <YAxis stroke="#888" />
          <Tooltip 
            contentStyle={{ backgroundColor: '#1a1a2e', border: '1px solid #00ff88' }}
            labelStyle={{ color: '#fff' }}
          />
          <Area 
            type="monotone" 
            dataKey="connections" 
            stroke="#00ff88" 
            fillOpacity={1} 
            fill="url(#colorConnections)" 
          />
          <Line type="monotone" dataKey="connections" stroke="#00ff88" strokeWidth={2} dot={{ fill: '#00ff88' }} />
        </AreaChart>
      </ResponsiveContainer>
    </div>
  )
}