<?php
session_start();
include('config.php');
if(!isset($_SESSION['usuario'])){ header('Location: index.php'); exit(); }

function rrmdir($dir){
    if(!is_dir($dir)) return;
    $objects = scandir($dir);
    foreach($objects as $object){
        if($object=='.' || $object=='..') continue;
        $path = $dir . DIRECTORY_SEPARATOR . $object;
        if(is_dir($path)) rrmdir($path); else unlink($path);
    }
    rmdir($dir);
}

$message = '';
if($_SERVER['REQUEST_METHOD'] === 'POST' && !empty($_POST['url'])){
    $url = $_POST['url'];
    $tmp = sys_get_temp_dir() . DIRECTORY_SEPARATOR . 'panel_update.zip';
    // descargar
    $fp = @fopen($url, 'rb');
    if($fp){
        $out = @fopen($tmp, 'wb');
        if($out){
            while(!feof($fp)){
                fwrite($out, fread($fp, 8192));
            }
            fclose($out);
        }
        fclose($fp);
    } else {
        $message = 'No se pudo descargar el archivo. Verifique la URL.';
    }

    if(!$message && file_exists($tmp) && filesize($tmp) > 100){
        $zip = new ZipArchive();
        if($zip->open($tmp) === true){
            $extract_dir = sys_get_temp_dir() . DIRECTORY_SEPARATOR . 'panel_update_tmp';
            if(is_dir($extract_dir)) rrmdir($extract_dir);
            mkdir($extract_dir);
            $zip->extractTo($extract_dir);
            $zip->close();
            // Copiar archivos extraídos sobre el panel (cuidado: sobrescribe)
            $it = new RecursiveIteratorIterator(new RecursiveDirectoryIterator($extract_dir, RecursiveDirectoryIterator::SKIP_DOTS), RecursiveIteratorIterator::SELF_FIRST);
            foreach($it as $item){
                $dest = __DIR__ . DIRECTORY_SEPARATOR . $it->getSubPathName();
                if($item->isDir()){
                    if(!is_dir($dest)) mkdir($dest, 0755, true);
                } else {
                    copy($item->getPathname(), $dest);
                }
            }
            rrmdir($extract_dir);
            unlink($tmp);
            $message = 'Actualización completada. Archivos reemplazados.';
        } else {
            $message = 'El archivo no es un ZIP válido.';
        }
    } else {
        if(!$message) $message = 'Archivo ZIP inválido o demasiado pequeño.';
    }
}
?>
<!doctype html><html><head><meta charset="utf-8"><title>Actualizar</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="assets/custom.css" rel="stylesheet"></head><body class="bg-light">
<div class="container py-4">
  <h3>Actualizar panel</h3>
  <?php if($message): ?><div class="alert alert-info"><?=htmlspecialchars($message)?></div><?php endif; ?>
  <form method="post">
    <div class="mb-3"><label>URL directa al ZIP</label><input class="form-control" type="url" name="url" placeholder="https://.../panel_v2.zip" required></div>
    <div class="d-grid"><button class="btn btn-success">Descargar y actualizar</button></div>
  </form>
  <a href="dashboard.php" class="btn btn-secondary mt-3">Volver</a>
</div>
</body></html>
