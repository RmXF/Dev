<?php
session_start();
include("config.php");
if(!isset($_SESSION['usuario'])){ header("Location: index.php"); exit(); }

$mensaje='';
if($_SERVER['REQUEST_METHOD']==='POST'){
    // guardar cambios simples: usuario y pass actuales en config.php
    $newuser = trim($_POST['usuario'] ?? '');
    $newpass = trim($_POST['contrasena'] ?? '');
    if($newuser && $newpass){
        $cfg = '<?php\n$usuario_panel = "'.addslashes($newuser).'";\n$contrasena_panel = "'.addslashes($newpass).'";\n$panel_dir = __DIR__;\n?>';
        file_put_contents(__DIR__.'/config.php', $cfg);
        $mensaje='Credenciales actualizadas';
    } else { $mensaje='Complete los campos'; }
}
?>
<!doctype html><html><head><meta charset="utf-8"><title>Configuración</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="assets/custom.css" rel="stylesheet"></head><body class="bg-light">
<div class="container py-4">
  <h3>Configuración</h3>
  <?php if($mensaje): ?><div class="alert alert-info"><?=htmlspecialchars($mensaje)?></div><?php endif; ?>
  <form method="post">
    <div class="mb-3"><label>Usuario</label><input class="form-control" name="usuario" value="<?=htmlspecialchars($usuario_panel)?>"></div>
    <div class="mb-3"><label>Contraseña</label><input class="form-control" name="contrasena" value="<?=htmlspecialchars($contrasena_panel)?>"></div>
    <div class="d-grid"><button class="btn btn-primary">Guardar</button></div>
  </form>
  <a href="dashboard.php" class="btn btn-secondary mt-3">Volver</a>
</div>
</body></html>
