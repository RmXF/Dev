document.addEventListener('DOMContentLoaded', function(){
  function updateClock(){
    var el = document.getElementById('clock');
    if(el){
      var d = new Date();
      el.textContent = d.toLocaleString();
    }
  }
  updateClock();
  setInterval(updateClock, 1000);

  var btn = document.getElementById('themeToggle');
  btn && btn.addEventListener('click', function(){
    document.body.classList.toggle('bg-dark');
    document.body.classList.toggle('bg-light');
    var dark = document.body.classList.contains('bg-dark');
    btn.textContent = dark ? 'Modo claro' : 'Modo oscuro';
  });
});
