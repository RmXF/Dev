<?php
// Configuración básica
$usuario_panel = "admin";
$contrasena_panel = "1234";
$panel_dir = __DIR__;
?>
