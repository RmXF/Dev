<?php
// ==============================================
// CEO SSH PANEL - CENTRO DE NOTIFICACIONES
// Versión: 2.0.0
// ==============================================

require_once '../includes/config.php';
require_once '../includes/database.php';
require_once '../includes/functions.php';
require_once '../includes/auth.php';

requireLogin();

$message = '';
$error = '';

// Marcar notificación como leída
if (isset($_GET['mark_read'])) {
    $id = intval($_GET['mark_read']);
    markNotificationAsRead($id, $_SESSION['user_id']);
    header('Location: notifications.php');
    exit;
}

// Marcar todas como leídas
if (isset($_GET['mark_all_read'])) {
    markAllNotificationsAsRead($_SESSION['user_id']);
    header('Location: notifications.php');
    exit;
}

// Eliminar notificación
if (isset($_GET['delete']) && isAdmin()) {
    $id = intval($_GET['delete']);
    deleteNotification($id, $_SESSION['user_id']);
    header('Location: notifications.php');
    exit;
}

// Crear notificación (solo admin)
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'create' && isAdmin()) {
    $userId = intval($_POST['user_id']);
    $title = trim($_POST['title']);
    $message = trim($_POST['message']);
    $type = $_POST['type'];
    
    if (empty($title) || empty($message)) {
        $error = 'Título y mensaje son requeridos';
    } else {
        addNotification($userId, $title, $message, $type);
        $message = 'Notificación enviada exitosamente';
        addLog($_SESSION['user_id'], 'create_notification', "Envió notificación a usuario ID: $userId", getClientIP(), getUserAgent());
    }
}

// Obtener notificaciones
$notifications = getNotifications($_SESSION['user_id'], 100);
$unreadCount = getUnreadCount($_SESSION['user_id']);

// Obtener usuarios para el select (solo admin)
$users = [];
if (isAdmin()) {
    $users = getAllUsers(1000, 0);
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Notificaciones - CEO SSH Panel</title>
    <link rel="icon" href="../assets/img/favicon.ico">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="../assets/css/style.css">
    <link rel="stylesheet" href="../assets/css/responsive.css">
    <script src="../assets/js/app.js" defer></script>
</head>
<body>
    <div class="app-container">
        <!-- Sidebar -->
        <aside class="sidebar" id="sidebar">
            <div class="logo">
                <div class="logo-icon"><i class="fas fa-shield-alt"></i></div>
                <div class="logo-text">CEO SSH</div>
            </div>
            
            <nav class="sidebar-nav">
                <div class="nav-section">
                    <div class="nav-label">Principal</div>
                    <a href="dashboard.php" class="sidebar-link"><i class="fas fa-tachometer-alt"></i><span>Dashboard</span></a>
                    <a href="users.php" class="sidebar-link"><i class="fas fa-users"></i><span>Usuarios</span></a>
                </div>
                
                <div class="nav-section">
                    <div class="nav-label">Configuración</div>
                    <a href="profile.php" class="sidebar-link"><i class="fas fa-user"></i><span>Mi Perfil</span></a>
                    <?php if (isAdmin()): ?>
                    <a href="settings.php" class="sidebar-link"><i class="fas fa-cog"></i><span>Configuración</span></a>
                    <a href="backups.php" class="sidebar-link"><i class="fas fa-database"></i><span>Backups</span></a>
                    <a href="logs.php" class="sidebar-link"><i class="fas fa-history"></i><span>Logs</span></a>
                    <?php endif; ?>
                    <a href="notifications.php" class="sidebar-link active"><i class="fas fa-bell"></i><span>Notificaciones</span></a>
                    <a href="help.php" class="sidebar-link"><i class="fas fa-question-circle"></i><span>Ayuda</span></a>
                </div>
            </nav>
            
            <div class="user-info">
                <div style="display: flex; align-items: center; gap: 12px;">
                    <div class="user-avatar"><?php echo strtoupper(substr($_SESSION['username'], 0, 1)); ?></div>
                    <div class="user-details">
                        <div class="user-name"><?php echo htmlspecialchars($_SESSION['username']); ?></div>
                        <div class="user-role"><?php echo isAdmin() ? 'Administrador' : 'Usuario'; ?></div>
                    </div>
                </div>
                <div style="margin-top: 12px;">
                    <a href="../api/auth.php?action=logout" class="btn btn-secondary btn-sm" style="width: 100%;"><i class="fas fa-sign-out-alt"></i> Cerrar Sesión</a>
                </div>
            </div>
        </aside>
        
        <!-- Main Content -->
        <main class="main-content" id="mainContent">
            <header class="header">
                <div class="header-left">
                    <button class="toggle-sidebar" onclick="toggleSidebar()"><i class="fas fa-bars"></i></button>
                    <div class="page-title">
                        <h1>Centro de Notificaciones</h1>
                        <p>Gestiona tus notificaciones</p>
                    </div>
                </div>
                
                <div class="header-right">
                    <button class="theme-toggle" onclick="toggleTheme()"><i class="fas fa-moon" id="themeIcon"></i></button>
                </div>
            </header>
            
            <div class="content">
                <!-- Mensajes -->
                <?php if ($message): ?>
                    <div class="alert alert-success" style="background: var(--success-bg); border: 1px solid var(--success); color: var(--success); padding: 12px 16px; border-radius: 12px; margin-bottom: 20px;">
                        <i class="fas fa-check-circle"></i> <?php echo $message; ?>
                    </div>
                <?php endif; ?>
                
                <?php if ($error): ?>
                    <div class="alert alert-error" style="background: var(--error-bg); border: 1px solid var(--error); color: var(--error); padding: 12px 16px; border-radius: 12px; margin-bottom: 20px;">
                        <i class="fas fa-exclamation-triangle"></i> <?php echo $error; ?>
                    </div>
                <?php endif; ?>
                
                <!-- Barra de acciones -->
                <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px; flex-wrap: wrap; gap: 10px;">
                    <div>
                        <h2 style="margin: 0;">Mis Notificaciones</h2>
                        <p class="text-muted" style="margin: 5px 0 0;">
                            <?php if ($unreadCount > 0): ?>
                                <span class="badge badge-info"><?php echo $unreadCount; ?> no leídas</span>
                            <?php else: ?>
                                Todas las notificaciones están leídas
                            <?php endif; ?>
                        </p>
                    </div>
                    
                    <div style="display: flex; gap: 10px;">
                        <?php if ($unreadCount > 0): ?>
                            <a href="?mark_all_read=1" class="btn btn-secondary" onclick="return confirm('¿Marcar todas las notificaciones como leídas?')">
                                <i class="fas fa-check-double"></i> Marcar todas leídas
                            </a>
                        <?php endif; ?>
                        
                        <?php if (isAdmin()): ?>
                            <button class="btn btn-primary" onclick="openModal('createNotificationModal')">
                                <i class="fas fa-plus"></i> Nueva Notificación
                            </button>
                        <?php endif; ?>
                    </div>
                </div>
                
                <!-- Lista de notificaciones -->
                <div class="card">
                    <div class="card-header">
                        <h3 class="card-title"><i class="fas fa-bell"></i> Notificaciones</h3>
                    </div>
                    <div class="card-body" style="padding: 0;">
                        <?php if (empty($notifications)): ?>
                            <div class="empty-state" style="padding: 60px 20px;">
                                <i class="fas fa-bell-slash"></i>
                                <h3>No hay notificaciones</h3>
                                <p>No tienes notificaciones en este momento</p>
                            </div>
                        <?php else: ?>
                            <div class="notification-list-full">
                                <?php foreach ($notifications as $notif): ?>
                                    <div class="notification-item-full <?php echo $notif['is_read'] ? '' : 'unread'; ?>" style="
                                        display: flex;
                                        align-items: flex-start;
                                        gap: 15px;
                                        padding: 16px 20px;
                                        border-bottom: 1px solid var(--border);
                                        transition: background var(--transition-fast);
                                        <?php echo !$notif['is_read'] ? 'background: var(--accent-bg);' : ''; ?>
                                    ">
                                        <div class="notification-icon" style="
                                            width: 40px;
                                            height: 40px;
                                            background: <?php 
                                                switch($notif['type']) {
                                                    case 'success': echo 'var(--success-bg)'; break;
                                                    case 'warning': echo 'var(--warning-bg)'; break;
                                                    case 'error': echo 'var(--error-bg)'; break;
                                                    default: echo 'var(--info-bg)';
                                                }
                                            ?>;
                                            border-radius: 12px;
                                            display: flex;
                                            align-items: center;
                                            justify-content: center;
                                        ">
                                            <i class="fas <?php 
                                                switch($notif['type']) {
                                                    case 'success': echo 'fa-check-circle'; break;
                                                    case 'warning': echo 'fa-exclamation-triangle'; break;
                                                    case 'error': echo 'fa-times-circle'; break;
                                                    default: echo 'fa-info-circle';
                                                }
                                            ?>" style="color: <?php 
                                                switch($notif['type']) {
                                                    case 'success': echo 'var(--success)'; break;
                                                    case 'warning': echo 'var(--warning)'; break;
                                                    case 'error': echo 'var(--error)'; break;
                                                    default: echo 'var(--info)';
                                                }
                                            ?>;"></i>
                                        </div>
                                        
                                        <div style="flex: 1;">
                                            <div style="display: flex; justify-content: space-between; align-items: flex-start; flex-wrap: wrap; gap: 10px;">
                                                <h4 style="margin: 0;"><?php echo htmlspecialchars($notif['title']); ?></h4>
                                                <span class="text-muted" style="font-size: 11px;">
                                                    <i class="far fa-clock"></i> <?php echo timeAgo($notif['created_at']); ?>
                                                </span>
                                            </div>
                                            <p style="margin: 8px 0 0; color: var(--text-secondary);">
                                                <?php echo htmlspecialchars($notif['message']); ?>
                                            </p>
                                        </div>
                                        
                                        <div style="display: flex; gap: 5px;">
                                            <?php if (!$notif['is_read']): ?>
                                                <a href="?mark_read=<?php echo $notif['id']; ?>" class="btn btn-sm btn-secondary" title="Marcar como leída">
                                                    <i class="fas fa-check"></i>
                                                </a>
                                            <?php endif; ?>
                                            
                                            <?php if (isAdmin()): ?>
                                                <a href="?delete=<?php echo $notif['id']; ?>" class="btn btn-sm btn-danger" title="Eliminar" onclick="return confirm('¿Eliminar esta notificación?')">
                                                    <i class="fas fa-trash"></i>
                                                </a>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                <?php endforeach; ?>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </main>
    </div>
    
    <!-- Modal Crear Notificación (solo admin) -->
    <?php if (isAdmin()): ?>
    <div id="createNotificationModal" class="modal">
        <div class="modal-content" style="max-width: 500px;">
            <div class="modal-header">
                <h3><i class="fas fa-bell"></i> Crear Notificación</h3>
                <button class="modal-close" onclick="closeModal('createNotificationModal')">&times;</button>
            </div>
            <form method="POST" class="modal-body">
                <input type="hidden" name="action" value="create">
                
                <div class="form-group">
                    <label class="form-label">Usuario destino</label>
                    <select name="user_id" class="form-control" required>
                        <option value="0">Todos los usuarios</option>
                        <?php foreach ($users as $user): ?>
                            <option value="<?php echo $user['id']; ?>"><?php echo htmlspecialchars($user['username']); ?> (<?php echo $user['role']; ?>)</option>
                        <?php endforeach; ?>
                    </select>
                </div>
                
                <div class="form-group">
                    <label class="form-label">Título</label>
                    <input type="text" name="title" class="form-control" required placeholder="Título de la notificación">
                </div>
                
                <div class="form-group">
                    <label class="form-label">Mensaje</label>
                    <textarea name="message" class="form-control" rows="4" required placeholder="Contenido del mensaje"></textarea>
                </div>
                
                <div class="form-group">
                    <label class="form-label">Tipo</label>
                    <select name="type" class="form-control">
                        <option value="info">📘 Información</option>
                        <option value="success">✅ Éxito</option>
                        <option value="warning">⚠️ Advertencia</option>
                        <option value="error">❌ Error</option>
                    </select>
                </div>
                
                <div class="modal-footer" style="padding: 0; margin-top: 20px;">
                    <button type="button" class="btn btn-secondary" onclick="closeModal('createNotificationModal')">Cancelar</button>
                    <button type="submit" class="btn btn-primary">Enviar Notificación</button>
                </div>
            </form>
        </div>
    </div>
    <?php endif; ?>
    
    <style>
        .notification-item-full:hover {
            background: var(--bg-hover) !important;
        }
        
        .notification-item-full.unread {
            border-left: 3px solid var(--accent);
        }
    </style>
</body>
</html>

<?php
// Función helper para tiempo relativo
function timeAgo($timestamp) {
    $time = strtotime($timestamp);
    $now = time();
    $diff = $now - $time;
    
    if ($diff < 60) {
        return 'Hace ' . $diff . ' segundos';
    } elseif ($diff < 3600) {
        $mins = floor($diff / 60);
        return 'Hace ' . $mins . ' minuto' . ($mins > 1 ? 's' : '');
    } elseif ($diff < 86400) {
        $hours = floor($diff / 3600);
        return 'Hace ' . $hours . ' hora' . ($hours > 1 ? 's' : '');
    } elseif ($diff < 604800) {
        $days = floor($diff / 86400);
        return 'Hace ' . $days . ' día' . ($days > 1 ? 's' : '');
    } else {
        return date('d/m/Y H:i', $time);
    }
}
?>