<?php
// ==============================================
// CEO SSH PANEL - GESTIÓN DE USUARIOS
// Versión: 2.0.0
// ==============================================

require_once '../includes/config.php';
require_once '../includes/database.php';
require_once '../includes/functions.php';
require_once '../includes/auth.php';

// Solo administradores pueden acceder
requireAdmin();

$message = '';
$error = '';
$success = '';

// Procesar acciones POST
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    
    // Crear usuario
    if ($action === 'create') {
        $username = trim($_POST['username']);
        $password = $_POST['password'];
        $days = intval($_POST['days']);
        $email = trim($_POST['email'] ?? '');
        
        // Validar datos
        if (empty($username) || empty($password)) {
            $error = 'Usuario y contraseña son requeridos';
        } elseif (strlen($password) < 6) {
            $error = 'La contraseña debe tener al menos 6 caracteres';
        } elseif (!validateUsername($username)) {
            $error = 'El usuario solo puede contener letras, números y guión bajo (3-20 caracteres)';
        } else {
            // Verificar si ya existe
            $existing = getSSHTokenByUsername($username);
            if ($existing) {
                $error = 'El usuario ya existe';
            } else {
                $expireDate = date('Y-m-d', strtotime("+$days days"));
                
                // Crear usuario en sistema
                $created = createSystemUser($username, $password, $expireDate);
                
                if ($created) {
                    // Guardar en BD
                    $tokenId = createSSHToken([
                        'username' => $username,
                        'password' => password_hash($password, PASSWORD_DEFAULT),
                        'expires_at' => $expireDate,
                        'created_by' => $_SESSION['user_id'],
                        'status' => 'active'
                    ]);
                    
                    if ($tokenId) {
                        addLog($_SESSION['user_id'], 'create_user', "Creado usuario SSH: $username ($days días)", getClientIP(), getUserAgent());
                        addNotification($_SESSION['user_id'], 'Usuario Creado', "Se ha creado el usuario <strong>$username</strong> con expiración en $days días", 'success');
                        $success = "Usuario <strong>$username</strong> creado exitosamente. Contraseña: <code>$password</code>";
                    } else {
                        $error = 'Error al guardar en base de datos';
                    }
                } else {
                    $error = 'Error al crear usuario en el sistema';
                }
            }
        }
    }
    
    // Eliminar usuario
    if ($action === 'delete') {
        $tokenId = intval($_POST['user_id']);
        $token = getSSHTokenById($tokenId);
        
        if ($token) {
            $deleted = deleteSSHToken($tokenId);
            if ($deleted) {
                addLog($_SESSION['user_id'], 'delete_user', "Eliminado usuario SSH: {$token['username']}", getClientIP(), getUserAgent());
                addNotification($_SESSION['user_id'], 'Usuario Eliminado', "Se ha eliminado el usuario <strong>{$token['username']}</strong>", 'warning');
                $success = "Usuario <strong>{$token['username']}</strong> eliminado exitosamente";
            } else {
                $error = 'Error al eliminar usuario';
            }
        } else {
            $error = 'Usuario no encontrado';
        }
    }
    
    // Extender usuario
    if ($action === 'extend') {
        $tokenId = intval($_POST['user_id']);
        $days = intval($_POST['days']);
        $token = getSSHTokenById($tokenId);
        
        if ($token) {
            $newExpire = extendSystemUser($token['username'], $days);
            updateSSHToken($tokenId, ['expires_at' => $newExpire]);
            
            addLog($_SESSION['user_id'], 'extend_user', "Extendido usuario {$token['username']} +$days días", getClientIP(), getUserAgent());
            addNotification($_SESSION['user_id'], 'Usuario Extendido', "Se ha extendido el usuario <strong>{$token['username']}</strong> por $days días", 'info');
            $success = "Usuario <strong>{$token['username']}</strong> extendido por $days días. Nueva expiración: " . date('d/m/Y', strtotime($newExpire));
        } else {
            $error = 'Usuario no encontrado';
        }
    }
    
    // Cambiar estado
    if ($action === 'toggle_status') {
        $tokenId = intval($_POST['user_id']);
        $newStatus = $_POST['status'];
        $token = getSSHTokenById($tokenId);
        
        if ($token) {
            updateSSHToken($tokenId, ['status' => $newStatus]);
            
            if ($newStatus == 'blocked') {
                blockSystemUser($token['username']);
            } elseif ($newStatus == 'active') {
                unblockSystemUser($token['username']);
            }
            
            addLog($_SESSION['user_id'], 'toggle_user_status', "Cambiado estado de {$token['username']} a $newStatus", getClientIP(), getUserAgent());
            $success = "Estado del usuario <strong>{$token['username']}</strong> actualizado a " . ucfirst($newStatus);
        } else {
            $error = 'Usuario no encontrado';
        }
    }
}

// Obtener filtros
$statusFilter = $_GET['status'] ?? '';
$searchFilter = $_GET['search'] ?? '';
$page = intval($_GET['page'] ?? 1);
$limit = 20;
$offset = ($page - 1) * $limit;

// Construir filtros
$filters = [];
if ($statusFilter) $filters['status'] = $statusFilter;
if ($searchFilter) $filters['username'] = $searchFilter;
$filters['limit'] = $limit;
$filters['offset'] = $offset;

// Obtener usuarios
$users = getSSHTokens($filters);
$totalUsers = db_count('ssh_tokens', '1=1');
$totalPages = ceil($totalUsers / $limit);

// Estadísticas
$stats = [
    'total' => db_count('ssh_tokens'),
    'active' => db_count('ssh_tokens', "status = 'active' AND expires_at > NOW()"),
    'expired' => db_count('ssh_tokens', "expires_at <= NOW() OR status = 'expired'"),
    'blocked' => db_count('ssh_tokens', "status = 'blocked'"),
    'suspended' => db_count('ssh_tokens', "status = 'suspended'")
];
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gestión de Usuarios - CEO SSH Panel</title>
    <link rel="icon" href="../assets/img/favicon.ico">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="../assets/css/style.css">
    <link rel="stylesheet" href="../assets/css/responsive.css">
    <script src="../assets/js/app.js" defer></script>
</head>
<body>
    <div class="app-container">
        <!-- Sidebar -->
        <aside class="sidebar" id="sidebar">
            <div class="logo">
                <div class="logo-icon"><i class="fas fa-shield-alt"></i></div>
                <div class="logo-text">CEO SSH</div>
            </div>
            
            <nav class="sidebar-nav">
                <div class="nav-section">
                    <div class="nav-label">Principal</div>
                    <a href="dashboard.php" class="sidebar-link"><i class="fas fa-tachometer-alt"></i><span>Dashboard</span></a>
                    <a href="users.php" class="sidebar-link active"><i class="fas fa-users"></i><span>Usuarios</span></a>
                </div>
                
                <div class="nav-section">
                    <div class="nav-label">Configuración</div>
                    <a href="profile.php" class="sidebar-link"><i class="fas fa-user"></i><span>Mi Perfil</span></a>
                    <a href="settings.php" class="sidebar-link"><i class="fas fa-cog"></i><span>Configuración</span></a>
                    <a href="backups.php" class="sidebar-link"><i class="fas fa-database"></i><span>Backups</span></a>
                    <a href="logs.php" class="sidebar-link"><i class="fas fa-history"></i><span>Logs</span></a>
                    <a href="notifications.php" class="sidebar-link"><i class="fas fa-bell"></i><span>Notificaciones</span></a>
                    <a href="help.php" class="sidebar-link"><i class="fas fa-question-circle"></i><span>Ayuda</span></a>
                </div>
            </nav>
            
            <div class="user-info">
                <div style="display: flex; align-items: center; gap: 12px;">
                    <div class="user-avatar"><?php echo strtoupper(substr($_SESSION['username'], 0, 1)); ?></div>
                    <div class="user-details">
                        <div class="user-name"><?php echo htmlspecialchars($_SESSION['username']); ?></div>
                        <div class="user-role">Administrador</div>
                    </div>
                </div>
                <div style="margin-top: 12px;">
                    <a href="../api/auth.php?action=logout" class="btn btn-secondary btn-sm" style="width: 100%;"><i class="fas fa-sign-out-alt"></i> Cerrar Sesión</a>
                </div>
            </div>
        </aside>
        
        <!-- Main Content -->
        <main class="main-content" id="mainContent">
            <header class="header">
                <div class="header-left">
                    <button class="toggle-sidebar" onclick="toggleSidebar()"><i class="fas fa-bars"></i></button>
                    <div class="page-title">
                        <h1>Gestión de Usuarios</h1>
                        <p>Administra todos los tokens SSH del sistema</p>
                    </div>
                </div>
                
                <div class="header-right">
                    <button class="theme-toggle" onclick="toggleTheme()"><i class="fas fa-moon" id="themeIcon"></i></button>
                </div>
            </header>
            
            <div class="content">
                <!-- Mensajes -->
                <?php if ($success): ?>
                    <div class="alert alert-success" style="background: var(--success-bg); border: 1px solid var(--success); color: var(--success); padding: 12px 16px; border-radius: 12px; margin-bottom: 20px;">
                        <i class="fas fa-check-circle"></i> <?php echo $success; ?>
                    </div>
                <?php endif; ?>
                
                <?php if ($error): ?>
                    <div class="alert alert-error" style="background: var(--error-bg); border: 1px solid var(--error); color: var(--error); padding: 12px 16px; border-radius: 12px; margin-bottom: 20px;">
                        <i class="fas fa-exclamation-triangle"></i> <?php echo $error; ?>
                    </div>
                <?php endif; ?>
                
                <!-- Stats Cards -->
                <div class="stats-grid" style="margin-bottom: 20px;">
                    <div class="stat-card">
                        <div class="stat-icon"><i class="fas fa-users"></i></div>
                        <div class="stat-value"><?php echo $stats['total']; ?></div>
                        <div class="stat-label">Total Usuarios</div>
                    </div>
                    <div class="stat-card">
                        <div class="stat-icon"><i class="fas fa-check-circle"></i></div>
                        <div class="stat-value"><?php echo $stats['active']; ?></div>
                        <div class="stat-label">Activos</div>
                    </div>
                    <div class="stat-card">
                        <div class="stat-icon"><i class="fas fa-clock"></i></div>
                        <div class="stat-value"><?php echo $stats['expired']; ?></div>
                        <div class="stat-label">Expirados</div>
                    </div>
                    <div class="stat-card">
                        <div class="stat-icon"><i class="fas fa-ban"></i></div>
                        <div class="stat-value"><?php echo $stats['blocked']; ?></div>
                        <div class="stat-label">Bloqueados</div>
                    </div>
                </div>
                
                <!-- Barra de acciones -->
                <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px; flex-wrap: wrap; gap: 10px;">
                    <div style="display: flex; gap: 10px; flex-wrap: wrap;">
                        <button class="btn btn-primary" onclick="openModal('createUserModal')">
                            <i class="fas fa-plus"></i> Crear Usuario
                        </button>
                        <button class="btn btn-secondary" onclick="openModal('bulkCreateModal')">
                            <i class="fas fa-file-upload"></i> Crear Múltiple
                        </button>
                    </div>
                    
                    <div style="display: flex; gap: 10px;">
                        <select id="statusFilter" class="form-control" style="width: 150px;" onchange="applyFilters()">
                            <option value="">Todos</option>
                            <option value="active" <?php echo $statusFilter == 'active' ? 'selected' : ''; ?>>Activos</option>
                            <option value="expired" <?php echo $statusFilter == 'expired' ? 'selected' : ''; ?>>Expirados</option>
                            <option value="blocked" <?php echo $statusFilter == 'blocked' ? 'selected' : ''; ?>>Bloqueados</option>
                            <option value="suspended" <?php echo $statusFilter == 'suspended' ? 'selected' : ''; ?>>Suspendidos</option>
                        </select>
                        <input type="text" id="searchFilter" class="form-control" placeholder="Buscar usuario..." value="<?php echo htmlspecialchars($searchFilter); ?>" style="width: 200px;">
                        <button class="btn btn-primary" onclick="applyFilters()"><i class="fas fa-search"></i></button>
                        <button class="btn btn-secondary" onclick="resetFilters()"><i class="fas fa-undo"></i></button>
                    </div>
                </div>
                
                <!-- Tabla de usuarios -->
                <div class="table-container">
                    <table style="width: 100%;">
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>Usuario</th>
                                <th>Contraseña</th>
                                <th>Expiración</th>
                                <th>Estado</th>
                                <th>Creado por</th>
                                <th>Fecha creación</th>
                                <th>Acciones</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (empty($users)): ?>
                                <tr>
                                    <td colspan="8" style="text-align: center; padding: 40px;">
                                        <i class="fas fa-inbox" style="font-size: 48px; color: var(--text-tertiary);"></i>
                                        <p>No hay usuarios registrados</p>
                                    </td>
                                </tr>
                            <?php else: ?>
                                <?php foreach ($users as $user): ?>
                                    <tr>
                                        <td><?php echo $user['id']; ?></td>
                                        <td>
                                            <strong><?php echo htmlspecialchars($user['username']); ?></strong>
                                            <br>
                                            <small class="text-muted">Conexiones: <?php echo getUserConnections($user['username']); ?></small>
                                        </td>
                                        <td>
                                            <code style="font-size: 11px;"><?php echo substr($user['password'], 0, 20); ?>...</code>
                                            <button class="btn btn-sm btn-secondary" onclick="copyPassword('<?php echo htmlspecialchars($user['password']); ?>')" style="padding: 2px 6px; margin-left: 5px;">
                                                <i class="fas fa-copy"></i>
                                            </button>
                                        </td>
                                        <td>
                                            <?php echo date('d/m/Y', strtotime($user['expires_at'])); ?>
                                            <br>
                                            <?php
                                            $daysLeft = ceil((strtotime($user['expires_at']) - time()) / 86400);
                                            if ($daysLeft > 0 && $daysLeft <= 7):
                                            ?>
                                                <span class="badge badge-warning" style="font-size: 10px;"><?php echo $daysLeft; ?> días restantes</span>
                                            <?php elseif ($daysLeft <= 0): ?>
                                                <span class="badge badge-error" style="font-size: 10px;">Expirado</span>
                                            <?php endif; ?>
                                        </td>
                                        <td>
                                            <span class="badge badge-<?php echo $user['status']; ?>">
                                                <?php 
                                                    $statusLabels = [
                                                        'active' => 'Activo',
                                                        'expired' => 'Expirado',
                                                        'blocked' => 'Bloqueado',
                                                        'suspended' => 'Suspendido'
                                                    ];
                                                    echo $statusLabels[$user['status']] ?? $user['status'];
                                                ?>
                                            </span>
                                        </td>
                                        <td><?php echo htmlspecialchars($user['creator'] ?? 'Sistema'); ?></td>
                                        <td><?php echo date('d/m/Y H:i', strtotime($user['created_at'])); ?></td>
                                        <td>
                                            <div style="display: flex; gap: 5px; flex-wrap: wrap;">
                                                <button class="btn btn-sm btn-warning" onclick="extendUser(<?php echo $user['id']; ?>, '<?php echo htmlspecialchars($user['username']); ?>')" title="Extender">
                                                    <i class="fas fa-calendar-plus"></i>
                                                </button>
                                                <button class="btn btn-sm btn-info" onclick="showUserInfo(<?php echo $user['id']; ?>)" title="Info">
                                                    <i class="fas fa-info-circle"></i>
                                                </button>
                                                <?php if ($user['status'] == 'active'): ?>
                                                    <button class="btn btn-sm btn-danger" onclick="toggleStatus(<?php echo $user['id']; ?>, 'blocked')" title="Bloquear">
                                                        <i class="fas fa-ban"></i>
                                                    </button>
                                                <?php elseif ($user['status'] == 'blocked'): ?>
                                                    <button class="btn btn-sm btn-success" onclick="toggleStatus(<?php echo $user['id']; ?>, 'active')" title="Activar">
                                                        <i class="fas fa-check"></i>
                                                    </button>
                                                <?php endif; ?>
                                                <button class="btn btn-sm btn-danger" onclick="deleteUser(<?php echo $user['id']; ?>, '<?php echo htmlspecialchars($user['username']); ?>')" title="Eliminar">
                                                    <i class="fas fa-trash"></i>
                                                </button>
                                            </div>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
                
                <!-- Paginación -->
                <?php if ($totalPages > 1): ?>
                <div style="display: flex; justify-content: center; gap: 10px; margin-top: 20px;">
                    <?php if ($page > 1): ?>
                        <a href="?page=<?php echo $page-1; ?>&status=<?php echo urlencode($statusFilter); ?>&search=<?php echo urlencode($searchFilter); ?>" class="btn btn-secondary">Anterior</a>
                    <?php endif; ?>
                    
                    <span style="padding: 8px 16px;">Página <?php echo $page; ?> de <?php echo $totalPages; ?></span>
                    
                    <?php if ($page < $totalPages): ?>
                        <a href="?page=<?php echo $page+1; ?>&status=<?php echo urlencode($statusFilter); ?>&search=<?php echo urlencode($searchFilter); ?>" class="btn btn-secondary">Siguiente</a>
                    <?php endif; ?>
                </div>
                <?php endif; ?>
            </div>
        </main>
    </div>
    
    <!-- Modal Crear Usuario -->
    <div id="createUserModal" class="modal">
        <div class="modal-content" style="max-width: 500px;">
            <div class="modal-header">
                <h3><i class="fas fa-user-plus"></i> Crear Usuario</h3>
                <button class="modal-close" onclick="closeModal('createUserModal')">&times;</button>
            </div>
            <form method="POST" class="modal-body">
                <input type="hidden" name="action" value="create">
                
                <div class="form-group">
                    <label class="form-label">Usuario *</label>
                    <input type="text" name="username" class="form-control" required placeholder="ejemplo_usuario">
                    <small class="text-muted">Solo letras, números y guión bajo (3-20 caracteres)</small>
                </div>
                
                <div class="form-group">
                    <label class="form-label">Contraseña *</label>
                    <input type="text" name="password" class="form-control" required placeholder="contraseña_segura">
                    <small class="text-muted">Mínimo 6 caracteres</small>
                </div>
                
                <div class="form-group">
                    <label class="form-label">Email (opcional)</label>
                    <input type="email" name="email" class="form-control" placeholder="usuario@ejemplo.com">
                </div>
                
                <div class="form-group">
                    <label class="form-label">Días de expiración</label>
                    <select name="days" class="form-control">
                        <option value="7">7 días</option>
                        <option value="15">15 días</option>
                        <option value="30" selected>30 días</option>
                        <option value="60">60 días</option>
                        <option value="90">90 días</option>
                        <option value="180">180 días</option>
                        <option value="365">365 días</option>
                    </select>
                </div>
                
                <div class="modal-footer" style="padding: 0; margin-top: 20px;">
                    <button type="button" class="btn btn-secondary" onclick="closeModal('createUserModal')">Cancelar</button>
                    <button type="submit" class="btn btn-primary">Crear Usuario</button>
                </div>
            </form>
        </div>
    </div>
    
    <!-- Modal Extender Usuario -->
    <div id="extendUserModal" class="modal">
        <div class="modal-content" style="max-width: 400px;">
            <div class="modal-header">
                <h3><i class="fas fa-calendar-plus"></i> Extender Usuario</h3>
                <button class="modal-close" onclick="closeModal('extendUserModal')">&times;</button>
            </div>
            <form method="POST" class="modal-body">
                <input type="hidden" name="action" value="extend">
                <input type="hidden" name="user_id" id="extendUserId">
                
                <p>Usuario: <strong id="extendUsername"></strong></p>
                
                <div class="form-group">
                    <label class="form-label">Días a agregar</label>
                    <select name="days" class="form-control">
                        <option value="7">+7 días</option>
                        <option value="15">+15 días</option>
                        <option value="30" selected>+30 días</option>
                        <option value="60">+60 días</option>
                        <option value="90">+90 días</option>
                        <option value="180">+180 días</option>
                    </select>
                </div>
                
                <div class="modal-footer" style="padding: 0; margin-top: 20px;">
                    <button type="button" class="btn btn-secondary" onclick="closeModal('extendUserModal')">Cancelar</button>
                    <button type="submit" class="btn btn-primary">Extender</button>
                </div>
            </form>
        </div>
    </div>
    
    <!-- Modal Información Usuario -->
    <div id="infoUserModal" class="modal">
        <div class="modal-content" style="max-width: 500px;">
            <div class="modal-header">
                <h3><i class="fas fa-info-circle"></i> Información del Usuario</h3>
                <button class="modal-close" onclick="closeModal('infoUserModal')">&times;</button>
            </div>
            <div class="modal-body" id="infoUserContent">
                <div class="text-center">Cargando...</div>
            </div>
        </div>
    </div>
    
    <script>
        function applyFilters() {
            const status = document.getElementById('statusFilter').value;
            const search = document.getElementById('searchFilter').value;
            window.location.href = `?status=${status}&search=${encodeURIComponent(search)}`;
        }
        
        function resetFilters() {
            window.location.href = '?';
        }
        
        function extendUser(id, username) {
            document.getElementById('extendUserId').value = id;
            document.getElementById('extendUsername').innerHTML = username;
            openModal('extendUserModal');
        }
        
        function deleteUser(id, username) {
            if (confirm(`¿Estás seguro de eliminar al usuario ${username}?\n\nEsta acción no se puede deshacer.`)) {
                const form = document.createElement('form');
                form.method = 'POST';
                form.innerHTML = `
                    <input type="hidden" name="action" value="delete">
                    <input type="hidden" name="user_id" value="${id}">
                `;
                document.body.appendChild(form);
                form.submit();
            }
        }
        
        function toggleStatus(id, status) {
            const action = status === 'blocked' ? 'bloquear' : 'activar';
            if (confirm(`¿Estás seguro de ${action} este usuario?`)) {
                const form = document.createElement('form');
                form.method = 'POST';
                form.innerHTML = `
                    <input type="hidden" name="action" value="toggle_status">
                    <input type="hidden" name="user_id" value="${id}">
                    <input type="hidden" name="status" value="${status}">
                `;
                document.body.appendChild(form);
                form.submit();
            }
        }
        
        function showUserInfo(id) {
            openModal('infoUserModal');
            document.getElementById('infoUserContent').innerHTML = '<div class="text-center"><i class="fas fa-spinner fa-spin"></i> Cargando...</div>';
            
            fetch(`../api/users.php?id=${id}`)
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        const user = data.data;
                        document.getElementById('infoUserContent').innerHTML = `
                            <div class="form-group">
                                <label class="form-label">Usuario</label>
                                <input type="text" class="form-control" value="${user.username}" readonly>
                            </div>
                            <div class="form-group">
                                <label class="form-label">Expiración</label>
                                <input type="text" class="form-control" value="${new Date(user.expires_at).toLocaleDateString()}" readonly>
                            </div>
                            <div class="form-group">
                                <label class="form-label">Estado</label>
                                <input type="text" class="form-control" value="${user.status}" readonly>
                            </div>
                            <div class="form-group">
                                <label class="form-label">Creado por</label>
                                <input type="text" class="form-control" value="${user.creator || 'Sistema'}" readonly>
                            </div>
                            <div class="form-group">
                                <label class="form-label">Fecha creación</label>
                                <input type="text" class="form-control" value="${new Date(user.created_at).toLocaleString()}" readonly>
                            </div>
                            <div class="form-group">
                                <label class="form-label">Último login</label>
                                <input type="text" class="form-control" value="${user.last_login ? new Date(user.last_login).toLocaleString() : 'Nunca'}" readonly>
                            </div>
                        `;
                    } else {
                        document.getElementById('infoUserContent').innerHTML = '<div class="alert alert-error">Error al cargar información</div>';
                    }
                })
                .catch(error => {
                    document.getElementById('infoUserContent').innerHTML = '<div class="alert alert-error">Error de conexión</div>';
                });
        }
        
        function copyPassword(password) {
            navigator.clipboard.writeText(password).then(() => {
                alert('Contraseña copiada al portapapeles');
            });
        }
    </script>
</body>
</html>