<?php
require_once '../includes/config.php';
require_once '../includes/database.php';
require_once '../includes/functions.php';
require_once '../includes/auth.php';
require_once '../includes/validation.php';

// Verificar login
requireLogin();

$stats = getSystemStats();
$serverInfo = getServerInfo();
$unreadCount = getUnreadCount($_SESSION['user_id']);
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard - CEO SSH Panel</title>
    <link rel="icon" href="../assets/img/favicon.ico">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <link rel="stylesheet" href="../assets/css/style.css">
    <link rel="stylesheet" href="../assets/css/responsive.css">
    <script src="../assets/js/app.js" defer></script>
</head>
<body>
    <div class="app-container">
        <!-- Sidebar -->
        <aside class="sidebar" id="sidebar">
            <div class="logo">
                <div class="logo-icon">
                    <i class="fas fa-shield-alt"></i>
                </div>
                <div class="logo-text">CEO SSH</div>
            </div>
            
            <nav class="sidebar-nav">
                <div class="nav-section">
                    <div class="nav-label">Principal</div>
                    <a href="dashboard.php" class="sidebar-link active">
                        <i class="fas fa-tachometer-alt"></i>
                        <span>Dashboard</span>
                    </a>
                    <a href="users.php" class="sidebar-link">
                        <i class="fas fa-users"></i>
                        <span>Usuarios</span>
                    </a>
                </div>
                
                <div class="nav-section">
                    <div class="nav-label">Configuración</div>
                    <a href="profile.php" class="sidebar-link">
                        <i class="fas fa-user"></i>
                        <span>Mi Perfil</span>
                    </a>
                    <?php if (isAdmin()): ?>
                    <a href="settings.php" class="sidebar-link">
                        <i class="fas fa-cog"></i>
                        <span>Configuración</span>
                    </a>
                    <a href="backups.php" class="sidebar-link">
                        <i class="fas fa-database"></i>
                        <span>Backups</span>
                    </a>
                    <a href="logs.php" class="sidebar-link">
                        <i class="fas fa-history"></i>
                        <span>Logs</span>
                    </a>
                    <?php endif; ?>
                </div>
            </nav>
            
            <div class="user-info">
                <div style="display: flex; align-items: center; gap: 12px;">
                    <div class="user-avatar">
                        <?php echo strtoupper(substr($_SESSION['username'], 0, 1)); ?>
                    </div>
                    <div class="user-details">
                        <div class="user-name"><?php echo htmlspecialchars($_SESSION['username']); ?></div>
                        <div class="user-role"><?php echo $_SESSION['role'] === 'admin' ? 'Administrador' : 'Usuario'; ?></div>
                    </div>
                </div>
            </div>
        </aside>
        
        <!-- Main Content -->
        <main class="main-content" id="mainContent">
            <header class="header">
                <div class="header-left">
                    <button class="toggle-sidebar" onclick="toggleSidebar()">
                        <i class="fas fa-bars"></i>
                    </button>
                    <div class="page-title">
                        <h1>Dashboard</h1>
                        <p>Bienvenido, <?php echo htmlspecialchars($_SESSION['username']); ?></p>
                    </div>
                </div>
                
                <div class="header-right">
                    <div class="notification-btn" onclick="toggleDropdown('notificationDropdown')">
                        <i class="fas fa-bell"></i>
                        <?php if ($unreadCount > 0): ?>
                        <span class="notification-badge" id="notificationBadge"><?php echo $unreadCount; ?></span>
                        <?php endif; ?>
                    </div>
                    
                    <button class="theme-toggle" onclick="toggleTheme()">
                        <i class="fas fa-moon" id="themeIcon"></i>
                    </button>
                    
                    <div class="user-dropdown">
                        <button class="user-btn" onclick="toggleDropdown('userDropdown')">
                            <div class="user-avatar-small">
                                <?php echo strtoupper(substr($_SESSION['username'], 0, 1)); ?>
                            </div>
                            <span class="user-name-small"><?php echo htmlspecialchars($_SESSION['username']); ?></span>
                            <i class="fas fa-chevron-down"></i>
                        </button>
                        
                        <div class="dropdown-menu" id="userDropdown">
                            <a href="profile.php" class="dropdown-item">
                                <i class="fas fa-user"></i>
                                <span>Mi Perfil</span>
                            </a>
                            <div class="dropdown-divider"></div>
                            <a href="../api/auth.php?action=logout" class="dropdown-item">
                                <i class="fas fa-sign-out-alt"></i>
                                <span>Cerrar Sesión</span>
                            </a>
                        </div>
                    </div>
                </div>
                
                <!-- Notifications Dropdown -->
                <div class="notification-dropdown" id="notificationDropdown">
                    <div class="notification-header">
                        <span>Notificaciones</span>
                        <button class="btn-sm" onclick="markAllAsRead()">Marcar todas</button>
                    </div>
                    <div class="notification-list" id="notificationList">
                        <div class="empty-state">Cargando...</div>
                    </div>
                </div>
            </header>
            
            <div class="content">
                <!-- Stats Grid -->
                <div class="stats-grid">
                    <div class="stat-card">
                        <div class="stat-icon">
                            <i class="fas fa-users"></i>
                        </div>
                        <div class="stat-value" id="totalUsers"><?php echo $stats['total_users']; ?></div>
                        <div class="stat-label">Total Usuarios</div>
                    </div>
                    
                    <div class="stat-card">
                        <div class="stat-icon">
                            <i class="fas fa-check-circle"></i>
                        </div>
                        <div class="stat-value" id="activeTokens"><?php echo $stats['active_tokens']; ?></div>
                        <div class="stat-label">Tokens Activos</div>
                    </div>
                    
                    <div class="stat-card">
                        <div class="stat-icon">
                            <i class="fas fa-wifi"></i>
                        </div>
                        <div class="stat-value" id="onlineUsers"><?php echo $stats['online_users']; ?></div>
                        <div class="stat-label">Usuarios Online</div>
                    </div>
                    
                    <div class="stat-card">
                        <div class="stat-icon">
                            <i class="fas fa-chart-line"></i>
                        </div>
                        <div class="stat-value" id="serverLoad"><?php echo $stats['load']; ?></div>
                        <div class="stat-label">Carga del Servidor</div>
                    </div>
                    
                    <div class="stat-card">
                        <div class="stat-icon">
                            <i class="fas fa-hdd"></i>
                        </div>
                        <div class="stat-value" id="diskUsage"><?php echo $stats['disk_usage']; ?>%</div>
                        <div class="stat-label">Uso de Disco</div>
                    </div>
                    
                    <div class="stat-card">
                        <div class="stat-icon">
                            <i class="fas fa-microchip"></i>
                        </div>
                        <div class="stat-value" id="memoryUsage"><?php echo $stats['memory_usage']; ?>%</div>
                        <div class="stat-label">Uso de Memoria</div>
                    </div>
                </div>
                
                <!-- Charts Row -->
                <div class="row" style="margin-bottom: 30px;">
                    <div class="col-12 col-md-6">
                        <div class="card">
                            <div class="card-header">
                                <h3 class="card-title">Crecimiento de Usuarios</h3>
                            </div>
                            <div class="card-body">
                                <canvas id="userChart" height="300"></canvas>
                            </div>
                        </div>
                    </div>
                    
                    <div class="col-12 col-md-6">
                        <div class="card">
                            <div class="card-header">
                                <h3 class="card-title">Información del Servidor</h3>
                            </div>
                            <div class="card-body">
                                <table style="width: 100%;">
                                    <tr>
                                        <td style="padding: 8px 0; color: var(--text-secondary);">Hostname</td>
                                        <td style="padding: 8px 0;"><?php echo $serverInfo['hostname']; ?></td>
                                    </tr>
                                    <tr>
                                        <td style="padding: 8px 0; color: var(--text-secondary);">Sistema Operativo</td>
                                        <td style="padding: 8px 0;"><?php echo $serverInfo['os']; ?></td>
                                    </tr>
                                    <tr>
                                        <td style="padding: 8px 0; color: var(--text-secondary);">PHP Version</td>
                                        <td style="padding: 8px 0;"><?php echo $serverInfo['php_version']; ?></td>
                                    </tr>
                                    <tr>
                                        <td style="padding: 8px 0; color: var(--text-secondary);">MySQL Version</td>
                                        <td style="padding: 8px 0;"><?php echo $serverInfo['mysql_version']; ?></td>
                                    </tr>
                                    <tr>
                                        <td style="padding: 8px 0; color: var(--text-secondary);">Uptime</td>
                                        <td style="padding: 8px 0;"><?php echo $serverInfo['uptime']; ?></td>
                                    </tr>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
                
                <!-- Services Status -->
                <div class="card">
                    <div class="card-header">
                        <h3 class="card-title">Estado de Servicios</h3>
                    </div>
                    <div class="card-body">
                        <table style="width: 100%;">
                            <thead>
                                <tr>
                                    <th>Servicio</th>
                                    <th>Puerto</th>
                                    <th>Estado</th>
                                    <th>Acción</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr>
                                    <td>SSH</td>
                                    <td><?php echo SSH_PORT; ?></td>
                                    <td><span class="badge badge-success">Activo</span></td>
                                    <td><button class="btn btn-sm btn-primary" onclick="showToast('Función disponible pronto', 'info')">Reiniciar</button></td>
                                </tr>
                                <tr>
                                    <td>Dropbear</td>
                                    <td><?php echo DROPBEAR_PORT; ?></td>
                                    <td><span class="badge badge-success">Activo</span></td>
                                    <td><button class="btn btn-sm btn-primary" onclick="showToast('Función disponible pronto', 'info')">Reiniciar</button></td>
                                </tr>
                                <tr>
                                    <td>Stunnel</td>
                                    <td><?php echo STUNNEL_PORT; ?></td>
                                    <td><span class="badge badge-success">Activo</span></td>
                                    <td><button class="btn btn-sm btn-primary" onclick="showToast('Función disponible pronto', 'info')">Reiniciar</button></td>
                                </tr>
                                <tr>
                                    <td>Squid</td>
                                    <td><?php echo SQUID_PORT; ?></td>
                                    <td><span class="badge badge-success">Activo</span></td>
                                    <td><button class="btn btn-sm btn-primary" onclick="showToast('Función disponible pronto', 'info')">Reiniciar</button></td>
                                </tr>
                                <tr>
                                    <td>OpenVPN</td>
                                    <td><?php echo OPENVPN_PORT; ?></td>
                                    <td><span class="badge badge-success">Activo</span></td>
                                    <td><button class="btn btn-sm btn-primary" onclick="showToast('Función disponible pronto', 'info')">Reiniciar</button></td>
                                </tr>
                                <tr>
                                    <td>BadVPN</td>
                                    <td><?php echo BADVPN_PORT; ?> (UDP)</td>
                                    <td><span class="badge badge-success">Activo</span></td>
                                    <td><button class="btn btn-sm btn-primary" onclick="showToast('Función disponible pronto', 'info')">Reiniciar</button></td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </main>
    </div>
    
    <script>
        // Inicializar gráfica
        setTimeout(() => {
            const canvas = document.getElementById('userChart');
            if (canvas && typeof Chart !== 'undefined') {
                new Chart(canvas, {
                    type: 'line',
                    data: {
                        labels: ['Ene', 'Feb', 'Mar', 'Abr', 'May', 'Jun', 'Jul', 'Ago', 'Sep', 'Oct', 'Nov', 'Dic'],
                        datasets: [{
                            label: 'Usuarios Activos',
                            data: [65, 78, 90, 85, 102, 115, 130, 145, 160, 175, 190, 210],
                            borderColor: '#0087ff',
                            backgroundColor: 'rgba(0, 135, 255, 0.1)',
                            fill: true,
                            tension: 0.4
                        }]
                    },
                    options: {
                        responsive: true,
                        maintainAspectRatio: false,
                        plugins: {
                            legend: {
                                labels: { color: getComputedStyle(document.body).getPropertyValue('--text-secondary') }
                            }
                        },
                        scales: {
                            y: {
                                grid: { color: getComputedStyle(document.body).getPropertyValue('--border') },
                                ticks: { color: getComputedStyle(document.body).getPropertyValue('--text-secondary') }
                            },
                            x: {
                                grid: { color: getComputedStyle(document.body).getPropertyValue('--border') },
                                ticks: { color: getComputedStyle(document.body).getPropertyValue('--text-secondary') }
                            }
                        }
                    }
                });
            }
        }, 500);
    </script>
</body>
</html>