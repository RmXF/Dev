<?php
require_once '../includes/config.php';
require_once '../includes/database.php';
require_once '../includes/functions.php';
require_once '../includes/auth.php';
require_once '../includes/validation.php';

// Verificar login
requireLogin();


requireAdmin();

$message = '';
$error = '';

// Procesar configuración
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    
    if ($action === 'save_general') {
        setSetting('panel_name', $_POST['panel_name']);
        setSetting('maintenance_mode', $_POST['maintenance_mode']);
        setSetting('session_timeout', $_POST['session_timeout']);
        setSetting('default_expiration_days', $_POST['default_expiration_days']);
        setSetting('max_login_attempts', $_POST['max_login_attempts']);
        
        $message = "Configuración general guardada";
        addLog($_SESSION['user_id'], 'update_settings', 'Actualizó configuración general', getClientIP(), getUserAgent());
    }
    
    if ($action === 'save_notifications') {
        setSetting('notifications_enabled', $_POST['notifications_enabled']);
        setSetting('telegram_bot_token', $_POST['telegram_bot_token']);
        setSetting('telegram_chat_id', $_POST['telegram_chat_id']);
        setSetting('smtp_host', $_POST['smtp_host']);
        setSetting('smtp_port', $_POST['smtp_port']);
        setSetting('smtp_user', $_POST['smtp_user']);
        setSetting('smtp_pass', $_POST['smtp_pass']);
        setSetting('smtp_from', $_POST['smtp_from']);
        
        $message = "Configuración de notificaciones guardada";
        addLog($_SESSION['user_id'], 'update_settings', 'Actualizó configuración de notificaciones', getClientIP(), getUserAgent());
    }
    
    if ($action === 'save_security') {
        setSetting('recaptcha_site_key', $_POST['recaptcha_site_key']);
        setSetting('recaptcha_secret_key', $_POST['recaptcha_secret_key']);
        setSetting('login_lockout_time', $_POST['login_lockout_time']);
        
        $message = "Configuración de seguridad guardada";
        addLog($_SESSION['user_id'], 'update_settings', 'Actualizó configuración de seguridad', getClientIP(), getUserAgent());
    }
}

// Cargar configuración actual
$settings = [
    'panel_name' => getSetting('panel_name', 'CEO SSH'),
    'maintenance_mode' => getSetting('maintenance_mode', '0'),
    'session_timeout' => getSetting('session_timeout', '3600'),
    'default_expiration_days' => getSetting('default_expiration_days', '30'),
    'max_login_attempts' => getSetting('max_login_attempts', '5'),
    'notifications_enabled' => getSetting('notifications_enabled', '1'),
    'telegram_bot_token' => getSetting('telegram_bot_token', ''),
    'telegram_chat_id' => getSetting('telegram_chat_id', ''),
    'smtp_host' => getSetting('smtp_host', ''),
    'smtp_port' => getSetting('smtp_port', '587'),
    'smtp_user' => getSetting('smtp_user', ''),
    'smtp_pass' => getSetting('smtp_pass', ''),
    'smtp_from' => getSetting('smtp_from', ''),
    'recaptcha_site_key' => getSetting('recaptcha_site_key', ''),
    'recaptcha_secret_key' => getSetting('recaptcha_secret_key', ''),
    'login_lockout_time' => getSetting('login_lockout_time', '900')
];
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Configuración - CEO SSH Panel</title>
    <link rel="icon" href="../assets/img/favicon.ico">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="../assets/css/style.css">
    <link rel="stylesheet" href="../assets/css/responsive.css">
    <script src="../assets/js/app.js" defer></script>
</head>
<body>
    <div class="app-container">
        <aside class="sidebar" id="sidebar">
            <div class="logo">
                <div class="logo-icon"><i class="fas fa-shield-alt"></i></div>
                <div class="logo-text">CEO SSH</div>
            </div>
            <nav class="sidebar-nav">
                <div class="nav-section">
                    <div class="nav-label">Principal</div>
                    <a href="dashboard.php" class="sidebar-link"><i class="fas fa-tachometer-alt"></i><span>Dashboard</span></a>
                    <a href="users.php" class="sidebar-link"><i class="fas fa-users"></i><span>Usuarios</span></a>
                </div>
                <div class="nav-section">
                    <div class="nav-label">Configuración</div>
                    <a href="profile.php" class="sidebar-link"><i class="fas fa-user"></i><span>Mi Perfil</span></a>
                    <a href="settings.php" class="sidebar-link active"><i class="fas fa-cog"></i><span>Configuración</span></a>
                    <a href="backups.php" class="sidebar-link"><i class="fas fa-database"></i><span>Backups</span></a>
                    <a href="logs.php" class="sidebar-link"><i class="fas fa-history"></i><span>Logs</span></a>
                    <a href="help.php" class="sidebar-link"><i class="fas fa-question-circle"></i><span>Ayuda</span></a>
                </div>
            </nav>
            <div class="user-info">
                <div style="display: flex; align-items: center; gap: 12px;">
                    <div class="user-avatar"><?php echo strtoupper(substr($_SESSION['username'], 0, 1)); ?></div>
                    <div class="user-details">
                        <div class="user-name"><?php echo htmlspecialchars($_SESSION['username']); ?></div>
                        <div class="user-role">Administrador</div>
                    </div>
                </div>
            </div>
        </aside>
        
        <main class="main-content" id="mainContent">
            <header class="header">
                <div class="header-left">
                    <button class="toggle-sidebar" onclick="toggleSidebar()"><i class="fas fa-bars"></i></button>
                    <div class="page-title">
                        <h1>Configuración</h1>
                        <p>Configuración general del panel</p>
                    </div>
                </div>
                <div class="header-right">
                    <button class="theme-toggle" onclick="toggleTheme()"><i class="fas fa-moon" id="themeIcon"></i></button>
                    <div class="user-dropdown">
                        <button class="user-btn" onclick="toggleDropdown('userDropdown')">
                            <div class="user-avatar-small"><?php echo strtoupper(substr($_SESSION['username'], 0, 1)); ?></div>
                            <span class="user-name-small"><?php echo htmlspecialchars($_SESSION['username']); ?></span>
                            <i class="fas fa-chevron-down"></i>
                        </button>
                        <div class="dropdown-menu" id="userDropdown">
                            <a href="profile.php" class="dropdown-item"><i class="fas fa-user"></i><span>Mi Perfil</span></a>
                            <div class="dropdown-divider"></div>
                            <a href="../api/auth.php?action=logout" class="dropdown-item"><i class="fas fa-sign-out-alt"></i><span>Cerrar Sesión</span></a>
                        </div>
                    </div>
                </div>
            </header>
            
            <div class="content">
                <?php if ($message): ?>
                    <div style="background: var(--success); color: white; padding: 12px 16px; border-radius: 12px; margin-bottom: 20px;">
                        <i class="fas fa-check-circle"></i> <?php echo $message; ?>
                    </div>
                <?php endif; ?>
                
                <div class="row">
                    <!-- Configuración General -->
                    <div class="col-12">
                        <div class="card">
                            <div class="card-header">
                                <h3 class="card-title"><i class="fas fa-globe"></i> Configuración General</h3>
                            </div>
                            <div class="card-body">
                                <form method="POST">
                                    <input type="hidden" name="action" value="save_general">
                                    <div class="row">
                                        <div class="col-12 col-md-6">
                                            <div class="form-group">
                                                <label class="form-label">Nombre del Panel</label>
                                                <input type="text" name="panel_name" class="form-control" value="<?php echo htmlspecialchars($settings['panel_name']); ?>">
                                            </div>
                                        </div>
                                        <div class="col-12 col-md-6">
                                            <div class="form-group">
                                                <label class="form-label">Modo Mantenimiento</label>
                                                <select name="maintenance_mode" class="form-control">
                                                    <option value="0" <?php echo $settings['maintenance_mode'] == '0' ? 'selected' : ''; ?>>Desactivado</option>
                                                    <option value="1" <?php echo $settings['maintenance_mode'] == '1' ? 'selected' : ''; ?>>Activado</option>
                                                </select>
                                            </div>
                                        </div>
                                        <div class="col-12 col-md-4">
                                            <div class="form-group">
                                                <label class="form-label">Tiempo de Sesión (segundos)</label>
                                                <input type="number" name="session_timeout" class="form-control" value="<?php echo $settings['session_timeout']; ?>">
                                            </div>
                                        </div>
                                        <div class="col-12 col-md-4">
                                            <div class="form-group">
                                                <label class="form-label">Días expiración por defecto</label>
                                                <input type="number" name="default_expiration_days" class="form-control" value="<?php echo $settings['default_expiration_days']; ?>">
                                            </div>
                                        </div>
                                        <div class="col-12 col-md-4">
                                            <div class="form-group">
                                                <label class="form-label">Intentos máximos de login</label>
                                                <input type="number" name="max_login_attempts" class="form-control" value="<?php echo $settings['max_login_attempts']; ?>">
                                            </div>
                                        </div>
                                    </div>
                                    <button type="submit" class="btn btn-primary"><i class="fas fa-save"></i> Guardar Configuración</button>
                                </form>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Configuración de Notificaciones -->
                    <div class="col-12 col-md-6">
                        <div class="card">
                            <div class="card-header">
                                <h3 class="card-title"><i class="fas fa-bell"></i> Notificaciones</h3>
                            </div>
                            <div class="card-body">
                                <form method="POST">
                                    <input type="hidden" name="action" value="save_notifications">
                                    <div class="form-group">
                                        <label class="form-label">Habilitar Notificaciones</label>
                                        <select name="notifications_enabled" class="form-control">
                                            <option value="1" <?php echo $settings['notifications_enabled'] == '1' ? 'selected' : ''; ?>>Activado</option>
                                            <option value="0" <?php echo $settings['notifications_enabled'] == '0' ? 'selected' : ''; ?>>Desactivado</option>
                                        </select>
                                    </div>
                                    <h4 style="margin: 20px 0 10px;">Telegram</h4>
                                    <div class="form-group">
                                        <label class="form-label">Bot Token</label>
                                        <input type="text" name="telegram_bot_token" class="form-control" value="<?php echo htmlspecialchars($settings['telegram_bot_token']); ?>" placeholder="1234567890:ABCdefGHIjklmNOPqrstUVwxyz">
                                    </div>
                                    <div class="form-group">
                                        <label class="form-label">Chat ID</label>
                                        <input type="text" name="telegram_chat_id" class="form-control" value="<?php echo htmlspecialchars($settings['telegram_chat_id']); ?>" placeholder="-1001234567890">
                                    </div>
                                    <h4 style="margin: 20px 0 10px;">Email (SMTP)</h4>
                                    <div class="form-group">
                                        <label class="form-label">Servidor SMTP</label>
                                        <input type="text" name="smtp_host" class="form-control" value="<?php echo htmlspecialchars($settings['smtp_host']); ?>" placeholder="smtp.gmail.com">
                                    </div>
                                    <div class="row">
                                        <div class="col-6">
                                            <div class="form-group">
                                                <label class="form-label">Puerto</label>
                                                <input type="text" name="smtp_port" class="form-control" value="<?php echo $settings['smtp_port']; ?>" placeholder="587">
                                            </div>
                                        </div>
                                        <div class="col-6">
                                            <div class="form-group">
                                                <label class="form-label">Email remitente</label>
                                                <input type="email" name="smtp_from" class="form-control" value="<?php echo htmlspecialchars($settings['smtp_from']); ?>" placeholder="admin@dominio.com">
                                            </div>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label class="form-label">Usuario SMTP</label>
                                        <input type="text" name="smtp_user" class="form-control" value="<?php echo htmlspecialchars($settings['smtp_user']); ?>">
                                    </div>
                                    <div class="form-group">
                                        <label class="form-label">Contraseña SMTP</label>
                                        <input type="password" name="smtp_pass" class="form-control" value="<?php echo htmlspecialchars($settings['smtp_pass']); ?>">
                                    </div>
                                    <button type="submit" class="btn btn-primary"><i class="fas fa-save"></i> Guardar Notificaciones</button>
                                </form>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Configuración de Seguridad -->
                    <div class="col-12 col-md-6">
                        <div class="card">
                            <div class="card-header">
                                <h3 class="card-title"><i class="fas fa-shield-alt"></i> Seguridad</h3>
                            </div>
                            <div class="card-body">
                                <form method="POST">
                                    <input type="hidden" name="action" value="save_security">
                                    <div class="form-group">
                                        <label class="form-label">Tiempo de bloqueo (segundos)</label>
                                        <input type="number" name="login_lockout_time" class="form-control" value="<?php echo $settings['login_lockout_time']; ?>">
                                    </div>
                                    <h4 style="margin: 20px 0 10px;">reCAPTCHA</h4>
                                    <div class="form-group">
                                        <label class="form-label">Site Key</label>
                                        <input type="text" name="recaptcha_site_key" class="form-control" value="<?php echo htmlspecialchars($settings['recaptcha_site_key']); ?>">
                                    </div>
                                    <div class="form-group">
                                        <label class="form-label">Secret Key</label>
                                        <input type="text" name="recaptcha_secret_key" class="form-control" value="<?php echo htmlspecialchars($settings['recaptcha_secret_key']); ?>">
                                    </div>
                                    <button type="submit" class="btn btn-primary"><i class="fas fa-save"></i> Guardar Seguridad</button>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </main>
    </div>
</body>
</html>