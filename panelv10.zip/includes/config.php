<?php
// ==============================================
// CEO SSH PANEL - CONFIGURACIÓN PRINCIPAL
// Versión: 2.0.0
// ==============================================

// Error Reporting
error_reporting(E_ALL);
ini_set('display_errors', 0);
ini_set('log_errors', 1);
ini_set('error_log', '/var/log/ceo-ssh-php.log');

// Timezone
date_default_timezone_set('America/Mexico_City');

// Session Configuration
ini_set('session.cookie_httponly', 1);
ini_set('session.use_only_cookies', 1);
ini_set('session.cookie_secure', 0);
ini_set('session.cookie_samesite', 'Strict');
session_name('CEO_SSH_SESSION');
session_start();

// Database Configuration
define('DB_HOST', 'localhost');
define('DB_USER', 'ceo_ssh');
define('DB_PASS', 'DB_PASS_PLACEHOLDER');
define('DB_NAME', 'ceo_ssh');

// Security Keys
define('JWT_SECRET', 'JWT_SECRET_PLACEHOLDER');
define('ENCRYPTION_KEY', 'ENCRYPTION_KEY_PLACEHOLDER');

// Panel Configuration
define('PANEL_NAME', 'CEO SSH');
define('PANEL_VERSION', '2.0.0');
define('PANEL_URL', 'http://' . $_SERVER['HTTP_HOST']);

// API Configuration
define('API_VERSION', 'v1');
define('API_RATE_LIMIT', 100);
define('API_RATE_WINDOW', 60);

// Session Configuration
define('SESSION_TIMEOUT', 3600);
define('MAX_LOGIN_ATTEMPTS', 5);
define('LOGIN_LOCKOUT_TIME', 900);

// SSH Configuration
define('SSH_PORT', 22);
define('DROPBEAR_PORT', 7300);
define('STUNNEL_PORT', 8000);
define('SQUID_PORT', 3128);
define('OPENVPN_PORT', 1194);
define('BADVPN_PORT', 7300);

// Rate Limiting
define('RATE_LIMIT_WINDOW', 15 * 60);
define('RATE_LIMIT_MAX_REQUESTS', 100);

// Upload Configuration
define('MAX_UPLOAD_SIZE', 10 * 1024 * 1024);
define('ALLOWED_EXTENSIONS', ['zip', 'gz', 'conf', 'txt', 'pdf']);

// Cache Configuration
define('CACHE_ENABLED', true);
define('CACHE_TTL', 300);

// Backup Configuration
define('BACKUP_PATH', '/var/backups/ceo-ssh');
define('BACKUP_KEEP_DAYS', 7);

// Initialize Database Connection
function getDB() {
    static $conn = null;
    if ($conn === null) {
        try {
            $conn = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);
            if ($conn->connect_error) {
                throw new Exception("Connection failed: " . $conn->connect_error);
            }
            $conn->set_charset("utf8mb4");
        } catch (Exception $e) {
            error_log("Database connection error: " . $e->getMessage());
            return null;
        }
    }
    return $conn;
}

// Helper Functions
function isAjax() {
    return !empty($_SERVER['HTTP_X_REQUESTED_WITH']) && 
           strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest';
}

function jsonResponse($data, $status = 200) {
    http_response_code($status);
    header('Content-Type: application/json');
    header('Access-Control-Allow-Origin: *');
    header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS');
    header('Access-Control-Allow-Headers: Content-Type, Authorization, X-Requested-With');
    echo json_encode($data);
    exit;
}

function errorResponse($message, $code = 400, $details = null) {
    $response = ['success' => false, 'error' => $message];
    if ($details) $response['details'] = $details;
    jsonResponse($response, $code);
}

function successResponse($data = null, $message = 'Success', $code = 200) {
    $response = ['success' => true, 'message' => $message];
    if ($data) $response['data'] = $data;
    jsonResponse($response, $code);
}

function getClientIP() {
    $ip = $_SERVER['REMOTE_ADDR'];
    if (isset($_SERVER['HTTP_CF_CONNECTING_IP'])) {
        $ip = $_SERVER['HTTP_CF_CONNECTING_IP'];
    } elseif (isset($_SERVER['HTTP_X_FORWARDED_FOR'])) {
        $ip = explode(',', $_SERVER['HTTP_X_FORWARDED_FOR'])[0];
    }
    return $ip;
}

function getUserAgent() {
    return $_SERVER['HTTP_USER_AGENT'] ?? 'Unknown';
}

function generateCSRFToken() {
    if (!isset($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf_token'];
}

function verifyCSRFToken($token) {
    return isset($_SESSION['csrf_token']) && hash_equals($_SESSION['csrf_token'], $token);
}

function encrypt($data) {
    $iv = random_bytes(16);
    $encrypted = openssl_encrypt($data, 'AES-256-CBC', ENCRYPTION_KEY, 0, $iv);
    return base64_encode($iv . $encrypted);
}

function decrypt($data) {
    $data = base64_decode($data);
    $iv = substr($data, 0, 16);
    $encrypted = substr($data, 16);
    return openssl_decrypt($encrypted, 'AES-256-CBC', ENCRYPTION_KEY, 0, $iv);
}

// CORS Headers
header('Access-Control-Allow-Origin: ' . PANEL_URL);
header('Access-Control-Allow-Credentials: true');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}
?>