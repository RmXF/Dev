<?php
// ==============================================
// CEO SSH PANEL - AUTENTICACIÓN
// Versión: 2.0.0
// ==============================================

require_once __DIR__ . '/config.php';
require_once __DIR__ . '/database.php';
require_once __DIR__ . '/functions.php';

// ==============================================
// FUNCIONES DE AUTENTICACIÓN
// ==============================================

function login($username, $password, $ip, $userAgent) {
    $user = getUserByUsername($username);
    
    if (!$user) {
        addLog(0, 'login_failed', "Intento de login fallido: $username", $ip, $userAgent);
        return false;
    }
    
    // Verificar intentos de login
    $attempts = db_count('logs', "action = 'login_failed' AND ip_address = ? AND created_at > DATE_SUB(NOW(), INTERVAL 15 MINUTE)", [$ip]);
    
    if ($attempts >= MAX_LOGIN_ATTEMPTS) {
        addLog($user['id'], 'login_blocked', "Demasiados intentos fallidos desde IP: $ip", $ip, $userAgent);
        return false;
    }
    
    // Verificar contraseña
    if (!password_verify($password, $user['password'])) {
        addLog($user['id'], 'login_failed', "Contraseña incorrecta para usuario: $username", $ip, $userAgent);
        return false;
    }
    
    // Verificar estado
    if ($user['status'] !== 'active') {
        addLog($user['id'], 'login_blocked', "Intento de login con cuenta {$user['status']}", $ip, $userAgent);
        return false;
    }
    
    // Iniciar sesión
    $_SESSION['user_id'] = $user['id'];
    $_SESSION['username'] = $user['username'];
    $_SESSION['email'] = $user['email'];
    $_SESSION['role'] = $user['role'];
    $_SESSION['logged_in'] = true;
    $_SESSION['login_time'] = time();
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    $_SESSION['ip_address'] = $ip;
    $_SESSION['user_agent'] = $userAgent;
    
    // Actualizar último login
    updateUser($user['id'], [
        'last_login' => date('Y-m-d H:i:s'),
        'last_ip' => $ip
    ]);
    
    addLog($user['id'], 'login', "Inicio de sesión exitoso desde IP: $ip", $ip, $userAgent);
    
    // Registrar sesión activa
    $sessionId = session_id();
    db_insert('active_sessions', [
        'id' => $sessionId,
        'user_id' => $user['id'],
        'ip_address' => $ip,
        'user_agent' => $userAgent,
        'last_activity' => time()
    ]);
    
    return true;
}

function logout() {
    if (isLoggedIn()) {
        addLog($_SESSION['user_id'], 'logout', "Cierre de sesión", getClientIP(), getUserAgent());
        
        // Eliminar sesión activa
        $sessionId = session_id();
        db_delete('active_sessions', 'id = ?', [$sessionId]);
    }
    
    $_SESSION = [];
    
    if (isset($_COOKIE[session_name()])) {
        setcookie(session_name(), '', time() - 3600, '/');
    }
    
    session_destroy();
    return true;
}

function isLoggedIn() {
    if (!isset($_SESSION['logged_in']) || !$_SESSION['logged_in']) {
        return false;
    }
    
    // Verificar timeout
    if (isset($_SESSION['login_time']) && (time() - $_SESSION['login_time']) > SESSION_TIMEOUT) {
        logout();
        return false;
    }
    
    // Verificar que el usuario aún existe en BD
    $user = getUserById($_SESSION['user_id']);
    if (!$user || $user['status'] !== 'active') {
        logout();
        return false;
    }
    
    // Verificar IP (opcional - seguridad extra)
    if (defined('CHECK_SESSION_IP') && CHECK_SESSION_IP && isset($_SESSION['ip_address'])) {
        if ($_SESSION['ip_address'] !== getClientIP()) {
            logout();
            return false;
        }
    }
    
    // Actualizar última actividad
    $sessionId = session_id();
    db_update('active_sessions', ['last_activity' => time()], 'id = ?', [$sessionId]);
    
    return true;
}

function requireLogin() {
    if (!isLoggedIn()) {
        header('Location: /index.php');
        exit;
    }
}

function isAdmin() {
    return isLoggedIn() && ($_SESSION['role'] === 'admin');
}

function requireAdmin() {
    requireLogin();
    if (!isAdmin()) {
        if (isAjax()) {
            errorResponse('No tienes permisos para realizar esta acción', 403);
        } else {
            header('HTTP/1.0 403 Forbidden');
            die('<h1>Acceso Denegado</h1><p>No tienes permisos para acceder a esta página.</p>');
        }
    }
}

function isReseller() {
    return isLoggedIn() && ($_SESSION['role'] === 'reseller' || $_SESSION['role'] === 'admin');
}

function hasPermission($requiredRole) {
    if (!isLoggedIn()) return false;
    
    $roles = ['user' => 1, 'reseller' => 2, 'admin' => 3];
    $userRole = $roles[$_SESSION['role']] ?? 0;
    $required = $roles[$requiredRole] ?? 0;
    
    return $userRole >= $required;
}

function verifyAPIKey($apiKey) {
    $user = getUserByApiKey($apiKey);
    if ($user && $user['status'] === 'active') {
        return $user;
    }
    return false;
}

function regenerateAPIKey($userId) {
    $newApiKey = bin2hex(random_bytes(32));
    updateUser($userId, ['api_key' => $newApiKey]);
    return $newApiKey;
}

function checkTwoFactor($code) {
    if (!isset($_SESSION['2fa_secret'])) {
        return true;
    }
    
    // Implementar verificación de 2FA aquí
    // Por ahora, siempre retorna true
    return true;
}

function getActiveSessions($userId = null) {
    $userId = $userId ?? ($_SESSION['user_id'] ?? 0);
    return db_select(
        "SELECT id, ip_address, user_agent, last_activity FROM active_sessions 
         WHERE user_id = ? ORDER BY last_activity DESC",
        [$userId]
    );
}

function terminateSession($sessionId, $userId = null) {
    $userId = $userId ?? ($_SESSION['user_id'] ?? 0);
    return db_delete('active_sessions', 'id = ? AND user_id = ?', [$sessionId, $userId]);
}

function terminateAllOtherSessions($currentSessionId, $userId = null) {
    $userId = $userId ?? ($_SESSION['user_id'] ?? 0);
    return db_delete('active_sessions', 'id != ? AND user_id = ?', [$currentSessionId, $userId]);
}

// ==============================================
// MIDDLEWARE FUNCTIONS
// ==============================================

function rateLimit($key, $limit = 100, $window = 3600) {
    $file = sys_get_temp_dir() . "/rate_limit_" . md5($key);
    $data = @json_decode(file_get_contents($file), true);
    
    if (!$data) {
        $data = ['count' => 1, 'reset' => time() + $window];
    } elseif (time() > $data['reset']) {
        $data = ['count' => 1, 'reset' => time() + $window];
    } else {
        $data['count']++;
    }
    
    file_put_contents($file, json_encode($data));
    
    if ($data['count'] > $limit) {
        header('X-RateLimit-Limit: ' . $limit);
        header('X-RateLimit-Reset: ' . $data['reset']);
        header('X-RateLimit-Remaining: 0');
        return false;
    }
    
    header('X-RateLimit-Limit: ' . $limit);
    header('X-RateLimit-Reset: ' . $data['reset']);
    header('X-RateLimit-Remaining: ' . ($limit - $data['count']));
    
    return true;
}

function csrfProtection() {
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        if (!isset($_POST['csrf_token']) || !verifyCSRFToken($_POST['csrf_token'])) {
            if (isAjax()) {
                errorResponse('CSRF token inválido', 403);
            } else {
                die('CSRF token inválido');
            }
        }
    }
}

function sanitizeInput($data) {
    if (is_array($data)) {
        return array_map('sanitizeInput', $data);
    }
    return htmlspecialchars(trim($data), ENT_QUOTES, 'UTF-8');
}
?>