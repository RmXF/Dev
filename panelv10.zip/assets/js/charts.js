// ==============================================
// CEO SSH PANEL - CHARTS JS
// Todas las gráficas del panel
// ==============================================

// Almacenar instancias de gráficas
const chartInstances = {};

// ==============================================
// COLORES POR TEMA
// ==============================================

function getChartColors() {
    const isDark = document.body.classList.contains('light') ? false : true;
    
    return {
        primary: '#0087ff',
        primaryLight: 'rgba(0, 135, 255, 0.1)',
        secondary: '#f59e0b',
        secondaryLight: 'rgba(245, 158, 11, 0.1)',
        success: '#10b981',
        successLight: 'rgba(16, 185, 129, 0.1)',
        error: '#ef4444',
        errorLight: 'rgba(239, 68, 68, 0.1)',
        warning: '#f59e0b',
        warningLight: 'rgba(245, 158, 11, 0.1)',
        grid: isDark ? '#27272a' : '#e4e4e7',
        text: isDark ? '#a1a1aa' : '#3f3f46',
        textLight: isDark ? '#71717a' : '#a1a1aa'
    };
}

// ==============================================
// CONFIGURACIÓN BASE DE GRÁFICAS
// ==============================================

function getBaseChartOptions(title, showLegend = true) {
    const colors = getChartColors();
    
    return {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
            legend: {
                display: showLegend,
                position: 'top',
                labels: {
                    color: colors.text,
                    font: { size: 12, family: "'Inter', sans-serif" },
                    usePointStyle: true,
                    boxWidth: 8
                }
            },
            tooltip: {
                mode: 'index',
                intersect: false,
                backgroundColor: document.body.classList.contains('light') ? '#ffffff' : '#1e1e2e',
                titleColor: document.body.classList.contains('light') ? '#18181b' : '#ffffff',
                bodyColor: document.body.classList.contains('light') ? '#3f3f46' : '#a1a1aa',
                borderColor: colors.grid,
                borderWidth: 1,
                padding: 10,
                cornerRadius: 8,
                titleFont: { size: 13, weight: 'bold' },
                bodyFont: { size: 12 },
                callbacks: {
                    label: function(context) {
                        let label = context.dataset.label || '';
                        if (label) label += ': ';
                        label += context.parsed.y;
                        return label;
                    }
                }
            }
        },
        scales: {
            y: {
                beginAtZero: true,
                grid: {
                    color: colors.grid,
                    drawBorder: false,
                    drawTicks: true
                },
                ticks: {
                    color: colors.text,
                    font: { size: 11 },
                    stepSize: 1,
                    callback: function(value) {
                        return value;
                    }
                },
                title: {
                    display: true,
                    text: title,
                    color: colors.textLight,
                    font: { size: 11 }
                }
            },
            x: {
                grid: {
                    display: false,
                    drawBorder: false
                },
                ticks: {
                    color: colors.text,
                    font: { size: 11 },
                    maxRotation: 45,
                    minRotation: 45
                }
            }
        },
        interaction: {
            mode: 'nearest',
            axis: 'x',
            intersect: false
        },
        elements: {
            line: {
                tension: 0.4,
                borderWidth: 2,
                fill: true
            },
            point: {
                radius: 3,
                hoverRadius: 6,
                borderWidth: 2,
                borderColor: document.body.classList.contains('light') ? '#ffffff' : '#1e1e2e'
            }
        }
    };
}

// ==============================================
// GRÁFICA DE LÍNEAS
// ==============================================

function createLineChart(canvasId, data, title, showLegend = true) {
    if (chartInstances[canvasId]) {
        chartInstances[canvasId].destroy();
    }
    
    const canvas = document.getElementById(canvasId);
    if (!canvas) return null;
    
    if (typeof Chart === 'undefined') {
        setTimeout(() => createLineChart(canvasId, data, title, showLegend), 500);
        return null;
    }
    
    const colors = getChartColors();
    const ctx = canvas.getContext('2d');
    
    const chartData = {
        labels: data.labels,
        datasets: [{
            label: data.label,
            data: data.values,
            borderColor: colors.primary,
            backgroundColor: colors.primaryLight,
            borderWidth: 2,
            fill: true,
            tension: 0.4,
            pointBackgroundColor: colors.primary,
            pointBorderColor: document.body.classList.contains('light') ? '#ffffff' : '#1e1e2e',
            pointRadius: 4,
            pointHoverRadius: 6
        }]
    };
    
    chartInstances[canvasId] = new Chart(ctx, {
        type: 'line',
        data: chartData,
        options: getBaseChartOptions(title, showLegend)
    });
    
    return chartInstances[canvasId];
}

// ==============================================
// GRÁFICA DE BARRAS
// ==============================================

function createBarChart(canvasId, data, title, showLegend = true) {
    if (chartInstances[canvasId]) {
        chartInstances[canvasId].destroy();
    }
    
    const canvas = document.getElementById(canvasId);
    if (!canvas) return null;
    
    if (typeof Chart === 'undefined') {
        setTimeout(() => createBarChart(canvasId, data, title, showLegend), 500);
        return null;
    }
    
    const colors = getChartColors();
    const ctx = canvas.getContext('2d');
    
    const datasets = data.datasets || [{
        label: data.label,
        data: data.values,
        backgroundColor: colors.primary,
        borderRadius: 8,
        barPercentage: 0.7,
        categoryPercentage: 0.8
    }];
    
    chartInstances[canvasId] = new Chart(ctx, {
        type: 'bar',
        data: {
            labels: data.labels,
            datasets: datasets
        },
        options: {
            ...getBaseChartOptions(title, showLegend),
            scales: {
                ...getBaseChartOptions(title, showLegend).scales,
                y: {
                    ...getBaseChartOptions(title, showLegend).scales.y,
                    beginAtZero: true,
                    grid: { color: colors.grid },
                    ticks: { color: colors.text }
                }
            }
        }
    });
    
    return chartInstances[canvasId];
}

// ==============================================
// GRÁFICA DE DONA
// ==============================================

function createDoughnutChart(canvasId, data, title) {
    if (chartInstances[canvasId]) {
        chartInstances[canvasId].destroy();
    }
    
    const canvas = document.getElementById(canvasId);
    if (!canvas) return null;
    
    if (typeof Chart === 'undefined') {
        setTimeout(() => createDoughnutChart(canvasId, data, title), 500);
        return null;
    }
    
    const colors = getChartColors();
    const ctx = canvas.getContext('2d');
    
    const colorPalette = [
        colors.primary,
        colors.secondary,
        colors.success,
        colors.warning,
        colors.error,
        '#8b5cf6',
        '#ec4899',
        '#06b6d4'
    ];
    
    const chartData = {
        labels: data.labels,
        datasets: [{
            data: data.values,
            backgroundColor: colorPalette.slice(0, data.labels.length),
            borderWidth: 0,
            hoverOffset: 10
        }]
    };
    
    chartInstances[canvasId] = new Chart(ctx, {
        type: 'doughnut',
        data: chartData,
        options: {
            responsive: true,
            maintainAspectRatio: false,
            cutout: '60%',
            plugins: {
                legend: {
                    position: 'bottom',
                    labels: {
                        color: colors.text,
                        font: { size: 12 },
                        usePointStyle: true,
                        boxWidth: 8,
                        padding: 15
                    }
                },
                tooltip: {
                    backgroundColor: document.body.classList.contains('light') ? '#ffffff' : '#1e1e2e',
                    titleColor: document.body.classList.contains('light') ? '#18181b' : '#ffffff',
                    bodyColor: document.body.classList.contains('light') ? '#3f3f46' : '#a1a1aa',
                    borderColor: colors.grid,
                    borderWidth: 1,
                    callbacks: {
                        label: function(context) {
                            const label = context.label || '';
                            const value = context.parsed || 0;
                            const total = context.dataset.data.reduce((a, b) => a + b, 0);
                            const percentage = ((value / total) * 100).toFixed(1);
                            return `${label}: ${value} (${percentage}%)`;
                        }
                    }
                }
            }
        }
    });
    
    return chartInstances[canvasId];
}

// ==============================================
// GRÁFICA DE ÁREA
// ==============================================

function createAreaChart(canvasId, data, title) {
    if (chartInstances[canvasId]) {
        chartInstances[canvasId].destroy();
    }
    
    const canvas = document.getElementById(canvasId);
    if (!canvas) return null;
    
    if (typeof Chart === 'undefined') {
        setTimeout(() => createAreaChart(canvasId, data, title), 500);
        return null;
    }
    
    const colors = getChartColors();
    const ctx = canvas.getContext('2d');
    
    chartInstances[canvasId] = new Chart(ctx, {
        type: 'line',
        data: {
            labels: data.labels,
            datasets: [{
                label: data.label,
                data: data.values,
                borderColor: colors.primary,
                backgroundColor: colors.primaryLight,
                borderWidth: 0,
                fill: true,
                tension: 0.4
            }]
        },
        options: {
            ...getBaseChartOptions(title, true),
            elements: {
                point: {
                    radius: 0,
                    hoverRadius: 6
                }
            }
        }
    });
    
    return chartInstances[canvasId];
}

// ==============================================
// ACTUALIZAR GRÁFICAS POR TEMA
// ==============================================

function updateChartsTheme() {
    const colors = getChartColors();
    
    Object.keys(chartInstances).forEach(canvasId => {
        const chart = chartInstances[canvasId];
        if (chart && chart.config) {
            // Actualizar colores de los datasets
            if (chart.config.data.datasets) {
                chart.config.data.datasets.forEach(dataset => {
                    if (dataset.borderColor && typeof dataset.borderColor === 'string') {
                        if (dataset.borderColor.includes('#0087ff')) {
                            dataset.borderColor = colors.primary;
                            dataset.backgroundColor = colors.primaryLight;
                        }
                        if (dataset.borderColor.includes('#f59e0b')) {
                            dataset.borderColor = colors.secondary;
                            dataset.backgroundColor = colors.secondaryLight;
                        }
                        if (dataset.borderColor.includes('#10b981')) {
                            dataset.borderColor = colors.success;
                            dataset.backgroundColor = colors.successLight;
                        }
                    }
                });
            }
            
            // Actualizar opciones
            if (chart.config.options) {
                if (chart.config.options.plugins?.legend?.labels) {
                    chart.config.options.plugins.legend.labels.color = colors.text;
                }
                if (chart.config.options.scales?.y?.grid) {
                    chart.config.options.scales.y.grid.color = colors.grid;
                }
                if (chart.config.options.scales?.y?.ticks) {
                    chart.config.options.scales.y.ticks.color = colors.text;
                }
                if (chart.config.options.scales?.x?.ticks) {
                    chart.config.options.scales.x.ticks.color = colors.text;
                }
            }
            
            chart.update();
        }
    });
}

// Escuchar cambios de tema
document.addEventListener('themeChanged', () => {
    updateChartsTheme();
});

// ==============================================
// DATOS DE EJEMPLO PARA GRÁFICAS
// ==============================================

function getSampleUserGrowthData() {
    return {
        labels: ['Ene', 'Feb', 'Mar', 'Abr', 'May', 'Jun', 'Jul', 'Ago', 'Sep', 'Oct', 'Nov', 'Dic'],
        values: [45, 52, 48, 60, 75, 82, 95, 110, 125, 140, 155, 170],
        label: 'Usuarios Activos'
    };
}

function getSampleServerLoadData() {
    return {
        labels: ['00:00', '02:00', '04:00', '06:00', '08:00', '10:00', '12:00', '14:00', '16:00', '18:00', '20:00', '22:00'],
        values: [0.3, 0.2, 0.2, 0.4, 0.8, 1.2, 1.5, 1.8, 1.6, 1.4, 1.0, 0.6],
        label: 'Load Average'
    };
}

function getSampleResourceUsageData() {
    return {
        labels: ['CPU', 'Memoria', 'Disco', 'Red'],
        values: [45, 62, 38, 25],
        label: 'Uso de Recursos (%)'
    };
}

// ==============================================
// EXPORTAR FUNCIONES
// ==============================================

window.createLineChart = createLineChart;
window.createBarChart = createBarChart;
window.createDoughnutChart = createDoughnutChart;
window.createAreaChart = createAreaChart;
window.updateChartsTheme = updateChartsTheme;
window.getChartColors = getChartColors;