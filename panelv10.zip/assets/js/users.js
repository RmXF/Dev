// ==============================================
// CEO SSH PANEL - USERS JS
// Gestión completa de usuarios
// ==============================================

// ==============================================
// VARIABLES GLOBALES
// ==============================================

let currentPage = 1;
let totalPages = 1;
let currentFilters = {
    search: '',
    status: 'all',
    sort: 'created_at',
    order: 'desc'
};
let selectedUsers = [];

// ==============================================
// INICIALIZACIÓN
// ==============================================

document.addEventListener('DOMContentLoaded', () => {
    if (document.getElementById('usersTable')) {
        initUsersPage();
    }
});

function initUsersPage() {
    loadUsers();
    
    // Configurar búsqueda en tiempo real
    const searchInput = document.getElementById('searchUser');
    if (searchInput) {
        let searchTimeout;
        searchInput.addEventListener('input', (e) => {
            clearTimeout(searchTimeout);
            searchTimeout = setTimeout(() => {
                currentFilters.search = e.target.value;
                currentPage = 1;
                loadUsers();
            }, 500);
        });
    }
    
    // Configurar filtro de estado
    const statusFilter = document.getElementById('statusFilter');
    if (statusFilter) {
        statusFilter.addEventListener('change', (e) => {
            currentFilters.status = e.target.value;
            currentPage = 1;
            loadUsers();
        });
    }
}

// ==============================================
// CARGAR USUARIOS
// ==============================================

async function loadUsers() {
    showLoading('usersTable', 'Cargando usuarios...');
    
    try {
        const params = new URLSearchParams({
            page: currentPage,
            search: currentFilters.search,
            status: currentFilters.status,
            sort: currentFilters.sort,
            order: currentFilters.order
        });
        
        const response = await fetch(`/api/users.php?${params}`, {
            credentials: 'include'
        });
        const data = await response.json();
        
        if (data.success) {
            renderUsersTable(data.data.users);
            renderPagination(data.data.pagination);
            updateUserStats(data.data.stats);
        } else {
            showToast(data.error || 'Error al cargar usuarios', 'error');
        }
    } catch (error) {
        console.error('Error loading users:', error);
        showToast('Error de conexión', 'error');
    } finally {
        hideLoading('usersTable');
    }
}

// ==============================================
// RENDERIZAR TABLA DE USUARIOS
// ==============================================

function renderUsersTable(users) {
    const container = document.getElementById('usersTable');
    if (!container) return;
    
    if (!users || users.length === 0) {
        container.innerHTML = `
            <div class="empty-state">
                <i class="fas fa-users-slash"></i>
                <h3>No hay usuarios</h3>
                <p>No se encontraron usuarios con los filtros aplicados</p>
                <button class="btn btn-primary" onclick="openModal('createUserModal')">
                    <i class="fas fa-plus"></i> Crear primer usuario
                </button>
            </div>
        `;
        return;
    }
    
    const tableHtml = `
        <table class="data-table">
            <thead>
                <tr>
                    <th width="40">
                        <input type="checkbox" id="selectAll" onchange="toggleSelectAll()">
                    </th>
                    <th>Usuario</th>
                    <th>Contraseña</th>
                    <th>Expiración</th>
                    <th>Estado</th>
                    <th>Uso</th>
                    <th>Último acceso</th>
                    <th>Acciones</th>
                </tr>
            </thead>
            <tbody>
                ${users.map(user => renderUserRow(user)).join('')}
            </tbody>
        </table>
    `;
    
    container.innerHTML = tableHtml;
    
    // Inicializar tooltips
    initTooltips();
}

function renderUserRow(user) {
    const statusClass = user.status === 'active' ? 'success' : (user.status === 'expired' ? 'error' : 'warning');
    const statusText = user.status === 'active' ? 'Activo' : (user.status === 'expired' ? 'Expirado' : 'Suspendido');
    const trafficPercent = user.traffic_limit ? ((user.traffic_used / user.traffic_limit) * 100).toFixed(1) : 0;
    const daysLeft = Math.ceil((new Date(user.expires_at) - new Date()) / (1000 * 60 * 60 * 24));
    
    return `
        <tr>
            <td>
                <input type="checkbox" class="user-checkbox" value="${user.id}" onchange="updateSelectedUsers()">
            </td>
            <td>
                <div class="user-info">
                    <div class="user-avatar-mini">${user.username.charAt(0).toUpperCase()}</div>
                    <div>
                        <div class="user-name">${escapeHtml(user.username)}</div>
                        <div class="user-id">ID: ${user.id}</div>
                    </div>
                </div>
            </td>
            <td>
                <div class="password-cell">
                    <code>${user.password || '••••••••'}</code>
                    <button class="btn-icon" onclick="copyToClipboard('${user.password}')" data-tooltip="Copiar contraseña">
                        <i class="fas fa-copy"></i>
                    </button>
                </div>
            </td>
            <td>
                <div class="expiration-cell">
                    <span>${formatDate(user.expires_at)}</span>
                    ${daysLeft < 7 ? `<span class="expiration-badge ${daysLeft <= 0 ? 'expired' : 'warning'}">
                        ${daysLeft <= 0 ? 'Expirado' : `${daysLeft} días`}
                    </span>` : ''}
                </div>
            </td>
            <td>
                <span class="status-badge status-${statusClass}">${statusText}</span>
            </td>
            <td>
                <div class="usage-cell">
                    <div class="usage-bar">
                        <div class="usage-progress" style="width: ${trafficPercent}%"></div>
                    </div>
                    <span class="usage-text">${formatBytes(user.traffic_used)} / ${user.traffic_limit ? formatBytes(user.traffic_limit) : '∞'}</span>
                </div>
            </td>
            <td>
                <div class="last-login">
                    ${user.last_login ? formatRelativeTime(user.last_login) : 'Nunca'}
                </div>
            </td>
            <td>
                <div class="action-buttons">
                    <button class="btn-icon" onclick="extendUser(${user.id})" data-tooltip="Extender">
                        <i class="fas fa-calendar-plus"></i>
                    </button>
                    <button class="btn-icon" onclick="showUserDetails(${user.id})" data-tooltip="Detalles">
                        <i class="fas fa-info-circle"></i>
                    </button>
                    <button class="btn-icon danger" onclick="deleteUser(${user.id}, '${user.username}')" data-tooltip="Eliminar">
                        <i class="fas fa-trash"></i>
                    </button>
                </div>
            </td>
        </tr>
    `;
}

// ==============================================
// PAGINACIÓN
// ==============================================

function renderPagination(pagination) {
    const container = document.getElementById('pagination');
    if (!container) return;
    
    totalPages = pagination.total_pages;
    currentPage = pagination.current_page;
    
    if (totalPages <= 1) {
        container.innerHTML = '';
        return;
    }
    
    let pages = [];
    const maxVisible = 5;
    let startPage = Math.max(1, currentPage - Math.floor(maxVisible / 2));
    let endPage = Math.min(totalPages, startPage + maxVisible - 1);
    
    if (endPage - startPage + 1 < maxVisible) {
        startPage = Math.max(1, endPage - maxVisible + 1);
    }
    
    for (let i = startPage; i <= endPage; i++) {
        pages.push(i);
    }
    
    const paginationHtml = `
        <button class="pagination-btn" onclick="goToPage(1)" ${currentPage === 1 ? 'disabled' : ''}>
            <i class="fas fa-angle-double-left"></i>
        </button>
        <button class="pagination-btn" onclick="goToPage(${currentPage - 1})" ${currentPage === 1 ? 'disabled' : ''}>
            <i class="fas fa-angle-left"></i>
        </button>
        ${pages.map(page => `
            <button class="pagination-btn ${page === currentPage ? 'active' : ''}" onclick="goToPage(${page})">
                ${page}
            </button>
        `).join('')}
        <button class="pagination-btn" onclick="goToPage(${currentPage + 1})" ${currentPage === totalPages ? 'disabled' : ''}>
            <i class="fas fa-angle-right"></i>
        </button>
        <button class="pagination-btn" onclick="goToPage(${totalPages})" ${currentPage === totalPages ? 'disabled' : ''}>
            <i class="fas fa-angle-double-right"></i>
        </button>
    `;
    
    container.innerHTML = paginationHtml;
}

function goToPage(page) {
    if (page < 1 || page > totalPages || page === currentPage) return;
    currentPage = page;
    loadUsers();
}

// ==============================================
// CREAR USUARIO
// ==============================================

async function createUser() {
    const username = document.getElementById('username')?.value;
    const password = document.getElementById('password')?.value;
    const days = document.getElementById('days')?.value;
    const trafficLimit = document.getElementById('trafficLimit')?.value;
    
    if (!username || !password) {
        showToast('Complete todos los campos requeridos', 'error');
        return;
    }
    
    if (password.length < 6) {
        showToast('La contraseña debe tener al menos 6 caracteres', 'error');
        return;
    }
    
    showLoading('createUserBtn', 'Creando...');
    
    try {
        const response = await fetch('/api/users.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'X-Requested-With': 'XMLHttpRequest'
            },
            body: JSON.stringify({
                action: 'create',
                username: username,
                password: password,
                days: parseInt(days),
                traffic_limit: trafficLimit ? parseInt(trafficLimit) * 1024 * 1024 * 1024 : null
            }),
            credentials: 'include'
        });
        
        const data = await response.json();
        
        if (data.success) {
            showToast(`Usuario ${username} creado exitosamente`, 'success');
            closeModal('createUserModal');
            resetCreateUserForm();
            loadUsers();
            
            // Mostrar credenciales
            showUserCredentials(data.data);
        } else {
            showToast(data.error || 'Error al crear usuario', 'error');
        }
    } catch (error) {
        console.error('Error creating user:', error);
        showToast('Error de conexión', 'error');
    } finally {
        hideLoading('createUserBtn');
    }
}

function resetCreateUserForm() {
    const form = document.getElementById('createUserForm');
    if (form) form.reset();
}

function showUserCredentials(user) {
    const modal = document.createElement('div');
    modal.className = 'modal show';
    modal.innerHTML = `
        <div class="modal-content" style="max-width: 450px;">
            <div class="modal-header">
                <h3><i class="fas fa-check-circle" style="color: var(--success);"></i> Usuario Creado</h3>
                <button class="modal-close" onclick="this.closest('.modal').remove()">&times;</button>
            </div>
            <div class="modal-body">
                <p>Usuario creado exitosamente. Guarda estas credenciales:</p>
                <div style="background: var(--bg-tertiary); padding: 15px; border-radius: 12px; margin: 15px 0;">
                    <div><strong>Usuario:</strong> <code>${escapeHtml(user.username)}</code></div>
                    <div><strong>Contraseña:</strong> <code>${escapeHtml(user.password)}</code></div>
                    <div><strong>Expira:</strong> ${formatDate(user.expires_at)}</div>
                </div>
                <div class="alert alert-info">
                    <i class="fas fa-info-circle"></i>
                    Estas credenciales no se mostrarán nuevamente.
                </div>
            </div>
            <div class="modal-footer">
                <button class="btn btn-secondary" onclick="copyToClipboard('${user.username}\\n${user.password}')">
                    <i class="fas fa-copy"></i> Copiar
                </button>
                <button class="btn btn-primary" onclick="this.closest('.modal').remove()">
                    Cerrar
                </button>
            </div>
        </div>
    `;
    document.body.appendChild(modal);
}

// ==============================================
// ELIMINAR USUARIO
// ==============================================

function deleteUser(userId, username) {
    confirmDialog(
        `¿Estás seguro de eliminar al usuario ${username}?`,
        async () => {
            try {
                const response = await fetch(`/api/users.php?id=${userId}`, {
                    method: 'DELETE',
                    credentials: 'include'
                });
                const data = await response.json();
                
                if (data.success) {
                    showToast(`Usuario ${username} eliminado`, 'success');
                    loadUsers();
                } else {
                    showToast(data.error || 'Error al eliminar usuario', 'error');
                }
            } catch (error) {
                console.error('Error deleting user:', error);
                showToast('Error de conexión', 'error');
            }
        }
    );
}

// ==============================================
// EXTENDER USUARIO
// ==============================================

function extendUser(userId) {
    const days = prompt('¿Cuántos días deseas agregar?', '30');
    if (!days || isNaN(days) || days <= 0) return;
    
    showLoading(`extendBtn-${userId}`, 'Extendiendo...');
    
    fetch('/api/users.php', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
            'X-Requested-With': 'XMLHttpRequest'
        },
        body: JSON.stringify({
            action: 'extend',
            user_id: userId,
            days: parseInt(days)
        }),
        credentials: 'include'
    })
    .then(response => response.json())
    .then(data => {
        hideLoading(`extendBtn-${userId}`);
        if (data.success) {
            showToast(`Usuario extendido ${days} días`, 'success');
            loadUsers();
        } else {
            showToast(data.error || 'Error al extender usuario', 'error');
        }
    })
    .catch(error => {
        hideLoading(`extendBtn-${userId}`);
        showToast('Error de conexión', 'error');
    });
}

// ==============================================
// DETALLES DEL USUARIO
// ==============================================

async function showUserDetails(userId) {
    try {
        const response = await fetch(`/api/users.php?id=${userId}&details=1`, {
            credentials: 'include'
        });
        const data = await response.json();
        
        if (data.success) {
            renderUserDetailsModal(data.data);
        }
    } catch (error) {
        console.error('Error loading user details:', error);
        showToast('Error al cargar detalles', 'error');
    }
}

function renderUserDetailsModal(user) {
    const modal = document.createElement('div');
    modal.className = 'modal show';
    modal.innerHTML = `
        <div class="modal-content" style="max-width: 600px;">
            <div class="modal-header">
                <h3><i class="fas fa-user"></i> Detalles del Usuario</h3>
                <button class="modal-close" onclick="this.closest('.modal').remove()">&times;</button>
            </div>
            <div class="modal-body">
                <div class="user-detail-header">
                    <div class="user-avatar-large">${user.username.charAt(0).toUpperCase()}</div>
                    <div>
                        <h2>${escapeHtml(user.username)}</h2>
                        <p>ID: ${user.id} | Creado: ${formatDate(user.created_at)}</p>
                    </div>
                </div>
                
                <div class="detail-section">
                    <h4>Información de la Cuenta</h4>
                    <div class="detail-grid">
                        <div><strong>Estado:</strong> <span class="status-badge status-${user.status === 'active' ? 'success' : 'error'}">${user.status}</span></div>
                        <div><strong>Expiración:</strong> ${formatDate(user.expires_at)}</div>
                        <div><strong>Días restantes:</strong> ${Math.ceil((new Date(user.expires_at) - new Date()) / (1000 * 60 * 60 * 24))} días</div>
                        <div><strong>Último acceso:</strong> ${user.last_login ? formatRelativeTime(user.last_login) : 'Nunca'}</div>
                        <div><strong>Última IP:</strong> ${user.last_ip || 'N/A'}</div>
                        <div><strong>Creado por:</strong> ${user.creator || 'Sistema'}</div>
                    </div>
                </div>
                
                <div class="detail-section">
                    <h4>Uso de Tráfico</h4>
                    <div class="usage-detail">
                        <div class="usage-bar-large">
                            <div class="usage-progress" style="width: ${user.traffic_limit ? ((user.traffic_used / user.traffic_limit) * 100) : 0}%"></div>
                        </div>
                        <div class="usage-stats">
                            <span>Usado: ${formatBytes(user.traffic_used)}</span>
                            <span>Límite: ${user.traffic_limit ? formatBytes(user.traffic_limit) : 'Ilimitado'}</span>
                        </div>
                    </div>
                </div>
                
                <div class="detail-section">
                    <h4>Conexiones Activas</h4>
                    <div id="userConnections">
                        <div class="loading-spinner"><i class="fas fa-spinner fa-spin"></i> Cargando...</div>
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <button class="btn btn-warning" onclick="extendUser(${user.id}); this.closest('.modal').remove()">
                    <i class="fas fa-calendar-plus"></i> Extender
                </button>
                <button class="btn btn-danger" onclick="deleteUser(${user.id}, '${user.username}'); this.closest('.modal').remove()">
                    <i class="fas fa-trash"></i> Eliminar
                </button>
                <button class="btn btn-secondary" onclick="this.closest('.modal').remove()">
                    Cerrar
                </button>
            </div>
        </div>
    `;
    
    document.body.appendChild(modal);
    
    // Cargar conexiones activas
    loadUserConnections(user.username, modal);
}

async function loadUserConnections(username, modal) {
    try {
        const response = await fetch(`/api/users.php?action=connections&username=${username}`, {
            credentials: 'include'
        });
        const data = await response.json();
        
        const container = modal.querySelector('#userConnections');
        if (container) {
            if (data.success && data.data.length > 0) {
                container.innerHTML = `
                    <table class="mini-table">
                        <thead>
                            <tr><th>PID</th><th>Puerto</th><th>IP</th><th>Conectado desde</th></tr>
                        </thead>
                        <tbody>
                            ${data.data.map(conn => `
                                <tr>
                                    <td>${conn.pid}</td>
                                    <td>${conn.port}</td>
                                    <td>${conn.ip}</td>
                                    <td>${formatRelativeTime(conn.start_time)}</td>
                                </tr>
                            `).join('')}
                        </tbody>
                    </table>
                    <button class="btn btn-sm btn-danger" onclick="killUserConnections('${username}')">
                        <i class="fas fa-power-off"></i> Cerrar todas las conexiones
                    </button>
                `;
            } else {
                container.innerHTML = '<p class="text-muted">No hay conexiones activas</p>';
            }
        }
    } catch (error) {
        console.error('Error loading connections:', error);
    }
}

// ==============================================
// ACCIONES MASIVAS
// ==============================================

function toggleSelectAll() {
    const selectAll = document.getElementById('selectAll');
    const checkboxes = document.querySelectorAll('.user-checkbox');
    
    checkboxes.forEach(cb => {
        cb.checked = selectAll.checked;
    });
    
    updateSelectedUsers();
}

function updateSelectedUsers() {
    const checkboxes = document.querySelectorAll('.user-checkbox:checked');
    selectedUsers = Array.from(checkboxes).map(cb => cb.value);
    
    const bulkActions = document.getElementById('bulkActions');
    if (bulkActions) {
        bulkActions.style.display = selectedUsers.length > 0 ? 'flex' : 'none';
        document.getElementById('selectedCount').textContent = selectedUsers.length;
    }
}

function bulkExtend() {
    const days = prompt('¿Cuántos días agregar a los usuarios seleccionados?', '30');
    if (!days || isNaN(days) || days <= 0) return;
    
    confirmDialog(
        `¿Extender ${selectedUsers.length} usuarios por ${days} días?`,
        async () => {
            showLoading('bulkExtendBtn', 'Extendiendo...');
            
            try {
                const response = await fetch('/api/users.php?action=bulk', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                        'X-Requested-With': 'XMLHttpRequest'
                    },
                    body: JSON.stringify({
                        action: 'bulk_extend',
                        users: selectedUsers,
                        days: parseInt(days)
                    }),
                    credentials: 'include'
                });
                
                const data = await response.json();
                hideLoading('bulkExtendBtn');
                
                if (data.success) {
                    showToast(`${data.data.count} usuarios extendidos`, 'success');
                    loadUsers();
                } else {
                    showToast(data.error || 'Error al extender usuarios', 'error');
                }
            } catch (error) {
                hideLoading('bulkExtendBtn');
                showToast('Error de conexión', 'error');
            }
        }
    );
}

function bulkDelete() {
    confirmDialog(
        `¿Eliminar ${selectedUsers.length} usuarios? Esta acción no se puede deshacer.`,
        async () => {
            showLoading('bulkDeleteBtn', 'Eliminando...');
            
            try {
                const response = await fetch('/api/users.php?action=bulk', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                        'X-Requested-With': 'XMLHttpRequest'
                    },
                    body: JSON.stringify({
                        action: 'bulk_delete',
                        users: selectedUsers
                    }),
                    credentials: 'include'
                });
                
                const data = await response.json();
                hideLoading('bulkDeleteBtn');
                
                if (data.success) {
                    showToast(`${data.data.count} usuarios eliminados`, 'success');
                    loadUsers();
                } else {
                    showToast(data.error || 'Error al eliminar usuarios', 'error');
                }
            } catch (error) {
                hideLoading('bulkDeleteBtn');
                showToast('Error de conexión', 'error');
            }
        }
    );
}

// ==============================================
// ESTADÍSTICAS DE USUARIOS
// ==============================================

function updateUserStats(stats) {
    const elements = {
        'totalUsers': stats.total,
        'activeUsers': stats.active,
        'expiredUsers': stats.expired,
        'suspendedUsers': stats.suspended,
        'totalTraffic': formatBytes(stats.total_traffic)
    };
    
    for (const [id, value] of Object.entries(elements)) {
        const element = document.getElementById(id);
        if (element) {
            element.innerHTML = value;
        }
    }
}

// ==============================================
// EXPORTAR USUARIOS
// ==============================================

async function exportUsers(format = 'csv') {
    try {
        const params = new URLSearchParams({
            format: format,
            search: currentFilters.search,
            status: currentFilters.status
        });
        
        const response = await fetch(`/api/users.php?action=export&${params}`, {
            credentials: 'include'
        });
        
        if (response.ok) {
            const blob = await response.blob();
            const url = window.URL.createObjectURL(blob);
            const a = document.createElement('a');
            a.href = url;
            a.download = `usuarios_${new Date().toISOString().slice(0, 19)}.${format}`;
            document.body.appendChild(a);
            a.click();
            document.body.removeChild(a);
            window.URL.revokeObjectURL(url);
            
            showToast('Exportación completada', 'success');
        } else {
            showToast('Error al exportar', 'error');
        }
    } catch (error) {
        console.error('Error exporting users:', error);
        showToast('Error de conexión', 'error');
    }
}

// ==============================================
// KILL USER CONNECTIONS
// ==============================================

async function killUserConnections(username) {
    confirmDialog(
        `¿Cerrar todas las conexiones activas de ${username}?`,
        async () => {
            try {
                const response = await fetch('/api/users.php', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                        'X-Requested-With': 'XMLHttpRequest'
                    },
                    body: JSON.stringify({
                        action: 'kill_connections',
                        username: username
                    }),
                    credentials: 'include'
                });
                
                const data = await response.json();
                
                if (data.success) {
                    showToast(`Conexiones de ${username} cerradas`, 'success');
                    closeAllModals();
                } else {
                    showToast(data.error || 'Error al cerrar conexiones', 'error');
                }
            } catch (error) {
                showToast('Error de conexión', 'error');
            }
        }
    );
}

// ==============================================
// EXPORTAR FUNCIONES
// ==============================================

window.loadUsers = loadUsers;
window.createUser = createUser;
window.deleteUser = deleteUser;
window.extendUser = extendUser;
window.showUserDetails = showUserDetails;
window.bulkExtend = bulkExtend;
window.bulkDelete = bulkDelete;
window.exportUsers = exportUsers;
window.killUserConnections = killUserConnections;
window.goToPage = goToPage;
window.toggleSelectAll = toggleSelectAll;
window.updateSelectedUsers = updateSelectedUsers;