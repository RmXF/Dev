// ==============================================
// CEO SSH PANEL - SETTINGS JS
// Configuración del panel
// ==============================================

// ==============================================
// VARIABLES GLOBALES
// ==============================================

let settingsData = {};
let activeTab = 'general';

// ==============================================
// INICIALIZACIÓN
// ==============================================

document.addEventListener('DOMContentLoaded', () => {
    if (document.getElementById('settingsContainer')) {
        initSettings();
    }
});

function initSettings() {
    loadSettings();
    initTabs();
    initPasswordGenerator();
    initTestNotifications();
}

// ==============================================
// CARGAR CONFIGURACIÓN
// ==============================================

async function loadSettings() {
    showLoading('settingsForm', 'Cargando configuración...');
    
    try {
        const response = await fetch('/api/settings.php', {
            credentials: 'include'
        });
        const data = await response.json();
        
        if (data.success) {
            settingsData = data.data;
            populateForms(settingsData);
        } else {
            showToast(data.error || 'Error al cargar configuración', 'error');
        }
    } catch (error) {
        console.error('Error loading settings:', error);
        showToast('Error de conexión', 'error');
    } finally {
        hideLoading('settingsForm');
    }
}

function populateForms(settings) {
    // General settings
    const generalFields = ['panel_name', 'maintenance_mode', 'session_timeout', 'default_expiration_days', 'max_login_attempts'];
    generalFields.forEach(field => {
        const input = document.getElementById(field);
        if (input) input.value = settings[field] || '';
    });
    
    // Notification settings
    const notifFields = ['notifications_enabled', 'telegram_bot_token', 'telegram_chat_id', 'smtp_host', 'smtp_port', 'smtp_user', 'smtp_pass', 'smtp_from'];
    notifFields.forEach(field => {
        const input = document.getElementById(field);
        if (input) input.value = settings[field] || '';
    });
    
    // Security settings
    const securityFields = ['recaptcha_site_key', 'recaptcha_secret_key', 'login_lockout_time'];
    securityFields.forEach(field => {
        const input = document.getElementById(field);
        if (input) input.value = settings[field] || '';
    });
    
    // Update checkbox states
    document.getElementById('maintenance_mode').value = settings.maintenance_mode || '0';
    document.getElementById('notifications_enabled').value = settings.notifications_enabled || '1';
}

// ==============================================
// GUARDAR CONFIGURACIÓN
// ==============================================

async function saveSettings(formId) {
    const form = document.getElementById(formId);
    if (!form) return;
    
    const formData = new FormData(form);
    const data = {};
    
    formData.forEach((value, key) => {
        data[key] = value;
    });
    
    showLoading('saveBtn', 'Guardando...');
    
    try {
        const response = await fetch('/api/settings.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'X-Requested-With': 'XMLHttpRequest'
            },
            body: JSON.stringify(data),
            credentials: 'include'
        });
        
        const result = await response.json();
        hideLoading('saveBtn');
        
        if (result.success) {
            showToast('Configuración guardada correctamente', 'success');
            settingsData = { ...settingsData, ...data };
        } else {
            showToast(result.error || 'Error al guardar configuración', 'error');
        }
    } catch (error) {
        hideLoading('saveBtn');
        showToast('Error de conexión', 'error');
    }
}

// ==============================================
// PESTAÑAS
// ==============================================

function initTabs() {
    const tabs = document.querySelectorAll('.settings-tab');
    tabs.forEach(tab => {
        tab.addEventListener('click', () => {
            const tabId = tab.dataset.tab;
            switchTab(tabId);
        });
    });
}

function switchTab(tabId) {
    activeTab = tabId;
    
    // Update tab buttons
    document.querySelectorAll('.settings-tab').forEach(tab => {
        tab.classList.toggle('active', tab.dataset.tab === tabId);
    });
    
    // Update tab content
    document.querySelectorAll('.tab-content').forEach(content => {
        content.classList.toggle('active', content.id === `tab-${tabId}`);
    });
}

// ==============================================
// GENERADOR DE CONTRASEÑAS
// ==============================================

function initPasswordGenerator() {
    const generateBtn = document.getElementById('generatePassword');
    if (generateBtn) {
        generateBtn.addEventListener('click', generateRandomPassword);
    }
}

function generateRandomPassword() {
    const length = 12;
    const charset = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789!@#$%^&*';
    let password = '';
    
    for (let i = 0; i < length; i++) {
        const randomIndex = Math.floor(Math.random() * charset.length);
        password += charset[randomIndex];
    }
    
    const passwordInput = document.getElementById('smtp_pass');
    if (passwordInput) {
        passwordInput.value = password;
        showToast('Contraseña generada', 'success');
    }
}

// ==============================================
// PRUEBA DE NOTIFICACIONES
// ==============================================

function initTestNotifications() {
    const testTelegramBtn = document.getElementById('testTelegram');
    const testEmailBtn = document.getElementById('testEmail');
    
    if (testTelegramBtn) {
        testTelegramBtn.addEventListener('click', () => testNotification('telegram'));
    }
    
    if (testEmailBtn) {
        testEmailBtn.addEventListener('click', () => testNotification('email'));
    }
}

async function testNotification(channel) {
    showLoading(`test${channel.charAt(0).toUpperCase() + channel.slice(1)}`, 'Enviando...');
    
    try {
        const response = await fetch('/api/notifications.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'X-Requested-With': 'XMLHttpRequest'
            },
            body: JSON.stringify({
                action: 'test',
                channel: channel
            }),
            credentials: 'include'
        });
        
        const data = await response.json();
        hideLoading(`test${channel.charAt(0).toUpperCase() + channel.slice(1)}`);
        
        if (data.success) {
            showToast(`Notificación de prueba enviada por ${channel}`, 'success');
        } else {
            showToast(data.error || `Error al enviar notificación por ${channel}`, 'error');
        }
    } catch (error) {
        hideLoading(`test${channel.charAt(0).toUpperCase() + channel.slice(1)}`);
        showToast('Error de conexión', 'error');
    }
}

// ==============================================
// BACKUP
// ==============================================

async function createBackup() {
    confirmDialog(
        '¿Crear una copia de seguridad de la base de datos?',
        async () => {
            showLoading('createBackupBtn', 'Creando backup...');
            
            try {
                const response = await fetch('/api/backup.php', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                        'X-Requested-With': 'XMLHttpRequest'
                    },
                    body: JSON.stringify({ action: 'create' }),
                    credentials: 'include'
                });
                
                const data = await response.json();
                hideLoading('createBackupBtn');
                
                if (data.success) {
                    showToast('Backup creado exitosamente', 'success');
                    if (typeof loadBackups === 'function') loadBackups();
                } else {
                    showToast(data.error || 'Error al crear backup', 'error');
                }
            } catch (error) {
                hideLoading('createBackupBtn');
                showToast('Error de conexión', 'error');
            }
        }
    );
}

// ==============================================
// RESTABLECER CONFIGURACIÓN
// ==============================================

function resetSettings() {
    confirmDialog(
        '¿Restablecer toda la configuración a los valores por defecto? Esta acción no se puede deshacer.',
        async () => {
            showLoading('resetBtn', 'Restableciendo...');
            
            try {
                const response = await fetch('/api/settings.php?action=reset', {
                    method: 'POST',
                    credentials: 'include'
                });
                
                const data = await response.json();
                hideLoading('resetBtn');
                
                if (data.success) {
                    showToast('Configuración restablecida', 'success');
                    setTimeout(() => location.reload(), 1500);
                } else {
                    showToast(data.error || 'Error al restablecer', 'error');
                }
            } catch (error) {
                hideLoading('resetBtn');
                showToast('Error de conexión', 'error');
            }
        }
    );
}

// ==============================================
// VALIDACIÓN DE FORMULARIOS
// ==============================================

function validateEmail(email) {
    const re = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return re.test(email);
}

function validatePort(port) {
    const num = parseInt(port);
    return !isNaN(num) && num > 0 && num < 65536;
}

// ==============================================
// EXPORTAR FUNCIONES
// ==============================================

window.saveSettings = saveSettings;
window.switchTab = switchTab;
window.testNotification = testNotification;
window.createBackup = createBackup;
window.resetSettings = resetSettings;
window.generateRandomPassword = generateRandomPassword;