// ==============================================
// CEO SSH PANEL - NOTIFICACIONES JS
// Sistema de notificaciones en tiempo real
// ==============================================

// ==============================================
// CONFIGURACIÓN
// ==============================================

let notificationSound = null;
let notificationPermission = false;
let lastNotificationId = 0;
let notificationInterval = null;

// ==============================================
// INICIALIZACIÓN
// ==============================================

document.addEventListener('DOMContentLoaded', () => {
    initNotifications();
});

function initNotifications() {
    // Inicializar sonido
    initNotificationSound();
    
    // Solicitar permisos para notificaciones del navegador
    if ('Notification' in window) {
        if (Notification.permission === 'default') {
            // No pedir automáticamente, esperar acción del usuario
        } else if (Notification.permission === 'granted') {
            notificationPermission = true;
        }
    }
    
    // Escuchar eventos de WebSocket para notificaciones en tiempo real
    document.addEventListener('websocketConnected', () => {
        console.log('WebSocket connected for notifications');
    });
}

// ==============================================
// SONIDO DE NOTIFICACIONES
// ==============================================

function initNotificationSound() {
    try {
        notificationSound = new Audio('/assets/sounds/notification.mp3');
        notificationSound.volume = 0.5;
    } catch (error) {
        console.log('Notification sound not available');
    }
}

function playNotificationSound() {
    if (notificationSound && localStorage.getItem('notificationSound') !== 'false') {
        notificationSound.play().catch(e => console.log('Sound play failed:', e));
    }
}

// ==============================================
// NOTIFICACIONES DEL NAVEGADOR
// ==============================================

function requestNotificationPermission() {
    if ('Notification' in window && Notification.permission !== 'granted') {
        Notification.requestPermission().then(permission => {
            notificationPermission = permission === 'granted';
            if (notificationPermission) {
                showToast('Notificaciones activadas', 'success');
            }
        });
    }
}

function showBrowserNotification(title, body, icon = '/assets/img/logo.png') {
    if (notificationPermission && document.hidden) {
        const notification = new Notification(title, {
            body: body,
            icon: icon,
            silent: false
        });
        
        notification.onclick = () => {
            window.focus();
            notification.close();
        };
        
        setTimeout(() => notification.close(), 5000);
    }
}

// ==============================================
// NOTIFICACIONES EN TIEMPO REAL (WebSocket)
// ==============================================

function handleRealtimeNotification(notification) {
    // Reproducir sonido
    playNotificationSound();
    
    // Mostrar toast
    showToast(notification.message, notification.type);
    
    // Mostrar notificación del navegador si la página no está visible
    if (document.hidden) {
        showBrowserNotification(notification.title, notification.message);
    }
    
    // Actualizar badge
    updateNotificationBadge(notification.unread_count);
    
    // Actualizar lista de notificaciones
    if (document.getElementById('notificationList')) {
        addNotificationToList(notification);
    }
}

function addNotificationToList(notification) {
    const container = document.getElementById('notificationList');
    if (!container) return;
    
    const notificationHtml = `
        <div class="notification-item unread" onclick="markNotificationAsRead(${notification.id})">
            <div class="notification-icon">
                <i class="fas ${getNotificationIcon(notification.type)}"></i>
            </div>
            <div class="notification-content">
                <div class="notification-title">${escapeHtml(notification.title)}</div>
                <div class="notification-message">${escapeHtml(notification.message)}</div>
                <div class="notification-time">Ahora mismo</div>
            </div>
        </div>
    `;
    
    // Insertar al principio
    container.insertAdjacentHTML('afterbegin', notificationHtml);
    
    // Limitar número de notificaciones
    while (container.children.length > 50) {
        container.removeChild(container.lastChild);
    }
}

// ==============================================
// NOTIFICACIONES POR EMAIL
// ==============================================

async function sendEmailNotification(to, subject, message) {
    try {
        const response = await fetch('/api/notifications.php?action=email', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'X-Requested-With': 'XMLHttpRequest'
            },
            body: JSON.stringify({
                to: to,
                subject: subject,
                message: message
            }),
            credentials: 'include'
        });
        
        const data = await response.json();
        return data.success;
    } catch (error) {
        console.error('Error sending email:', error);
        return false;
    }
}

// ==============================================
// NOTIFICACIONES POR TELEGRAM
// ==============================================

async function sendTelegramNotification(chatId, message) {
    try {
        const response = await fetch('/api/notifications.php?action=telegram', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'X-Requested-With': 'XMLHttpRequest'
            },
            body: JSON.stringify({
                chat_id: chatId,
                message: message
            }),
            credentials: 'include'
        });
        
        const data = await response.json();
        return data.success;
    } catch (error) {
        console.error('Error sending Telegram notification:', error);
        return false;
    }
}

// ==============================================
// NOTIFICACIONES DE EXPIRACIÓN
// ==============================================

async function checkExpiringUsers() {
    try {
        const response = await fetch('/api/notifications.php?action=expiring', {
            credentials: 'include'
        });
        const data = await response.json();
        
        if (data.success && data.data.length > 0) {
            data.data.forEach(user => {
                const daysLeft = user.days_left;
                let message = '';
                
                if (daysLeft <= 0) {
                    message = `El usuario ${user.username} ha expirado.`;
                } else if (daysLeft <= 3) {
                    message = `El usuario ${user.username} expira en ${daysLeft} días.`;
                } else if (daysLeft <= 7) {
                    message = `El usuario ${user.username} expira en ${daysLeft} días.`;
                }
                
                if (message) {
                    showToast(message, 'warning');
                    
                    // Enviar notificación por email si está configurado
                    if (user.email) {
                        sendEmailNotification(user.email, 'Cuenta por expirar', message);
                    }
                }
            });
        }
    } catch (error) {
        console.error('Error checking expiring users:', error);
    }
}

// ==============================================
// NOTIFICACIONES DE SISTEMA
// ==============================================

async function sendSystemNotification(title, message, type = 'info', userId = null) {
    try {
        const response = await fetch('/api/notifications.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'X-Requested-With': 'XMLHttpRequest'
            },
            body: JSON.stringify({
                action: 'create',
                title: title,
                message: message,
                type: type,
                user_id: userId
            }),
            credentials: 'include'
        });
        
        const data = await response.json();
        
        if (data.success) {
            // Si es para el usuario actual, mostrar inmediatamente
            if (!userId || userId === currentUser?.id) {
                handleRealtimeNotification({
                    id: data.id,
                    title: title,
                    message: message,
                    type: type,
                    unread_count: data.unread_count
                });
            }
        }
        
        return data.success;
    } catch (error) {
        console.error('Error sending system notification:', error);
        return false;
    }
}

// ==============================================
// ALERTAS DE SEGURIDAD
// ==============================================

function showSecurityAlert(message, level = 'warning') {
    const alertColors = {
        info: 'var(--info)',
        warning: 'var(--warning)',
        error: 'var(--error)',
        success: 'var(--success)'
    };
    
    const alert = document.createElement('div');
    alert.className = `security-alert security-alert-${level}`;
    alert.style.cssText = `
        position: fixed;
        top: 20px;
        right: 20px;
        background: ${alertColors[level]};
        color: white;
        padding: 12px 20px;
        border-radius: 12px;
        z-index: 10000;
        animation: slideInRight 0.3s ease-out;
        box-shadow: 0 4px 12px rgba(0,0,0,0.15);
        max-width: 350px;
    `;
    alert.innerHTML = `
        <div style="display: flex; align-items: center; gap: 10px;">
            <i class="fas ${level === 'warning' ? 'fa-exclamation-triangle' : 'fa-shield-alt'}"></i>
            <span>${escapeHtml(message)}</span>
            <button onclick="this.parentElement.parentElement.remove()" style="background: none; border: none; color: white; cursor: pointer;">
                <i class="fas fa-times"></i>
            </button>
        </div>
    `;
    
    document.body.appendChild(alert);
    
    setTimeout(() => {
        if (alert.parentElement) alert.remove();
    }, 8000);
}

// ==============================================
// NOTIFICACIONES DE LOGIN
// ==============================================

async function notifyNewLogin(ip, location, device) {
    const message = `Nuevo inicio de sesión desde ${ip} (${location}) en ${device}`;
    
    if (currentUser?.email) {
        await sendEmailNotification(
            currentUser.email,
            'Nuevo inicio de sesión en CEO SSH',
            message
        );
    }
    
    showSecurityAlert(message, 'info');
}

// ==============================================
// CONFIGURACIÓN DE NOTIFICACIONES DEL USUARIO
// ==============================================

function saveNotificationSettings(settings) {
    localStorage.setItem('notificationSettings', JSON.stringify(settings));
}

function getNotificationSettings() {
    const defaultSettings = {
        sound: true,
        browser: true,
        email: true,
        telegram: false,
        expiring_days: 3
    };
    
    const saved = localStorage.getItem('notificationSettings');
    return saved ? JSON.parse(saved) : defaultSettings;
}

function toggleNotificationSound() {
    const settings = getNotificationSettings();
    settings.sound = !settings.sound;
    saveNotificationSettings(settings);
    
    showToast(`Sonido de notificaciones ${settings.sound ? 'activado' : 'desactivado'}`, 'success');
}

function toggleBrowserNotifications() {
    if (Notification.permission === 'granted') {
        const settings = getNotificationSettings();
        settings.browser = !settings.browser;
        saveNotificationSettings(settings);
        showToast(`Notificaciones del navegador ${settings.browser ? 'activadas' : 'desactivadas'}`, 'success');
    } else {
        requestNotificationPermission();
    }
}

// ==============================================
// INICIALIZAR VERIFICACIONES PERIÓDICAS
// ==============================================

// Verificar usuarios por expirar cada hora
if (notificationInterval) clearInterval(notificationInterval);
notificationInterval = setInterval(() => {
    checkExpiringUsers();
}, 3600000); // Cada hora

// ==============================================
// EXPORTAR FUNCIONES
// ==============================================

window.sendSystemNotification = sendSystemNotification;
window.showSecurityAlert = showSecurityAlert;
window.requestNotificationPermission = requestNotificationPermission;
window.toggleNotificationSound = toggleNotificationSound;
window.toggleBrowserNotifications = toggleBrowserNotifications;
window.checkExpiringUsers = checkExpiringUsers;
window.notifyNewLogin = notifyNewLogin;