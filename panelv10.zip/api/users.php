<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization, X-Requested-With');

require_once '../includes/config.php';
require_once '../includes/auth.php';
require_once '../includes/functions.php';

// Manejar OPTIONS para CORS
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

// Verificar autenticación
if (!isLoggedIn()) {
    errorResponse('No autorizado', 401);
}

$method = $_SERVER['REQUEST_METHOD'];

// ==============================================
// GET - Listar usuarios
// ==============================================
if ($method === 'GET') {
    $filters = [];
    
    if (isset($_GET['status'])) {
        $filters['status'] = $_GET['status'];
    }
    if (isset($_GET['search'])) {
        $filters['search'] = $_GET['search'];
    }
    if (isset($_GET['limit'])) {
        $filters['limit'] = intval($_GET['limit']);
    }
    
    $users = getSSHTokens($filters);
    successResponse($users, 'Usuarios obtenidos');
}

// ==============================================
// POST - Crear, eliminar o extender
// ==============================================
if ($method === 'POST') {
    $data = json_decode(file_get_contents('php://input'), true);
    if (!$data) {
        $data = $_POST;
    }
    
    $action = $data['action'] ?? '';
    
    // CREAR USUARIO
    if ($action === 'create') {
        if (!isAdmin()) {
            errorResponse('Se requieren permisos de administrador', 403);
        }
        
        $username = trim($data['username']);
        $password = $data['password'];
        $days = intval($data['days'] ?? 30);
        
        if (empty($username) || empty($password)) {
            errorResponse('Usuario y contraseña requeridos');
        }
        
        if (strlen($password) < 6) {
            errorResponse('La contraseña debe tener al menos 6 caracteres');
        }
        
        // Verificar si ya existe
        $existing = getSSHTokenByUsername($username);
        if ($existing) {
            errorResponse('El usuario ya existe');
        }
        
        $expireDate = date('Y-m-d', strtotime("+$days days"));
        
        // Crear en sistema
        $created = createSystemUser($username, $password, $expireDate);
        
        if (!$created) {
            errorResponse('Error al crear usuario en el sistema');
        }
        
        // Guardar en BD
        $tokenId = createSSHToken([
            'username' => $username,
            'password' => $password,
            'expires_at' => $expireDate,
            'created_by' => $_SESSION['user_id']
        ]);
        
        if ($tokenId) {
            addLog($_SESSION['user_id'], 'create_user', "Creado usuario SSH: $username", getClientIP(), getUserAgent());
            addNotification($_SESSION['user_id'], 'Usuario Creado', "Se ha creado el usuario $username con expiración en $days días", 'success');
            
            successResponse([
                'id' => $tokenId,
                'username' => $username,
                'password' => $password,
                'expires_at' => $expireDate
            ], 'Usuario creado exitosamente');
        } else {
            errorResponse('Error al guardar en base de datos');
        }
    }
    
    // ELIMINAR USUARIO
    if ($action === 'delete') {
        if (!isAdmin()) {
            errorResponse('Se requieren permisos de administrador', 403);
        }
        
        $tokenId = intval($data['user_id']);
        $token = getSSHTokenById($tokenId);
        
        if (!$token) {
            errorResponse('Usuario no encontrado');
        }
        
        $deleted = deleteSSHToken($tokenId);
        
        if ($deleted) {
            addLog($_SESSION['user_id'], 'delete_user', "Eliminado usuario SSH: {$token['username']}", getClientIP(), getUserAgent());
            successResponse(null, 'Usuario eliminado');
        } else {
            errorResponse('Error al eliminar usuario');
        }
    }
    
    // EXTENDER USUARIO
    if ($action === 'extend') {
        $tokenId = intval($data['user_id']);
        $days = intval($data['days']);
        
        if ($days <= 0) {
            errorResponse('Los días deben ser mayores a 0');
        }
        
        $token = getSSHTokenById($tokenId);
        
        if (!$token) {
            errorResponse('Usuario no encontrado');
        }
        
        $newExpire = extendSystemUser($token['username'], $days);
        updateSSHToken($tokenId, ['expires_at' => $newExpire]);
        
        addLog($_SESSION['user_id'], 'extend_user', "Extendido usuario {$token['username']} +$days días", getClientIP(), getUserAgent());
        
        successResponse(['new_expiration' => $newExpire], "Usuario extendido $days días");
    }
}

// ==============================================
// PUT - Actualizar usuario
// ==============================================
if ($method === 'PUT') {
    if (!isAdmin()) {
        errorResponse('Se requieren permisos de administrador', 403);
    }
    
    $data = json_decode(file_get_contents('php://input'), true);
    $tokenId = intval($data['id'] ?? 0);
    
    if (!$tokenId) {
        errorResponse('ID de usuario requerido');
    }
    
    $updateData = [];
    if (isset($data['status'])) {
        $updateData['status'] = $data['status'];
    }
    if (isset($data['expires_at'])) {
        $updateData['expires_at'] = $data['expires_at'];
        // Actualizar en sistema
        $token = getSSHTokenById($tokenId);
        if ($token) {
            shell_exec("usermod -e " . escapeshellarg($data['expires_at']) . " " . escapeshellarg($token['username']));
        }
    }
    if (isset($data['traffic_limit'])) {
        $updateData['traffic_limit'] = $data['traffic_limit'];
    }
    if (isset($data['connection_limit'])) {
        $updateData['connection_limit'] = $data['connection_limit'];
    }
    
    if (updateSSHToken($tokenId, $updateData)) {
        addLog($_SESSION['user_id'], 'update_user', "Actualizado usuario ID: $tokenId", getClientIP(), getUserAgent());
        successResponse(null, 'Usuario actualizado');
    } else {
        errorResponse('Error al actualizar');
    }
}

// ==============================================
// DELETE - Eliminar usuario
// ==============================================
if ($method === 'DELETE') {
    if (!isAdmin()) {
        errorResponse('Se requieren permisos de administrador', 403);
    }
    
    $tokenId = intval($_GET['id'] ?? 0);
    
    if (!$tokenId) {
        errorResponse('ID de usuario requerido');
    }
    
    $token = getSSHTokenById($tokenId);
    
    if (!$token) {
        errorResponse('Usuario no encontrado');
    }
    
    $deleted = deleteSSHToken($tokenId);
    
    if ($deleted) {
        addLog($_SESSION['user_id'], 'delete_user', "Eliminado usuario SSH: {$token['username']}", getClientIP(), getUserAgent());
        successResponse(null, 'Usuario eliminado');
    } else {
        errorResponse('Error al eliminar usuario');
    }
}

// Si no se encontró ninguna acción
errorResponse('Método no permitido', 405);
?>