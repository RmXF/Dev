<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization, X-Requested-With');

require_once '../includes/config.php';
require_once '../includes/auth.php';
require_once '../includes/functions.php';

// Manejar OPTIONS para CORS
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

// Solo administradores
if (!isAdmin()) {
    errorResponse('No autorizado. Se requieren permisos de administrador', 403);
}

$method = $_SERVER['REQUEST_METHOD'];

// ==============================================
// GET - Listar backups
// ==============================================
if ($method === 'GET') {
    $backupDir = BACKUP_PATH;
    
    if (!is_dir($backupDir)) {
        mkdir($backupDir, 0755, true);
    }
    
    $backups = [];
    $files = glob($backupDir . '/backup_*.sql');
    rsort($files);
    
    foreach ($files as $file) {
        $backups[] = [
            'filename' => basename($file),
            'size' => filesize($file),
            'size_human' => formatBytes(filesize($file)),
            'date' => date('Y-m-d H:i:s', filemtime($file)),
            'date_human' => date('d/m/Y H:i:s', filemtime($file))
        ];
    }
    
    // Estadísticas de backups
    $totalBackups = count($backups);
    $totalSize = array_sum(array_column($backups, 'size'));
    $lastBackup = $backups[0] ?? null;
    
    successResponse([
        'backups' => $backups,
        'stats' => [
            'total' => $totalBackups,
            'total_size' => formatBytes($totalSize),
            'last_backup' => $lastBackup,
            'backup_path' => BACKUP_PATH,
            'keep_days' => BACKUP_KEEP_DAYS
        ]
    ]);
}

// ==============================================
// POST - Crear backup
// ==============================================
if ($method === 'POST') {
    $data = json_decode(file_get_contents('php://input'), true);
    $type = $data['type'] ?? 'database';
    
    if ($type === 'database') {
        $filename = createBackup();
        
        if ($filename) {
            addLog($_SESSION['user_id'], 'create_backup', "Creó backup: $filename", getClientIP(), getUserAgent());
            successResponse(['filename' => $filename], 'Backup creado exitosamente');
        } else {
            errorResponse('Error al crear backup');
        }
    }
    
    if ($type === 'full') {
        // Backup completo del panel
        $backupFile = BACKUP_PATH . '/full_backup_' . date('Ymd_His') . '.tar.gz';
        $command = "tar -czf $backupFile -C " . dirname(INSTALL_DIR) . " " . basename(INSTALL_DIR) . " 2>/dev/null";
        shell_exec($command);
        
        if (file_exists($backupFile)) {
            db_insert('backups', [
                'filename' => basename($backupFile),
                'size' => filesize($backupFile),
                'type' => 'full',
                'created_by' => $_SESSION['user_id']
            ]);
            
            addLog($_SESSION['user_id'], 'create_full_backup', "Creó backup completo: " . basename($backupFile), getClientIP(), getUserAgent());
            successResponse(['filename' => basename($backupFile)], 'Backup completo creado');
        } else {
            errorResponse('Error al crear backup completo');
        }
    }
    
    errorResponse('Tipo de backup no válido');
}

// ==============================================
// DELETE - Eliminar backup
// ==============================================
if ($method === 'DELETE') {
    $filename = basename($_GET['filename'] ?? '');
    
    if (empty($filename)) {
        errorResponse('Nombre de archivo requerido');
    }
    
    // Validar que sea un archivo de backup
    if (!preg_match('/^(backup_|full_backup_)/', $filename)) {
        errorResponse('Nombre de archivo no válido');
    }
    
    $filepath = BACKUP_PATH . '/' . $filename;
    
    if (file_exists($filepath)) {
        unlink($filepath);
        db_delete('backups', 'filename = ?', [$filename]);
        addLog($_SESSION['user_id'], 'delete_backup', "Eliminó backup: $filename", getClientIP(), getUserAgent());
        successResponse(null, 'Backup eliminado');
    } else {
        errorResponse('Archivo no encontrado');
    }
}

// ==============================================
// GET para descargar backup
// ==============================================
if ($method === 'GET' && isset($_GET['download'])) {
    $filename = basename($_GET['download']);
    $filepath = BACKUP_PATH . '/' . $filename;
    
    // Validar que sea un archivo de backup
    if (!preg_match('/^(backup_|full_backup_)/', $filename)) {
        errorResponse('Archivo no válido', 403);
    }
    
    if (file_exists($filepath)) {
        header('Content-Type: application/octet-stream');
        header('Content-Disposition: attachment; filename="' . $filename . '"');
        header('Content-Length: ' . filesize($filepath));
        header('Cache-Control: no-cache');
        readfile($filepath);
        exit;
    } else {
        errorResponse('Archivo no encontrado', 404);
    }
}

errorResponse('Método no permitido', 405);
?>