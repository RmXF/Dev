<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, PUT, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization, X-Requested-With');

require_once '../includes/config.php';
require_once '../includes/auth.php';
require_once '../includes/functions.php';

// Manejar OPTIONS para CORS
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

if (!isLoggedIn()) {
    errorResponse('No autorizado', 401);
}

$method = $_SERVER['REQUEST_METHOD'];

// ==============================================
// GET - Obtener notificaciones
// ==============================================
if ($method === 'GET') {
    $limit = intval($_GET['limit'] ?? 20);
    $notifications = getNotifications($_SESSION['user_id'], $limit);
    $unreadCount = getUnreadCount($_SESSION['user_id']);
    
    successResponse([
        'notifications' => $notifications,
        'unread_count' => $unreadCount
    ]);
}

// ==============================================
// POST - Marcar notificaciones
// ==============================================
if ($method === 'POST') {
    $data = json_decode(file_get_contents('php://input'), true);
    if (!$data) {
        $data = $_POST;
    }
    
    $action = $data['action'] ?? '';
    
    // Marcar una como leída
    if ($action === 'mark_read') {
        $id = intval($data['id'] ?? 0);
        if ($id) {
            markNotificationAsRead($id, $_SESSION['user_id']);
            successResponse(null, 'Notificación marcada como leída');
        } else {
            errorResponse('ID de notificación requerido');
        }
    }
    
    // Marcar todas como leídas
    if ($action === 'mark_all_read') {
        markAllNotificationsAsRead($_SESSION['user_id']);
        successResponse(null, 'Todas las notificaciones marcadas como leídas');
    }
    
    // Crear notificación (solo admin)
    if ($action === 'create') {
        if (!isAdmin()) {
            errorResponse('No autorizado', 403);
        }
        
        $title = $data['title'] ?? '';
        $message = $data['message'] ?? '';
        $type = $data['type'] ?? 'info';
        $userId = intval($data['user_id'] ?? $_SESSION['user_id']);
        
        if (empty($title) || empty($message)) {
            errorResponse('Título y mensaje requeridos');
        }
        
        addNotification($userId, $title, $message, $type);
        successResponse(null, 'Notificación creada');
    }
    
    errorResponse('Acción no válida');
}

// ==============================================
// PUT - Marcar como leída
// ==============================================
if ($method === 'PUT') {
    $data = json_decode(file_get_contents('php://input'), true);
    $id = intval($data['id'] ?? 0);
    
    if ($id) {
        markNotificationAsRead($id, $_SESSION['user_id']);
        successResponse(null, 'Notificación actualizada');
    } else {
        errorResponse('ID de notificación requerido');
    }
}

errorResponse('Método no permitido', 405);
?>