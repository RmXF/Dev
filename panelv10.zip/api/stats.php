<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization, X-Requested-With');

require_once '../includes/config.php';
require_once '../includes/auth.php';
require_once '../includes/functions.php';

// Manejar OPTIONS para CORS
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

// Verificar autenticación (excepto para stats públicas)
$public = isset($_GET['public']) && $_GET['public'] == '1';

if (!$public && !isLoggedIn()) {
    errorResponse('No autorizado', 401);
}

$method = $_SERVER['REQUEST_METHOD'];

if ($method === 'GET') {
    $stats = getSystemStats();
    
    // Si se solicita gráfica
    if (isset($_GET['chart'])) {
        $chartData = [];
        $months = [];
        $values = [];
        
        for ($i = 5; $i >= 0; $i--) {
            $month = date('Y-m', strtotime("-$i months"));
            $monthName = date('M', strtotime("-$i months"));
            $count = db_select_one(
                "SELECT COUNT(*) as count FROM ssh_tokens WHERE DATE_FORMAT(created_at, '%Y-%m') = ?",
                [$month]
            );
            $months[] = $monthName;
            $values[] = intval($count['count'] ?? 0);
        }
        
        $chartData['labels'] = $months;
        $chartData['values'] = $values;
        successResponse($chartData);
    }
    
    // Estadísticas adicionales
    $totalLogs = db_select_one("SELECT COUNT(*) as count FROM logs")['count'] ?? 0;
    $logsToday = db_select_one("SELECT COUNT(*) as count FROM logs WHERE DATE(created_at) = CURDATE()")['count'] ?? 0;
    $totalUsers = db_select_one("SELECT COUNT(*) as count FROM users")['count'] ?? 0;
    $totalAdmins = db_select_one("SELECT COUNT(*) as count FROM users WHERE role = 'admin'")['count'] ?? 0;
    
    // Actividad reciente
    $recentActivity = db_select(
        "SELECT action, COUNT(*) as count FROM logs WHERE created_at > DATE_SUB(NOW(), INTERVAL 24 HOUR) GROUP BY action ORDER BY count DESC LIMIT 5"
    );
    
    $stats['total_logs'] = $totalLogs;
    $stats['logs_today'] = $logsToday;
    $stats['total_users_system'] = $totalUsers;
    $stats['total_admins'] = $totalAdmins;
    $stats['recent_activity'] = $recentActivity;
    $stats['timestamp'] = date('Y-m-d H:i:s');
    
    successResponse($stats);
}

errorResponse('Método no permitido', 405);
?>