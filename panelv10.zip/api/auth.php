<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST, GET, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization, X-Requested-With');

require_once '../includes/config.php';
require_once '../includes/functions.php';

$method = $_SERVER['REQUEST_METHOD'];

// Manejar OPTIONS para CORS
if ($method === 'OPTIONS') {
    http_response_code(200);
    exit;
}

// ==============================================
// LOGIN
// ==============================================
if ($method === 'POST' && isset($_POST['action']) && $_POST['action'] === 'login') {
    $username = trim($_POST['username']);
    $password = $_POST['password'];
    $ip = getClientIP();
    $userAgent = getUserAgent();
    
    if (empty($username) || empty($password)) {
        header('Location: ../index.php?error=Usuario y contraseña requeridos');
        exit;
    }
    
    $user = getUserByUsername($username);
    
    if (!$user) {
        addLog(0, 'login_failed', "Intento de login fallido: $username", $ip, $userAgent);
        header('Location: ../index.php?error=Credenciales inválidas');
        exit;
    }
    
    // Verificar intentos de login
    $attempts = db_select_one(
        "SELECT COUNT(*) as count FROM logs WHERE action = 'login_failed' AND ip_address = ? AND created_at > DATE_SUB(NOW(), INTERVAL 15 MINUTE)",
        [$ip]
    );
    
    if ($attempts && $attempts['count'] >= MAX_LOGIN_ATTEMPTS) {
        addLog($user['id'], 'login_blocked', "Demasiados intentos fallidos", $ip, $userAgent);
        header('Location: ../index.php?error=Demasiados intentos. Espere 15 minutos');
        exit;
    }
    
    // Verificar contraseña
    if (!password_verify($password, $user['password'])) {
        addLog($user['id'], 'login_failed', "Contraseña incorrecta", $ip, $userAgent);
        header('Location: ../index.php?error=Credenciales inválidas');
        exit;
    }
    
    // Verificar estado
    if ($user['status'] !== 'active') {
        addLog($user['id'], 'login_blocked', "Cuenta {$user['status']}", $ip, $userAgent);
        header('Location: ../index.php?error=Cuenta no activa');
        exit;
    }
    
    // Iniciar sesión
    $_SESSION['user_id'] = $user['id'];
    $_SESSION['username'] = $user['username'];
    $_SESSION['email'] = $user['email'];
    $_SESSION['role'] = $user['role'];
    $_SESSION['logged_in'] = true;
    $_SESSION['login_time'] = time();
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    
    // Actualizar último login
    updateUser($user['id'], [
        'last_login' => date('Y-m-d H:i:s'),
        'last_ip' => $ip
    ]);
    
    addLog($user['id'], 'login', "Inicio de sesión exitoso", $ip, $userAgent);
    
    header('Location: ../pages/dashboard.php');
    exit;
}

// ==============================================
// LOGOUT
// ==============================================
if (isset($_GET['action']) && $_GET['action'] === 'logout') {
    if (isLoggedIn()) {
        addLog($_SESSION['user_id'], 'logout', "Cierre de sesión", getClientIP(), getUserAgent());
    }
    
    $_SESSION = array();
    if (isset($_COOKIE[session_name()])) {
        setcookie(session_name(), '', time()-3600, '/');
    }
    session_destroy();
    
    header('Location: ../index.php');
    exit;
}

// ==============================================
// VERIFICAR TOKEN (API)
// ==============================================
if ($method === 'GET' && isset($_GET['action']) && $_GET['action'] === 'verify') {
    $headers = getallheaders();
    $token = str_replace('Bearer ', '', $headers['Authorization'] ?? '');
    
    if (empty($token)) {
        errorResponse('Token no proporcionado', 401);
    }
    
    $user = verifyAPIKey($token);
    if ($user) {
        successResponse($user, 'Token válido');
    } else {
        errorResponse('Token inválido', 401);
    }
}

// ==============================================
// REGENERAR API KEY
// ==============================================
if ($method === 'POST' && isset($_POST['action']) && $_POST['action'] === 'regenerate_api_key') {
    if (!isLoggedIn()) {
        errorResponse('No autorizado', 401);
    }
    
    $newApiKey = generateAPIKey($_SESSION['user_id']);
    addLog($_SESSION['user_id'], 'regenerate_api_key', 'Regeneró API Key', getClientIP(), getUserAgent());
    
    successResponse(['api_key' => $newApiKey], 'API Key regenerada');
}

// Si no se encontró ninguna acción
errorResponse('Acción no válida', 400);
?>