<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization, X-Requested-With');

require_once '../includes/config.php';
require_once '../includes/auth.php';
require_once '../includes/functions.php';

// Manejar OPTIONS para CORS
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

// ==============================================
// Obtener información del WebSocket
// ==============================================
if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    $wsPort = 3002;
    $wsHost = $_SERVER['HTTP_HOST'];
    $wsUrl = "ws://{$wsHost}:{$wsPort}";
    
    // Verificar si el servicio WebSocket está corriendo
    $wsRunning = false;
    $socket = @fsockopen('localhost', $wsPort, $errno, $errstr, 2);
    if ($socket) {
        $wsRunning = true;
        fclose($socket);
    }
    
    $info = [
        'enabled' => true,
        'running' => $wsRunning,
        'url' => $wsUrl,
        'port' => $wsPort,
        'host' => $wsHost,
        'status' => $wsRunning ? 'online' : 'offline'
    ];
    
    // Si está autenticado, generar token para conexión
    if (isLoggedIn()) {
        $payload = [
            'id' => $_SESSION['user_id'],
            'username' => $_SESSION['username'],
            'role' => $_SESSION['role'],
            'exp' => time() + 3600
        ];
        $info['token'] = JWT::encode($payload, JWT_SECRET);
    }
    
    successResponse($info);
}

// ==============================================
// POST - Acciones del WebSocket
// ==============================================
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!isAdmin()) {
        errorResponse('No autorizado', 403);
    }
    
    $data = json_decode(file_get_contents('php://input'), true);
    $action = $data['action'] ?? '';
    
    // Reiniciar servicio WebSocket
    if ($action === 'restart') {
        $output = [];
        $return = 0;
        exec('systemctl restart ws-proxy 2>&1', $output, $return);
        
        if ($return === 0) {
            addLog($_SESSION['user_id'], 'restart_websocket', 'Reinició servicio WebSocket', getClientIP(), getUserAgent());
            successResponse(null, 'WebSocket reiniciado');
        } else {
            errorResponse('Error al reiniciar WebSocket: ' . implode("\n", $output));
        }
    }
    
    // Obtener estadísticas del WebSocket
    if ($action === 'stats') {
        $output = [];
        exec('ss -tulpn | grep 3002 2>/dev/null', $output);
        $connections = count($output);
        
        successResponse([
            'connections' => $connections,
            'port' => 3002,
            'service' => 'ws-proxy',
            'status' => file_exists('/etc/systemd/system/ws-proxy.service') ? 'installed' : 'not_installed'
        ]);
    }
    
    errorResponse('Acción no válida');
}

errorResponse('Método no permitido', 405);
?>