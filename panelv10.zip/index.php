<?php
require_once 'includes/config.php';
require_once 'includes/auth.php';

// Redirigir si ya está logueado
if (isLoggedIn()) {
    header('Location: pages/dashboard.php');
    exit;
}

// Verificar si es modo mantenimiento
$maintenance = getSetting('maintenance_mode');
if ($maintenance == '1') {
    die('<h1>Modo Mantenimiento</h1><p>El panel está en mantenimiento. Vuelva más tarde.</p>');
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=yes">
    <meta name="theme-color" content="#0087ff">
    <meta name="description" content="CEO SSH Panel - Panel de control profesional para gestión de VPN">
    <title>CEO SSH Panel - Iniciar Sesión</title>
    <link rel="icon" href="assets/img/favicon.ico" type="image/x-icon">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="assets/css/style.css">
    <link rel="stylesheet" href="assets/css/responsive.css">
    <style>
        .login-container {
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            background: linear-gradient(135deg, var(--bg-primary) 0%, var(--bg-secondary) 100%);
            position: relative;
            overflow: hidden;
        }
        
        .login-container::before {
            content: '';
            position: absolute;
            width: 300px;
            height: 300px;
            background: radial-gradient(circle, var(--accent) 0%, transparent 70%);
            top: -150px;
            right: -150px;
            opacity: 0.1;
            border-radius: 50%;
        }
        
        .login-container::after {
            content: '';
            position: absolute;
            width: 400px;
            height: 400px;
            background: radial-gradient(circle, var(--accent) 0%, transparent 70%);
            bottom: -200px;
            left: -200px;
            opacity: 0.05;
            border-radius: 50%;
        }
        
        .login-box {
            background: var(--bg-card);
            border-radius: 32px;
            padding: 50px;
            width: 100%;
            max-width: 450px;
            border: 1px solid var(--border);
            box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.5);
            position: relative;
            z-index: 1;
            backdrop-filter: blur(10px);
            animation: fadeInUp 0.6s ease-out;
        }
        
        @keyframes fadeInUp {
            from {
                opacity: 0;
                transform: translateY(30px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }
        
        .login-icon {
            width: 80px;
            height: 80px;
            background: linear-gradient(135deg, var(--accent), var(--accent-hover));
            border-radius: 24px;
            display: flex;
            align-items: center;
            justify-content: center;
            margin: 0 auto 25px;
            animation: pulse 2s infinite;
        }
        
        @keyframes pulse {
            0%, 100% { transform: scale(1); }
            50% { transform: scale(1.05); }
        }
        
        .login-icon i {
            font-size: 40px;
            color: white;
        }
        
        .input-group {
            margin-bottom: 25px;
            position: relative;
        }
        
        .input-group i {
            position: absolute;
            left: 16px;
            top: 50%;
            transform: translateY(-50%);
            color: var(--text-tertiary);
            font-size: 18px;
            transition: all 0.3s;
        }
        
        .input-group input {
            width: 100%;
            padding: 14px 16px 14px 48px;
            background: var(--bg-tertiary);
            border: 2px solid var(--border);
            border-radius: 16px;
            color: var(--text-primary);
            font-size: 15px;
            transition: all 0.3s;
        }
        
        .input-group input:focus {
            outline: none;
            border-color: var(--accent);
            box-shadow: 0 0 0 4px rgba(0, 135, 255, 0.1);
        }
        
        .input-group input:focus + i {
            color: var(--accent);
        }
        
        .password-toggle {
            position: absolute;
            right: 16px;
            top: 50%;
            transform: translateY(-50%);
            cursor: pointer;
            color: var(--text-tertiary);
            transition: all 0.3s;
        }
        
        .password-toggle:hover {
            color: var(--accent);
        }
        
        .btn-login {
            width: 100%;
            padding: 14px;
            background: linear-gradient(135deg, var(--accent), var(--accent-hover));
            border: none;
            border-radius: 16px;
            color: white;
            font-size: 16px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s;
            margin-top: 10px;
        }
        
        .btn-login:hover {
            transform: translateY(-2px);
            box-shadow: 0 10px 25px -5px rgba(0, 135, 255, 0.4);
        }
        
        .btn-login:active {
            transform: translateY(0);
        }
        
        .alert {
            padding: 12px 16px;
            border-radius: 12px;
            margin-bottom: 20px;
            display: flex;
            align-items: center;
            gap: 10px;
            animation: slideIn 0.3s ease-out;
        }
        
        @keyframes slideIn {
            from {
                opacity: 0;
                transform: translateX(-20px);
            }
            to {
                opacity: 1;
                transform: translateX(0);
            }
        }
        
        .alert-error {
            background: rgba(239, 68, 68, 0.1);
            border: 1px solid var(--error);
            color: var(--error);
        }
        
        .alert-success {
            background: rgba(16, 185, 129, 0.1);
            border: 1px solid var(--success);
            color: var(--success);
        }
        
        .version {
            text-align: center;
            margin-top: 25px;
            color: var(--text-tertiary);
            font-size: 12px;
        }
        
        @media (max-width: 768px) {
            .login-box { padding: 30px; margin: 20px; }
        }
    </style>
</head>
<body>
    <div class="login-container">
        <div class="login-box">
            <div class="login-icon">
                <i class="fas fa-shield-alt"></i>
            </div>
            
            <h2 style="text-align: center; margin-bottom: 10px; font-size: 28px;">Bienvenido</h2>
            <p style="text-align: center; color: var(--text-secondary); margin-bottom: 35px;">Ingresa tus credenciales</p>
            
            <?php if (isset($_GET['error'])): ?>
                <div class="alert alert-error">
                    <i class="fas fa-exclamation-triangle"></i>
                    <span><?php echo htmlspecialchars($_GET['error']); ?></span>
                </div>
            <?php endif; ?>
            
            <?php if (isset($_GET['success'])): ?>
                <div class="alert alert-success">
                    <i class="fas fa-check-circle"></i>
                    <span><?php echo htmlspecialchars($_GET['success']); ?></span>
                </div>
            <?php endif; ?>
            
            <form method="POST" action="api/auth.php" id="loginForm">
                <input type="hidden" name="action" value="login">
                
                <div class="input-group">
                    <i class="fas fa-user"></i>
                    <input type="text" name="username" placeholder="Usuario" required autocomplete="username">
                </div>
                
                <div class="input-group">
                    <i class="fas fa-lock"></i>
                    <input type="password" name="password" id="password" placeholder="Contraseña" required autocomplete="current-password">
                    <span class="password-toggle" onclick="togglePassword()">
                        <i class="fas fa-eye" id="toggleIcon"></i>
                    </span>
                </div>
                
                <button type="submit" class="btn-login" id="loginBtn">
                    <span>Iniciar Sesión</span>
                    <i class="fas fa-arrow-right" style="margin-left: 10px;"></i>
                </button>
            </form>
            
            <div class="version">
                <i class="fas fa-code-branch"></i> CEO SSH Panel v<?php echo PANEL_VERSION; ?>
            </div>
        </div>
    </div>
    
    <script>
        function togglePassword() {
            const password = document.getElementById('password');
            const icon = document.getElementById('toggleIcon');
            
            if (password.type === 'password') {
                password.type = 'text';
                icon.className = 'fas fa-eye-slash';
            } else {
                password.type = 'password';
                icon.className = 'fas fa-eye';
            }
        }
        
        document.getElementById('loginForm').addEventListener('submit', function(e) {
            const btn = document.getElementById('loginBtn');
            btn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Iniciando...';
            btn.disabled = true;
        });
        
        // Animación de entrada
        document.querySelector('.login-box').style.opacity = '0';
        setTimeout(() => {
            document.querySelector('.login-box').style.opacity = '1';
        }, 100);
    </script>
</body>
</html>