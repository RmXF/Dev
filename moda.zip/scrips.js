const PRODUCTS_PER_PAGE = 12;

let selectedMainCategory = "Todos";
let selectedSubcategory = "Todos";
let searchTerm = "";
let visibleProducts = PRODUCTS_PER_PAGE;

let cart = [];
let selectedProduct = null;
let selectedSize = null;


const productGrid =
    document.getElementById("productGrid");

const emptyState =
    document.getElementById("emptyState");

const searchInput =
    document.getElementById("searchInput");

const productCounter =
    document.getElementById("productCounter");

const loadMoreButton =
    document.getElementById("loadMore");

const subcategoryWrapper =
    document.getElementById("subcategoryWrapper");

const subcategoryFilters =
    document.getElementById("subcategoryFilters");

const clearFiltersButton =
    document.getElementById("clearFilters");


const cartCount =
    document.getElementById("cartCount");

const cartItems =
    document.getElementById("cartItems");

const cartEmpty =
    document.getElementById("cartEmpty");

const cartFooter =
    document.getElementById("cartFooter");

const cartTotal =
    document.getElementById("cartTotal");


function formatPrice(price) {

    return new Intl.NumberFormat(
        "es-AR",
        {
            style: "currency",
            currency: "ARS",
            maximumFractionDigits: 0
        }
    ).format(price);

}


function getActiveProducts() {

    return products.filter(product =>
        product.active === true
    );

}


function getFilteredProducts() {

    return getActiveProducts().filter(product => {

        const mainCategoryMatch =
            selectedMainCategory === "Todos" ||
            product.category === selectedMainCategory;


        const subcategoryMatch =
            selectedSubcategory === "Todos" ||
            product.subcategory === selectedSubcategory;


        const normalizedSearch =
            searchTerm
                .toLowerCase()
                .trim();


        const searchMatch =
            !normalizedSearch ||

            product.name
                .toLowerCase()
                .includes(normalizedSearch) ||

            product.category
                .toLowerCase()
                .includes(normalizedSearch) ||

            product.subcategory
                .toLowerCase()
                .includes(normalizedSearch) ||

            product.type
                .toLowerCase()
                .includes(normalizedSearch);


        return (
            mainCategoryMatch &&
            subcategoryMatch &&
            searchMatch
        );

    });

}


function renderSubcategories() {

    const activeProducts =
        getActiveProducts();


    const relevantProducts =
        selectedMainCategory === "Todos"
            ? activeProducts
            : activeProducts.filter(
                product =>
                    product.category ===
                    selectedMainCategory
            );


    const subcategories =
        [
            ...new Set(
                relevantProducts.map(
                    product =>
                        product.subcategory
                )
            )
        ];


    subcategoryFilters.innerHTML = "";


    if (subcategories.length === 0) {

        subcategoryWrapper.style.display =
            "none";

        return;

    }


    subcategoryWrapper.style.display =
        "block";


    const allButton =
        document.createElement("button");


    allButton.className =
        `subcategory-filter ${
            selectedSubcategory === "Todos"
                ? "active"
                : ""
        }`;


    allButton.textContent =
        "Todos";


    allButton.addEventListener(
        "click",
        () => {

            selectedSubcategory =
                "Todos";

            visibleProducts =
                PRODUCTS_PER_PAGE;

            renderSubcategories();
            renderProducts();

        }
    );


    subcategoryFilters.appendChild(
        allButton
    );


    subcategories.forEach(subcategory => {

        const button =
            document.createElement("button");


        button.className =
            `subcategory-filter ${
                selectedSubcategory ===
                subcategory
                    ? "active"
                    : ""
            }`;


        button.textContent =
            subcategory;


        button.addEventListener(
            "click",
            () => {

                selectedSubcategory =
                    subcategory;

                visibleProducts =
                    PRODUCTS_PER_PAGE;

                renderSubcategories();
                renderProducts();

            }
        );


        subcategoryFilters.appendChild(
            button
        );

    });

}


function renderProducts() {

    const filteredProducts =
        getFilteredProducts();


    productGrid.innerHTML = "";


    if (filteredProducts.length === 0) {

        emptyState.style.display =
            "block";

        loadMoreButton.style.display =
            "none";


        productCounter.textContent =
            "No hay productos disponibles";

        return;

    }


    emptyState.style.display =
        "none";


    const productsToShow =
        filteredProducts.slice(
            0,
            visibleProducts
        );


    productsToShow.forEach(
        product => {

            const card =
                document.createElement(
                    "article"
                );


            card.className =
                "product-card";


            const oldPriceHTML =
                product.oldPrice
                    ? `
                        <span class="old-price">
                            ${formatPrice(product.oldPrice)}
                        </span>
                    `
                    : "";


            const badgeHTML =
                product.badge
                    ? `
                        <span class="product-badge">
                            ${product.badge}
                        </span>
                    `
                    : "";


            card.innerHTML = `

                <div class="product-image">

                    ${badgeHTML}


                    <button
                        class="favorite-button"
                        data-favorite="${product.id}"
                        aria-label="Agregar a favoritos"
                    >
                        ♡
                    </button>


                    <img
                        src="${product.image}"
                        alt="${product.name}"
                        loading="lazy"
                        decoding="async"
                        onerror="
                            this.style.display='none';
                            this.parentElement.classList.add('image-error');
                        "
                    >


                    <button
                        class="quick-view"
                        data-quick="${product.id}"
                    >
                        Vista rápida
                    </button>

                </div>


                <div class="product-info">

                    <span class="product-category">

                        ${product.category}
                        ·
                        ${product.subcategory}

                    </span>


                    <div class="product-name-row">

                        <h3 class="product-name">
                            ${product.name}
                        </h3>

                    </div>


                    <div class="product-price">

                        <strong>
                            ${formatPrice(product.price)}
                        </strong>

                        ${oldPriceHTML}

                    </div>


                    <button
                        class="add-product"
                        data-add="${product.id}"
                    >
                        Agregar al carrito
                    </button>

                </div>

            `;


            productGrid.appendChild(card);

        }
    );


    updateProductCounter(
        filteredProducts.length,
        productsToShow.length
    );


    loadMoreButton.style.display =
        filteredProducts.length >
        visibleProducts
            ? "inline-flex"
            : "none";


    attachProductEvents();

}


function updateProductCounter(
    total,
    showing
) {

    productCounter.textContent =
        `Mostrando ${showing} de ${total} productos`;

}


function attachProductEvents() {

    document
        .querySelectorAll("[data-add]")
        .forEach(button => {

            button.addEventListener(
                "click",
                () => {

                    const product =
                        products.find(
                            item =>
                                item.id ===
                                Number(
                                    button.dataset.add
                                )
                        );


                    if (!product) return;


                    addToCart(
                        product,
                        product.sizes[0]
                    );

                }
            );

        });


    document
        .querySelectorAll("[data-quick]")
        .forEach(button => {

            button.addEventListener(
                "click",
                () => {

                    openProductModal(
                        Number(
                            button.dataset.quick
                        )
                    );

                }
            );

        });


    document
        .querySelectorAll("[data-favorite]")
        .forEach(button => {

            button.addEventListener(
                "click",
                () => {

                    button.classList.toggle(
                        "active"
                    );


                    button.textContent =
                        button.classList.contains(
                            "active"
                        )
                            ? "♥"
                            : "♡";

                }
            );

        });

}


/* =========================
   FILTROS PRINCIPALES
========================= */

document
    .querySelectorAll("[data-main-filter]")
    .forEach(button => {

        button.addEventListener(
            "click",
            () => {

                selectedMainCategory =
                    button.dataset.mainFilter;


                selectedSubcategory =
                    "Todos";


                visibleProducts =
                    PRODUCTS_PER_PAGE;


                document
                    .querySelectorAll(
                        "[data-main-filter]"
                    )
                    .forEach(btn => {

                        btn.classList.remove(
                            "active"
                        );

                    });


                button.classList.add(
                    "active"
                );


                renderSubcategories();
                renderProducts();

            }
        );

    });


/* =========================
   TARJETAS DE CATEGORÍA
========================= */

document
    .querySelectorAll(
        "[data-main-category]"
    )
    .forEach(card => {

        card.addEventListener(
            "click",
            () => {

                selectedMainCategory =
                    card.dataset.mainCategory;


                selectedSubcategory =
                    "Todos";


                visibleProducts =
                    PRODUCTS_PER_PAGE;


                document
                    .querySelectorAll(
                        "[data-main-filter]"
                    )
                    .forEach(button => {

                        button.classList.toggle(
                            "active",

                            button.dataset.mainFilter ===
                            selectedMainCategory
                        );

                    });


                renderSubcategories();
                renderProducts();


                document
                    .getElementById("catalogo")
                    .scrollIntoView({
                        behavior: "smooth"
                    });

            }
        );

    });


/* =========================
   BUSCADOR
========================= */

searchInput.addEventListener(
    "input",
    event => {

        searchTerm =
            event.target.value;

        visibleProducts =
            PRODUCTS_PER_PAGE;

        renderProducts();

    }
);


/* =========================
   CARGAR MÁS
========================= */

loadMoreButton.addEventListener(
    "click",
    () => {

        visibleProducts +=
            PRODUCTS_PER_PAGE;

        renderProducts();

    }
);


/* =========================
   LIMPIAR FILTROS
========================= */

clearFiltersButton.addEventListener(
    "click",
    () => {

        selectedMainCategory =
            "Todos";

        selectedSubcategory =
            "Todos";

        searchTerm =
            "";

        visibleProducts =
            PRODUCTS_PER_PAGE;


        searchInput.value =
            "";


        document
            .querySelectorAll(
                "[data-main-filter]"
            )
            .forEach(button => {

                button.classList.toggle(
                    "active",

                    button.dataset.mainFilter ===
                    "Todos"
                );

            });


        renderSubcategories();
        renderProducts();

    }
);


/* =========================
   MODAL
========================= */

const productModal =
    document.getElementById(
        "productModal"
    );

const modalImage =
    document.getElementById(
        "modalImage"
    );

const modalCategory =
    document.getElementById(
        "modalCategory"
    );

const modalName =
    document.getElementById(
        "modalName"
    );

const modalPrice =
    document.getElementById(
        "modalPrice"
    );

const modalDescription =
    document.getElementById(
        "modalDescription"
    );

const sizeOptions =
    document.getElementById(
        "sizeOptions"
    );


function openProductModal(id) {

    selectedProduct =
        products.find(
            product =>
                product.id === id
        );


    if (!selectedProduct) return;


    selectedSize =
        selectedProduct.sizes[0];


    modalImage.innerHTML = `

        <img
            src="${selectedProduct.image}"
            alt="${selectedProduct.name}"
        >

    `;


    modalCategory.textContent =
        `${selectedProduct.category} · ${selectedProduct.subcategory}`;


    modalName.textContent =
        selectedProduct.name;


    modalPrice.textContent =
        formatPrice(
            selectedProduct.price
        );


    modalDescription.textContent =
        selectedProduct.description;


    sizeOptions.innerHTML = "";


    selectedProduct.sizes.forEach(
        size => {

            const button =
                document.createElement(
                    "button"
                );


            button.className =
                "size-option";


            button.textContent =
                size;


            if (
                size === selectedSize
            ) {

                button.classList.add(
                    "active"
                );

            }


            button.addEventListener(
                "click",
                () => {

                    selectedSize =
                        size;


                    document
                        .querySelectorAll(
                            ".size-option"
                        )
                        .forEach(btn => {

                            btn.classList.remove(
                                "active"
                            );

                        });


                    button.classList.add(
                        "active"
                    );

                }
            );


            sizeOptions.appendChild(
                button
            );

        }
    );


    productModal.classList.add(
        "active"
    );


    document.body.style.overflow =
        "hidden";

}


function closeProductModal() {

    productModal.classList.remove(
        "active"
    );


    document.body.style.overflow =
        "";

}


document
    .getElementById("modalClose")
    .addEventListener(
        "click",
        closeProductModal
    );


document
    .getElementById("modalOverlay")
    .addEventListener(
        "click",
        closeProductModal
    );


document
    .getElementById("modalAdd")
    .addEventListener(
        "click",
        () => {

            if (!selectedProduct) return;


            addToCart(
                selectedProduct,
                selectedSize
            );


            closeProductModal();

        }
    );


/* =========================
   CARRITO
========================= */

function loadCart() {

    try {

        const savedCart =
            localStorage.getItem(
                "af-modas-cart"
            );


        if (savedCart) {

            cart =
                JSON.parse(savedCart);

        }

    } catch (error) {

        cart = [];

    }

}


function saveCart() {

    localStorage.setItem(
        "af-modas-cart",
        JSON.stringify(cart)
    );

}


function addToCart(
    product,
    size
) {

    const existingItem =
        cart.find(
            item =>
                item.id === product.id &&
                item.size === size
        );


    if (existingItem) {

        existingItem.quantity++;

    } else {

        cart.push({

            id: product.id,
            name: product.name,
            price: product.price,
            image: product.image,
            size: size,
            quantity: 1

        });

    }


    saveCart();
    updateCart();


    showToast(
        `${product.name} agregado al carrito`
    );

}


function updateCart() {

    const totalItems =
        cart.reduce(
            (total, item) =>
                total +
                item.quantity,
            0
        );


    cartCount.textContent =
        totalItems;


    cartItems.innerHTML = "";


    if (cart.length === 0) {

        cartEmpty.style.display =
            "block";

        cartFooter.style.display =
            "none";

        return;

    }


    cartEmpty.style.display =
        "none";

    cartFooter.style.display =
        "block";


    cart.forEach(item => {

        const cartItem =
            document.createElement(
                "div"
            );


        cartItem.className =
            "cart-item";


        cartItem.innerHTML = `

            <img
                class="cart-item-image"
                src="${item.image}"
                alt="${item.name}"
            >


            <div>

                <h4>
                    ${item.name}
                </h4>

                <p>
                    Talle: ${item.size}
                </p>

                <p>
                    ${formatPrice(item.price)}
                </p>


                <div class="quantity-controls">

                    <button
                        data-minus="${item.id}"
                        data-size="${item.size}"
                    >
                        −
                    </button>


                    <span>
                        ${item.quantity}
                    </span>


                    <button
                        data-plus="${item.id}"
                        data-size="${item.size}"
                    >
                        +
                    </button>

                </div>

            </div>


            <button
                class="remove-item"
                data-remove="${item.id}"
                data-size="${item.size}"
            >
                ×
            </button>

        `;


        cartItems.appendChild(
            cartItem
        );

    });


    attachCartEvents();


    const total =
        cart.reduce(
            (sum, item) =>
                sum +
                (
                    item.price *
                    item.quantity
                ),
            0
        );


    cartTotal.textContent =
        formatPrice(total);

}


function attachCartEvents() {

    document
        .querySelectorAll("[data-plus]")
        .forEach(button => {

            button.addEventListener(
                "click",
                () => {

                    changeQuantity(
                        Number(
                            button.dataset.plus
                        ),
                        button.dataset.size,
                        1
                    );

                }
            );

        });


    document
        .querySelectorAll("[data-minus]")
        .forEach(button => {

            button.addEventListener(
                "click",
                () => {

                    changeQuantity(
                        Number(
                            button.dataset.minus
                        ),
                        button.dataset.size,
                        -1
                    );

                }
            );

        });


    document
        .querySelectorAll("[data-remove]")
        .forEach(button => {

            button.addEventListener(
                "click",
                () => {

                    cart =
                        cart.filter(
                            item =>
                                !(
                                    item.id ===
                                    Number(
                                        button.dataset.remove
                                    ) &&
                                    item.size ===
                                    button.dataset.size
                                )
                        );


                    saveCart();
                    updateCart();

                }
            );

        });

}


function changeQuantity(
    id,
    size,
    change
) {

    const item =
        cart.find(
            item =>
                item.id === id &&
                item.size === size
        );


    if (!item) return;


    item.quantity += change;


    if (item.quantity <= 0) {

        cart =
            cart.filter(
                product =>
                    !(
                        product.id === id &&
                        product.size === size
                    )
            );

    }


    saveCart();
    updateCart();

}


/* =========================
   ABRIR / CERRAR CARRITO
========================= */

const cartPanel =
    document.getElementById(
        "cartPanel"
    );

const cartOverlay =
    document.getElementById(
        "cartOverlay"
    );


function openCart() {

    cartPanel.classList.add(
        "active"
    );

    cartOverlay.classList.add(
        "active"
    );

}


function closeCart() {

    cartPanel.classList.remove(
        "active"
    );

    cartOverlay.classList.remove(
        "active"
    );

}


document
    .getElementById("openCart")
    .addEventListener(
        "click",
        openCart
    );


document
    .getElementById("closeCart")
    .addEventListener(
        "click",
        closeCart
    );


cartOverlay.addEventListener(
    "click",
    closeCart
);


/* =========================
   MODO CLARO / OSCURO
========================= */

const themeToggle =
    document.getElementById(
        "themeToggle"
    );


const savedTheme =
    localStorage.getItem(
        "af-modas-theme"
    );


if (savedTheme === "dark") {

    document.body.classList.add(
        "dark"
    );

}


themeToggle.addEventListener(
    "click",
    () => {

        document.body.classList.toggle(
            "dark"
        );


        localStorage.setItem(
            "af-modas-theme",

            document.body.classList.contains(
                "dark"
            )
                ? "dark"
                : "light"
        );

    }
);


/* =========================
   DESTACADOS
========================= */

document
    .getElementById("showFeatured")
    .addEventListener(
        "click",
        () => {

            const featuredProducts =
                getActiveProducts().filter(
                    product =>
                        product.featured
                );


            selectedMainCategory =
                "Todos";

            selectedSubcategory =
                "Todos";

            searchTerm =
                "";


            searchInput.value =
                "";


            visibleProducts =
                featuredProducts.length;


            renderSubcategories();


            productGrid.innerHTML = "";


            featuredProducts.forEach(
                product => {

                    const card =
                        document.createElement(
                            "article"
                        );


                    card.className =
                        "product-card";


                    card.innerHTML = `

                        <div class="product-image">

                            <span class="product-badge">
                                DESTACADO
                            </span>


                            <img
                                src="${product.image}"
                                alt="${product.name}"
                                loading="lazy"
                            >


                            <button
                                class="quick-view"
                                data-quick="${product.id}"
                            >
                                Vista rápida
                            </button>

                        </div>


                        <div class="product-info">

                            <span class="product-category">

                                ${product.category}
                                ·
                                ${product.subcategory}

                            </span>


                            <h3 class="product-name">

                                ${product.name}

                            </h3>


                            <div class="product-price">

                                <strong>

                                    ${formatPrice(product.price)}

                                </strong>

                            </div>


                            <button
                                class="add-product"
                                data-add="${product.id}"
                            >

                                Agregar al carrito

                            </button>

                        </div>

                    `;


                    productGrid.appendChild(
                        card
                    );

                }
            );


            productCounter.textContent =
                `${featuredProducts.length} productos destacados`;


            loadMoreButton.style.display =
                "none";


            attachProductEvents();


            document
                .getElementById("catalogo")
                .scrollIntoView({
                    behavior: "smooth"
                });

        }
    );


/* =========================
   PROMOCIÓN
========================= */

document
    .getElementById("promoButton")
    .addEventListener(
        "click",
        () => {

            clearFiltersButton.click();


            document
                .getElementById("catalogo")
                .scrollIntoView({
                    behavior: "smooth"
                });

        }
    );


/* =========================
   NEWSLETTER
========================= */

const newsletterForm =
    document.getElementById(
        "newsletterForm"
    );

const newsletterMessage =
    document.getElementById(
        "newsletterMessage"
    );


newsletterForm.addEventListener(
    "submit",
    event => {

        event.preventDefault();


        newsletterMessage.textContent =
            "¡Listo! Te avisaremos sobre nuestras novedades ✦";


        newsletterForm.reset();


        setTimeout(
            () => {

                newsletterMessage.textContent =
                    "";

            },
            5000
        );

    }
);


/* =========================
   FINALIZAR PEDIDO
========================= */

document
    .getElementById("checkoutButton")
    .addEventListener(
        "click",
        () => {

            if (cart.length === 0) {

                showToast(
                    "Tu carrito está vacío"
                );

                return;

            }


            showToast(
                "Tu pedido está listo para continuar"
            );

        }
    );


/* =========================
   TOAST
========================= */

const toast =
    document.getElementById(
        "toast"
    );

const toastMessage =
    document.getElementById(
        "toastMessage"
    );


let toastTimeout;


function showToast(message) {

    clearTimeout(
        toastTimeout
    );


    toastMessage.textContent =
        message;


    toast.classList.add(
        "active"
    );


    toastTimeout =
        setTimeout(
            () => {

                toast.classList.remove(
                    "active"
                );

            },
            3000
        );

}


/* =========================
   MENÚ MÓVIL
========================= */

const menuButton =
    document.getElementById(
        "menuButton"
    );

const nav =
    document.getElementById(
        "nav"
    );


menuButton.addEventListener(
    "click",
    () => {

        nav.classList.toggle(
            "mobile-active"
        );

    }
);


document
    .querySelectorAll(".nav a")
    .forEach(link => {

        link.addEventListener(
            "click",
            () => {

                nav.classList.remove(
                    "mobile-active"
                );

            }
        );

    });


/* =========================
   TECLA ESC
========================= */

document.addEventListener(
    "keydown",
    event => {

        if (event.key === "Escape") {

            closeProductModal();
            closeCart();

        }

    }
);


/* =========================
   INICIALIZACIÓN
========================= */

loadCart();

renderSubcategories();

renderProducts();

updateCart();