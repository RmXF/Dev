const products = [

    {
        id: 1,
        name: "Remera Oversize Essential",
        category: "Hombre",
        subcategory: "Remeras",
        type: "Oversize",

        price: 24999,
        oldPrice: 29999,

        badge: "NUEVO",

        image: "https://www.dropbox.com/scl/fi/REEMPLAZAR-IMAGEN.jpg?raw=1",

        description: "Remera oversize de estilo urbano, cómoda y fácil de combinar.",

        sizes: [
            "S",
            "M",
            "L",
            "XL"
        ],

        colors: [
            "Negro",
            "Blanco"
        ],

        featured: true,

        stock: 15,

        active: true
    },


    {
        id: 2,
        name: "Remera Classic Black",
        category: "Hombre",
        subcategory: "Remeras",
        type: "Classic",

        price: 22999,
        oldPrice: null,

        badge: "DESTACADO",

        image: "https://www.dropbox.com/scl/fi/REEMPLAZAR-IMAGEN.jpg?raw=1",

        description: "Remera clásica con un diseño minimalista para usar todos los días.",

        sizes: [
            "S",
            "M",
            "L",
            "XL"
        ],

        colors: [
            "Negro"
        ],

        featured: true,

        stock: 20,

        active: true
    },


    {
        id: 3,
        name: "Hoodie Urban",
        category: "Hombre",
        subcategory: "Buzos",
        type: "Hoodie",

        price: 45999,
        oldPrice: null,

        badge: "BEST SELLER",

        image: "https://www.dropbox.com/scl/fi/REEMPLAZAR-IMAGEN.jpg?raw=1",

        description: "Hoodie urbano con capucha, diseñado para ofrecer comodidad y estilo.",

        sizes: [
            "S",
            "M",
            "L",
            "XL"
        ],

        colors: [
            "Negro",
            "Gris"
        ],

        featured: true,

        stock: 10,

        active: true
    },


    {
        id: 4,
        name: "Buzo Minimal",
        category: "Hombre",
        subcategory: "Buzos",
        type: "Crewneck",

        price: 47999,
        oldPrice: 54999,

        badge: "OFERTA",

        image: "https://www.dropbox.com/scl/fi/REEMPLAZAR-IMAGEN.jpg?raw=1",

        description: "Buzo de diseño limpio y moderno, ideal para combinar con cualquier outfit.",

        sizes: [
            "S",
            "M",
            "L",
            "XL"
        ],

        colors: [
            "Negro",
            "Beige"
        ],

        featured: false,

        stock: 8,

        active: true
    },


    {
        id: 5,
        name: "Cargo Street",
        category: "Hombre",
        subcategory: "Pantalones",
        type: "Cargo",

        price: 52999,
        oldPrice: 59999,

        badge: "NUEVO",

        image: "https://www.dropbox.com/scl/fi/REEMPLAZAR-IMAGEN.jpg?raw=1",

        description: "Pantalón cargo con bolsillos funcionales y diseño urbano.",

        sizes: [
            "38",
            "40",
            "42",
            "44"
        ],

        colors: [
            "Negro",
            "Verde"
        ],

        featured: false,

        stock: 12,

        active: true
    },


    {
        id: 6,
        name: "Jean Wide Fit",
        category: "Hombre",
        subcategory: "Pantalones",
        type: "Wide Fit",

        price: 54999,
        oldPrice: null,

        badge: "TREND",

        image: "https://www.dropbox.com/scl/fi/REEMPLAZAR-IMAGEN.jpg?raw=1",

        description: "Jean de corte amplio inspirado en las tendencias urbanas actuales.",

        sizes: [
            "38",
            "40",
            "42",
            "44"
        ],

        colors: [
            "Azul"
        ],

        featured: true,

        stock: 14,

        active: true
    },


    {
        id: 7,
        name: "Campera Urban Tech",
        category: "Hombre",
        subcategory: "Camperas",
        type: "Urban",

        price: 68999,
        oldPrice: null,

        badge: "NUEVO",

        image: "https://www.dropbox.com/scl/fi/REEMPLAZAR-IMAGEN.jpg?raw=1",

        description: "Campera moderna con diseño urbano y detalles funcionales.",

        sizes: [
            "S",
            "M",
            "L",
            "XL"
        ],

        colors: [
            "Negro"
        ],

        featured: true,

        stock: 7,

        active: true
    },


    {
        id: 8,
        name: "Conjunto Sport Essential",
        category: "Hombre",
        subcategory: "Conjuntos",
        type: "Deportivo",

        price: 74999,
        oldPrice: 82999,

        badge: "OFERTA",

        image: "https://www.dropbox.com/scl/fi/REEMPLAZAR-IMAGEN.jpg?raw=1",

        description: "Conjunto cómodo para un look deportivo y moderno.",

        sizes: [
            "S",
            "M",
            "L",
            "XL"
        ],

        colors: [
            "Negro",
            "Gris"
        ],

        featured: false,

        stock: 9,

        active: true
    },


    {
        id: 9,
        name: "Remera Basic Woman",
        category: "Mujer",
        subcategory: "Remeras",
        type: "Basic",

        price: 21999,
        oldPrice: null,

        badge: "NUEVO",

        image: "https://www.dropbox.com/scl/fi/REEMPLAZAR-IMAGEN.jpg?raw=1",

        description: "Remera básica y versátil para combinar con cualquier estilo.",

        sizes: [
            "S",
            "M",
            "L"
        ],

        colors: [
            "Blanco",
            "Negro",
            "Beige"
        ],

        featured: false,

        stock: 18,

        active: true
    },


    {
        id: 10,
        name: "Top Urban Fit",
        category: "Mujer",
        subcategory: "Tops",
        type: "Urban",

        price: 18999,
        oldPrice: null,

        badge: "DESTACADO",

        image: "https://www.dropbox.com/scl/fi/REEMPLAZAR-IMAGEN.jpg?raw=1",

        description: "Top moderno con diseño ajustado y estilo urbano.",

        sizes: [
            "S",
            "M",
            "L"
        ],

        colors: [
            "Negro",
            "Blanco"
        ],

        featured: true,

        stock: 11,

        active: true
    },


    {
        id: 11,
        name: "Pantalón Wide Woman",
        category: "Mujer",
        subcategory: "Pantalones",
        type: "Wide Leg",

        price: 49999,
        oldPrice: null,

        badge: "NUEVO",

        image: "https://www.dropbox.com/scl/fi/REEMPLAZAR-IMAGEN.jpg?raw=1",

        description: "Pantalón de pierna amplia con diseño moderno y elegante.",

        sizes: [
            "36",
            "38",
            "40",
            "42"
        ],

        colors: [
            "Negro",
            "Beige"
        ],

        featured: true,

        stock: 10,

        active: true
    },


    {
        id: 12,
        name: "Conjunto Essential Woman",
        category: "Mujer",
        subcategory: "Conjuntos",
        type: "Casual",

        price: 69999,
        oldPrice: 79999,

        badge: "OFERTA",

        image: "https://www.dropbox.com/scl/fi/REEMPLAZAR-IMAGEN.jpg?raw=1",

        description: "Conjunto moderno diseñado para comodidad y estilo.",

        sizes: [
            "S",
            "M",
            "L"
        ],

        colors: [
            "Beige",
            "Negro"
        ],

        featured: false,

        stock: 6,

        active: true
    },


    {
        id: 13,
        name: "Gorra AF Signature",
        category: "Accesorios",
        subcategory: "Gorras",
        type: "Signature",

        price: 18999,
        oldPrice: null,

        badge: "LIMITED",

        image: "https://www.dropbox.com/scl/fi/REEMPLAZAR-IMAGEN.jpg?raw=1",

        description: "Gorra exclusiva AF-MODAS para completar tu outfit.",

        sizes: [
            "Único"
        ],

        colors: [
            "Negro"
        ],

        featured: true,

        stock: 20,

        active: true
    },


    {
        id: 14,
        name: "Bolso Urban",
        category: "Accesorios",
        subcategory: "Bolsos",
        type: "Urban",

        price: 32999,
        oldPrice: null,

        badge: "NUEVO",

        image: "https://www.dropbox.com/scl/fi/odbluwrigy4i522mwgwgv/IMG-20260822-WA0257.jpg?rlkey=7xjzah22sd5a8eb68vjpgriph&st=xd4jae6q&raw=1",

        description: "Bolso práctico y moderno para acompañarte todos los días.",

        sizes: [
            "Único"
        ],

        colors: [
            "Negro",
            "Marrón"
        ],

        featured: false,

        stock: 8,

        active: true
    }

];