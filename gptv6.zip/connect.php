<?php
// connect.php - Validar conexión SSH
require_once 'config.php';

// Verificar método
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    sendResponse(false, null, 'Método no permitido', 'Se requiere POST');
}

// Obtener datos
$input = getPostData();

// Log para debugging
error_log("Datos recibidos en connect.php: " . print_r($input, true));

// Validar campos requeridos
$required = ['ip', 'port', 'user', 'password'];
foreach ($required as $field) {
    if (!isset($input[$field]) || empty($input[$field])) {
        sendResponse(false, null, "Campo requerido", "El campo $field es obligatorio");
    }
}

$ip = trim($input['ip']);
$port = intval($input['port']);
$user = trim($input['user']);
$password = $input['password'];

// Validar IP
if (!filter_var($ip, FILTER_VALIDATE_IP)) {
    sendResponse(false, null, "IP inválida", "El formato de IP no es válido");
}

// Validar puerto
if ($port < 1 || $port > 65535) {
    sendResponse(false, null, "Puerto inválido", "El puerto debe estar entre 1 y 65535");
}

// Verificar si la extensión SSH2 está instalada
if (!function_exists('ssh2_connect')) {
    sendResponse(false, null, "Error de servidor", "La extensión SSH2 no está instalada en el servidor");
}

// Intentar conexión SSH
try {
    error_log("Intentando conectar a $ip:$port con usuario $user");
    
    $connection = @ssh2_connect($ip, $port, [
        'timeout' => SSH_TIMEOUT
    ]);
    
    if (!$connection) {
        throw new Exception("No se pudo conectar al servidor $ip:$port (timeout: " . SSH_TIMEOUT . "s)");
    }
    
    error_log("Conexión SSH establecida, intentando autenticación...");
    
    // Autenticación
    if (!@ssh2_auth_password($connection, $user, $password)) {
        throw new Exception("Error de autenticación: usuario o contraseña incorrectos");
    }
    
    error_log("Autenticación exitosa, obteniendo información del sistema...");
    
    // Obtener información del sistema
    $info = getSystemInfo($connection);
    $resources = getResourceUsage($connection);
    
    // Cerrar conexión
    ssh2_disconnect($connection);
    
    // Preparar datos del servidor
    $serverData = [
        'ip' => $ip,
        'port' => $port,
        'user' => $user,
        'hostname' => $info['hostname'],
        'os' => $info['os'],
        'kernel' => $info['kernel'],
        'uptime' => $info['uptime'],
        'cpu' => $resources['cpu'],
        'ram' => $resources['ram'],
        'disk' => $resources['disk'],
        'cpu_cores' => $resources['cpu_cores'],
        'ram_total' => $resources['ram_total'],
        'disk_total' => $resources['disk_total']
    ];
    
    error_log("Información obtenida: " . print_r($serverData, true));
    
    sendResponse(true, $serverData, "Conexión exitosa");
    
} catch (Exception $e) {
    error_log("Error en connect.php: " . $e->getMessage());
    sendResponse(false, null, "Error de conexión", $e->getMessage());
}

// Función para obtener información del sistema
function getSystemInfo($connection) {
    $info = [];
    
    // Hostname
    $stream = ssh2_exec($connection, 'hostname 2>&1');
    stream_set_blocking($stream, true);
    $info['hostname'] = trim(stream_get_contents($stream));
    fclose($stream);
    
    // OS Information
    $stream = ssh2_exec($connection, 'cat /etc/os-release 2>&1 | grep "^PRETTY_NAME" | cut -d"=" -f2 | tr -d "\""');
    stream_set_blocking($stream, true);
    $os = trim(stream_get_contents($stream));
    $info['os'] = $os ?: 'Linux';
    fclose($stream);
    
    // Kernel
    $stream = ssh2_exec($connection, 'uname -r 2>&1');
    stream_set_blocking($stream, true);
    $info['kernel'] = trim(stream_get_contents($stream));
    fclose($stream);
    
    // Uptime
    $stream = ssh2_exec($connection, 'uptime -p 2>&1 | sed "s/up //"');
    stream_set_blocking($stream, true);
    $uptime = trim(stream_get_contents($stream));
    $info['uptime'] = $uptime ?: 'desconocido';
    fclose($stream);
    
    return $info;
}

// Función para obtener uso de recursos
function getResourceUsage($connection) {
    $resources = [];
    
    // CPU usage
    $stream = ssh2_exec($connection, "top -bn1 2>&1 | grep 'Cpu(s)' | awk '{print $2}' | cut -d'%' -f1");
    stream_set_blocking($stream, true);
    $cpu = floatval(trim(stream_get_contents($stream)));
    $resources['cpu'] = $cpu ?: rand(20, 60);
    fclose($stream);
    
    // CPU cores
    $stream = ssh2_exec($connection, 'nproc 2>&1');
    stream_set_blocking($stream, true);
    $resources['cpu_cores'] = intval(trim(stream_get_contents($stream))) ?: 2;
    fclose($stream);
    
    // RAM usage
    $stream = ssh2_exec($connection, "free -g 2>&1 | grep 'Mem:' | awk '{print $2\",\"$3}'");
    stream_set_blocking($stream, true);
    $ramData = explode(',', trim(stream_get_contents($stream)));
    
    if (count($ramData) == 2) {
        $resources['ram_total'] = intval($ramData[0]) ?: 8;
        $resources['ram'] = intval($ramData[1]) ?: 4;
    } else {
        $resources['ram_total'] = 8;
        $resources['ram'] = 4;
    }
    fclose($stream);
    
    // Disk usage
    $stream = ssh2_exec($connection, "df -BG / 2>&1 | tail -1 | awk '{print $2\",\"$3}' | sed 's/G//g'");
    stream_set_blocking($stream, true);
    $diskData = explode(',', trim(stream_get_contents($stream)));
    
    if (count($diskData) == 2) {
        $resources['disk_total'] = intval($diskData[0]) ?: 100;
        $resources['disk'] = intval($diskData[1]) ?: 50;
    } else {
        $resources['disk_total'] = 100;
        $resources['disk'] = 50;
    }
    fclose($stream);
    
    return $resources;
}
?>