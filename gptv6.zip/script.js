// ============================================
// VPS CONTROL PANEL - CON MANEJO DE ERRORES JSON
// ============================================

const API_URL = window.location.origin + window.location.pathname.replace(/[^/]*$/, '');

// Función mejorada para hacer peticiones fetch con manejo de errores
async function fetchAPI(endpoint, options = {}) {
    const url = `${API_URL}${endpoint}`;
    console.log(`🌐 Fetching: ${url}`, options);
    
    try {
        const response = await fetch(url, {
            ...options,
            headers: {
                'Content-Type': 'application/json',
                ...options.headers
            }
        });
        
        // Verificar si la respuesta es JSON
        const contentType = response.headers.get('content-type');
        if (!contentType || !contentType.includes('application/json')) {
            const text = await response.text();
            console.error('❌ Respuesta no es JSON:', text.substring(0, 200));
            throw new Error('El servidor no devolvió JSON. Posible error de PHP.');
        }
        
        const data = await response.json();
        console.log(`✅ Respuesta de ${endpoint}:`, data);
        
        if (!data.success) {
            throw new Error(data.error || data.message || 'Error desconocido');
        }
        
        return data;
        
    } catch (error) {
        console.error(`❌ Error en fetchAPI ${endpoint}:`, error);
        throw error;
    }
}

// Abrir modal
window.openAddServerModal = function() {
    document.getElementById('addServerModal').classList.add('active');
    document.getElementById('overlay').classList.add('active');
    document.body.style.overflow = 'hidden';
    
    document.getElementById('addServerForm').reset();
    document.getElementById('serverPort').value = '22';
    document.getElementById('connectionTest').style.display = 'none';
}

// Cerrar modal
window.closeModal = function() {
    document.getElementById('addServerModal').classList.remove('active');
    document.getElementById('overlay').classList.remove('active');
    document.body.style.overflow = '';
    
    document.getElementById('addServerForm').reset();
    document.getElementById('serverPort').value = '22';
    document.getElementById('connectionTest').style.display = 'none';
    
    document.getElementById('addServerSubmit').disabled = false;
    document.getElementById('addServerSubmit').innerHTML = '<i class="fas fa-plus"></i> Agregar Servidor';
}

// Toggle contraseña
window.togglePassword = function() {
    const input = document.getElementById('serverPassword');
    const icon = document.querySelector('.password-toggle i');
    
    if (input.type === 'password') {
        input.type = 'text';
        icon.className = 'fas fa-eye-slash';
    } else {
        input.type = 'password';
        icon.className = 'fas fa-eye';
    }
}

// Probar conexión y agregar servidor
window.testAndAddServer = async function() {
    const form = document.getElementById('addServerForm');
    const submitBtn = document.getElementById('addServerSubmit');
    const connectionTest = document.getElementById('connectionTest');
    
    if (!form.checkValidity()) {
        form.reportValidity();
        return;
    }
    
    const serverData = {
        ip: document.getElementById('serverIP').value,
        port: parseInt(document.getElementById('serverPort').value),
        user: document.getElementById('serverUser').value,
        password: document.getElementById('serverPassword').value,
        name: document.getElementById('serverName').value,
        location: document.getElementById('serverLocation').value || 'Desconocido',
        save_credentials: document.getElementById('saveCredentials').checked,
        auto_connect: document.getElementById('autoConnect').checked
    };
    
    // Mostrar test de conexión
    connectionTest.style.display = 'flex';
    connectionTest.querySelector('span').textContent = 'Conectando al servidor...';
    submitBtn.disabled = true;
    submitBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Conectando...';
    
    try {
        // 1. Probar conexión
        console.log('📡 Enviando datos a connect.php:', serverData);
        const connectResult = await fetchAPI('/connect.php', {
            method: 'POST',
            body: JSON.stringify({
                ip: serverData.ip,
                port: serverData.port,
                user: serverData.user,
                password: serverData.password
            })
        });
        
        console.log('✅ Conexión exitosa:', connectResult);
        
        connectionTest.querySelector('span').textContent = 'Conexión exitosa, guardando servidor...';
        
        // 2. Guardar servidor
        const serverInfo = connectResult.data;
        const saveResult = await fetchAPI('/save_server.php', {
            method: 'POST',
            body: JSON.stringify({
                ...serverData,
                cpu: serverInfo.cpu,
                ram: serverInfo.ram,
                disk: serverInfo.disk,
                uptime: serverInfo.uptime,
                os: serverInfo.os,
                kernel: serverInfo.kernel,
                cpu_cores: serverInfo.cpu_cores,
                ram_total: serverInfo.ram_total,
                disk_total: serverInfo.disk_total
            })
        });
        
        console.log('✅ Servidor guardado:', saveResult);
        
        showToast('Éxito', `Servidor ${serverData.name} agregado correctamente`, 'success');
        
        // Recargar servidores
        await loadServers();
        
        // Cerrar modal
        setTimeout(closeModal, 1000);
        
    } catch (error) {
        console.error('❌ Error:', error);
        showToast('Error', error.message, 'error');
        connectionTest.style.display = 'none';
    } finally {
        submitBtn.disabled = false;
        submitBtn.innerHTML = '<i class="fas fa-plus"></i> Agregar Servidor';
    }
}

// Cargar servidores
async function loadServers() {
    try {
        const result = await fetchAPI('/get_servers.php');
        localStorage.setItem('vps_servers', JSON.stringify(result.data || []));
        renderServers();
        updateStats();
    } catch (error) {
        console.error('Error cargando servidores:', error);
        showToast('Error', 'No se pudieron cargar los servidores', 'error');
    }
}

// Renderizar servidores
function renderServers() {
    const servers = JSON.parse(localStorage.getItem('vps_servers') || '[]');
    const grid = document.getElementById('serversGrid');
    const noServers = document.getElementById('noServers');
    
    if (!grid) return;
    
    if (servers.length === 0) {
        grid.innerHTML = '';
        if (noServers) noServers.style.display = 'block';
        return;
    }
    
    if (noServers) noServers.style.display = 'none';
    
    grid.innerHTML = servers.map(server => `
        <div class="server-card" onclick="viewServerDetails('${server.id}')">
            <div class="server-header">
                <div class="server-status status-${server.status}"></div>
                <div class="server-name">
                    <h3>${escapeHtml(server.name)}</h3>
                    <span class="server-ip">${escapeHtml(server.ip)}:${server.port}</span>
                </div>
                <button class="server-menu" onclick="event.stopPropagation()">
                    <i class="fas fa-ellipsis-v"></i>
                </button>
            </div>
            
            <div class="server-specs">
                <div class="spec"><i class="fas fa-microchip"></i> ${server.cpu_cores || 2} vCPU</div>
                <div class="spec"><i class="fas fa-memory"></i> ${server.ram_total || 8} GB RAM</div>
                <div class="spec"><i class="fas fa-hdd"></i> ${server.disk_total || 100} GB SSD</div>
            </div>
            
            <div class="server-usage">
                <div class="usage-item">
                    <span>CPU: ${server.cpu || 0}%</span>
                    <div class="progress-bar"><div class="progress" style="width: ${server.cpu || 0}%"></div></div>
                </div>
                <div class="usage-item">
                    <span>RAM: ${server.ram || 0} GB</span>
                    <div class="progress-bar"><div class="progress" style="width: ${((server.ram || 0) / (server.ram_total || 8) * 100)}%"></div></div>
                </div>
            </div>
            
            <div class="server-footer">
                <span class="server-location"><i class="fas fa-map-marker-alt"></i> ${escapeHtml(server.location)}</span>
                <div class="server-actions" onclick="event.stopPropagation()">
                    <button class="server-action-btn" onclick="controlServer('${server.id}', 'start')"><i class="fas fa-play"></i></button>
                    <button class="server-action-btn" onclick="controlServer('${server.id}', 'stop')"><i class="fas fa-stop"></i></button>
                    <button class="server-action-btn" onclick="controlServer('${server.id}', 'restart')"><i class="fas fa-redo-alt"></i></button>
                    <button class="server-action-btn delete" onclick="confirmDelete('${server.id}')"><i class="fas fa-trash"></i></button>
                </div>
            </div>
        </div>
    `).join('');
}

// Actualizar estadísticas
function updateStats() {
    const servers = JSON.parse(localStorage.getItem('vps_servers') || '[]');
    const total = servers.length;
    const active = servers.filter(s => s.status === 'active').length;
    
    document.getElementById('totalServers').textContent = total;
    document.getElementById('serverCount').textContent = total;
    document.getElementById('serverChange').innerHTML = `<i class="fas fa-arrow-up"></i> +${active}`;
    
    if (total > 0) {
        const avgCpu = Math.round(servers.reduce((acc, s) => acc + (s.cpu || 0), 0) / total);
        const avgRam = (servers.reduce((acc, s) => acc + (s.ram || 0), 0) / total).toFixed(1);
        
        document.getElementById('avgCpu').textContent = avgCpu + '%';
        document.getElementById('avgRam').textContent = avgRam + ' GB';
    }
}

// Controlar servidor
window.controlServer = async function(id, action) {
    const servers = JSON.parse(localStorage.getItem('vps_servers') || '[]');
    const server = servers.find(s => s.id === id);
    
    if (!server) return;
    
    if (action === 'restart') {
        showToast('Reiniciando', `Servidor ${server.name} se está reiniciando...`, 'info');
        
        try {
            await fetchAPI('/control_server.php', {
                method: 'POST',
                body: JSON.stringify({ id, action })
            });
            
            setTimeout(async () => {
                await loadServers();
                showToast('Reinicio completado', `Servidor ${server.name} reiniciado`, 'success');
            }, 5000);
            
        } catch (error) {
            showToast('Error', error.message, 'error');
        }
    } else {
        server.status = action === 'start' ? 'active' : 'stopped';
        localStorage.setItem('vps_servers', JSON.stringify(servers));
        renderServers();
        updateStats();
        showToast('Servidor', `Servidor ${server.name} ${action === 'start' ? 'iniciado' : 'detenido'}`, 'success');
    }
}

// Confirmar eliminación
window.confirmDelete = function(id) {
    const servers = JSON.parse(localStorage.getItem('vps_servers') || '[]');
    const server = servers.find(s => s.id === id);
    
    if (server && confirm(`¿Eliminar servidor ${server.name}?`)) {
        deleteServer(id);
    }
}

// Eliminar servidor
async function deleteServer(id) {
    try {
        await fetchAPI('/delete_server.php', {
            method: 'POST',
            body: JSON.stringify({ id })
        });
        
        await loadServers();
        showToast('Servidor eliminado', 'El servidor ha sido eliminado', 'warning');
        
    } catch (error) {
        showToast('Error', error.message, 'error');
    }
}

// Ver detalles
window.viewServerDetails = function(id) {
    const servers = JSON.parse(localStorage.getItem('vps_servers') || '[]');
    const server = servers.find(s => s.id === id);
    
    if (server) {
        alert(`
            Servidor: ${server.name}
            IP: ${server.ip}:${server.port}
            Usuario: ${server.user}
            SO: ${server.os}
            CPU: ${server.cpu}%
            RAM: ${server.ram} GB
            Disco: ${server.disk} GB
        `);
    }
}

// Toast notifications
function showToast(title, message, type = 'info') {
    const container = document.getElementById('toastContainer');
    if (!container) return;
    
    const toast = document.createElement('div');
    toast.className = `toast ${type}`;
    
    const icons = { success: 'fa-check-circle', error: 'fa-times-circle', warning: 'fa-exclamation-triangle', info: 'fa-info-circle' };
    
    toast.innerHTML = `
        <div class="toast-icon"><i class="fas ${icons[type]}"></i></div>
        <div class="toast-content">
            <div class="toast-title">${escapeHtml(title)}</div>
            <div class="toast-message">${escapeHtml(message)}</div>
        </div>
        <button class="toast-close" onclick="this.parentElement.remove()">×</button>
    `;
    
    container.appendChild(toast);
    setTimeout(() => toast.remove(), 5000);
}

// Utilidades
function escapeHtml(text) {
    if (!text) return '';
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
}

// Inicialización
document.addEventListener('DOMContentLoaded', async () => {
    console.log('🚀 Inicializando VPS Panel...');
    
    // Cargar servidores
    await loadServers();
    
    // Event listeners
    document.getElementById('menuToggle')?.addEventListener('click', () => {
        document.getElementById('sidebar').classList.toggle('active');
        document.getElementById('overlay').classList.toggle('active');
    });
    
    document.getElementById('overlay')?.addEventListener('click', () => {
        document.getElementById('sidebar').classList.remove('active');
        document.getElementById('overlay').classList.remove('active');
        closeModal();
    });
    
    document.getElementById('addServerBtn')?.addEventListener('click', openAddServerModal);
    document.getElementById('serverFilter')?.addEventListener('change', renderServers);
    
    // Cerrar con ESC
    document.addEventListener('keydown', (e) => {
        if (e.key === 'Escape') {
            closeModal();
            document.getElementById('sidebar').classList.remove('active');
            document.getElementById('overlay').classList.remove('active');
        }
    });
});