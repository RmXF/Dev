<?php
// save_server.php - Guardar servidor
require_once 'config.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    sendResponse(false, null, 'Método no permitido', 'Se requiere POST');
}

$input = getPostData();
error_log("Datos para guardar: " . print_r($input, true));

// Validar campos
$required = ['name', 'ip', 'port', 'user', 'password', 'location'];
foreach ($required as $field) {
    if (!isset($input[$field]) || empty($input[$field])) {
        sendResponse(false, null, "Campo requerido", "El campo $field es obligatorio");
    }
}

// Crear archivo servers.json si no existe
if (!file_exists('servers.json')) {
    file_put_contents('servers.json', json_encode([]));
    chmod('servers.json', 0666);
}

// Leer servidores existentes
$servers = json_decode(file_get_contents('servers.json'), true);
if (!is_array($servers)) {
    $servers = [];
}

// Crear nuevo servidor
$newServer = [
    'id' => uniqid(),
    'name' => $input['name'],
    'ip' => $input['ip'],
    'port' => intval($input['port']),
    'user' => $input['user'],
    'password' => isset($input['save_credentials']) && $input['save_credentials'] ? encrypt_password($input['password']) : '****',
    'location' => $input['location'],
    'status' => 'active',
    'cpu' => isset($input['cpu']) ? intval($input['cpu']) : 0,
    'ram' => isset($input['ram']) ? floatval($input['ram']) : 0,
    'disk' => isset($input['disk']) ? intval($input['disk']) : 0,
    'uptime' => $input['uptime'] ?? '0 días',
    'os' => $input['os'] ?? 'Linux',
    'kernel' => $input['kernel'] ?? '',
    'cpu_cores' => isset($input['cpu_cores']) ? intval($input['cpu_cores']) : 2,
    'ram_total' => isset($input['ram_total']) ? intval($input['ram_total']) : 8,
    'disk_total' => isset($input['disk_total']) ? intval($input['disk_total']) : 100,
    'created' => date('Y-m-d H:i:s'),
    'last_checked' => date('Y-m-d H:i:s')
];

// Agregar a la lista
$servers[] = $newServer;

// Guardar en archivo
if (file_put_contents('servers.json', json_encode($servers, JSON_PRETTY_PRINT))) {
    sendResponse(true, $newServer, 'Servidor guardado correctamente');
} else {
    sendResponse(false, null, 'Error al guardar', 'No se pudo escribir en el archivo servers.json');
}

// Función simple para encriptar (mejorar en producción)
function encrypt_password($password) {
    return base64_encode($password);
}
?>