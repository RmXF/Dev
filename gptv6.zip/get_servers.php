<?php
// get_servers.php - Obtener servidores
require_once 'config.php';

if ($_SERVER['REQUEST_METHOD'] !== 'GET') {
    sendResponse(false, null, 'Método no permitido', 'Se requiere GET');
}

$servers = [];

if (file_exists('servers.json')) {
    $content = file_get_contents('servers.json');
    $servers = json_decode($content, true);
    
    if (!is_array($servers)) {
        $servers = [];
    }
    
    // Ocultar contraseñas
    foreach ($servers as &$server) {
        if (isset($server['password']) && $server['password'] !== '****') {
            $server['password'] = '********';
        }
    }
}

sendResponse(true, $servers, 'Servidores obtenidos correctamente');
?>