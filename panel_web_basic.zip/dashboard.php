<?php
session_start();
if(empty($_SESSION['auth'])){
  header('Location: index.php');
  exit;
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<title>Dashboard - ReycodeSSH</title>
<style>
body {font-family:Arial;background:#0b0e13;color:white;margin:0;}
nav {background:#111923;padding:10px;}
nav a {color:#22c55e;margin-right:10px;text-decoration:none;}
main {padding:20px;}
</style>
</head>
<body>
<nav>
  <a href="dashboard.php">Inicio</a>
  <a href="logout.php">Cerrar sesión</a>
</nav>
<main>
<h2>Bienvenido al panel ReycodeSSH</h2>
<p>Este es un panel de prueba básico para verificar la instalación.</p>
<p>Si ves esta página, el panel está funcionando correctamente ✅</p>
</main>
</body>
</html>
