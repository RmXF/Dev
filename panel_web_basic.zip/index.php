<?php
session_start();
if(isset($_POST['user']) && isset($_POST['pass'])){
  if($_POST['user']=='admin' && $_POST['pass']=='admin123'){
    $_SESSION['auth']=true;
    header('Location: dashboard.php');
    exit;
  } else {
    $error = "Usuario o contraseña incorrectos";
  }
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<title>Panel ReycodeSSH</title>
<style>
body {font-family:Arial;background:#0b0e13;color:white;display:flex;justify-content:center;align-items:center;height:100vh;margin:0;}
form {background:#111923;padding:40px;border-radius:12px;box-shadow:0 0 15px rgba(0,0,0,0.6);width:300px;}
input {width:100%;margin:10px 0;padding:10px;border:none;border-radius:6px;}
button {width:100%;padding:10px;background:#22c55e;border:none;color:white;border-radius:6px;cursor:pointer;}
.error {color:#ff5555;text-align:center;}
</style>
</head>
<body>
<form method="post">
<h2>ReycodeSSH</h2>
<?php if(!empty($error)) echo "<p class='error'>$error</p>"; ?>
<input type="text" name="user" placeholder="Usuario" required>
<input type="password" name="pass" placeholder="Contraseña" required>
<button type="submit">Ingresar</button>
</form>
</body>
</html>
