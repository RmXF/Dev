/* AF MODAS · Gestión de cupones del panel. */
(() => {
  'use strict';
  const endpoint = '/api/coupons.php';
  const form = document.getElementById('couponForm');
  const list = document.getElementById('couponList');
  const save = document.getElementById('couponSave');
  const cancel = document.getElementById('couponCancel');
  const type = document.getElementById('couponType');
  const value = document.getElementById('couponValue');
  let coupons = [];
  let editingId = '';
  let busy = false;
  const today = () => new Intl.DateTimeFormat('en-CA', { timeZone: 'America/Argentina/Buenos_Aires', year: 'numeric', month: '2-digit', day: '2-digit' }).format(new Date());
  function resetForm() {
    editingId = '';
    form.reset();
    document.getElementById('couponActive').checked = true;
    document.getElementById('couponLimit').value = 100;
    document.getElementById('couponExpiry').min = today();
    document.getElementById('formTitle').textContent = 'Nuevo cupón';
    save.textContent = 'Guardar cupón';
    cancel.hidden = true;
    updateValueLimit();
  }
  function updateValueLimit() { value.max = type.value === 'percent' ? '100' : '10000000'; }
  function statusOf(coupon) {
    if (coupon.active === false) return ['Desactivado', 'inactive'];
    if (String(coupon.expiry || '') < today()) return ['Vencido', 'inactive'];
    if (Number(coupon.used || 0) >= Number(coupon.limit || 0)) return ['Agotado', 'inactive'];
    return ['Vigente', ''];
  }
  function render() {
    if (!coupons.length) { list.innerHTML = '<div class="coupon-empty">Todavía no hay cupones. Creá el primero en el formulario.</div>'; return; }
    list.innerHTML = coupons.map(c => {
      const [label, statusClass] = statusOf(c);
      const id = escapeHtml(String(c.id || ''));
      return `<article class="coupon-card"><div class="coupon-top"><span class="coupon-code">${escapeHtml(c.code || '')}</span><span class="coupon-status ${statusClass}">${label}</span></div>` +
        `<div class="coupon-meta">${escapeHtml(c.name || '')}</div>` +
        `<div class="coupon-stats"><span>${c.type === 'percent' ? Number(c.value || 0) + '%' : '$' + Number(c.value || 0).toLocaleString('es-AR')} de descuento</span>` +
        `<span>Hasta ${escapeHtml(c.expiry || '—')}</span><span>Usos: ${Number(c.used || 0)} / ${Number(c.limit || 0)}</span></div>` +
        `<div class="coupon-actions"><button class="coupon-btn secondary" data-action="edit" data-id="${id}">Editar</button>` +
        `<button class="coupon-btn secondary" data-action="toggle" data-id="${id}">${c.active === false ? 'Activar' : 'Desactivar'}</button>` +
        `<button class="coupon-btn danger" data-action="delete" data-id="${id}">Eliminar</button></div></article>`;
    }).join('');
  }
  async function api(method, data) {
    const response = await fetch(endpoint, { method, headers: data ? { 'Content-Type': 'application/json' } : {}, body: data ? JSON.stringify(data) : undefined, cache: 'no-store' });
    const result = await response.json();
    if (!response.ok || result.success === false) throw new Error(result.message || 'Error de servidor');
    return result;
  }
  async function reload() {
    const result = await api('GET');
    coupons = Array.isArray(result.data) ? result.data : [];
    render();
  }
  async function mutate(method, data, success) {
    if (busy) return;
    busy = true; save.disabled = true;
    try { await api(method, data); await reload(); showToast(success, 'success'); return true; }
    catch (error) { showToast(error.message, 'error'); return false; }
    finally { busy = false; save.disabled = false; }
  }
  form.addEventListener('submit', async event => {
    event.preventDefault();
    const data = {
      code: document.getElementById('couponCode').value.trim().toUpperCase(),
      name: document.getElementById('couponName').value.trim(),
      type: type.value, value: Number(value.value),
      expiry: document.getElementById('couponExpiry').value,
      limit: Number(document.getElementById('couponLimit').value),
      active: document.getElementById('couponActive').checked
    };
    if (editingId) data.id = editingId;
    if (await mutate(editingId ? 'PUT' : 'POST', data, editingId ? 'Cupón actualizado' : 'Cupón creado')) resetForm();
  });
  list.addEventListener('click', async event => {
    const button = event.target.closest('button[data-action]');
    if (!button || busy) return;
    const coupon = coupons.find(c => String(c.id) === button.dataset.id);
    if (!coupon) return;
    if (button.dataset.action === 'edit') {
      editingId = String(coupon.id);
      document.getElementById('couponCode').value = coupon.code || '';
      document.getElementById('couponName').value = coupon.name || '';
      type.value = coupon.type === 'percent' ? 'percent' : 'fixed';
      updateValueLimit(); value.value = coupon.value || '';
      document.getElementById('couponExpiry').min = '';
      document.getElementById('couponExpiry').value = coupon.expiry || '';
      document.getElementById('couponLimit').value = coupon.limit || 1;
      document.getElementById('couponActive').checked = coupon.active !== false;
      document.getElementById('formTitle').textContent = 'Editar cupón';
      save.textContent = 'Guardar cambios'; cancel.hidden = false;
      form.scrollIntoView({ behavior: 'smooth', block: 'start' });
    } else if (button.dataset.action === 'toggle') {
      const data = { ...coupon, active: coupon.active === false };
      await mutate('PUT', data, data.active ? 'Cupón activado' : 'Cupón desactivado');
    } else if (button.dataset.action === 'delete') {
      if (!confirm(`¿Eliminar el cupón ${coupon.code}?`)) return;
      if (await mutate('DELETE', { id: coupon.id }, 'Cupón eliminado') && editingId === String(coupon.id)) resetForm();
    }
  });
  cancel.addEventListener('click', resetForm);
  type.addEventListener('change', updateValueLimit);
  initAdminPage('coupons', async () => {
    resetForm();
    try { await reload(); } catch (error) { list.textContent = 'No se pudieron cargar los cupones.'; showToast(error.message, 'error'); }
  });
})();
