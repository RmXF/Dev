/* AF MODAS · Sesión del panel y token para operaciones de la API. */
(() => {
  'use strict';
  const originalFetch = window.fetch.bind(window);
  const authURL = '/api/auth.php';
  let redirecting = false;

  function clearLocalSession() {
    try {
      sessionStorage.removeItem('af_admin_session');
      sessionStorage.removeItem('af_admin_user');
      sessionStorage.removeItem('af_admin_csrf');
    } catch (_) {}
  }

  function loginRedirect() {
    if (redirecting) return;
    redirecting = true;
    clearLocalSession();
    try {
      sessionStorage.setItem('af_redirect_after_login', location.pathname + location.search);
    } catch (_) {}
    location.replace('/admin/login.html');
  }

  async function getSession() {
    const response = await originalFetch(authURL, {
      credentials: 'same-origin', cache: 'no-store'
    });
    if (!response.ok) throw new Error('No se pudo verificar la sesión.');
    const data = await response.json();
    if (!data.success) throw new Error(data.message || 'No se pudo verificar la sesión.');
    return data;
  }

  window.afCheckSession = async function () {
    try {
      const session = await getSession();
      if (!session.authenticated) {
        loginRedirect();
        return false;
      }
      sessionStorage.setItem('af_admin_session', 'true');
      sessionStorage.setItem('af_admin_user', session.user || 'Admin');
      sessionStorage.setItem('af_admin_csrf', session.csrf_token);
      return true;
    } catch (error) {
      console.error('Verificación de sesión:', error);
      // Fallo cerrado: las API no aceptarán operaciones sin sesión verificada.
      const message = document.createElement('div');
      message.setAttribute('role', 'alert');
      message.style.cssText = 'position:fixed;z-index:99999;inset:20px 20px auto;padding:18px;border-radius:12px;background:#722f42;color:#fff;text-align:center';
      message.textContent = 'No se pudo verificar la sesión. Comprobá la conexión y recargá la página.';
      document.body.appendChild(message);
      return false;
    }
  };

  window.afLogout = async function (reason = '') {
    if (redirecting) return;
    redirecting = true;
    try {
      const csrf = (await getSession()).csrf_token;
      const response = await originalFetch(authURL, {
        method: 'DELETE', credentials: 'same-origin', cache: 'no-store',
        headers: { 'X-CSRF-Token': csrf }
      });
      if (!response.ok) throw new Error('El servidor rechazó el cierre de sesión.');
      clearLocalSession();
      if (reason === 'inactivity') {
        try { sessionStorage.setItem('af_logout_reason', 'inactivity'); } catch (_) {}
      }
      location.replace('/admin/login.html');
    } catch (error) {
      console.error('Error al cerrar la sesión:', error);
      redirecting = false;
      alert('No se pudo cerrar la sesión en el servidor. Revisá la conexión e intentá de nuevo.');
    }
  };

  window.fetch = async function (input, init) {
    let request = new Request(input, init);
    const url = new URL(request.url);
    const isAPI = url.origin === location.origin && url.pathname.startsWith('/api/');
    const isAuth = url.pathname === '/api/auth.php';
    const mutation = !['GET', 'HEAD', 'OPTIONS'].includes(request.method.toUpperCase());

    if (isAPI && !isAuth && mutation) {
      let csrf = '';
      try { csrf = sessionStorage.getItem('af_admin_csrf') || ''; } catch (_) {}
      if (!csrf) {
        const session = await getSession();
        if (!session.authenticated) {
          loginRedirect();
          throw new Error('Sesión vencida.');
        }
        csrf = session.csrf_token;
        try { sessionStorage.setItem('af_admin_csrf', csrf); } catch (_) {}
      }
      const headers = new Headers(request.headers);
      headers.set('X-CSRF-Token', csrf);
      request = new Request(request, { headers, credentials: 'same-origin' });
    }

    const response = await originalFetch(request);
    if (isAPI && !isAuth && response.status === 401) loginRedirect();
    return response;
  };
})();
