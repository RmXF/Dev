(() => {
  'use strict';
  const $ = id => document.getElementById(id);
  const keys = ['name','address','phone','social','website','thanks','instructions','disclaimer','color'];
  let logo = '', url = '', dirty = false, logoBusy = false, previewBusy = false;
  try { document.body.classList.toggle('dark', localStorage.getItem('admin_theme') === 'dark'); } catch (_) {}
  const status = text => { $('status').textContent = text; };
  const values = () => Object.fromEntries([...keys.map(k=>[k,$(k).value.trim()]),['logo',logo]]);
  function updateLogo() { $('logoPreview').src = logo || '/assets/img/af-logo.png'; $('colorValue').textContent = $('color').value; }
  $('pdfForm').addEventListener('input',()=>{dirty=true;updateLogo();$('previewHint').hidden=false;$('previewHint').textContent='Cambiaste el diseño. Actualizá la vista previa para verlo.';});
  window.addEventListener('beforeunload', e=>{if(dirty){e.preventDefault();e.returnValue='';}});
  $('clearLogo').onclick=()=>{if(logoBusy)return;logo='';$('logoFile').value='';dirty=true;updateLogo();};
  $('logoFile').onchange=async()=>{
    const file=$('logoFile').files[0];if(!file)return;
    if(file.size>5*1024*1024 || !['image/png','image/jpeg','image/webp'].includes(file.type)){status('Elegí PNG, JPG o WebP de hasta 5 MB.');return;}
    logoBusy=true;$('save').disabled=true;
    let source='';
    try{
      source=URL.createObjectURL(file);const img=new Image();img.src=source;await img.decode();
      const scale=Math.min(1,256/img.naturalWidth,256/img.naturalHeight);const canvas=document.createElement('canvas');
      canvas.width=Math.max(1,Math.round(img.naturalWidth*scale));canvas.height=Math.max(1,Math.round(img.naturalHeight*scale));
      canvas.getContext('2d').drawImage(img,0,0,canvas.width,canvas.height);const png=canvas.toDataURL('image/png');
      if(png.length>400000)throw new Error('El logo es demasiado grande.');logo=png;dirty=true;updateLogo();status('Logo preparado. Guardá para aplicarlo.');
    }catch(e){status(e.message || 'No se pudo leer la imagen.');}finally{if(source)URL.revokeObjectURL(source);logoBusy=false;$('save').disabled=false;}
  };
  $('pdfForm').onsubmit=async e=>{
    e.preventDefault();if(logoBusy)return;$('save').disabled=true;$('fields').disabled=true;
    try{const response=await fetch('/api/pdf_settings.php',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(values())});const result=await response.json();if(!response.ok||!result.success)throw new Error(result.message||'No se pudo guardar');dirty=false;status('Ajustes guardados. Se aplican a los próximos comprobantes.');}
    catch(e){status(e.message);}finally{$('save').disabled=false;$('fields').disabled=false;}
  };
  $('preview').onclick=async()=>{
    if(logoBusy||previewBusy)return;if(!$('pdfForm').reportValidity())return;
    previewBusy=true;$('preview').disabled=true;status('Generando PDF de prueba…');
    try{
      const quote={preview:true,order_id:'PRUEBA',issued_at:new Date().toISOString(),subtotal:40000,coupon:'EJEMPLO',discount:4000,total:36000,items:[{code:'EJ-01',name:'Remera de ejemplo',color:'Beige',gender:'mujer',sizes:'M, L',qty:2,price:12000,subtotal:24000},{code:'EJ-02',name:'Pantalón de ejemplo',color:'Negro',gender:'unisex',sizes:'38, 40',qty:1,price:16000,subtotal:16000}]};
      const file=await window.AFOrderPDF.generate(quote,$('name').value,values());
      const old=url;url=URL.createObjectURL(file);$('pdfPreview').src=url;$('pdfPreview').hidden=false;$('download').href=url;$('download').hidden=false;$('previewHint').hidden=true;
      if(old)URL.revokeObjectURL(old);status('Vista previa lista. Podés descargar el PDF de prueba.');
    }catch(e){status(e.message||'No se pudo generar la vista previa.');}finally{previewBusy=false;$('preview').disabled=false;}
  };
  (async()=>{
    if(!(await window.afCheckSession()))return;
    try{const response=await fetch('/api/pdf_settings.php',{cache:'no-store'});const result=await response.json();if(!response.ok||!result.success)throw new Error('No se pudo cargar la configuración. Recargá para reintentar.');keys.forEach(k=>$(k).value=result.data[k]||'');logo=result.data.logo||'';updateLogo();$('fields').disabled=false;status('Configuración cargada.');}
    catch(e){status(e.message);}
  })();
})();
