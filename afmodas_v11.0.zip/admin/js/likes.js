/* AF MODAS · Estadísticas privadas de Me encanta. */
(() => {
  'use strict';
  const list = document.getElementById('allLikes');
  const refresh = document.getElementById('refreshLikes');
  let busy = false;
  async function reload() {
    if (busy) return;
    busy = true; refresh.disabled = true;
    try {
      const response = await fetch('/api/product_likes.php?ranking=1', {cache:'no-store'});
      const result = await response.json();
      if (!response.ok || !result.success || !Array.isArray(result.data)) throw new Error();
      const rows = result.data;
      document.getElementById('totalLikes').textContent = Number(result.total || 0).toLocaleString('es-AR');
      document.getElementById('likesWinner').textContent = rows[0]?.name || 'Todavía no hay votos';
      document.getElementById('winnerLikes').textContent = rows.length ? '♥ ' + Number(rows[0].likes).toLocaleString('es-AR') + ' Me encanta' : 'Los votos aparecerán cuando tus clientes elijan sus prendas favoritas.';
      list.replaceChildren();
      if (!rows.length) { const p = document.createElement('p'); p.className = 'likes-status'; p.textContent = 'Todavía no hay prendas con likes.'; list.appendChild(p); }
      rows.forEach((product,index) => {
        const row = document.createElement('article'); row.className = 'likes-row';
        const rank = document.createElement('span'); rank.className = 'likes-rank'; rank.textContent = String(index+1);
        const photo = document.createElement('img'); photo.loading = 'lazy'; photo.alt = String(product.name);
        photo.src = product.removed ? '/assets/img/af-logo.png' : '/api/product_image.php?code=' + encodeURIComponent(String(product.code));
        photo.addEventListener('error', () => { photo.src = '/assets/img/af-logo.png'; }, {once:true});
        const detail = document.createElement('div');
        const name = document.createElement(product.removed ? 'span' : 'a'); name.className = 'likes-name'; name.textContent = String(product.name);
        if (!product.removed) { name.href = '/producto.php?code=' + encodeURIComponent(String(product.code)); name.target = '_blank'; name.rel = 'noopener'; }
        const code = document.createElement('small'); code.className = 'likes-code'; code.textContent = '#' + String(product.code) + (product.removed ? ' · Retirada del catálogo' : '');
        detail.append(name,code);
        const count = document.createElement('span'); count.className = 'likes-count'; count.textContent = '♥ ' + Number(product.likes || 0).toLocaleString('es-AR');
        row.append(rank,photo,detail,count); list.appendChild(row);
      });
    } catch (_) {
      list.replaceChildren(); const error = document.createElement('p'); error.className = 'likes-status'; error.textContent = 'No se pudieron consultar los votos. Intentá actualizar.'; list.appendChild(error);
      document.getElementById('totalLikes').textContent = '—'; document.getElementById('likesWinner').textContent = 'No disponible'; document.getElementById('winnerLikes').textContent = '';
    } finally { busy = false; refresh.disabled = false; }
  }
  refresh.addEventListener('click', reload);
  initAdminPage('likes', reload);
})();
