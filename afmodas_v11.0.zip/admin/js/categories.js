/* AF MODAS · CRUD de categorías. La API impide eliminar categorías en uso. */
(() => {
  'use strict';
  const endpoint = '/api/categories.php';
  const list = document.getElementById('categoryList');
  const form = document.getElementById('categoryForm');
  const input = document.getElementById('categoryName');
  const save = document.getElementById('categorySave');
  let categories = [], busy = false;
  async function request(method, body) {
    const response = await fetch(endpoint, { method, cache:'no-store', headers: body ? { 'Content-Type':'application/json' } : {}, body: body ? JSON.stringify(body) : undefined });
    const result = await response.json();
    if (!response.ok || result.success !== true) throw new Error(result.message || 'No se pudo actualizar la lista');
    return result;
  }
  function render() {
    if (!categories.length) { list.innerHTML = '<p class="cat-empty">Todavía no hay categorías.</p>'; return; }
    list.innerHTML = categories.map(category => {
      const name = escapeHtml(category.name);
      const count = Number(category.products) || 0;
      const alternatives = categories.filter(other => other.name !== category.name);
      const move = count ? `<label class="cat-reassign">Mover a <select class="cat-input" aria-label="Categoría de destino para ${name}">${alternatives.map(other => `<option value="${escapeHtml(other.name)}">${escapeHtml(other.name)}</option>`).join('')}</select></label>` : '';
      return `<article class="cat-row"><div><div class="cat-name">${name}</div><small class="cat-count">${count} ${count === 1 ? 'prenda' : 'prendas'}</small></div>` +
        `<div class="cat-actions"><a class="cat-link" href="products.html?category=${encodeURIComponent(category.name)}">Ver prendas</a>` +
        move + `<button class="cat-btn danger" type="button" data-name="${name}" ${categories.length <= 1 ? 'disabled' : ''}>${count ? 'Mover y eliminar' : 'Eliminar'}</button></div></article>`;
    }).join('');
  }
  async function reload() {
    const result = await request('GET');
    categories = result.data || [];
    render();
  }
  form.addEventListener('submit', async event => {
    event.preventDefault(); if (busy) return;
    busy = true; save.disabled = true;
    try {
      await request('POST', { name: input.value.trim() });
      await reload(); input.value = ''; showToast('Categoría agregada', 'success'); input.focus();
    } catch (error) { showToast(error.message, 'error'); }
    finally { busy = false; save.disabled = false; }
  });
  list.addEventListener('click', async event => {
    const button = event.target.closest('button[data-name]');
    if (!button || button.disabled || busy) return;
    const name = button.dataset.name;
    const reassign = button.closest('.cat-row').querySelector('.cat-reassign select')?.value || '';
    const count = categories.find(category => category.name === name)?.products || 0;
    if (!confirm(count ? `¿Mover ${count} prendas a «${reassign}» y eliminar «${name}»?` : `¿Eliminar la categoría «${name}»?`)) return;
    busy = true; button.disabled = true;
    try { const result = await request('DELETE', { name, reassign_to: reassign }); await reload(); showToast(result.message, 'success'); }
    catch (error) { showToast(error.message, 'error'); await reload().catch(() => {}); }
    finally { busy = false; }
  });
  initAdminPage('categories', async () => {
    try { await reload(); }
    catch (error) { list.textContent = 'No se pudieron cargar las categorías.'; showToast(error.message, 'error'); }
  });
})();
