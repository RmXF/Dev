/* AF MODAS: resumen del catálogo. Comparaciones actuales, no historial de ventas. */
(function () {
  'use strict';
  const charts = {};
  const number = value => Math.max(0, Number(value) || 0);
  const stock = p => number(p.stock);
  const fmt = value => value.toLocaleString('es-AR');
  const escape = value => String(value ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  const products = () => Array.isArray(window.products) ? window.products : [];
  function card(label, value, icon, color, href, id) {
    const tag = href ? 'a' : 'div';
    return `<${tag} class="admin-stat-card control-stat" ${href ? `href="${href}"` : ''}><div class="admin-stat-icon" style="background:${color}"><i class="fas fa-${icon}"></i></div><div><h3 ${id ? `id="${id}"` : ''}>${value}</h3><p>${label}</p></div></${tag}>`;
  }
  window.renderStats = function () {
    const list = products();
    const el = document.getElementById('adminStats');
    if (!el) return;
    el.innerHTML = [
      card('Prendas registradas', fmt(list.length), 'tshirt', '#ef6b64', 'products.html'),
      card('Categorías con prendas', fmt(new Set(list.map(p => p.category || 'Sin categoría')).size), 'tags', '#8667e8', 'categories.html'),
      card('Unidades disponibles', fmt(list.reduce((sum,p) => sum + stock(p),0)), 'boxes', '#18ae76'),
      card('Valor del stock', '$' + fmt(list.reduce((sum,p) => sum + number(p.price) * stock(p),0)), 'dollar-sign', '#c89b3c'),
      card('Total de Me encanta', '…', 'heart', '#aa4c6b', 'likes.html', 'dashboardLikesTotal'),
      card('Prendas sin stock', fmt(list.filter(p => stock(p) === 0).length), 'box-open', '#ef6b64', 'products.html'),
      card('Prendas con stock bajo', fmt(list.filter(p => stock(p) > 0 && stock(p) <= 5).length), 'exclamation-triangle', '#c89b3c', 'products.html')
    ].join('');
    const attention = document.getElementById('stockAttention');
    if (attention) {
      const low = list.filter(p => stock(p) <= 5).sort((a,b) => stock(a) - stock(b));
      attention.innerHTML = low.length ? `<div class="control-table-wrap"><table class="control-table"><thead><tr><th>Prenda</th><th>Categoría</th><th>Unidades</th><th>Estado</th></tr></thead><tbody>${low.slice(0,12).map(p => `<tr><td>${escape(p.name || 'Prenda')}<small>#${escape(p.code)}</small></td><td>${escape(p.category || 'Sin categoría')}</td><td>${fmt(stock(p))}</td><td><span class="control-badge ${stock(p) === 0 ? 'empty' : ''}">${stock(p) === 0 ? 'Sin stock' : 'Stock bajo'}</span></td></tr>`).join('')}</tbody></table></div><a class="control-more" href="products.html">Revisar en Productos${low.length > 12 ? ` · ${fmt(low.length)} prendas en total` : ''} →</a>` : '<p class="control-empty">Todas las prendas tienen más de 5 unidades disponibles.</p>';
    }
    loadDashboardLikes();
  };
  async function loadDashboardLikes() {
    const count = document.getElementById('dashboardLikesTotal');
    if (!count) return;
    try {
      const response = await fetch('/api/product_likes.php?ranking=1', {cache:'no-store'});
      const result = await response.json();
      if (!response.ok || !result.success) throw new Error('Consulta no disponible');
      count.textContent = fmt(number(result.total));
    } catch (_) { count.textContent = '—'; count.title = 'No se pudo consultar el total de Me encanta'; }
  }
  function area(id, labels, values, name, color) {
    const el = document.getElementById(id);
    if (!el) return;
    if (charts[id]) { charts[id].destroy(); delete charts[id]; }
    if (!products().length) { el.innerHTML = '<p class="control-empty">No hay prendas para mostrar.</p>'; return; }
    if (typeof ApexCharts === 'undefined') {
      el.innerHTML = `<p class="control-note">Gráfica no disponible. Resumen:</p><ul>${labels.map((label,i) => `<li>${escape(label)}: ${fmt(values[i])}</li>`).join('')}</ul>`;
      return;
    }
    el.innerHTML = '';
    const dark = document.body.classList.contains('dark');
    charts[id] = new ApexCharts(el, {
      chart:{type:'area',height:280,fontFamily:'Inter, sans-serif',background:'transparent',toolbar:{show:false},animations:{enabled:!window.matchMedia('(prefers-reduced-motion: reduce)').matches,speed:500}},
      series:[{name,data:values}], colors:[color],
      stroke:{curve:'smooth',width:2.5}, fill:{type:'gradient',gradient:{opacityFrom:.38,opacityTo:.025,stops:[0,100]}},
      markers:{size:4,hover:{size:6}}, dataLabels:{enabled:false},
      xaxis:{categories:labels,labels:{trim:true,rotate:-25,style:{colors:dark?'#b8bdc7':'#68717d'}}},
      yaxis:{min:0,forceNiceScale:true,labels:{formatter:v => fmt(Math.round(v)),style:{colors:dark?'#b8bdc7':'#68717d'}}},
      grid:{borderColor:dark?'rgba(255,255,255,.07)':'rgba(60,50,40,.08)',strokeDashArray:4},
      tooltip:{theme:dark?'dark':'light',y:{formatter:v => fmt(v)}}, theme:{mode:dark?'dark':'light'}, legend:{show:false}
    });
    charts[id].render();
  }
  window.renderDonaChart = function () {
    const groups = new Map();
    products().forEach(p => { const key = String(p.category || 'Sin categoría'); groups.set(key,(groups.get(key) || 0)+1); });
    const entries = [...groups].sort((a,b) => b[1]-a[1] || a[0].localeCompare(b[0]));
    area('chartDona', entries.map(e=>e[0]), entries.map(e=>e[1]), 'Prendas', '#ef6b64');
  };
  window.renderBarChart = function () {
    const groups = new Map([['Hombre',0],['Mujer',0],['Unisex',0]]);
    products().forEach(p => {
      const gender = String(p.gender || 'unisex').trim().toLowerCase();
      const key = ({hombre:'Hombre',varon:'Hombre','varón':'Hombre',mujer:'Mujer',unisex:'Unisex'})[gender] || 'Otros';
      groups.set(key,(groups.get(key) || 0)+stock(p));
    });
    area('chartBar',[...groups.keys()],[...groups.values()],'Unidades','#18ae76');
  };
  window.renderRadialChart = function () {
    const list = products();
    area('chartRadial',['Sin stock','1 a 5 unidades','6 a 15 unidades','Más de 15 unidades'],[
      list.filter(p=>stock(p)===0).length,list.filter(p=>stock(p)>0 && stock(p)<=5).length,
      list.filter(p=>stock(p)>5 && stock(p)<=15).length,list.filter(p=>stock(p)>15).length
    ],'Prendas','#4f7cff');
  };
})();
