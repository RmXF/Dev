// ============================================
// AF MODAS — DASHBOARD
// ============================================

let chartDonaInstance = null;
let chartBarInstance = null;
let chartRadialInstance = null;

// ============================================
// UTILIDADES DE COLOR
// ============================================
function isDarkMode() {
  return document.body.classList.contains('dark');
}

function getTextColor() {
  return isDarkMode() ? '#eaeaea' : '#264653';
}

function getGridColor() {
  return isDarkMode() ? 'rgba(255,255,255,0.06)' : 'rgba(107,79,58,0.08)';
}

// ============================================
// ESTADÍSTICAS
// ============================================
function renderStats() {
  const total = window.products.length;
  const categories = new Set(window.products.map(p => p.category)).size;
  const stockValue = window.products.reduce(
    (s, p) => s + (Number(p.price) * Number(p.stock || 0)), 0
  );
  const totalStock = window.products.reduce(
    (s, p) => s + Number(p.stock || 0), 0
  );

  const stats = document.getElementById('adminStats');
  if (!stats) return;

  stats.innerHTML = `
    <div class="admin-stat-card">
      <div class="admin-stat-icon" style="background:#2a9d8f;"><i class="fas fa-tshirt"></i></div>
      <h3>${total}</h3><p>Productos</p>
    </div>
    <div class="admin-stat-card">
      <div class="admin-stat-icon" style="background:#e76f51;"><i class="fas fa-tags"></i></div>
      <h3>${categories}</h3><p>Categorías</p>
    </div>
    <div class="admin-stat-card">
      <div class="admin-stat-icon" style="background:#e9c46a;"><i class="fas fa-dollar-sign"></i></div>
      <h3>$${stockValue.toLocaleString()}</h3><p>Valor Stock</p>
    </div>
    <div class="admin-stat-card">
      <div class="admin-stat-icon" style="background:#8ab17d;"><i class="fas fa-boxes"></i></div>
      <h3>${totalStock}</h3><p>Unidades</p>
    </div>
  `;
}

// ============================================
// GRÁFICO DONA
// ============================================
function renderDonaChart() {
  const container = document.getElementById('chartDona');
  if (!container) return;

  const catCount = {};
  window.products.forEach(p => {
    const cat = p.category || 'Sin categoría';
    catCount[cat] = (catCount[cat] || 0) + 1;
  });

  const categories = Object.keys(catCount);
  const counts = Object.values(catCount);

  if (chartDonaInstance) chartDonaInstance.destroy();

  if (categories.length === 0) {
    container.innerHTML = '<div style="text-align:center;padding:3rem;color:#888;"><i class="fas fa-inbox" style="font-size:2rem;opacity:0.3;"></i><p style="margin-top:0.5rem;">Sin productos</p></div>';
    return;
  }

  const options = {
    series: counts,
    chart: {
      type: 'donut', height: 300,
      fontFamily: 'Inter, sans-serif',
      background: 'transparent',
      animations: {
        enabled: true, easing: 'easeinout', speed: 800,
        animateGradually: { enabled: true, delay: 150 }
      }
    },
    labels: categories,
    colors: ['#2a9d8f','#e76f51','#e9c46a','#8ab17d','#6b4f3a','#b35f9e','#264653','#f4a261','#6366f1','#f59e0b'],
    legend: {
      position: 'bottom', fontFamily: 'Inter, sans-serif',
      labels: { colors: getTextColor() },
      markers: { width: 10, height: 10, radius: 10 },
      itemMargin: { horizontal: 8, vertical: 4 }
    },
    dataLabels: {
      enabled: true,
      style: { fontSize: '11px', fontFamily: 'Inter, sans-serif', fontWeight: 700 }
    },
    plotOptions: {
      pie: {
        donut: {
          size: '65%',
          labels: {
            show: true,
            name: {
              show: true, fontSize: '13px', fontFamily: 'Inter, sans-serif',
              color: getTextColor(), offsetY: -5
            },
            value: {
              show: true, fontSize: '22px', fontFamily: 'Inter, sans-serif',
              fontWeight: 900, color: getTextColor(), offsetY: 5
            },
            total: {
              show: true, label: 'Total',
              fontSize: '13px', fontFamily: 'Inter, sans-serif',
              color: getTextColor(),
              formatter: (w) => w.globals.seriesTotals.reduce((a, b) => a + b, 0)
            }
          }
        }
      }
    },
    tooltip: {
      theme: isDarkMode() ? 'dark' : 'light',
      style: { fontFamily: 'Inter, sans-serif' },
      y: { formatter: (val) => val + ' producto' + (val !== 1 ? 's' : '') }
    }
  };

  chartDonaInstance = new ApexCharts(container, options);
  chartDonaInstance.render();
}

// ============================================
// GRÁFICO BARRAS
// ============================================
function renderBarChart() {
  const container = document.getElementById('chartBar');
  if (!container) return;

  const genCount = { hombre: 0, mujer: 0, unisex: 0 };
  window.products.forEach(p => {
    if (genCount[p.gender] !== undefined) genCount[p.gender]++;
  });

  if (chartBarInstance) chartBarInstance.destroy();

  const options = {
    series: [{ name: 'Productos', data: [genCount.hombre, genCount.mujer, genCount.unisex] }],
    chart: {
      type: 'bar', height: 300,
      fontFamily: 'Inter, sans-serif',
      background: 'transparent', toolbar: { show: false },
      animations: { enabled: true, easing: 'easeinout', speed: 800 }
    },
    plotOptions: {
      bar: {
        borderRadius: 8,
        borderRadiusApplication: 'end',
        columnWidth: '55%',
        distributed: true,
        dataLabels: { position: 'top' }
      }
    },
    colors: ['#93c5fd', '#f9a8d4', '#fcd34d'],
    dataLabels: {
      enabled: true, offsetY: -20,
      style: {
        fontSize: '13px', fontFamily: 'Inter, sans-serif',
        fontWeight: 700, colors: [getTextColor()]
      }
    },
    xaxis: {
      categories: ['Hombre', 'Mujer', 'Unisex'],
      labels: {
        style: { fontSize: '12px', fontFamily: 'Inter, sans-serif', fontWeight: 600, colors: getTextColor() }
      },
      axisBorder: { show: false }, axisTicks: { show: false }
    },
    yaxis: {
      labels: {
        style: { fontSize: '11px', fontFamily: 'Inter, sans-serif', colors: getTextColor() },
        formatter: (val) => Math.floor(val)
      }
    },
    grid: {
      borderColor: getGridColor(),
      strokeDashArray: 4,
      xaxis: { lines: { show: false } },
      yaxis: { lines: { show: true } }
    },
    legend: { show: false },
    tooltip: {
      theme: isDarkMode() ? 'dark' : 'light',
      style: { fontFamily: 'Inter, sans-serif' },
      y: { formatter: (val) => val + ' producto' + (val !== 1 ? 's' : '') }
    }
  };

  chartBarInstance = new ApexCharts(container, options);
  chartBarInstance.render();
}

// ============================================
// GRÁFICO RADIAL
// ============================================
function renderRadialChart() {
  const container = document.getElementById('chartRadial');
  if (!container) return;

  const total = window.products.length;
  const conStock = window.products.filter(p => Number(p.stock) > 0).length;
  const porcentaje = total > 0 ? Math.round((conStock / total) * 100) : 0;

  if (chartRadialInstance) chartRadialInstance.destroy();

  const options = {
    series: [porcentaje],
    chart: {
      type: 'radialBar', height: 320,
      fontFamily: 'Inter, sans-serif',
      background: 'transparent',
      animations: { enabled: true, easing: 'easeinout', speed: 1000 }
    },
    plotOptions: {
      radialBar: {
        hollow: { size: '65%' },
        track: { background: getGridColor(), strokeWidth: '100%' },
        dataLabels: {
          name: {
            show: true, fontSize: '14px', fontFamily: 'Inter, sans-serif',
            color: getTextColor(), offsetY: -10
          },
          value: {
            show: true, fontSize: '32px', fontFamily: 'Inter, sans-serif',
            fontWeight: 900, color: '#2a9d8f', offsetY: 5,
            formatter: (val) => val + '%'
          }
        }
      }
    },
    fill: {
      type: 'gradient',
      gradient: {
        shade: 'dark', type: 'horizontal',
        gradientToColors: ['#8ab17d'], stops: [0, 100]
      }
    },
    stroke: { lineCap: 'round' },
    labels: ['Con Stock'],
    colors: ['#2a9d8f']
  };

  chartRadialInstance = new ApexCharts(container, options);
  chartRadialInstance.render();
}

// ============================================
// RENDER COMPLETO
// ============================================
function renderDashboard() {
  renderStats();
  renderDonaChart();
  renderBarChart();
  renderRadialChart();
}

// ============================================
// RE-RENDER AL CAMBIAR TEMA
// ============================================
document.addEventListener('themeChanged', () => {
  setTimeout(() => {
    renderDonaChart();
    renderBarChart();
    renderRadialChart();
  }, 100);
});

// ============================================
// INICIALIZACIÓN
// ============================================
initAdminPage('dashboard', async () => {
  await fetchProducts();
  renderDashboard();
});