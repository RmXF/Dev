// ============================================
// AF MODAS — ADMIN PANEL · FUNCIONES COMUNES
// ============================================

// CONFIGURACIÓN GLOBAL
const API_BASE = window.location.origin + '/api';
const SITE_URL = window.location.origin + '/';

// ⏱️ TIEMPO DE INACTIVIDAD (5 minutos)
const INACTIVITY_TIMEOUT = 300000;
const WARNING_BEFORE_LOGOUT = 60000;

// DATOS GLOBALES COMPARTIDOS
window.products = [];
window.notifications = [];
window.editingCode = null;

// ============================================
// PROTECCIÓN DE SESIÓN
// ============================================
function checkSession() {
  const session = sessionStorage.getItem('af_admin_session');

  if (!session) {
    sessionStorage.setItem(
      'af_redirect_after_login',
      window.location.pathname + window.location.search
    );
    window.location.href = '/admin/login.html';
    return false;
  }

  const user = sessionStorage.getItem('af_admin_user');
  const userDisplay = document.getElementById('adminUserDisplay');
  if (userDisplay && user) userDisplay.textContent = user;

  return true;
}

// ============================================
// AUTO-LOGOUT POR INACTIVIDAD
// ============================================
let inactivityTimer = null;
let warningTimer = null;
let warningElement = null;

function forceLogout(reason) {
  sessionStorage.removeItem('af_admin_session');
  sessionStorage.removeItem('af_admin_user');

  if (warningElement && warningElement.parentNode) {
    warningElement.remove();
  }

  const msg = reason === 'inactivity'
    ? '⏱️ Sesión cerrada por inactividad'
    : '🔒 Sesión cerrada';

  alert(msg);
  window.location.href = '/admin/login.html';
}

function resetInactivityTimer() {
  if (inactivityTimer) clearTimeout(inactivityTimer);
  if (warningTimer) clearTimeout(warningTimer);

  if (warningElement && warningElement.parentNode) {
    warningElement.remove();
    warningElement = null;
  }

  warningTimer = setTimeout(() => {
    warningElement = document.createElement('div');
    warningElement.className = 'session-warning';
    warningElement.innerHTML = '⚠️ La sesión se cerrará pronto por inactividad';
    document.body.appendChild(warningElement);
  }, INACTIVITY_TIMEOUT - WARNING_BEFORE_LOGOUT);

  inactivityTimer = setTimeout(() => {
    forceLogout('inactivity');
  }, INACTIVITY_TIMEOUT);
}

function startInactivityWatcher() {
  ['mousemove', 'mousedown', 'keydown', 'scroll', 'touchstart', 'click', 'focus', 'input'].forEach(event => {
    document.addEventListener(event, resetInactivityTimer, { passive: true });
  });
  resetInactivityTimer();
  console.log('⏱️ Auto-logout activo: ' + (INACTIVITY_TIMEOUT / 1000) + 's');
}

// ============================================
// LOGOUT MANUAL
// ============================================
function logoutAdmin() {
  if (!confirm('¿Cerrar sesión?')) return;
  if (inactivityTimer) clearTimeout(inactivityTimer);
  if (warningTimer) clearTimeout(warningTimer);
  sessionStorage.removeItem('af_admin_session');
  sessionStorage.removeItem('af_admin_user');
  window.location.href = '/admin/login.html';
}

// ============================================
// NAVEGACIÓN
// ============================================
function goToSite() {
  window.open(SITE_URL, '_blank');
}

function toggleAdminMenu() {
  const sidebar = document.getElementById('adminSidebar');
  if (sidebar) sidebar.classList.toggle('open');
}

// ============================================
// TEMA CLARO/OSCURO
// ============================================
function toggleTheme() {
  document.body.classList.toggle('dark');
  const icon = document.getElementById('themeIcon');
  if (icon) {
    icon.className = document.body.classList.contains('dark') ? 'fas fa-sun' : 'fas fa-moon';
  }
  localStorage.setItem(
    'admin_theme',
    document.body.classList.contains('dark') ? 'dark' : 'light'
  );

  // Notificar a la página para que actualice gráficos si es necesario
  document.dispatchEvent(new CustomEvent('themeChanged'));
}

function loadTheme() {
  if (localStorage.getItem('admin_theme') === 'dark') {
    document.body.classList.add('dark');
    const icon = document.getElementById('themeIcon');
    if (icon) icon.className = 'fas fa-sun';
  }
}

// ============================================
// TOAST
// ============================================
function showToast(message, type) {
  const toast = document.createElement('div');
  toast.className = 'toast' + (type ? ' ' + type : '');
  toast.textContent = message;
  document.body.appendChild(toast);
  setTimeout(() => { if (toast.parentNode) toast.remove(); }, 3000);
}

// ============================================
// MODALES
// ============================================
function closeModal(id) {
  const modal = document.getElementById(id);
  if (modal) modal.classList.remove('open');
}

document.addEventListener('click', function(e) {
  if (e.target.classList.contains('modal-overlay')) {
    e.target.classList.remove('open');
  }
});

// ============================================
// UTILIDADES
// ============================================
function escapeHtml(value) {
  if (value === null || value === undefined) return '';
  return String(value)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#039;');
}

function normalizeProductSizes(value) {
  if (Array.isArray(value)) {
    return value.map(s => String(s).trim()).filter(Boolean);
  }
  if (typeof value === 'string') {
    const trimmed = value.trim();
    if (!trimmed) return [];

    if (
      trimmed.length > 1 &&
      trimmed.charAt(0) === '[' &&
      trimmed.charAt(trimmed.length - 1) === ']'
    ) {
      try {
        const parsed = JSON.parse(trimmed);
        if (Array.isArray(parsed)) {
          return parsed.map(s => String(s).trim()).filter(Boolean);
        }
      } catch (e) {}
    }

    return trimmed.split(',').map(s => s.trim()).filter(Boolean);
  }
  return [];
}

function productSizesText(value) {
  return normalizeProductSizes(value).join(', ');
}

function productSizesHtml(value) {
  const sizes = normalizeProductSizes(value);
  if (!sizes.length) return '<span style="opacity:0.4;">—</span>';
  return sizes.map(s =>
    `<span style="display:inline-block;background:#f0e6d2;color:#6b4f3a;padding:2px 8px;border-radius:8px;font-size:0.7rem;font-weight:700;margin-right:4px;">${escapeHtml(s)}</span>`
  ).join('');
}

function normalizeProductColor(value) {
  if (value === null || value === undefined) return '';
  return String(value).trim();
}

function productColorHtml(color) {
  const c = normalizeProductColor(color);
  if (!c) return '<span style="opacity:0.4;">—</span>';
  return `<span style="display:inline-flex;align-items:center;gap:0.3rem;"><i class="fas fa-circle" style="color:#2a9d8f;font-size:0.5rem;"></i>${escapeHtml(c)}</span>`;
}

function normalizeProduct(product) {
  if (!product || typeof product !== 'object') return product;
  return {
    ...product,
    code: product.code !== undefined ? String(product.code) : generateCode(),
    name: product.name || '',
    color: normalizeProductColor(product.color || product.colour || ''),
    sizes: normalizeProductSizes(product.sizes || product.talles || product.tallesDisponibles || ''),
    price: Number(product.price) || 0,
    stock: Number(product.stock) || 0,
    category: product.category || 'BUSO',
    gender: product.gender || 'unisex',
    image: product.image || '',
    badge: product.badge || ''
  };
}

function generateCode() {
  let code;
  let exists;
  do {
    code = String(Math.floor(10000 + Math.random() * 90000));
    exists = window.products.some(p => String(p.code) === String(code));
  } while (exists);
  return code;
}

function getBadgeLabel(badge) {
  const labels = {
    new: 'Nuevo',
    offer: 'Oferta',
    featured: 'Destacado',
    low: 'Últimas'
  };
  return labels[badge] || '';
}

// ============================================
// API — PRODUCTOS
// ============================================
async function fetchProducts() {
  try {
    const response = await fetch(API_BASE + '/products.php');
    if (!response.ok) throw new Error('Error');

    const data = await response.json();
    let list = [];
    if (Array.isArray(data)) list = data;
    else if (data && Array.isArray(data.data)) list = data.data;
    else if (data && Array.isArray(data.products)) list = data.products;

    window.products = list.map(p => normalizeProduct(p));
    return window.products;
  } catch (error) {
    console.error('Error cargando productos:', error);
    window.products = [];
    return [];
  }
}

async function saveProductToServer(product) {
  try {
    const response = await fetch(API_BASE + '/products.php', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(product)
    });
    if (!response.ok) throw new Error('Error');
    return await response.json().catch(() => null);
  } catch (error) {
    console.error('Error guardando:', error);
    return null;
  }
}

async function updateProductOnServer(product) {
  try {
    const response = await fetch(
      API_BASE + '/products.php?code=' + encodeURIComponent(product.code),
      {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(product)
      }
    );
    if (!response.ok) throw new Error('Error');
    return await response.json().catch(() => null);
  } catch (error) {
    console.error('Error actualizando:', error);
    return null;
  }
}

async function deleteProductFromServer(code) {
  try {
    const response = await fetch(
      API_BASE + '/products.php?code=' + encodeURIComponent(code),
      { method: 'DELETE' }
    );
    if (!response.ok) throw new Error('Error');
    return true;
  } catch (error) {
    console.error('Error eliminando:', error);
    return false;
  }
}

// ============================================
// API — NOTIFICACIONES
// ============================================
async function fetchNotifications() {
  try {
    const response = await fetch(API_BASE + '/notifications.php');
    if (!response.ok) throw new Error('Error');

    const data = await response.json();
    let list = [];
    if (Array.isArray(data)) list = data;
    else if (data && Array.isArray(data.data)) list = data.data;

    window.notifications = list;
    return window.notifications;
  } catch (error) {
    console.error('Error cargando notificaciones:', error);
    window.notifications = [];
    return [];
  }
}

async function saveNotificationToServer(notification) {
  try {
    const response = await fetch(API_BASE + '/notifications.php', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(notification)
    });
    if (!response.ok) throw new Error('Error');
    return await response.json().catch(() => null);
  } catch (error) {
    console.error('Error guardando notificación:', error);
    return null;
  }
}

async function deleteNotificationFromServer(id) {
  try {
    const response = await fetch(
      API_BASE + '/notifications.php?id=' + encodeURIComponent(id),
      { method: 'DELETE' }
    );
    if (!response.ok) throw new Error('Error');
    return true;
  } catch (error) {
    console.error('Error eliminando notificación:', error);
    return false;
  }
}

// ============================================
// LAYOUT DINÁMICO (navbar + sidebar)
// ============================================
function buildNavbar() {
  return `
    <nav class="admin-navbar">
      <span class="admin-logo"><i class="fas fa-crown"></i> AF MODAS</span>
      <div class="admin-nav-actions">
        <button class="admin-nav-btn" onclick="toggleAdminMenu()"><i class="fas fa-bars"></i></button>
        <button class="admin-nav-btn" onclick="goToSite()"><i class="fas fa-store"></i></button>
        <button class="admin-nav-btn" onclick="toggleTheme()"><i id="themeIcon" class="fas fa-moon"></i></button>
        <span class="admin-user"><i class="fas fa-user-circle"></i> <span id="adminUserDisplay"></span></span>
        <button class="admin-nav-btn danger" onclick="logoutAdmin()"><i class="fas fa-sign-out-alt"></i></button>
      </div>
    </nav>
  `;
}

function buildSidebar(activePage) {
  const items = [
    { id: 'dashboard',     href: 'index.html',         icon: 'fa-chart-pie', label: 'Dashboard' },
    { id: 'products',      href: 'products.html',      icon: 'fa-tshirt',    label: 'Productos' },
    { id: 'notifications', href: 'notifications.html', icon: 'fa-bell',      label: 'Notificaciones' },
    { id: 'settings',      href: 'settings.html',      icon: 'fa-cog',       label: 'Ajustes' }
  ];

  return `
    <div class="admin-sidebar" id="adminSidebar">
      ${items.map(item => `
        <a href="${item.href}"
           class="admin-sidebar-item ${item.id === activePage ? 'active' : ''}">
          <i class="fas ${item.icon}"></i> ${item.label}
        </a>
      `).join('')}
    </div>
  `;
}

function injectLayout(activePage) {
  const container = document.getElementById('adminLayout');
  if (!container) return;
  container.innerHTML = buildNavbar() + buildSidebar(activePage);
}

// ============================================
// INICIALIZACIÓN
// ============================================
function initAdminPage(activePage, onReady) {
  document.addEventListener('DOMContentLoaded', async () => {
    console.log('🚀 Iniciando:', activePage);

    if (!checkSession()) return;

    loadTheme();
    injectLayout(activePage);
    startInactivityWatcher();

    if (typeof onReady === 'function') {
      try {
        await onReady();
      } catch (e) {
        console.error('Error en onReady:', e);
      }
    }

    console.log('✅ Listo:', activePage);
  });
}