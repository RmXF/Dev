// ============================================
// AF MODAS - ADMIN PANEL
// VERSION: COLOR + TALLES + WHATSAPP SETTINGS
// ============================================

const API_BASE = window.location.origin + '/api';
const SITE_URL = window.location.origin + '/';

let products = [];
let coupons = [];
let notifications = [];
let activityLog = [];
let editingCode = null;
let chartInstances = { dona: null, bar: null };


// ============================================
// VERIFICAR SESIÓN
// ============================================

function checkSession() {
    const session = sessionStorage.getItem('af_admin_session');

    if (!session) {
        window.location.href = '/admin/login.html';
        return false;
    }

    const user = sessionStorage.getItem('af_admin_user');

    if (user) {
        const userDisplay = document.getElementById('adminUserDisplay');

        if (userDisplay) {
            userDisplay.textContent = user;
        }
    }

    return true;
}


// ============================================
// API - PRODUCTOS
// ============================================

async function fetchProducts() {
    try {
        const response = await fetch(API_BASE + '/products.php');

        if (!response.ok) {
            throw new Error('Error al obtener productos');
        }

        const data = await response.json();

        // Soportar {success, data} o array directo
        let list = [];
        if (Array.isArray(data)) {
            list = data;
        } else if (data && Array.isArray(data.data)) {
            list = data.data;
        } else if (data && Array.isArray(data.products)) {
            list = data.products;
        }

        products = list.map(product => normalizeProduct(product));

    } catch (error) {
        console.error('Error cargando productos:', error);
        products = [];
    }
}


async function saveProductToServer(product) {
    try {
        const response = await fetch(API_BASE + '/products.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(product)
        });

        if (!response.ok) {
            throw new Error('No se pudo guardar el producto');
        }

        return await response.json().catch(() => null);

    } catch (error) {
        console.error('Error guardando producto:', error);
        return null;
    }
}


async function updateProductOnServer(product) {
    try {
        const response = await fetch(
            API_BASE + '/products.php?code=' + encodeURIComponent(product.code),
            {
                method: 'PUT',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(product)
            }
        );

        if (!response.ok) {
            throw new Error('No se pudo actualizar el producto');
        }

        return await response.json().catch(() => null);

    } catch (error) {
        console.error('Error actualizando producto:', error);
        return null;
    }
}


async function deleteProductFromServer(code) {
    try {
        const response = await fetch(
            API_BASE + '/products.php?code=' + encodeURIComponent(code),
            {
                method: 'DELETE'
            }
        );

        if (!response.ok) {
            throw new Error('No se pudo eliminar el producto');
        }

        return true;

    } catch (error) {
        console.error('Error eliminando producto:', error);
        return false;
    }
}


// ============================================
// API - CUPONES
// ============================================

async function fetchCoupons() {
    try {
        const response = await fetch(API_BASE + '/coupons.php');

        if (!response.ok) {
            throw new Error('Error al obtener cupones');
        }

        const data = await response.json();

        let list = [];
        if (Array.isArray(data)) list = data;
        else if (data && Array.isArray(data.data)) list = data.data;

        coupons = list;

    } catch (error) {
        console.error('Error cargando cupones:', error);
        coupons = [];
    }
}


async function saveCouponToServer(coupon) {
    try {
        const response = await fetch(API_BASE + '/coupons.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(coupon)
        });

        if (!response.ok) {
            throw new Error('No se pudo guardar el cupón');
        }

        return await response.json().catch(() => null);

    } catch (error) {
        console.error('Error guardando cupón:', error);
        return null;
    }
}


async function deleteCouponFromServer(id) {
    try {
        const response = await fetch(
            API_BASE + '/coupons.php?id=' + encodeURIComponent(id),
            {
                method: 'DELETE'
            }
        );

        if (!response.ok) {
            throw new Error('No se pudo eliminar el cupón');
        }

        return true;

    } catch (error) {
        console.error('Error eliminando cupón:', error);
        return false;
    }
}


// ============================================
// API - NOTIFICACIONES
// ============================================

async function fetchNotifications() {
    try {
        const response = await fetch(API_BASE + '/notifications.php');

        if (!response.ok) {
            throw new Error('Error al obtener notificaciones');
        }

        const data = await response.json();

        let list = [];
        if (Array.isArray(data)) list = data;
        else if (data && Array.isArray(data.data)) list = data.data;

        notifications = list;

    } catch (error) {
        console.error('Error cargando notificaciones:', error);
        notifications = [];
    }
}


async function saveNotificationToServer(notification) {
    try {
        const response = await fetch(API_BASE + '/notifications.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(notification)
        });

        if (!response.ok) {
            throw new Error('No se pudo guardar la notificación');
        }

        return await response.json().catch(() => null);

    } catch (error) {
        console.error('Error guardando notificación:', error);
        return null;
    }
}


async function deleteNotificationFromServer(id) {
    try {
        const response = await fetch(
            API_BASE + '/notifications.php?id=' + encodeURIComponent(id),
            {
                method: 'DELETE'
            }
        );

        if (!response.ok) {
            throw new Error('No se pudo eliminar la notificación');
        }

        return true;

    } catch (error) {
        console.error('Error eliminando notificación:', error);
        return false;
    }
}


// ============================================
// API - ACTIVIDAD
// ============================================

async function fetchActivity() {
    try {
        const response = await fetch(API_BASE + '/activity.php');

        if (!response.ok) {
            throw new Error('Error al obtener actividad');
        }

        const data = await response.json();

        let list = [];
        if (Array.isArray(data)) list = data;
        else if (data && Array.isArray(data.data)) list = data.data;

        activityLog = list;

    } catch (error) {
        console.error('Error cargando actividad:', error);
        activityLog = [];
    }
}


async function saveActivityToServer(activity) {
    try {
        const response = await fetch(API_BASE + '/activity.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(activity)
        });

        if (!response.ok) {
            throw new Error('No se pudo guardar actividad');
        }

        return await response.json().catch(() => null);

    } catch (error) {
        console.error('Error guardando actividad:', error);
        return null;
    }
}


// ============================================
// UTILIDADES
// ============================================

function escapeHtml(value) {
    if (value === null || value === undefined) {
        return '';
    }

    return String(value)
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;')
        .replace(/"/g, '&quot;')
        .replace(/'/g, '&#039;');
}


// ============================================
// NORMALIZACIÓN DE TALLES
// ============================================

function normalizeProductSizes(value) {

    if (Array.isArray(value)) {
        return value
            .map(size => String(size).trim())
            .filter(Boolean);
    }

    if (typeof value === 'string') {

        const trimmed = value.trim();

        if (!trimmed) {
            return [];
        }

        if (
            trimmed.length > 1 &&
            trimmed.charAt(0) === '[' &&
            trimmed.charAt(trimmed.length - 1) === ']'
        ) {
            try {
                const parsed = JSON.parse(trimmed);

                if (Array.isArray(parsed)) {
                    return parsed
                        .map(size => String(size).trim())
                        .filter(Boolean);
                }
            } catch (error) {
                // ignore
            }
        }

        return trimmed
            .split(',')
            .map(size => size.trim())
            .filter(Boolean);
    }

    return [];
}


function productSizesText(value) {
    return normalizeProductSizes(value).join(', ');
}


function productSizesHtml(value) {

    const sizes = normalizeProductSizes(value);

    if (!sizes.length) {
        return '<span class="muted-chip">—</span>';
    }

    return sizes
        .map(size => {
            return `<span class="size-chip">${escapeHtml(size)}</span>`;
        })
        .join('');
}


// ============================================
// COLOR
// ============================================

function normalizeProductColor(value) {

    if (value === null || value === undefined) {
        return '';
    }

    return String(value).trim();
}


function productColorHtml(color) {

    const normalizedColor = normalizeProductColor(color);

    if (!normalizedColor) {
        return '<span class="muted-chip">—</span>';
    }

    return `
        <span class="color-chip">
            <i class="fas fa-circle"></i>
            ${escapeHtml(normalizedColor)}
        </span>
    `;
}


// ============================================
// NORMALIZAR PRODUCTO COMPLETO
// ============================================

function normalizeProduct(product) {

    if (!product || typeof product !== 'object') {
        return product;
    }

    return {
        ...product,

        code: product.code !== undefined
            ? String(product.code)
            : generateCode(),

        name: product.name || '',

        color: normalizeProductColor(
            product.color ||
            product.colour ||
            ''
        ),

        sizes: normalizeProductSizes(
            product.sizes ||
            product.talles ||
            product.tallesDisponibles ||
            ''
        ),

        price: Number(product.price) || 0,

        stock: Number(product.stock) || 0,

        category: product.category || 'BUSO',

        gender: product.gender || 'unisex',

        image: product.image || '',

        badge: product.badge || ''
    };
}


// ============================================
// GENERAR CÓDIGO
// ============================================

function generateCode() {

    let code;
    let exists;

    do {

        code = String(
            Math.floor(
                10000 +
                Math.random() * 90000
            )
        );

        exists = products.some(
            product =>
                String(product.code) === String(code)
        );

    } while (exists);

    return code;
}


// ============================================
// GENERAR CUPÓN
// ============================================

function generateCouponCode() {

    const chars =
        'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';

    let code = '';

    for (let i = 0; i < 10; i++) {

        code += chars[
            Math.floor(
                Math.random() * chars.length
            )
        ];

    }

    return code;
}


// ============================================
// TOAST
// ============================================

function showToast(message, type) {

    const toast = document.createElement('div');

    toast.className =
        'toast' +
        (type === 'warning'
            ? ' toast-warning'
            : '');

    toast.textContent = message;

    document.body.appendChild(toast);

    setTimeout(() => {

        if (toast && toast.parentNode) {
            toast.remove();
        }

    }, 3000);
}


// ============================================
// MODALES
// ============================================

function closeModal(id) {

    const modal = document.getElementById(id);

    if (modal) {
        modal.classList.remove('open');
    }
}


// ============================================
// BADGES
// ============================================

function getBadgeLabel(badge) {

    const labels = {
        new: 'Nuevo',
        offer: 'Oferta',
        featured: 'Destacado',
        low: 'Últimas'
    };

    return labels[badge] || '';
}


// ============================================
// NAVEGACIÓN
// ============================================

function toggleAdminMenu() {

    const sidebar =
        document.getElementById('adminSidebar');

    if (sidebar) {
        sidebar.classList.toggle('open');
    }
}


function showSection(section) {

    document
        .querySelectorAll('.admin-section')
        .forEach(element => {
            element.classList.remove('active');
        });

    const target =
        document.getElementById(
            'section-' + section
        );

    if (target) {
        target.classList.add('active');
    }

    document
        .querySelectorAll('.admin-sidebar-item')
        .forEach(element => {
            element.classList.remove('active');
        });

    const sidebarItem =
        document.querySelector(
            `.admin-sidebar-item[onclick="showSection('${section}')"]`
        );

    if (sidebarItem) {
        sidebarItem.classList.add('active');
    }

    const sidebar =
        document.getElementById('adminSidebar');

    if (sidebar) {
        sidebar.classList.remove('open');
    }

    switch (section) {

        case 'stats':
            updateStats();
            break;

        case 'products':
            filterAdminProducts();
            break;

        case 'coupons':
            displayCoupons();
            break;

        case 'notifications':
            displayAdminNotifications();
            break;

        case 'activity':
            displayActivity();
            break;

        case 'settings':
            loadSettings();
            break;
    }
}


function goToSite() {
    window.open(SITE_URL, '_blank');
}


function logoutAdmin() {

    if (!confirm('¿Cerrar sesión?')) {
        return;
    }

    sessionStorage.removeItem(
        'af_admin_session'
    );

    sessionStorage.removeItem(
        'af_admin_user'
    );

    window.location.href =
        '/admin/login.html';
}


// ============================================
// ESTADÍSTICAS
// ============================================

function updateStats() {

    const total = products.length;

    const categories =
        new Set(
            products.map(
                product => product.category
            )
        ).size;

    const stockValue =
        products.reduce(
            (sum, product) =>
                sum +
                (
                    Number(product.price) *
                    Number(product.stock || 0)
                ),
            0
        );

    const outStock =
        products.filter(
            product =>
                Number(product.stock) <= 0
        ).length;

    const stats =
        document.getElementById(
            'adminStats'
        );

    if (!stats) {
        return;
    }

    stats.innerHTML = `

        <div class="stat-card">

            <div
                class="stat-icon"
                style="
                    background:rgba(42,157,143,.15);
                    color:var(--mc-teal);
                "
            >
                <i class="fas fa-tshirt"></i>
            </div>

            <div class="stat-value">
                ${total}
            </div>

            <div class="stat-label">
                Productos
            </div>

        </div>


        <div class="stat-card">

            <div
                class="stat-icon"
                style="
                    background:rgba(231,111,81,.15);
                    color:var(--mc-orange);
                "
            >
                <i class="fas fa-layer-group"></i>
            </div>

            <div class="stat-value">
                ${categories}
            </div>

            <div class="stat-label">
                Categorías
            </div>

        </div>


        <div class="stat-card">

            <div
                class="stat-icon"
                style="
                    background:rgba(233,196,106,.15);
                    color:var(--warning);
                "
            >
                <i class="fas fa-dollar-sign"></i>
            </div>

            <div class="stat-value">
                $${stockValue.toLocaleString()}
            </div>

            <div class="stat-label">
                Valor Stock
            </div>

        </div>


        <div class="stat-card">

            <div
                class="stat-icon"
                style="
                    background:rgba(239,68,68,.15);
                    color:var(--danger);
                "
            >
                <i class="fas fa-exclamation-triangle"></i>
            </div>

            <div class="stat-value">
                ${outStock}
            </div>

            <div class="stat-label">
                Sin Stock
            </div>

        </div>

    `;

    renderCharts();
}


// ============================================
// GRÁFICOS
// ============================================

function renderCharts() {

    if (chartInstances.dona) {
        chartInstances.dona.destroy();
        chartInstances.dona = null;
    }

    if (chartInstances.bar) {
        chartInstances.bar.destroy();
        chartInstances.bar = null;
    }

    const categoryCount = {};

    const genderCount = {
        hombre: 0,
        mujer: 0,
        unisex: 0
    };

    products.forEach(product => {

        const category =
            product.category || 'Sin categoría';

        categoryCount[category] =
            (categoryCount[category] || 0) + 1;

        if (product.gender) {

            genderCount[product.gender] =
                (
                    genderCount[product.gender] ||
                    0
                ) + 1;

        }

    });

    const doughnutCanvas =
        document.getElementById(
            'chartDona'
        );

    const barCanvas =
        document.getElementById(
            'chartBar'
        );

    if (
        doughnutCanvas &&
        typeof Chart !== 'undefined' &&
        Object.keys(categoryCount).length
    ) {

        chartInstances.dona =
            new Chart(
                doughnutCanvas,
                {
                    type: 'doughnut',

                    data: {
                        labels:
                            Object.keys(
                                categoryCount
                            ),

                        datasets: [
                            {
                                data:
                                    Object.values(
                                        categoryCount
                                    ),

                                backgroundColor: [
                                    '#2a9d8f',
                                    '#e76f51',
                                    '#e9c46a',
                                    '#8ab17d',
                                    '#6b4f3a',
                                    '#b35f9e',
                                    '#6366f1',
                                    '#f59e0b'
                                ]
                            }
                        ]
                    },

                    options: {
                        responsive: true,
                        maintainAspectRatio: true,

                        cutout: '65%',

                        plugins: {
                            legend: {
                                labels: {
                                    color: '#b0b0c0',

                                    font: {
                                        size: 11
                                    }
                                }
                            }
                        }
                    }
                }
            );

    }


    if (
        barCanvas &&
        typeof Chart !== 'undefined'
    ) {

        chartInstances.bar =
            new Chart(
                barCanvas,
                {
                    type: 'bar',

                    data: {

                        labels: [
                            'Hombre',
                            'Mujer',
                            'Unisex'
                        ],

                        datasets: [
                            {
                                data: [
                                    genderCount.hombre,
                                    genderCount.mujer,
                                    genderCount.unisex
                                ],

                                backgroundColor: [
                                    '#93c5fd',
                                    '#f9a8d4',
                                    '#fcd34d'
                                ]
                            }
                        ]
                    },

                    options: {

                        responsive: true,

                        maintainAspectRatio: true,

                        plugins: {
                            legend: {
                                display: false
                            }
                        },

                        scales: {

                            y: {
                                ticks: {
                                    color: '#b0b0c0'
                                },

                                grid: {
                                    color:
                                        'rgba(255,255,255,.05)'
                                }
                            },

                            x: {
                                ticks: {
                                    color: '#b0b0c0'
                                }
                            }

                        }

                    }
                }
            );

    }

}


// ============================================
// PRODUCTOS
// ============================================

function filterAdminProducts() {

    const searchInput =
        document.getElementById(
            'adminSearch'
        );

    const categoryFilter =
        document.getElementById(
            'adminCatFilter'
        );

    const tbody =
        document.getElementById(
            'adminProductBody'
        );

    if (!tbody) {
        return;
    }

    const search =
        searchInput
            ? searchInput.value
                .toLowerCase()
                .trim()
            : '';

    const category =
        categoryFilter
            ? categoryFilter.value
            : 'all';


    const filtered =
        products.filter(product => {

            const productName =
                String(
                    product.name || ''
                ).toLowerCase();

            const productCode =
                String(
                    product.code || ''
                ).toLowerCase();

            const productColor =
                String(
                    product.color || ''
                ).toLowerCase();

            const productSizes =
                productSizesText(
                    product.sizes
                ).toLowerCase();

            const matchesSearch =
                !search ||
                productName.includes(search) ||
                productCode.includes(search) ||
                productColor.includes(search) ||
                productSizes.includes(search);

            const matchesCategory =
                category === 'all' ||
                product.category === category;

            return (
                matchesSearch &&
                matchesCategory
            );

        });


    tbody.innerHTML =
        filtered.map(product => {

            const image =
                escapeHtml(
                    product.image || ''
                );

            const code =
                escapeHtml(
                    product.code
                );

            const name =
                escapeHtml(
                    product.name
                );

            const price =
                Number(
                    product.price || 0
                ).toLocaleString();

            const stock =
                Number(
                    product.stock || 0
                );

            const badge =
                product.badge
                    ? escapeHtml(
                        getBadgeLabel(
                            product.badge
                        )
                    )
                    : '—';


            return `

                <tr>

                    <td>

                        <img
                            src="${image}"
                            alt="${name}"
                            onerror="
                                this.src='https://via.placeholder.com/35x35?text=AF'
                            "
                        >

                    </td>


                    <td>
                        #${code}
                    </td>


                    <td>
                        ${name}
                    </td>


                    <td>
                        ${productColorHtml(
                            product.color
                        )}
                    </td>


                    <td>

                        <div class="sizes-cell">

                            ${productSizesHtml(
                                product.sizes
                            )}

                        </div>

                    </td>


                    <td>
                        $${price}
                    </td>


                    <td>
                        ${stock}
                    </td>


                    <td>
                        ${badge}
                    </td>


                    <td>

                        <div
                            style="
                                display:flex;
                                gap:6px;
                            "
                        >

                            <button
                                class="action-btn edit"
                                onclick="
                                    editProduct('${code}')
                                "
                                title="Editar"
                            >
                                <i class="fas fa-edit"></i>
                            </button>


                            <button
                                class="action-btn delete"
                                onclick="
                                    deleteProduct('${code}')
                                "
                                title="Eliminar"
                            >
                                <i class="fas fa-trash"></i>
                            </button>

                        </div>

                    </td>

                </tr>

            `;

        }).join('');


    if (!filtered.length) {

        tbody.innerHTML = `

            <tr>

                <td
                    colspan="9"
                    style="
                        text-align:center;
                        padding:1.5rem;
                    "
                >
                    Sin productos
                </td>

            </tr>

        `;

    }

}


// ============================================
// AGREGAR PRODUCTO
// ============================================

function openAddProduct() {

    editingCode = null;

    const title =
        document.getElementById(
            'productModalTitle'
        );

    if (title) {
        title.textContent =
            'Agregar Producto';
    }


    [
        'prodName',
        'prodPrice',
        'prodImage',
        'prodColor',
        'prodSizes'
    ].forEach(id => {

        const element =
            document.getElementById(id);

        if (element) {
            element.value = '';
        }

    });


    const stock =
        document.getElementById(
            'prodStock'
        );

    if (stock) {
        stock.value = 10;
    }


    const category =
        document.getElementById(
            'prodCategory'
        );

    if (category) {

        if (
            !category.value ||
            category.value === ''
        ) {
            category.value = 'BUSO';
        }

    }


    const gender =
        document.getElementById(
            'prodGender'
        );

    if (gender) {
        gender.value = 'unisex';
    }


    const badge =
        document.getElementById(
            'prodBadge'
        );

    if (badge) {
        badge.value = '';
    }


    const modal =
        document.getElementById(
            'productModal'
        );

    if (modal) {
        modal.classList.add('open');
    }

}


// ============================================
// EDITAR PRODUCTO
// ============================================

function editProduct(code) {

    const product =
        products.find(
            item =>
                String(item.code) ===
                String(code)
        );

    if (!product) {

        showToast(
            'Producto no encontrado',
            'warning'
        );

        return;
    }


    editingCode = String(code);


    const name =
        document.getElementById(
            'prodName'
        );

    if (name) {
        name.value =
            product.name || '';
    }


    // COLOR
    const color =
        document.getElementById(
            'prodColor'
        );

    if (color) {

        color.value =
            normalizeProductColor(
                product.color
            );

    }


    // TALLES
    const sizes =
        document.getElementById(
            'prodSizes'
        );

    if (sizes) {

        sizes.value =
            productSizesText(
                product.sizes
            );

    }


    const price =
        document.getElementById(
            'prodPrice'
        );

    if (price) {
        price.value =
            product.price || '';
    }


    const stock =
        document.getElementById(
            'prodStock'
        );

    if (stock) {
        stock.value =
            product.stock || 0;
    }


    const category =
        document.getElementById(
            'prodCategory'
        );

    if (category) {
        category.value =
            product.category ||
            'BUSO';
    }


    const gender =
        document.getElementById(
            'prodGender'
        );

    if (gender) {
        gender.value =
            product.gender ||
            'unisex';
    }


    const image =
        document.getElementById(
            'prodImage'
        );

    if (image) {
        image.value =
            product.image || '';
    }


    const badge =
        document.getElementById(
            'prodBadge'
        );

    if (badge) {
        badge.value =
            product.badge || '';
    }


    const title =
        document.getElementById(
            'productModalTitle'
        );

    if (title) {
        title.textContent =
            'Editar Producto';
    }


    const modal =
        document.getElementById(
            'productModal'
        );

    if (modal) {
        modal.classList.add('open');
    }

}


// ============================================
// GUARDAR PRODUCTO
// ============================================

async function saveAdminProduct() {

    const nameElement =
        document.getElementById(
            'prodName'
        );

    const colorElement =
        document.getElementById(
            'prodColor'
        );

    const sizesElement =
        document.getElementById(
            'prodSizes'
        );

    const priceElement =
        document.getElementById(
            'prodPrice'
        );

    const stockElement =
        document.getElementById(
            'prodStock'
        );

    const categoryElement =
        document.getElementById(
            'prodCategory'
        );

    const genderElement =
        document.getElementById(
            'prodGender'
        );

    const imageElement =
        document.getElementById(
            'prodImage'
        );

    const badgeElement =
        document.getElementById(
            'prodBadge'
        );


    const name =
        nameElement
            ? nameElement.value.trim()
            : '';


    const color =
        colorElement
            ? normalizeProductColor(
                colorElement.value
            )
            : '';


    const sizes =
        sizesElement
            ? normalizeProductSizes(
                sizesElement.value
            )
            : [];


    const price =
        priceElement
            ? Number(
                priceElement.value
            )
            : 0;


    const stock =
        stockElement
            ? Number(
                stockElement.value
            ) || 0
            : 0;


    const category =
        categoryElement
            ? categoryElement.value
            : 'BUSO';


    const gender =
        genderElement
            ? genderElement.value
            : 'unisex';


    const image =
        imageElement
            ? imageElement.value.trim()
            : '';


    const badge =
        badgeElement
            ? badgeElement.value
            : '';


    // VALIDACIÓN
    if (!name) {
        showToast('Ingresa el nombre de la prenda', 'warning');
        return;
    }

    if (!price || price <= 0) {
        showToast('Ingresa un precio válido', 'warning');
        return;
    }

    if (!image) {
        showToast('Ingresa la URL de la imagen', 'warning');
        return;
    }


    // EDITAR PRODUCTO EXISTENTE
    if (editingCode) {

        const index =
            products.findIndex(
                product =>
                    String(product.code) ===
                    String(editingCode)
            );


        if (index === -1) {
            showToast('Producto no encontrado', 'warning');
            return;
        }


        const updatedProduct = {
            ...products[index],
            name,
            color,
            sizes,
            price,
            stock,
            category,
            gender,
            image,
            badge
        };


        products[index] =
            normalizeProduct(updatedProduct);


        await updateProductOnServer(products[index]);


        logActivity(
            'edit',
            'Producto editado',
            name +
            (color ? ' · Color: ' + color : '') +
            (sizes.length ? ' · Talles: ' + sizes.join(', ') : '')
        );

    }

    // AGREGAR PRODUCTO NUEVO
    else {

        const newProduct = {
            code: generateCode(),
            name,
            color,
            sizes,
            price,
            stock,
            category,
            gender,
            image,
            badge,
            createdAt: new Date().toISOString()
        };


        const normalizedProduct =
            normalizeProduct(newProduct);


        products.push(normalizedProduct);


        await saveProductToServer(normalizedProduct);


        logActivity(
            'add',
            'Producto agregado',
            name +
            (color ? ' · Color: ' + color : '') +
            (sizes.length ? ' · Talles: ' + sizes.join(', ') : '')
        );

    }


    closeModal('productModal');
    filterAdminProducts();
    updateStats();
    showToast('Producto guardado correctamente');
}


// ============================================
// ELIMINAR PRODUCTO
// ============================================

async function deleteProduct(code) {

    const product =
        products.find(
            item =>
                String(item.code) ===
                String(code)
        );

    if (!product) return;

    if (!confirm('¿Eliminar ' + product.name + '?')) return;

    products =
        products.filter(
            item =>
                String(item.code) !==
                String(code)
        );

    await deleteProductFromServer(code);

    logActivity('delete', 'Producto eliminado', product.name);

    filterAdminProducts();
    updateStats();
    showToast('Producto eliminado');
}


// ============================================
// CUPONES
// ============================================

function generateCoupon() {

    const name = document.getElementById('couponName').value.trim();
    const type = document.getElementById('couponType').value;
    const value = Number(document.getElementById('couponValue').value);
    const expiry = document.getElementById('couponExpiry').value;
    const limit = Number(document.getElementById('couponLimit').value) || 100;

    if (!name || !value || !expiry) {
        showToast('Completa los campos', 'warning');
        return;
    }

    const coupon = {
        id: 'c' + Date.now(),
        code: generateCouponCode(),
        name,
        type,
        value,
        expiry,
        limit,
        used: 0,
        createdAt: new Date().toISOString()
    };

    coupons.push(coupon);
    saveCouponToServer(coupon);
    displayCoupons();
    logActivity('coupon', 'Cupón creado', coupon.code);
    showToast('Cupón: ' + coupon.code);
}


function displayCoupons() {

    const container = document.getElementById('couponsList');

    if (!container) return;

    if (!coupons.length) {
        container.innerHTML = `
            <p style="text-align:center;color:#888;padding:2rem;">
                No hay cupones
            </p>
        `;
        return;
    }

    container.innerHTML =
        coupons.map(coupon => {

            const isExpired = new Date(coupon.expiry) < new Date();
            const isUsedUp = Number(coupon.used || 0) >= Number(coupon.limit || 0);

            const status = isExpired ? 'Expirado' : isUsedUp ? 'Agotado' : 'Activo';

            const statusColor = isExpired
                ? 'var(--danger)'
                : isUsedUp
                    ? 'var(--text-tertiary)'
                    : 'var(--success)';

            return `
                <div class="coupon-card">
                    <div class="coupon-code">${escapeHtml(coupon.code)}</div>
                    <div style="font-size:.7rem;color:var(--text-secondary);">
                        ${escapeHtml(coupon.name)}
                        ·
                        ${coupon.value}
                        ${coupon.type === 'percent' ? '%' : '$'}
                    </div>
                    <div style="font-size:.7rem;margin:.3rem 0;">
                        Expira: ${new Date(coupon.expiry).toLocaleDateString()}
                        ·
                        Usado: ${coupon.used || 0}/${coupon.limit || 0}
                    </div>
                    <div style="display:flex;gap:6px;align-items:center;">
                        <span style="font-size:.7rem;color:${statusColor};">
                            ${status}
                        </span>
                        <button
                            class="action-btn delete"
                            onclick="deleteCoupon('${escapeHtml(coupon.id)}')"
                        >
                            <i class="fas fa-trash"></i>
                        </button>
                    </div>
                </div>
            `;
        }).join('');
}


async function deleteCoupon(id) {

    if (!confirm('¿Eliminar cupón?')) return;

    coupons = coupons.filter(coupon => String(coupon.id) !== String(id));

    await deleteCouponFromServer(id);

    displayCoupons();
    showToast('Cupón eliminado');
}


// ============================================
// NOTIFICACIONES
// ============================================

function openAddNotification() {

    ['notifTitle', 'notifMsg', 'notifImg'].forEach(id => {
        const element = document.getElementById(id);
        if (element) element.value = '';
    });

    const modal = document.getElementById('notifModal');
    if (modal) modal.classList.add('open');
}


async function addAdminNotification() {

    const type = document.getElementById('notifType').value;
    const title = document.getElementById('notifTitle').value.trim();
    const message = document.getElementById('notifMsg').value.trim();
    const image = document.getElementById('notifImg').value.trim();

    if (!title || !message) {
        showToast('Completa los campos', 'warning');
        return;
    }

    const notification = {
        id: 'n' + Date.now(),
        type,
        title,
        message,
        image,
        createdAt: Date.now()
    };

    notifications.push(notification);
    await saveNotificationToServer(notification);

    logActivity('notif', 'Notificación publicada', title);
    closeModal('notifModal');
    displayAdminNotifications();
    showToast('Notificación publicada');
}


function displayAdminNotifications() {

    const container = document.getElementById('adminNotifList');

    if (!container) return;

    const active =
        notifications.filter(
            notification =>
                (
                    Date.now() -
                    Number(notification.createdAt || 0)
                ) < 86400000
        );

    container.innerHTML =
        active.map(notification => {

            const color =
                notification.type === 'Alerta' ? '#e76f51' :
                notification.type === 'Información' ? '#2a9d8f' :
                '#e9c46a';

            return `
                <div class="notif-item">
                    <div class="notif-color" style="background:${color};"></div>
                    <div class="notif-info">
                        <strong>${escapeHtml(notification.title)}</strong>
                        <p>${escapeHtml(notification.message)}</p>
                    </div>
                    <button
                        class="action-btn delete"
                        onclick="deleteNotif('${escapeHtml(notification.id)}')"
                    >
                        <i class="fas fa-trash"></i>
                    </button>
                </div>
            `;
        }).join('');

    if (!active.length) {
        container.innerHTML = `<p style="color:#888;">No hay notificaciones</p>`;
    }
}


async function deleteNotif(id) {

    notifications =
        notifications.filter(
            notification =>
                String(notification.id) !== String(id)
        );

    await deleteNotificationFromServer(id);

    displayAdminNotifications();
}


// ============================================
// ACTIVIDAD
// ============================================

function displayActivity() {

    const container = document.getElementById('activityList');

    if (!container) return;

    if (!activityLog.length) {
        container.innerHTML = `
            <p style="text-align:center;color:#888;padding:2rem;">
                <i class="fas fa-inbox"></i> Sin actividad
            </p>
        `;
        return;
    }

    const icons = {
        login: 'fa-sign-in-alt',
        add: 'fa-plus',
        edit: 'fa-edit',
        delete: 'fa-trash',
        logout: 'fa-sign-out-alt',
        notif: 'fa-bell',
        coupon: 'fa-ticket'
    };

    const colors = {
        login: '#3b82f6',
        add: '#10b981',
        edit: '#f59e0b',
        delete: '#ef4444',
        logout: '#6b4f3a',
        notif: '#8b5cf6',
        coupon: '#d4af37'
    };

    container.innerHTML =
        activityLog.map(activity => {

            const icon = icons[activity.type] || 'fa-info';
            const color = colors[activity.type] || '#888';
            const date = new Date(activity.timestamp);

            const timeString =
                date.toLocaleDateString() + ' ' +
                date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });

            return `
                <div class="activity-item">
                    <div class="activity-icon" style="background:${color}20;color:${color};">
                        <i class="fas ${icon}"></i>
                    </div>
                    <div style="flex:1;">
                        <strong style="font-size:.8rem;">${escapeHtml(activity.action)}</strong>
                        <p style="font-size:.7rem;color:var(--text-tertiary);">
                            ${escapeHtml(activity.details || '')}
                        </p>
                    </div>
                    <div style="text-align:right;">
                        <span style="font-size:.65rem;color:var(--text-tertiary);">
                            ${timeString}
                        </span>
                    </div>
                </div>
            `;
        }).join('');
}


function logActivity(type, action, details) {

    const entry = {
        id: 'a' + Date.now(),
        type,
        action,
        details: details || '',
        timestamp: new Date().toISOString()
    };

    activityLog.unshift(entry);

    if (activityLog.length > 200) {
        activityLog = activityLog.slice(0, 200);
    }

    saveActivityToServer(entry);
}


// ============================================================
// SETTINGS — CARGAR
// ============================================================
async function loadSettings() {
  try {
    const res = await fetch(API_URL + '/settings.php');
    const data = await res.json();

    let config = null;
    if (data && data.config) config = data.config;
    else if (data && data.data && data.data.config) config = data.data.config;
    else if (data && data.data && typeof data.data === 'object') config = data.data;
    else config = data || {};

    if (config) {
      const wa = document.getElementById('settingsWhatsapp');
      const sn = document.getElementById('settingsSiteName');
      const fs = document.getElementById('settingsFreeShip');
      const lg = document.getElementById('settingsLogoUrl');
      const ds = document.getElementById('settingsDescription');

      if (wa) wa.value = config.whatsapp || '';
      if (sn) sn.value = config.site_name || 'AF MODAS';
      if (fs) fs.value = config.free_ship || 100000;
      if (lg) lg.value = config.logo_url || '';
      if (ds) ds.value = config.description || '';

      console.log('✅ Configuración cargada:', config);
    }
  } catch(e) {
    console.error('Error cargando configuración:', e);
  }
}

// ============================================================
// SETTINGS — GUARDAR
// ============================================================
async function saveSettings() {
  const whatsapp = document.getElementById('settingsWhatsapp').value.trim();
  const siteName = document.getElementById('settingsSiteName').value.trim();
  const freeShip = parseInt(document.getElementById('settingsFreeShip').value) || 0;
  const logoUrl = document.getElementById('settingsLogoUrl').value.trim();
  const description = document.getElementById('settingsDescription').value.trim();

  if (!whatsapp) {
    showToast('⚠️ El WhatsApp es obligatorio', 'error');
    return;
  }
  if (!/^\d{10,15}$/.test(whatsapp)) {
    showToast('⚠️ WhatsApp debe tener 10-15 dígitos sin + ni espacios', 'error');
    return;
  }

  const statusEl = document.getElementById('settingsStatus');
  statusEl.textContent = '⏳ Guardando...';
  statusEl.style.color = '';

  try {
    const payload = {
      config: {
        whatsapp: whatsapp,
        site_name: siteName || 'AF MODAS',
        free_ship: freeShip,
        logo_url: logoUrl,
        description: description || 'Tienda de moda premium · Elegancia que trasciende'
      },
      whatsapp: whatsapp,
      site_name: siteName || 'AF MODAS',
      free_ship: freeShip,
      logo_url: logoUrl,
      description: description || 'Tienda de moda premium · Elegancia que trasciende'
    };

    const res = await fetch(API_URL + '/settings.php', {
      method: 'POST',
      headers: {'Content-Type': 'application/json'},
      body: JSON.stringify(payload)
    });

    const data = await res.json();
    if (data.success) {
      statusEl.textContent = '✅ Guardado correctamente';
      statusEl.style.color = '#2a9d8f';
      showToast('✅ Configuración guardada', 'success');
      localStorage.setItem('af_whatsapp', whatsapp);
    } else {
      throw new Error(data.message || 'Error');
    }
  } catch(e) {
    console.error(e);
    statusEl.textContent = '❌ Error al guardar';
    statusEl.style.color = '#e76f51';
    showToast('❌ Error al guardar configuración', 'error');
  }
}


// ============================================
// BACKUP JSON
// ============================================

function exportBackup() {

    if (!products.length) {
        showToast('No hay productos', 'warning');
        return;
    }

    const data = JSON.stringify(products, null, 2);

    const blob = new Blob([data], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');

    link.href = url;
    link.download = 'afmodas_backup.json';

    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);

    URL.revokeObjectURL(url);
    showToast('Backup descargado');
}


// ============================================
// ESCAPAR CSV
// ============================================

function csvEscape(value) {

    if (value === null || value === undefined) {
        return '""';
    }

    return '"' + String(value).replace(/"/g, '""') + '"';
}


// ============================================
// EXPORTAR CSV
// ============================================

function exportCSV() {

    if (!products.length) {
        showToast('No hay productos', 'warning');
        return;
    }

    let csv = 'codigo,nombre,color,talles,precio,stock,categoria,genero,imagen,etiqueta\n';

    products.forEach(product => {

        csv += [
            csvEscape(product.code),
            csvEscape(product.name),
            csvEscape(product.color || ''),
            csvEscape(productSizesText(product.sizes)),
            Number(product.price || 0),
            Number(product.stock || 0),
            csvEscape(product.category || ''),
            csvEscape(product.gender || ''),
            csvEscape(product.image || ''),
            csvEscape(product.badge || '')
        ].join(',') + '\n';

    });

    const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');

    link.href = url;
    link.download = 'afmodas_catalogo.csv';

    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);

    URL.revokeObjectURL(url);
    showToast('CSV descargado');
}


// ============================================
// IMPORTAR BACKUP
// ============================================

function importBackup(event) {

    const file =
        event && event.target && event.target.files
            ? event.target.files[0]
            : null;

    if (!file) return;

    const reader = new FileReader();

    reader.onload = async function (eventResult) {

        try {

            const imported = JSON.parse(eventResult.target.result);

            if (!Array.isArray(imported)) {
                showToast('Formato inválido', 'warning');
                return;
            }

            products = imported.map(product => normalizeProduct(product));

            for (const product of products) {
                await saveProductToServer(product);
            }

            filterAdminProducts();
            updateStats();

            showToast(products.length + ' productos importados');

        } catch (error) {

            console.error('Error importando backup:', error);
            showToast('Error al importar', 'warning');

        }

    };

    reader.readAsText(file);

    event.target.value = '';

}


// ============================================
// ELIMINAR TODOS LOS PRODUCTOS
// ============================================

function clearAllProducts() {

    if (!confirm('¿Eliminar TODOS los productos?')) return;

    products = [];

    filterAdminProducts();
    updateStats();

    showToast('Productos eliminados');
}


// ============================================
// INICIALIZACIÓN
// ============================================

async function init() {

    if (!checkSession()) {
        return;
    }

    await fetchProducts();
    await fetchCoupons();
    await fetchNotifications();
    await fetchActivity();

    updateStats();
    filterAdminProducts();
    displayCoupons();
    displayAdminNotifications();
    displayActivity();

    logActivity('login', 'Inicio de sesión', 'Panel de administración');
}


// ============================================
// DOM READY
// ============================================

document.addEventListener('DOMContentLoaded', init);