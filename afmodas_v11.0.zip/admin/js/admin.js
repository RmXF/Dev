// ============================================
// AF MODAS - ADMIN PANEL
// ============================================

const API_BASE = window.location.origin + '/api';
const SITE_URL = window.location.origin + '/';

let products = [];
let coupons = [];
let notifications = [];
let activityLog = [];
let categories = [];
let editingCode = null;
let chartInstances = { dona: null, bar: null };

// ===== VERIFICAR SESIÓN =====
function checkSession() {
    const session = sessionStorage.getItem('af_admin_session');
    if (!session) {
        window.location.href = '/admin/login.html';
        return false;
    }
    const user = sessionStorage.getItem('af_admin_user');
    if (user) {
        document.getElementById('adminUserDisplay').textContent = user;
    }
    return true;
}

// ===== API CALLS =====
async function fetchProducts() {
    try { const r = await fetch(API_BASE + '/products.php'); products = await r.json(); } catch(e) { products = []; }
}
async function fetchCoupons() {
    try { const r = await fetch(API_BASE + '/coupons.php'); coupons = await r.json(); } catch(e) { coupons = []; }
}
async function fetchNotifications() {
    try { const r = await fetch(API_BASE + '/notifications.php'); notifications = await r.json(); } catch(e) { notifications = []; }
}
async function fetchActivity() {
    try { const r = await fetch(API_BASE + '/activity.php'); activityLog = await r.json(); } catch(e) { activityLog = []; }
}
async function fetchCategories() {
    try {
        const r = await fetch(API_BASE + '/categories.php');
        const data = await r.json();
        categories = data.categories || [];
        return categories;
    } catch(e) {
        categories = [];
        return [];
    }
}
async function saveProductToServer(p) {
    try { await fetch(API_BASE + '/products.php', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(p) }); } catch(e) {}
}
async function updateProductOnServer(p) {
    try { await fetch(API_BASE + '/products.php', { method: 'PUT', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(p) }); } catch(e) {}
}
async function deleteProductFromServer(code) {
    try { await fetch(API_BASE + '/products.php?code=' + code, { method: 'DELETE' }); } catch(e) {}
}
async function saveCouponToServer(c) {
    try { await fetch(API_BASE + '/coupons.php', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(c) }); } catch(e) {}
}
async function deleteCouponFromServer(id) {
    try { await fetch(API_BASE + '/coupons.php?id=' + id, { method: 'DELETE' }); } catch(e) {}
}
async function saveNotificationToServer(n) {
    try { await fetch(API_BASE + '/notifications.php', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(n) }); } catch(e) {}
}
async function deleteNotificationFromServer(id) {
    try { await fetch(API_BASE + '/notifications.php?id=' + id, { method: 'DELETE' }); } catch(e) {}
}
async function saveActivityToServer(a) {
    try { await fetch(API_BASE + '/activity.php', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(a) }); } catch(e) {}
}

// ===== CATEGORÍAS =====
async function loadCategories() {
    const cats = await fetchCategories();
    updateCategorySelects(cats);
    displayCategories(cats);
    return cats;
}

function updateCategorySelects(cats) {
    // Actualizar select de categorías en productos
    const prodSelect = document.getElementById('prodCategory');
    if (prodSelect) {
        const currentVal = prodSelect.value;
        prodSelect.innerHTML = '<option value="">Seleccionar categoría...</option>';
        cats.forEach(cat => {
            const opt = document.createElement('option');
            opt.value = cat;
            opt.textContent = cat;
            prodSelect.appendChild(opt);
        });
        if (currentVal && cats.includes(currentVal)) {
            prodSelect.value = currentVal;
        }
    }
    
    // Actualizar select de filtro en productos
    const filterSelect = document.getElementById('adminCatFilter');
    if (filterSelect) {
        const currentVal = filterSelect.value;
        filterSelect.innerHTML = '<option value="all">Todas</option>';
        cats.forEach(cat => {
            const opt = document.createElement('option');
            opt.value = cat;
            opt.textContent = cat;
            filterSelect.appendChild(opt);
        });
        if (currentVal && cats.includes(currentVal)) {
            filterSelect.value = currentVal;
        }
    }
}

function displayCategories(cats) {
    const container = document.getElementById('categoriesList');
    if (!container) return;
    
    if (!cats || cats.length === 0) {
        container.innerHTML = `
            <div class="categories-empty">
                <i class="fas fa-tags"></i>
                <p>No hay categorías creadas</p>
                <span style="font-size:0.8rem;color:var(--text-tertiary);">Agrega tu primera categoría usando el formulario</span>
            </div>
        `;
        return;
    }
    
    // Contar productos por categoría
    const productCount = {};
    products.forEach(p => {
        if (p.category) {
            productCount[p.category] = (productCount[p.category] || 0) + 1;
        }
    });
    
    container.innerHTML = cats.map(cat => `
        <div class="category-item" data-category="${cat}">
            <div class="category-name">
                <span class="cat-icon"><i class="fas fa-tag"></i></span>
                ${cat}
                <span class="category-count">${productCount[cat] || 0} productos</span>
            </div>
            <div class="category-actions">
                <button class="btn-sm edit-cat" onclick="editCategory('${cat}')" title="Editar categoría">
                    <i class="fas fa-edit"></i>
                </button>
                <button class="btn-sm delete-cat" onclick="deleteCategory('${cat}')" 
                        ${(productCount[cat] || 0) > 0 ? 'disabled title="No se puede eliminar porque tiene productos"' : 'title="Eliminar categoría"'}>
                    <i class="fas fa-trash"></i>
                </button>
            </div>
        </div>
    `).join('');
}

async function addCategory() {
    const input = document.getElementById('newCategoryInput');
    const catName = input.value.trim().toUpperCase();
    
    if (!catName) {
        showToast('Ingresa un nombre para la categoría', 'warning');
        return;
    }
    
    if (categories.includes(catName)) {
        showToast('La categoría ya existe', 'warning');
        input.value = '';
        return;
    }
    
    try {
        const response = await fetch(API_BASE + '/categories.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ category: catName })
        });
        const data = await response.json();
        
        if (data.success) {
            categories.push(catName);
            updateCategorySelects(categories);
            displayCategories(categories);
            logActivity('category_add', 'Categoría agregada', catName);
            showToast('✅ Categoría "' + catName + '" agregada');
            input.value = '';
        } else {
            showToast('Error al agregar categoría', 'warning');
        }
    } catch(e) {
        showToast('Error de conexión', 'warning');
    }
}

async function deleteCategory(catName) {
    // Verificar si hay productos con esta categoría
    const count = products.filter(p => p.category === catName).length;
    if (count > 0) {
        showToast('No se puede eliminar: ' + count + ' productos usan esta categoría', 'warning');
        return;
    }
    
    if (!confirm('¿Eliminar la categoría "' + catName + '"?')) return;
    
    try {
        const response = await fetch(API_BASE + '/categories.php', {
            method: 'DELETE',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ category: catName })
        });
        const data = await response.json();
        
        if (data.success) {
            categories = categories.filter(c => c !== catName);
            updateCategorySelects(categories);
            displayCategories(categories);
            logActivity('category_delete', 'Categoría eliminada', catName);
            showToast('✅ Categoría "' + catName + '" eliminada');
        } else {
            showToast('Error al eliminar categoría', 'warning');
        }
    } catch(e) {
        showToast('Error de conexión', 'warning');
    }
}

async function editCategory(oldName) {
    const newName = prompt('Editar categoría "' + oldName + '":', oldName);
    if (!newName || newName === oldName) return;
    
    const newNameTrimmed = newName.trim().toUpperCase();
    if (!newNameTrimmed) {
        showToast('El nombre no puede estar vacío', 'warning');
        return;
    }
    
    if (categories.includes(newNameTrimmed) && newNameTrimmed !== oldName) {
        showToast('La categoría "' + newNameTrimmed + '" ya existe', 'warning');
        return;
    }
    
    try {
        const response = await fetch(API_BASE + '/categories.php', {
            method: 'PUT',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ old: oldName, new: newNameTrimmed })
        });
        const data = await response.json();
        
        if (data.success) {
            // Actualizar categorías
            const index = categories.indexOf(oldName);
            if (index !== -1) {
                categories[index] = newNameTrimmed;
            }
            
            // Actualizar productos que usaban la categoría antigua
            products.forEach(p => {
                if (p.category === oldName) {
                    p.category = newNameTrimmed;
                    updateProductOnServer(p);
                }
            });
            
            updateCategorySelects(categories);
            displayCategories(categories);
            logActivity('category_edit', 'Categoría editada', oldName + ' → ' + newNameTrimmed);
            showToast('✅ Categoría actualizada a "' + newNameTrimmed + '"');
        } else {
            showToast('Error al editar categoría', 'warning');
        }
    } catch(e) {
        showToast('Error de conexión', 'warning');
    }
}

// ===== UTILITY =====
function generateCode() {
    let c, e;
    do { c = String(Math.floor(10000 + Math.random() * 90000)); e = products.some(p => p.code === c); } while (e);
    return c;
}
function generateCouponCode() {
    const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
    let code = '';
    for (let i = 0; i < 10; i++) code += chars[Math.floor(Math.random() * chars.length)];
    return code;
}
function showToast(msg, type) {
    const t = document.createElement('div');
    t.className = 'toast' + (type === 'warning' ? ' toast-warning' : '');
    t.textContent = msg;
    document.body.appendChild(t);
    setTimeout(() => t.remove(), 3000);
}
function closeModal(id) { document.getElementById(id).classList.remove('open'); }
function getBadgeLabel(b) { const labels = { new: 'Nuevo', offer: 'Oferta', featured: 'Destacado', low: 'Últimas' }; return labels[b] || ''; }

// ===== NAV =====
function toggleAdminMenu() { document.getElementById('adminSidebar').classList.toggle('open'); }
function showSection(section) {
    document.querySelectorAll('.admin-section').forEach(el => el.classList.remove('active'));
    document.getElementById('section-' + section).classList.add('active');
    document.querySelectorAll('.admin-sidebar-item').forEach(el => el.classList.remove('active'));
    document.querySelector(`.admin-sidebar-item[onclick="showSection('${section}')"]`).classList.add('active');
    document.getElementById('adminSidebar').classList.remove('open');
    switch(section) {
        case 'stats': updateStats(); break;
        case 'products': filterAdminProducts(); break;
        case 'categories': loadCategories(); break;
        case 'coupons': displayCoupons(); break;
        case 'notifications': displayAdminNotifications(); break;
        case 'activity': displayActivity(); break;
        case 'settings': loadSettings(); break;
    }
}
function goToSite() { window.open(SITE_URL, '_blank'); }
function logoutAdmin() {
    if (confirm('¿Cerrar sesión?')) {
        sessionStorage.removeItem('af_admin_session');
        sessionStorage.removeItem('af_admin_user');
        window.location.href = '/admin/login.html';
    }
}

// ===== STATS =====
function updateStats() {
    const total = products.length;
    const cats = new Set(products.map(p => p.category)).size;
    const value = products.reduce((s, p) => s + p.price * (p.stock || 0), 0);
    const outStock = products.filter(p => p.stock <= 0).length;
    document.getElementById('adminStats').innerHTML = `
        <div class="stat-card"><div class="stat-icon" style="background:rgba(42,157,143,.15);color:var(--mc-teal);"><i class="fas fa-tshirt"></i></div><div class="stat-value">${total}</div><div class="stat-label">Productos</div></div>
        <div class="stat-card"><div class="stat-icon" style="background:rgba(231,111,81,.15);color:var(--mc-orange);"><i class="fas fa-layer-group"></i></div><div class="stat-value">${cats}</div><div class="stat-label">Categorías</div></div>
        <div class="stat-card"><div class="stat-icon" style="background:rgba(233,196,106,.15);color:var(--warning);"><i class="fas fa-dollar-sign"></i></div><div class="stat-value">$${value.toLocaleString()}</div><div class="stat-label">Valor Stock</div></div>
        <div class="stat-card"><div class="stat-icon" style="background:rgba(239,68,68,.15);color:var(--danger);"><i class="fas fa-exclamation-triangle"></i></div><div class="stat-value">${outStock}</div><div class="stat-label">Sin Stock</div></div>
    `;
    renderCharts();
}
function renderCharts() {
    if (chartInstances.dona) chartInstances.dona.destroy();
    if (chartInstances.bar) chartInstances.bar.destroy();
    const catCount = {};
    const genCount = { hombre: 0, mujer: 0, unisex: 0 };
    products.forEach(p => {
        if (p.category) catCount[p.category] = (catCount[p.category] || 0) + 1;
        if (p.gender) genCount[p.gender] = (genCount[p.gender] || 0) + 1;
    });
    const dc = document.getElementById('chartDona');
    const bc = document.getElementById('chartBar');
    if (dc && Object.keys(catCount).length) {
        chartInstances.dona = new Chart(dc, { type: 'doughnut', data: { labels: Object.keys(catCount), datasets: [{ data: Object.values(catCount), backgroundColor: ['#2a9d8f','#e76f51','#e9c46a','#8ab17d','#6b4f3a','#b35f9e','#6366f1','#f59e0b'] }] }, options: { responsive: true, maintainAspectRatio: true, cutout: '65%', plugins: { legend: { labels: { color: '#b0b0c0', font: { size: 11 } } } } } });
    }
    if (bc) {
        chartInstances.bar = new Chart(bc, { type: 'bar', data: { labels: ['Hombre','Mujer','Unisex'], datasets: [{ data: [genCount.hombre, genCount.mujer, genCount.unisex], backgroundColor: ['#93c5fd','#f9a8d4','#fcd34d'] }] }, options: { responsive: true, maintainAspectRatio: true, plugins: { legend: { display: false } }, scales: { y: { ticks: { color: '#b0b0c0' }, grid: { color: 'rgba(255,255,255,.05)' } }, x: { ticks: { color: '#b0b0c0' } } } } });
    }
}

// ===== PRODUCTS =====
function filterAdminProducts() {
    const search = document.getElementById('adminSearch').value.toLowerCase();
    const cat = document.getElementById('adminCatFilter').value;
    const tbody = document.getElementById('adminProductBody');
    const filtered = products.filter(p => p.name.toLowerCase().includes(search) && (cat === 'all' || p.category === cat));
    tbody.innerHTML = filtered.map(p => `
        <tr><td><img src="${p.image}" onerror="this.src='https://via.placeholder.com/35x35?text=AF'"></td>
        <td>#${p.code}</td><td>${p.name}</td><td>$${p.price}</td><td>${p.stock}</td>
        <td>${p.sizes && p.sizes.length ? p.sizes.join(', ') : '—'}</td>
        <td>${p.badge ? getBadgeLabel(p.badge) : '—'}</td>
        <td><div style="display:flex;gap:6px;"><button class="action-btn edit" onclick="editProduct('${p.code}')"><i class="fas fa-edit"></i></button><button class="action-btn delete" onclick="deleteProduct('${p.code}')"><i class="fas fa-trash"></i></button></div></td></tr>
    `).join('') || '<tr><td colspan="8" style="text-align:center;padding:1rem;">Sin productos</td></tr>';
}

function openAddProduct() {
    editingCode = null;
    document.getElementById('productModalTitle').textContent = 'Agregar Producto';
    ['prodName','prodPrice','prodImage'].forEach(id => document.getElementById(id).value = '');
    document.getElementById('prodStock').value = 10;
    document.getElementById('prodBadge').value = '';
    document.querySelectorAll('.size-check').forEach(cb => cb.checked = false);
    updateSizesDisplay();
    document.getElementById('productModal').classList.add('open');
}

function updateSizesDisplay() {
    const checked = document.querySelectorAll('.size-check:checked');
    const display = document.getElementById('selectedSizesDisplay');
    if (checked.length === 0) {
        display.textContent = 'Ningún talle seleccionado';
        display.style.color = 'var(--text-tertiary)';
    } else {
        display.textContent = 'Talles seleccionados: ' + Array.from(checked).map(cb => cb.value).join(', ');
        display.style.color = 'var(--success)';
    }
}

function getSelectedSizes() {
    return Array.from(document.querySelectorAll('.size-check:checked')).map(cb => cb.value);
}

function setSelectedSizes(sizes) {
    document.querySelectorAll('.size-check').forEach(cb => {
        cb.checked = sizes && sizes.includes(cb.value);
    });
    updateSizesDisplay();
}

document.querySelectorAll('.size-check').forEach(cb => {
    cb.addEventListener('change', updateSizesDisplay);
});

function editProduct(code) {
    const p = products.find(x => x.code === code);
    if (!p) return;
    editingCode = code;
    document.getElementById('prodName').value = p.name;
    document.getElementById('prodPrice').value = p.price;
    document.getElementById('prodStock').value = p.stock || 0;
    document.getElementById('prodCategory').value = p.category || '';
    document.getElementById('prodGender').value = p.gender || 'unisex';
    document.getElementById('prodImage').value = p.image || '';
    document.getElementById('prodBadge').value = p.badge || '';
    setSelectedSizes(p.sizes || []);
    document.getElementById('productModalTitle').textContent = 'Editar Producto';
    document.getElementById('productModal').classList.add('open');
}

async function saveAdminProduct() {
    const name = document.getElementById('prodName').value.trim();
    const price = parseInt(document.getElementById('prodPrice').value);
    const stock = parseInt(document.getElementById('prodStock').value) || 0;
    const category = document.getElementById('prodCategory').value;
    const gender = document.getElementById('prodGender').value;
    const image = document.getElementById('prodImage').value.trim();
    const badge = document.getElementById('prodBadge').value;
    const sizes = getSelectedSizes();
    
    if (!name || !price || !image) { showToast('Completa los campos', 'warning'); return; }
    if (!category) { showToast('Selecciona una categoría', 'warning'); return; }
    
    if (editingCode) {
        const i = products.findIndex(p => p.code === editingCode);
        if (i > -1) { 
            products[i] = { ...products[i], name, price, stock, category, gender, image, badge, sizes }; 
            await updateProductOnServer(products[i]); 
            logActivity('edit', 'Producto editado', name); 
        }
    } else {
        const newProduct = { code: generateCode(), name, price, stock, category, gender, image, badge, sizes, createdAt: new Date().toISOString() };
        products.push(newProduct);
        await saveProductToServer(newProduct);
        logActivity('add', 'Producto agregado', name);
    }
    closeModal('productModal');
    filterAdminProducts();
    updateStats();
    showToast('Guardado');
}

async function deleteProduct(code) {
    const p = products.find(x => x.code === code);
    if (!p || !confirm('¿Eliminar ' + p.name + '?')) return;
    products = products.filter(x => x.code !== code);
    await deleteProductFromServer(code);
    logActivity('delete', 'Producto eliminado', p.name);
    filterAdminProducts();
    updateStats();
    showToast('Eliminado');
}

// ===== COUPONS =====
function generateCoupon() {
    const name = document.getElementById('couponName').value.trim();
    const type = document.getElementById('couponType').value;
    const value = parseInt(document.getElementById('couponValue').value);
    const expiry = document.getElementById('couponExpiry').value;
    const limit = parseInt(document.getElementById('couponLimit').value) || 100;
    if (!name || !value || !expiry) { showToast('Completa campos', 'warning'); return; }
    const coupon = { id: 'c' + Date.now(), code: generateCouponCode(), name, type, value, expiry, limit, used: 0, createdAt: new Date().toISOString() };
    coupons.push(coupon);
    saveCouponToServer(coupon);
    displayCoupons();
    logActivity('coupon', 'Cupón creado', coupon.code);
    showToast('Cupón: ' + coupon.code);
}
function displayCoupons() {
    const container = document.getElementById('couponsList');
    if (!coupons.length) { container.innerHTML = '<p style="text-align:center;color:#888;padding:2rem;">No hay cupones</p>'; return; }
    container.innerHTML = coupons.map(c => {
        const isExpired = new Date(c.expiry) < new Date();
        const isUsedUp = c.used >= c.limit;
        const status = isExpired ? 'Expirado' : isUsedUp ? 'Agotado' : 'Activo';
        const statusColor = isExpired ? 'var(--danger)' : isUsedUp ? 'var(--text-tertiary)' : 'var(--success)';
        return `<div class="coupon-card"><div class="coupon-code">${c.code}</div><div style="font-size:.7rem;color:var(--text-secondary);">${c.name} · ${c.value}${c.type === 'percent' ? '%' : '$'}</div><div style="font-size:.7rem;margin:.3rem 0;">Expira: ${new Date(c.expiry).toLocaleDateString()} · Usado: ${c.used}/${c.limit}</div><div style="display:flex;gap:6px;align-items:center;"><span style="font-size:.7rem;color:${statusColor};">${status}</span><button class="action-btn delete" onclick="deleteCoupon('${c.id}')"><i class="fas fa-trash"></i></button></div></div>`;
    }).join('');
}
async function deleteCoupon(id) {
    if (!confirm('¿Eliminar cupón?')) return;
    coupons = coupons.filter(c => c.id !== id);
    await deleteCouponFromServer(id);
    displayCoupons();
    showToast('Eliminado');
}

// ===== NOTIFICATIONS =====
function openAddNotification() {
    ['notifTitle','notifMsg','notifImg'].forEach(id => document.getElementById(id).value = '');
    document.getElementById('notifModal').classList.add('open');
}
async function addAdminNotification() {
    const type = document.getElementById('notifType').value;
    const title = document.getElementById('notifTitle').value.trim();
    const message = document.getElementById('notifMsg').value.trim();
    const image = document.getElementById('notifImg').value.trim();
    if (!title || !message) { showToast('Completa campos', 'warning'); return; }
    const notif = { id: 'n' + Date.now(), type, title, message, image, createdAt: Date.now() };
    notifications.push(notif);
    await saveNotificationToServer(notif);
    logActivity('notif', 'Notificación publicada', title);
    closeModal('notifModal');
    displayAdminNotifications();
    showToast('Publicada');
}
function displayAdminNotifications() {
    const container = document.getElementById('adminNotifList');
    const active = notifications.filter(n => (Date.now() - n.createdAt) < 86400000);
    container.innerHTML = active.map(n => `
        <div class="notif-item"><div class="notif-color" style="background:${n.type === 'Alerta' ? '#e76f51' : n.type === 'Información' ? '#2a9d8f' : '#e9c46a'};"></div><div class="notif-info"><strong>${n.title}</strong><p>${n.message}</p></div><button class="action-btn delete" onclick="deleteNotif('${n.id}')"><i class="fas fa-trash"></i></button></div>
    `).join('') || '<p style="color:#888;">No hay notificaciones</p>';
}
async function deleteNotif(id) {
    notifications = notifications.filter(n => n.id !== id);
    await deleteNotificationFromServer(id);
    displayAdminNotifications();
}

// ===== ACTIVITY =====
function displayActivity() {
    const container = document.getElementById('activityList');
    if (!activityLog.length) { container.innerHTML = '<p style="text-align:center;color:#888;padding:2rem;"><i class="fas fa-inbox"></i> Sin actividad</p>'; return; }
    const icons = { login: 'fa-sign-in-alt', add: 'fa-plus', edit: 'fa-edit', delete: 'fa-trash', logout: 'fa-sign-out-alt', notif: 'fa-bell', coupon: 'fa-ticket', category_add: 'fa-plus-circle', category_delete: 'fa-minus-circle', category_edit: 'fa-edit' };
    const colors = { login: '#3b82f6', add: '#10b981', edit: '#f59e0b', delete: '#ef4444', logout: '#6b4f3a', notif: '#8b5cf6', coupon: '#d4af37', category_add: '#10b981', category_delete: '#ef4444', category_edit: '#f59e0b' };
    container.innerHTML = activityLog.map(a => {
        const icon = icons[a.type] || 'fa-info';
        const color = colors[a.type] || '#888';
        const date = new Date(a.timestamp);
        const timeStr = date.toLocaleDateString() + ' ' + date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
        return `<div class="activity-item"><div class="activity-icon" style="background:${color}20;color:${color};"><i class="fas ${icon}"></i></div><div style="flex:1;"><strong style="font-size:.8rem;">${a.action}</strong><p style="font-size:.7rem;color:var(--text-tertiary);">${a.details || ''}</p></div><div style="text-align:right;"><span style="font-size:.65rem;color:var(--text-tertiary);">${timeStr}</span></div></div>`;
    }).join('');
}
function logActivity(type, action, details) {
    const entry = { id: 'a' + Date.now(), type, action, details: details || '', timestamp: new Date().toISOString() };
    activityLog.unshift(entry);
    if (activityLog.length > 200) activityLog = activityLog.slice(0, 200);
    saveActivityToServer(entry);
}

// ===== SETTINGS =====
async function loadSettings() {
    try {
        const r = await fetch(API_BASE + '/settings.php');
        const data = await r.json();
        if (data.config) {
            document.getElementById('settingsWhatsapp').value = data.config.whatsapp || '';
            if (data.config.logo) {
                document.getElementById('settingsLogo').value = data.config.logo;
                document.getElementById('logoPreview').style.display = 'block';
                document.getElementById('logoPreviewImg').src = data.config.logo;
            }
        }
    } catch(e) {}
}

async function saveSettings() {
    const whatsapp = document.getElementById('settingsWhatsapp').value.trim();
    const logo = document.getElementById('settingsLogo').value.trim();
    
    if (!whatsapp) {
        showToast('Ingresa un número de WhatsApp', 'warning');
        return;
    }
    
    const cleanWhatsapp = whatsapp.replace(/[^0-9+]/g, '');
    if (cleanWhatsapp.length < 10) {
        showToast('Número inválido (mínimo 10 dígitos)', 'warning');
        return;
    }
    
    try {
        await fetch(API_BASE + '/settings.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ 
                config: { 
                    whatsapp: cleanWhatsapp,
                    logo: logo || '' 
                } 
            })
        });
        if (logo) {
            document.getElementById('logoPreview').style.display = 'block';
            document.getElementById('logoPreviewImg').src = logo;
        } else {
            document.getElementById('logoPreview').style.display = 'none';
        }
        showToast('✅ Configuración guardada');
    } catch(e) {
        showToast('Error al guardar', 'warning');
    }
}

async function removeLogo() {
    if (!confirm('¿Eliminar el logo actual?')) return;
    try {
        await fetch(API_BASE + '/settings.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ config: { logo: '' } })
        });
        document.getElementById('settingsLogo').value = '';
        document.getElementById('logoPreview').style.display = 'none';
        showToast('Logo eliminado');
    } catch(e) {
        showToast('Error al eliminar logo', 'warning');
    }
}

// ===== BACKUP =====
function exportBackup() {
    if (!products.length) { showToast('No hay productos', 'warning'); return; }
    const data = JSON.stringify(products, null, 2);
    const blob = new Blob([data], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url; a.download = 'afmodas_backup.json';
    document.body.appendChild(a); a.click(); document.body.removeChild(a);
    URL.revokeObjectURL(url);
    showToast('Descargado');
}
function exportCSV() {
    if (!products.length) { showToast('No hay productos', 'warning'); return; }
    let csv = 'codigo,nombre,precio,stock,categoria,genero,imagen,talles\n';
    products.forEach(p => { 
        const sizes = (p.sizes && p.sizes.length) ? p.sizes.join('|') : '';
        csv += `"${p.code}","${p.name}",${p.price},${p.stock},"${p.category}","${p.gender}","${p.image}","${sizes}"\n`; 
    });
    const blob = new Blob([csv], { type: 'text/csv' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url; a.download = 'afmodas_catalogo.csv';
    document.body.appendChild(a); a.click(); document.body.removeChild(a);
    URL.revokeObjectURL(url);
    showToast('CSV descargado');
}
function importBackup(event) {
    const file = event.target.files[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = async function(e) {
        try {
            const imported = JSON.parse(e.target.result);
            if (!Array.isArray(imported)) { showToast('Formato inválido', 'warning'); return; }
            products = imported;
            for (const p of products) {
                if (!p.sizes) p.sizes = [];
                await saveProductToServer(p);
            }
            filterAdminProducts();
            updateStats();
            showToast(products.length + ' importados');
        } catch(err) {
            showToast('Error al importar', 'warning');
        }
    };
    reader.readAsText(file);
    event.target.value = '';
}
function clearAllProducts() {
    if (!confirm('¿Eliminar TODOS los productos?')) return;
    products = [];
    filterAdminProducts();
    updateStats();
    showToast('Eliminados');
}

// ===== INIT =====
async function init() {
    if (!checkSession()) return;
    await fetchProducts();
    await fetchCoupons();
    await fetchNotifications();
    await fetchActivity();
    await loadCategories();
    updateStats();
    filterAdminProducts();
    displayCoupons();
    displayAdminNotifications();
    displayActivity();
    logActivity('login', 'Inicio de sesión', 'Panel de administración');
}
document.addEventListener('DOMContentLoaded', init);