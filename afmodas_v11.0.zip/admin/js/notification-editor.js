/* AF MODAS · Edición y orden manual de historias. */
(() => {
  'use strict';
  const list = document.getElementById('notifList');
  const modal = document.getElementById('notifModal');
  const button = document.getElementById('notifSaveButton');
  let editing = null, busy = false;
  const productSelect = document.getElementById('notifProduct');
  const productSearch = document.getElementById('notifProductSearch');
  const productResults = document.getElementById('notifProductResults');
  const productHint = document.getElementById('notifProductHint');
  const productSelected = document.getElementById('notifProductSelected');
  productHint.setAttribute('role', 'status');
  let productRequest = 0, productRows = [], productsLoading = false, productsError = false;
  const normalizeSearch = value => String(value || '').normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLowerCase().trim();
  function updateProductSelection() {
    const code = productSelect.value;
    const item = productRows.find(p => String(p.code) === code);
    productSelected.hidden = !code;
    document.getElementById('notifProductSelectedLabel').textContent = code
      ? `${item?.name || 'Prenda vinculada'} · #${code}` : '';
  }
  function searchProducts() {
    productResults.replaceChildren();
    const query = normalizeSearch(productSearch.value);
    productResults.hidden = true;
    if (productsLoading) { productHint.textContent = 'Cargando prendas… Podés escribir tu búsqueda.'; return; }
    if (productsError) { productHint.textContent = 'No se pudo cargar el catálogo. Cerrá y abrí el formulario para reintentar. El vínculo actual se conserva.'; return; }
    if (!query) { productHint.textContent = 'Buscá por código o nombre y tocá una prenda para vincularla. Es opcional.'; return; }
    const words = query.split(/\s+/);
    const matches = productRows.filter(p => words.every(word => p.search.includes(word)))
      .sort((a,b) => Number(normalizeSearch(b.code) === query) - Number(normalizeSearch(a.code) === query));
    productHint.textContent = matches.length
      ? `${matches.length} coincidencia${matches.length === 1 ? '' : 's'}.${matches.length > 20 ? ' Mostrando 20; escribí más para afinar la búsqueda.' : ' Tocá una para seleccionarla.'}`
      : 'No se encontraron prendas con ese código o nombre.';
    matches.slice(0,20).forEach(p => {
      const option = document.createElement('button');
      option.type = 'button'; option.className = 'notif-product-result';
      const name = document.createElement('strong'); name.textContent = p.name || 'Prenda';
      const code = document.createElement('span'); code.textContent = '#' + p.code;
      option.append(name,code);
      option.addEventListener('click', () => {
        productSelect.value = String(p.code);
        productSearch.value = ''; updateProductSelection(); searchProducts();
        productSearch.focus({preventScroll:true});
      });
      productResults.appendChild(option);
    });
    productResults.hidden = matches.length === 0;
  }
  productSearch.addEventListener('input', searchProducts);
  productSearch.addEventListener('focus', searchProducts);
  productSearch.addEventListener('keydown', event => {
    if (event.key === 'ArrowDown' && !productResults.hidden) { event.preventDefault(); productResults.querySelector('button')?.focus(); }
    if (event.key === 'Escape') { productResults.hidden = true; event.stopPropagation(); }
    if (event.key === 'Enter') { event.preventDefault(); if (!productResults.hidden) productResults.querySelector('button')?.focus(); }
  });
  productResults.addEventListener('keydown', event => {
    const buttons = [...productResults.querySelectorAll('button')];
    const i = buttons.indexOf(event.target);
    if (event.key === 'ArrowDown' || event.key === 'ArrowUp') {
      event.preventDefault(); buttons[Math.max(0, Math.min(buttons.length-1, i + (event.key === 'ArrowDown' ? 1 : -1)))]?.focus();
    }
    if (event.key === 'Escape') { event.stopPropagation(); productSearch.focus(); productResults.hidden = true; }
  });
  document.getElementById('notifProductClear').addEventListener('click', () => {
    productSelect.value = ''; productSearch.value = ''; updateProductSelection(); searchProducts();
    productSearch.focus({preventScroll:true});
  });
  async function loadProductOptions(selected = '') {
    const request = ++productRequest;
    productSelect.value = selected; productSearch.value = '';
    productRows = []; productsLoading = true; productsError = false;
    updateProductSelection(); searchProducts();
    try {
      const response = await fetch('/api/products.php', {cache:'no-store'});
      const data = await response.json();
      const rows = Array.isArray(data) ? data : data.data || data.products;
      if (!response.ok || !Array.isArray(rows)) throw new Error();
      if (request !== productRequest) return;
      productRows = rows.filter(p => p && String(p.code ?? '') !== '').map(p => ({...p, search: normalizeSearch(`${p.code} ${p.name || ''}`)}));
      productsLoading = false; updateProductSelection(); searchProducts();
    } catch (_) {
      if (request !== productRequest) return;
      productsLoading = false; productsError = true; searchProducts();
    }
  }
  const formatAge = value => {
    const time = Date.parse(String(value || ''));
    if (!Number.isFinite(time)) return 'Fecha no disponible';
    const minutes = Math.max(0, Math.floor((Date.now() - time) / 60000));
    if (minutes < 1) return 'Ahora';
    if (minutes < 60) return `Hace ${minutes} min`;
    if (minutes < 1440) return `Hace ${Math.floor(minutes / 60)} h`;
    return 'Hace más de un día';
  };
  async function api(path, method, body) {
    const response = await fetch('/api/notifications.php' + path, {
      method, cache:'no-store',
      headers: body ? { 'Content-Type':'application/json' } : {},
      body: body ? JSON.stringify(body) : undefined
    });
    const result = await response.json();
    if (!response.ok || result.success !== true) throw new Error(result.message || 'No se pudo guardar el cambio');
    return result;
  }
  async function reload() {
    const result = await api('', 'GET');
    window.notifications = Array.isArray(result.data) ? result.data : [];
    window.renderNotifications();
  }
  function render() {
    const rows = window.notifications || [];
    if (!rows.length) {
      list.innerHTML = '<div class="empty-state"><i class="fas fa-bell-slash"></i><h3>No hay notificaciones</h3><p>Creá tu primera historia para tus clientes.</p><button class="btn btn-warning" type="button" data-action="new"><i class="fas fa-plus"></i> Agregar notificación</button></div>';
      return;
    }
    list.innerHTML = rows.map((n,index) => {
      const info = getNotifTypeInfo(n.type);
      const stamp = Date.parse(String(n.created_at || ''));
      const remaining = stamp + 86400000 - Date.now();
      const expired = !Number.isFinite(stamp) || remaining <= 0;
      const id = escapeHtml(String(n.id || ''));
      return `<article class="notif-card ${expired ? 'notif-expired' : ''}">
        <div class="notif-color-bar" style="background:${info.color}"></div>
        <div class="notif-order" aria-label="Posición ${index+1}">${index+1}</div>
        <div class="notif-icon" style="background:${info.bg};color:${info.color}"><i class="fas ${info.icon}"></i></div>
        ${n.image ? `<img class="notif-image-preview" src="${escapeHtml(n.image)}" alt="" onerror="this.hidden=true">` : ''}
        <div class="notif-body"><span class="notif-type-badge" style="background:${info.bg};color:${info.color}">${escapeHtml(n.type || 'Información')}</span>
          <div class="notif-title">${escapeHtml(n.title || 'Sin título')}</div><div class="notif-message">${escapeHtml(n.message || '')}</div>
          ${n.product_code ? `<div class="notif-message">Prenda vinculada: #${escapeHtml(n.product_code)}</div>` : ''}
          <div class="notif-meta"><span><i class="fas fa-clock"></i> ${formatAge(n.created_at)}</span><span><i class="fas fa-hourglass-half"></i> ${expired ? 'Expirada' : `Expira en ${Math.floor(remaining/3600000)} h ${Math.floor(remaining%3600000/60000)} min`}</span></div>
        </div>
        <div class="notif-actions">
          <button type="button" class="notif-move" data-action="up" data-id="${id}" aria-label="Subir ${escapeHtml(n.title)}" title="Subir" ${index===0 ? 'disabled' : ''}><i class="fas fa-arrow-up"></i></button>
          <button type="button" class="notif-move" data-action="down" data-id="${id}" aria-label="Bajar ${escapeHtml(n.title)}" title="Bajar" ${index===rows.length-1 ? 'disabled' : ''}><i class="fas fa-arrow-down"></i></button>
          <button type="button" class="notif-edit" data-action="edit" data-id="${id}" aria-label="Editar ${escapeHtml(n.title)}" title="Editar"><i class="fas fa-pen"></i></button>
          ${expired ? `<button type="button" class="notif-renew" data-action="renew" data-id="${id}" aria-label="Renovar 24 horas ${escapeHtml(n.title)}" title="Renovar 24 horas"><i class="fas fa-rotate"></i></button>` : ''}
          <button type="button" data-action="delete" data-id="${id}" aria-label="Eliminar ${escapeHtml(n.title)}" title="Eliminar"><i class="fas fa-trash"></i></button>
        </div>
      </article>`;
    }).join('');
  }
  window.renderNotifications = render;
  window.openAddNotification = () => {
    editing = null;
    document.getElementById('notifModalTitle').textContent = 'Nueva notificación';
    button.innerHTML = '<i class="fas fa-bell"></i> Publicar';
    document.getElementById('notifTitle').value = '';
    document.getElementById('notifMsg').value = '';
    document.getElementById('notifImg').value = '';
    loadProductOptions();
    selectNotifType('Información');
    modal.classList.add('open');
    document.getElementById('notifTitle').focus();
  };
  function edit(id) {
    const item = (window.notifications || []).find(n => String(n.id) === String(id));
    if (!item) return;
    editing = String(item.id);
    document.getElementById('notifModalTitle').textContent = 'Editar notificación';
    button.innerHTML = '<i class="fas fa-save"></i> Guardar cambios';
    document.getElementById('notifTitle').value = item.title || '';
    document.getElementById('notifMsg').value = item.message || '';
    document.getElementById('notifImg').value = item.image || '';
    loadProductOptions(String(item.product_code || ''));
    selectNotifType(item.type || 'Información');
    modal.classList.add('open');
    document.getElementById('notifTitle').focus();
  }
  window.addNotification = async () => {
    if (busy) return;
    const data = {
      type: document.getElementById('notifType').value,
      title: document.getElementById('notifTitle').value.trim(),
      message: document.getElementById('notifMsg').value.trim(),
      image: document.getElementById('notifImg').value.trim(),
      product_code: productSelect.value
    };
    if (!data.title || !data.message) { showToast('Completá título y mensaje', 'warning'); return; }
    busy = true; button.disabled = true;
    try {
      await api(editing ? '?id='+encodeURIComponent(editing) : '', editing ? 'PUT':'POST', data);
      await reload(); closeModal('notifModal');
      showToast(editing ? 'Historia actualizada' : 'Historia publicada', 'success'); editing = null;
    } catch (error) { showToast(error.message, 'error'); }
    finally { busy = false; button.disabled = false; }
  };
  async function remove(id) {
    const item = (window.notifications || []).find(n => String(n.id) === String(id));
    if (!item || !confirm(`¿Eliminar la historia «${item.title}»?`)) return;
    busy = true;
    try { await api('?id='+encodeURIComponent(id),'DELETE'); await reload(); showToast('Historia eliminada','success'); }
    catch (error) { showToast(error.message,'error'); }
    finally { busy = false; }
  }
  async function renew(id) {
    busy = true;
    try { await api('?id='+encodeURIComponent(id)+'&renew=1','PUT'); await reload(); showToast('Historia renovada por 24 horas','success'); }
    catch (error) { showToast(error.message,'error'); }
    finally { busy = false; }
  }
  async function move(id, direction) {
    const current = [...(window.notifications || [])];
    const index = current.findIndex(n => String(n.id) === String(id));
    const next = index + direction;
    if (index < 0 || next < 0 || next >= current.length) return;
    [current[index],current[next]] = [current[next],current[index]];
    busy = true;
    try {
      await api('?reorder=1','PUT',{ ids:current.map(n => String(n.id)) });
      await reload(); showToast('Orden guardado','success');
    } catch (error) { await reload().catch(() => {}); showToast(error.message,'error'); }
    finally { busy = false; }
  }
  list.addEventListener('click', event => {
    const target = event.target.closest('button[data-action]');
    if (!target || busy) return;
    const action = target.dataset.action, id = target.dataset.id;
    if (action === 'new') window.openAddNotification();
    if (action === 'edit') edit(id);
    if (action === 'delete') remove(id);
    if (action === 'renew') renew(id);
    if (action === 'up' || action === 'down') move(id,action === 'up' ? -1 : 1);
  });
})();
