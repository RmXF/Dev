<?php
// ============================================================
// AF MODAS · HOME con Open Graph dinámico
// ============================================================
// Lee la configuración desde settings.json y genera
// las meta etiquetas dinámicas para que WhatsApp,
// Facebook, Twitter, Telegram etc. muestren la
// preview correcta al compartir el link.
// ============================================================

$dataFile = __DIR__ . '/data/settings.json';
$config = [];

if (file_exists($dataFile)) {
    $content = @file_get_contents($dataFile);
    if ($content) {
        $decoded = json_decode($content, true);
        if (is_array($decoded)) {
            $config = isset($decoded['config']) && is_array($decoded['config']) ? $decoded['config'] : $decoded;
        }
    }
}

// Valores por defecto
$siteName = $config['site_name'] ?? 'AF MODAS';
$description = $config['description'] ?? 'Tienda de moda premium · Elegancia que trasciende';
if (!is_string($siteName) || trim($siteName) === '') $siteName = 'AF MODAS';
if (!is_string($description) || trim($description) === '') $description = 'Descubrí prendas, estilos y novedades en el catálogo de AF MODAS. Elegí tus favoritos y prepará tu pedido online.';

// URL canónica e imagen pública absoluta para las vistas previas.
$canonicalUrl = 'https://afmodas.online/';
$shareImage = 'https://afmodas.online/assets/img/afmodas-share-v25.jpg';
$logoUrl = $config['logo_url'] ?? '';

$siteNameEsc = htmlspecialchars((string)$siteName, ENT_QUOTES, 'UTF-8');
$descriptionEsc = htmlspecialchars((string)$description, ENT_QUOTES, 'UTF-8');
$logoUrlEsc = htmlspecialchars((string)$logoUrl, ENT_QUOTES, 'UTF-8');
$shareImageEsc = htmlspecialchars($shareImage, ENT_QUOTES, 'UTF-8');
$canonicalUrlEsc = htmlspecialchars($canonicalUrl, ENT_QUOTES, 'UTF-8');
?>
<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title><?= $siteNameEsc ?> · Tienda de moda</title>
<link rel="icon" type="image/png" href="/assets/img/af-logo.png">

<!-- ============================================================
     SEO + OPEN GRAPH · WhatsApp / Facebook / Telegram / X
     ============================================================ -->
<meta name="description" content="<?= $descriptionEsc ?>">
<meta name="robots" content="index, follow">
<link rel="canonical" href="<?= $canonicalUrlEsc ?>">

<meta property="og:type" content="website">
<meta property="og:site_name" content="<?= $siteNameEsc ?>">
<meta property="og:locale" content="es_AR">
<meta property="og:url" content="<?= $canonicalUrlEsc ?>">
<meta property="og:title" content="<?= $siteNameEsc ?>">
<meta property="og:description" content="<?= $descriptionEsc ?>">
<meta property="og:image" content="<?= $shareImageEsc ?>">
<meta property="og:image:secure_url" content="<?= $shareImageEsc ?>">
<meta property="og:image:type" content="image/jpeg">
<meta property="og:image:width" content="900">
<meta property="og:image:height" content="900">
<meta property="og:image:alt" content="AF MODAS · Tienda Premium">

<meta name="twitter:card" content="summary_large_image">
<meta name="twitter:url" content="<?= $canonicalUrlEsc ?>">
<meta name="twitter:title" content="<?= $siteNameEsc ?>">
<meta name="twitter:description" content="<?= $descriptionEsc ?>">
<meta name="twitter:image" content="<?= $shareImageEsc ?>">
<meta name="twitter:image:alt" content="AF MODAS · Tienda Premium">

<meta name="theme-color" content="#b08d57">

<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">

<link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800;900&family=Playfair+Display:wght@400;500;600;700;800;900&family=JetBrains+Mono:wght@400;600;700&display=swap" rel="stylesheet">

<script src="https://cdnjs.cloudflare.com/ajax/libs/lottie-web/5.9.6/lottie.min.js"></script>

<style>
/* ============================================================
   AF MODAS · PREMIUM EDITORIAL UI
   IDs Y FUNCIONES EXISTENTES CONSERVADOS
============================================================ */

:root {
  --bg: #f5f3ef;
  --bg-soft: #eeebe5;
  --surface: rgba(255,255,255,.72);
  --surface-solid: #ffffff;
  --surface-soft: rgba(255,255,255,.48);

  --text: #171717;
  --text-soft: #66625c;
  --text-muted: #8d8982;

  --line: rgba(20,20,20,.08);
  --line-strong: rgba(20,20,20,.13);

  --gold: #b08d57;
  --gold-light: #d4b47a;
  --gold-dark: #806338;

  --black: #151515;
  --black-soft: #242424;

  --success: #248b63;
  --danger: #c9534d;
  --accent: #8e7352;

  --shadow-sm: 0 8px 24px rgba(30,25,20,.06);
  --shadow-md: 0 18px 50px rgba(30,25,20,.10);
  --shadow-lg: 0 30px 80px rgba(20,18,15,.18);

  --radius-sm: 14px;
  --radius-md: 22px;
  --radius-lg: 30px;
  --radius-xl: 38px;

  --nav-height: 74px;
}

body.dark {
  --bg: #0d0d0e;
  --bg-soft: #151516;
  --surface: rgba(28,28,29,.76);
  --surface-solid: #19191a;
  --surface-soft: rgba(35,35,36,.58);

  --text: #f3f1ed;
  --text-soft: #aaa59d;
  --text-muted: #77736c;

  --line: rgba(255,255,255,.075);
  --line-strong: rgba(255,255,255,.13);

  --gold: #c8a66b;
  --gold-light: #e1c184;
  --gold-dark: #967746;

  --black: #f2f0eb;
  --black-soft: #d4d0c8;

  --shadow-sm: 0 8px 30px rgba(0,0,0,.18);
  --shadow-md: 0 20px 60px rgba(0,0,0,.32);
  --shadow-lg: 0 35px 100px rgba(0,0,0,.5);
}

* {
  margin: 0;
  padding: 0;
  box-sizing: border-box;
}

html {
  scroll-behavior: smooth;
}

body {
  font-family: 'Inter', sans-serif;
  background:
    radial-gradient(circle at 8% 5%, rgba(176,141,87,.08), transparent 24rem),
    radial-gradient(circle at 92% 18%, rgba(176,141,87,.06), transparent 25rem),
    var(--bg);
  color: var(--text);
  transition:
    background .4s ease,
    color .4s ease;
  padding-top: var(--nav-height);
  min-height: 100vh;
  overflow-x: hidden;
}

body::before {
  content: "";
  position: fixed;
  inset: 0;
  pointer-events: none;
  z-index: -1;
  opacity: .35;
  background-image:
    linear-gradient(rgba(0,0,0,.015) 1px, transparent 1px),
    linear-gradient(90deg, rgba(0,0,0,.015) 1px, transparent 1px);
  background-size: 42px 42px;
}

body.dark::before {
  opacity: .08;
}

/* ============================================================
   UTILIDADES
============================================================ */

button,
a {
  -webkit-tap-highlight-color: transparent;
}

button {
  font-family: inherit;
}

.glass {
  background: var(--surface);
  backdrop-filter: blur(22px) saturate(130%);
  -webkit-backdrop-filter: blur(22px) saturate(130%);
  border: 1px solid var(--line);
  box-shadow: var(--shadow-sm);
}

/* ============================================================
   NAVBAR
============================================================ */

#navbar {
  position: fixed;
  top: 12px;
  left: 14px;
  right: 14px;
  height: 62px;
  z-index: 1000;

  display: flex;
  align-items: center;
  justify-content: space-between;

  padding: 0 16px 0 20px;

  background: rgba(255,255,255,.78);
  backdrop-filter: blur(24px) saturate(150%);
  -webkit-backdrop-filter: blur(24px) saturate(150%);

  border: 1px solid rgba(255,255,255,.72);
  border-radius: 22px;

  box-shadow:
    0 12px 40px rgba(30,25,20,.08),
    inset 0 1px 0 rgba(255,255,255,.8);

  transition: .35s ease;
}

body.dark #navbar {
  background: rgba(24,24,25,.82);
  border-color: rgba(255,255,255,.07);

  box-shadow:
    0 16px 50px rgba(0,0,0,.35),
    inset 0 1px 0 rgba(255,255,255,.05);
}

#navbar::after {
  content: "";
  position: absolute;
  left: 20%;
  right: 20%;
  bottom: -1px;
  height: 1px;
  background: linear-gradient(
    90deg,
    transparent,
    var(--gold),
    transparent
  );
  opacity: .45;
}

#navbar .logo {
  font-family: 'Playfair Display', serif;
  font-size: 1.42rem;
  font-weight: 900;
  letter-spacing: .08em;
  color: var(--text);
  display: flex;
  align-items: center;
  line-height: 1;
  position: relative;
}

#navbar .logo::before {
  content: "";
  width: 5px;
  height: 5px;
  border-radius: 50%;
  background: var(--gold);
  margin-right: 9px;
  box-shadow: 0 0 12px rgba(176,141,87,.5);
}

.nav-links {
  display: flex;
  align-items: center;
  gap: 5px;
}

.nav-links button,
.nav-links a {
  width: 40px;
  height: 40px;

  display: flex;
  align-items: center;
  justify-content: center;

  border: 1px solid transparent;
  border-radius: 14px;

  background: transparent;
  color: var(--text-soft);

  font-size: 1rem;
  cursor: pointer;
  text-decoration: none;

  transition:
    transform .25s ease,
    background .25s ease,
    color .25s ease,
    border .25s ease;
}

.nav-links button:hover,
.nav-links a:hover {
  background: rgba(176,141,87,.10);
  color: var(--gold-dark);
  border-color: rgba(176,141,87,.16);
  transform: translateY(-2px);
}

body.dark .nav-links button:hover,
body.dark .nav-links a:hover {
  color: var(--gold-light);
  background: rgba(200,166,107,.09);
}

.badge-cart {
  position: absolute;
  top: 1px;
  right: 0;

  min-width: 18px;
  height: 18px;

  display: flex;
  align-items: center;
  justify-content: center;

  padding: 0 5px;

  background: var(--gold);
  color: #fff;

  font-size: .58rem;
  font-weight: 800;

  border-radius: 99px;
  border: 2px solid var(--surface-solid);

  box-shadow: 0 4px 10px rgba(176,141,87,.25);
}

/* ============================================================
   HERO
============================================================ */

#hero {
  position: relative;
  max-width: 1400px;
  min-height: 570px;

  margin: 0 auto;
  padding: 58px 24px 62px;

  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;

  text-align: center;

  overflow: hidden;

  border-radius: 0 0 48px 48px;

  background:
    radial-gradient(
      circle at 50% 30%,
      rgba(255,255,255,.98),
      rgba(245,243,239,.92) 42%,
      rgba(232,226,216,.9) 100%
    );

  border-bottom: 1px solid var(--line);
}

body.dark #hero {
  background:
    radial-gradient(
      circle at 50% 30%,
      #24211c,
      #151515 45%,
      #0d0d0e 100%
    );
}

#hero::before {
  content: "AF";
  position: absolute;

  left: 50%;
  top: 42%;

  transform: translate(-50%, -50%);

  font-family: 'Playfair Display', serif;
  font-size: clamp(13rem, 31vw, 28rem);
  font-weight: 900;

  color: transparent;
  -webkit-text-stroke: 1px rgba(176,141,87,.08);

  pointer-events: none;
  user-select: none;
}

#hero::after {
  content: "";
  position: absolute;

  width: 480px;
  height: 480px;

  right: -220px;
  top: -230px;

  border-radius: 50%;

  border: 1px solid rgba(176,141,87,.14);

  box-shadow:
    0 0 0 40px rgba(176,141,87,.025),
    0 0 0 80px rgba(176,141,87,.018);

  pointer-events: none;
}

.story-ring-wrap {
  position: relative;
  z-index: 2;

  display: flex;
  justify-content: center;
  margin-bottom: 18px;
}

#storyRing {
  width: 82px;
  height: 82px;

  display: flex;
  align-items: center;
  justify-content: center;

  border-radius: 50%;

  background:
    conic-gradient(
      from 0deg,
      var(--gold),
      #e0c18b,
      var(--gold-dark),
      var(--gold)
    );

  padding: 3px;

  cursor: pointer;

  position: relative;

  box-shadow:
    0 12px 35px rgba(176,141,87,.20);

  transition: transform .3s ease;
}

#storyRing:hover {
  transform: scale(1.05) rotate(2deg);
}

#storyRing.has-stories {
  animation: storyPulse 2.5s ease-in-out infinite;
}

@keyframes storyPulse {
  0%,100% {
    box-shadow:
      0 12px 35px rgba(176,141,87,.20);
  }

  50% {
    box-shadow:
      0 15px 45px rgba(176,141,87,.38);
  }
}

#storyRing .ring-inner {
  width: 100%;
  height: 100%;

  border-radius: 50%;

  display: flex;
  align-items: center;
  justify-content: center;

  background: var(--surface-solid);

  color: var(--gold-dark);

  font-size: 1.25rem;

  border: 5px solid var(--surface-solid);

  box-shadow: inset 0 0 0 1px var(--line);
}

body.dark #storyRing .ring-inner {
  background: #171717;
  border-color: #171717;
}

#storyDot {
  position: absolute;

  right: 1px;
  bottom: 3px;

  width: 15px;
  height: 15px;

  border-radius: 50%;

  background: #4caf78;

  border: 3px solid var(--surface-solid);

  box-shadow: 0 0 0 3px rgba(76,175,120,.14);
}

.lottie-hero {
  position: relative;
  z-index: 2;

  width: 64px;
  height: 64px;

  margin: 0 auto 6px;

  opacity: .92;
}

#hero h1 {
  position: relative;
  z-index: 2;

  font-family: 'Playfair Display', serif;
  font-size: clamp(3.4rem, 9vw, 6.8rem);
  line-height: .9;

  font-weight: 900;
  letter-spacing: -.045em;

  margin: 8px 0 18px;

  color: var(--text);

  background:
    linear-gradient(
      135deg,
      #181818 0%,
      #5b4b36 48%,
      var(--gold) 100%
    );

  -webkit-background-clip: text;
  -webkit-text-fill-color: transparent;
}

body.dark #hero h1 {
  background:
    linear-gradient(
      135deg,
      #f5f2ec,
      var(--gold-light)
    );

  -webkit-background-clip: text;
  -webkit-text-fill-color: transparent;
}

#hero h1::after {
  content: "";
  display: block;

  width: 62px;
  height: 2px;

  margin: 20px auto 0;

  background: linear-gradient(
    90deg,
    transparent,
    var(--gold),
    transparent
  );
}

#heroDescription {
  position: relative;
  z-index: 2;

  max-width: 560px !important;

  color: var(--text-soft);

  font-size: .98rem;
  line-height: 1.8;

  letter-spacing: .08em;
  text-transform: uppercase;
}

#hero .btn-primary {
  position: relative;
  z-index: 2;

  margin-top: 26px;

  display: inline-flex;
  align-items: center;
  justify-content: center;
  gap: 12px;

  min-width: 190px;

  padding: 14px 24px;

  border: 1px solid rgba(176,141,87,.5);
  border-radius: 99px;

  background:
    linear-gradient(
      135deg,
      #1b1b1b,
      #34302a
    );

  color: #fff;

  font-weight: 700;
  font-size: .82rem;
  letter-spacing: .09em;
  text-transform: uppercase;

  cursor: pointer;

  box-shadow:
    0 12px 30px rgba(20,18,15,.18),
    inset 0 1px 0 rgba(255,255,255,.08);

  transition:
    transform .3s ease,
    box-shadow .3s ease;
}

#hero .btn-primary i {
  color: var(--gold-light);
  transition: transform .3s ease;
}

#hero .btn-primary:hover {
  transform: translateY(-4px);
  box-shadow:
    0 18px 40px rgba(20,18,15,.25);
}

#hero .btn-primary:hover i {
  transform: translateX(4px);
}

/* ============================================================
   SECTIONS
============================================================ */

.section {
  width: min(1180px, calc(100% - 32px));

  margin: 0 auto;
  padding: 72px 0 0;
}

.section-title {
  position: relative;

  display: flex;
  flex-direction: column;
  align-items: center;

  font-family: 'Playfair Display', serif;
  font-weight: 700;

  font-size: clamp(1.55rem, 3vw, 2.2rem);

  color: var(--text);

  margin-bottom: 32px;

  letter-spacing: -.02em;
}

.section-title::after {
  content: "";

  width: 42px;
  height: 2px;

  margin-top: 12px;

  background: var(--gold);

  box-shadow: 18px 0 0 rgba(176,141,87,.22);
}

/* ============================================================
   GRIDS
============================================================ */

.grid-3,
.grid-4,
.grid-2 {
  display: grid;
  gap: 18px;
}

.grid-3 {
  grid-template-columns: repeat(3, minmax(0,1fr));
}

.grid-4 {
  grid-template-columns: repeat(4, minmax(0,1fr));
}

.grid-2 {
  grid-template-columns: repeat(2, minmax(0,1fr));
}

/* ============================================================
   CARDS
============================================================ */

.card {
  position: relative;

  background:
    linear-gradient(
      145deg,
      rgba(255,255,255,.82),
      rgba(255,255,255,.50)
    );

  backdrop-filter: blur(20px);
  -webkit-backdrop-filter: blur(20px);

  border: 1px solid var(--line);

  border-radius: 25px;

  padding: 26px 22px;

  box-shadow: var(--shadow-sm);

  overflow: hidden;

  transition:
    transform .35s cubic-bezier(.2,.8,.2,1),
    box-shadow .35s ease,
    border-color .35s ease;
}

body.dark .card {
  background:
    linear-gradient(
      145deg,
      rgba(34,34,34,.85),
      rgba(23,23,23,.72)
    );
}

.card::before {
  content: "";

  position: absolute;

  width: 100px;
  height: 100px;

  right: -55px;
  top: -55px;

  border-radius: 50%;

  background: rgba(176,141,87,.07);
}

.card::after {
  content: "";

  position: absolute;

  left: 22px;
  top: 0;

  width: 36px;
  height: 2px;

  background: var(--gold);

  opacity: .7;
}

.card:hover {
  transform: translateY(-7px);

  border-color: rgba(176,141,87,.25);

  box-shadow:
    0 22px 55px rgba(30,25,20,.12);
}

body.dark .card:hover {
  box-shadow:
    0 22px 55px rgba(0,0,0,.38);
}

.card p {
  position: relative;
  z-index: 1;

  color: var(--text-soft);

  line-height: 1.75;
  font-size: .9rem;
}

/* ============================================================
   QUOTES
============================================================ */

.quote-icon {
  position: relative;
  z-index: 1;

  width: 42px;
  height: 42px;

  display: flex;
  align-items: center;
  justify-content: center;

  margin-bottom: 18px;

  border-radius: 13px;

  background: rgba(176,141,87,.10);

  color: var(--gold);

  font-size: 1rem;

  border: 1px solid rgba(176,141,87,.13);
}

.grid-3 .card p {
  font-family: 'Playfair Display', serif;

  font-size: .98rem;
  line-height: 1.65;

  color: var(--text);
}

/* ============================================================
   BENEFITS
============================================================ */

.grid-4 .card {
  min-height: 185px;

  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;

  text-align: center;
}

.benefit-lottie {
  width: 68px;
  height: 68px;

  margin: 0 auto 15px;

  padding: 8px;

  border-radius: 19px;

  background: rgba(176,141,87,.07);
}

.card h4 {
  position: relative;
  z-index: 2;

  font-size: .85rem;
  font-weight: 800;

  color: var(--text);

  letter-spacing: .04em;
  text-transform: uppercase;
}

/* ============================================================
   GALERÍA
============================================================ */

.grid-4 .gallery-img {
  position: relative;

  width: 100%;
  height: 235px;

  object-fit: cover;

  border-radius: 25px;

  border: 1px solid var(--line);

  filter: saturate(.88) contrast(1.02);

  cursor: pointer;

  box-shadow: var(--shadow-sm);

  transition:
    transform .45s cubic-bezier(.2,.8,.2,1),
    filter .45s ease,
    box-shadow .45s ease;
}

.grid-4 .gallery-img:hover {
  transform: translateY(-7px) scale(1.015);

  filter:
    saturate(1.05)
    contrast(1.05);

  box-shadow:
    0 22px 50px rgba(20,18,15,.18);
}

/* ============================================================
   FOOTER
============================================================ */

footer {
  position: relative;

  max-width: 1180px;

  margin: 80px auto 0;
  padding: 28px 20px 38px;

  text-align: center;

  color: var(--text-muted);

  font-size: .72rem;

  border-top: 1px solid var(--line);

  letter-spacing: .05em;
}

footer::before {
  content: "AF";

  display: block;

  font-family: 'Playfair Display', serif;

  font-size: 1.2rem;
  font-weight: 900;

  color: var(--gold);

  margin-bottom: 10px;
}

/* ============================================================
   CART FLOATING
============================================================ */

#cartFloating {
  position: fixed;

  bottom: 22px;
  right: 22px;

  width: 62px;
  height: 62px;

  display: flex;
  align-items: center;
  justify-content: center;

  border-radius: 21px;

  border: 1px solid rgba(255,255,255,.12);

  background:
    linear-gradient(
      145deg,
      #22201d,
      #0f0f0f
    );

  color: #fff;

  font-size: 1.2rem;

  box-shadow:
    0 18px 45px rgba(0,0,0,.25),
    inset 0 1px 0 rgba(255,255,255,.08);

  z-index: 1100;

  cursor: pointer;

  transition:
    transform .3s ease,
    box-shadow .3s ease;
}

#cartFloating::before {
  content: "";

  position: absolute;

  inset: -4px;

  border-radius: 24px;

  border: 1px solid rgba(176,141,87,.18);

  pointer-events: none;
}

#cartFloating:hover {
  transform: translateY(-5px) scale(1.03);

  box-shadow:
    0 24px 55px rgba(0,0,0,.32);
}

#cartFloating i {
  color: var(--gold-light);
}

#cartFloating .badge {
  position: absolute;

  top: -7px;
  right: -7px;

  min-width: 22px;
  height: 22px;

  display: flex;
  align-items: center;
  justify-content: center;

  padding: 0 6px;

  border-radius: 50px;

  background: var(--gold);

  color: #fff;

  border: 2px solid var(--bg);

  font-size: .62rem;
  font-weight: 900;

  box-shadow: 0 5px 14px rgba(176,141,87,.3);
}

/* ============================================================
   CART SHEET
============================================================ */

#cartSheet {
  position: fixed;

  left: 50%;
  bottom: 0;

  width: min(650px, 100%);

  max-height: 78vh;

  transform: translate(-50%, 110%);

  padding: 24px 24px 28px;

  background:
    linear-gradient(
      145deg,
      rgba(255,255,255,.96),
      rgba(244,241,236,.94)
    );

  backdrop-filter: blur(30px);
  -webkit-backdrop-filter: blur(30px);

  border: 1px solid rgba(255,255,255,.8);
  border-bottom: 0;

  border-radius: 34px 34px 0 0;

  box-shadow:
    0 -25px 80px rgba(20,18,15,.22);

  z-index: 1200;

  overflow-y: auto;

  transition:
    transform .45s cubic-bezier(.2,.8,.2,1);
}

body.dark #cartSheet {
  background:
    linear-gradient(
      145deg,
      rgba(29,29,30,.98),
      rgba(17,17,17,.98)
    );

  border-color: rgba(255,255,255,.07);

  box-shadow:
    0 -25px 90px rgba(0,0,0,.55);
}

#cartSheet::before {
  content: "";

  display: block;

  width: 44px;
  height: 4px;

  margin: -7px auto 20px;

  border-radius: 99px;

  background: var(--text-muted);

  opacity: .35;
}

#cartSheet.open {
  transform: translate(-50%, 0);
}

#cartSheet h3 {
  font-family: 'Playfair Display', serif;

  font-size: 1.5rem;

  color: var(--text);

  padding-bottom: 18px;

  border-bottom: 1px solid var(--line);
}

#cartSheet h3 i {
  color: var(--gold);
}

.cart-item {
  display: flex;
  align-items: center;
  gap: 16px;

  padding: 17px 0;

  border-bottom: 1px solid var(--line);
}

.cart-item strong {
  color: var(--text);
}

.cart-qty-controls {
  display: flex;
  align-items: center;

  padding: 3px;

  border-radius: 99px;

  background: var(--bg-soft);

  border: 1px solid var(--line);
}

.cart-qty-controls button {
  width: 27px;
  height: 27px;

  border: 0;
  border-radius: 50%;

  background: var(--surface-solid);

  color: var(--text);

  font-weight: 800;

  cursor: pointer;

  box-shadow: 0 2px 8px rgba(0,0,0,.05);

  transition: .2s ease;
}

.cart-qty-controls button:hover {
  background: var(--gold);
  color: #fff;
}

.cart-total {
  margin-top: 20px;

  padding: 17px 18px;

  border-radius: 18px;

  background: rgba(176,141,87,.08);

  border: 1px solid rgba(176,141,87,.14);

  color: var(--text);

  font-size: 1.2rem;
  font-weight: 900;

  text-align: right;
}

.btn-whatsapp {
  width: 100%;

  margin-top: 14px;

  padding: 15px;

  border: 0;
  border-radius: 17px;

  background: #25D366;

  color: white;

  font-size: .9rem;
  font-weight: 800;

  cursor: pointer;

  box-shadow:
    0 12px 28px rgba(37,211,102,.20);

  transition:
    transform .25s ease,
    box-shadow .25s ease;
}

.btn-whatsapp:hover {
  transform: translateY(-2px);

  box-shadow:
    0 17px 35px rgba(37,211,102,.28);
}

/* ============================================================
   STORY VIEWER
============================================================ */

#storyViewer {
  position: fixed;

  inset: 0;

  background:
    radial-gradient(
      circle at center,
      rgba(45,39,30,.70),
      rgba(0,0,0,.96)
    );

  backdrop-filter: blur(16px);
  -webkit-backdrop-filter: blur(16px);

  z-index: 2000;

  display: none;

  align-items: center;
  justify-content: center;

  padding: 18px;
}

#storyViewer .story-content {
  position: relative;

  width: min(430px, 100%);
  min-height: 580px;

  display: flex;
  flex-direction: column;

  padding: 18px;

  background:
    linear-gradient(
      145deg,
      #292721,
      #111111
    );

  border: 1px solid rgba(255,255,255,.09);

  border-radius: 34px;

  color: white;

  box-shadow:
    0 35px 100px rgba(0,0,0,.65);

  overflow: hidden;
}

#storyViewer .story-content::before {
  content: "AF MODAS";

  position: absolute;

  right: 22px;
  bottom: 80px;

  font-family: 'Playfair Display', serif;

  font-size: .65rem;
  letter-spacing: .2em;

  color: rgba(255,255,255,.2);
}

.story-progress {
  display: flex;

  gap: 5px;

  margin-bottom: 16px;
}

.story-progress span {
  flex: 1;

  height: 3px;

  border-radius: 99px;

  background: rgba(255,255,255,.15);

  overflow: hidden;
}

.story-progress span.active {
  background: var(--gold-light);

  box-shadow:
    0 0 12px rgba(212,180,122,.4);
}

.story-nav {
  display: flex;

  justify-content: space-between;

  margin-top: auto;

  padding-top: 16px;
}

.story-nav button {
  width: 45px;
  height: 45px;

  border: 1px solid rgba(255,255,255,.1);

  border-radius: 50%;

  background: rgba(255,255,255,.06);

  color: white;

  font-size: 1rem;

  cursor: pointer;

  transition: .25s ease;
}

.story-nav button:hover {
  background: rgba(176,141,87,.2);

  border-color: rgba(176,141,87,.35);
}

.story-close {
  position: absolute;

  top: 15px;
  right: 16px;

  width: 38px;
  height: 38px;

  display: flex;
  align-items: center;
  justify-content: center;

  background: rgba(255,255,255,.07);

  border: 1px solid rgba(255,255,255,.08);

  border-radius: 50%;

  color: white;

  font-size: 1rem;

  cursor: pointer;

  z-index: 5;
}

#storyBody {
  flex: 1;

  min-height: 360px !important;

  padding: 25px 10px;
}

#storyBody h3 {
  margin-top: 14px;

  font-family: 'Playfair Display', serif;

  font-size: 1.55rem;
}

#storyBody p {
  max-width: 320px;

  margin-top: 9px;

  color: rgba(255,255,255,.7);

  line-height: 1.7;
}

/* ============================================================
   IMAGE VIEWER
============================================================ */

#imageViewer {
  position: fixed;

  inset: 0;

  background: rgba(0,0,0,.94);

  backdrop-filter: blur(14px);
  -webkit-backdrop-filter: blur(14px);

  display: none;

  align-items: center;
  justify-content: center;

  z-index: 4000;

  padding: 25px;
}

#imageViewer img {
  max-width: min(92%, 1000px);
  max-height: 88%;

  object-fit: contain;

  border-radius: 20px;

  box-shadow:
    0 30px 100px rgba(0,0,0,.55);
}

#imageViewer button {
  position: absolute;

  top: 22px;
  right: 25px;

  width: 46px;
  height: 46px;

  border: 1px solid rgba(255,255,255,.12);

  border-radius: 50%;

  background: rgba(255,255,255,.08);

  color: white;

  font-size: 1.2rem;

  cursor: pointer;
}

/* ============================================================
   TOAST
============================================================ */

.toast {
  position: fixed;

  left: 50%;
  bottom: 25px;

  transform: translateX(-50%);

  z-index: 9999;

  display: flex;
  align-items: center;
  gap: 10px;

  max-width: calc(100% - 30px);

  padding: 13px 20px;

  background:
    rgba(25,25,25,.94);

  backdrop-filter: blur(18px);

  border: 1px solid rgba(255,255,255,.09);

  border-radius: 99px;

  color: white;

  font-size: .8rem;
  font-weight: 700;

  box-shadow:
    0 15px 45px rgba(0,0,0,.28);

  animation:
    toastIn .35s cubic-bezier(.2,.8,.2,1);
}

@keyframes toastIn {
  from {
    transform: translate(-50%, 20px) scale(.94);
    opacity: 0;
  }

  to {
    transform: translate(-50%, 0) scale(1);
    opacity: 1;
  }
}

/* ============================================================
   RESPONSIVE
============================================================ */

@media (max-width: 900px) {
  #hero {
    min-height: 520px;
  }

  .grid-3 {
    grid-template-columns: 1fr;
  }

  .grid-4 {
    grid-template-columns: repeat(2, minmax(0,1fr));
  }

  .section {
    padding-top: 60px;
  }
}

@media (max-width: 600px) {
  :root {
    --nav-height: 70px;
  }

  body {
    padding-top: var(--nav-height);
  }

  #navbar {
    top: 8px;
    left: 9px;
    right: 9px;

    height: 58px;

    padding-left: 15px;
    padding-right: 9px;

    border-radius: 19px;
  }

  #navbar .logo {
    font-size: 1.12rem;
  }

  #navbar .logo::before {
    width: 4px;
    height: 4px;
    margin-right: 7px;
  }

  .nav-links {
    gap: 1px;
  }

  .nav-links button,
  .nav-links a {
    width: 37px;
    height: 37px;
  }

  #hero {
    min-height: 515px;

    padding:
      45px 20px
      55px;

    border-radius: 0 0 34px 34px;
  }

  #hero::before {
    font-size: 16rem;
  }

  #hero h1 {
    font-size: clamp(3.2rem, 18vw, 5rem);
  }

  #heroDescription {
    font-size: .76rem;

    max-width: 330px !important;

    letter-spacing: .07em;
  }

  #hero .btn-primary {
    min-width: 180px;
    padding: 13px 20px;
  }

  .section {
    width: min(100% - 22px, 1180px);

    padding-top: 52px;
  }

  .section-title {
    font-size: 1.55rem;

    margin-bottom: 24px;
  }

  .grid-3,
  .grid-4 {
    gap: 13px;
  }

  .card {
    border-radius: 21px;
    padding: 21px 18px;
  }

  .grid-4 .card {
    min-height: 160px;
  }

  .benefit-lottie {
    width: 57px;
    height: 57px;
  }

  .card h4 {
    font-size: .72rem;
  }

  .grid-4 .gallery-img {
    height: 145px;

    border-radius: 19px;
  }

  #cartFloating {
    width: 58px;
    height: 58px;

    right: 17px;
    bottom: 17px;

    border-radius: 19px;
  }

  #cartSheet {
    max-height: 82vh;

    padding:
      20px
      18px
      25px;

    border-radius: 29px 29px 0 0;
  }

  .cart-item {
    align-items: flex-start;
    flex-wrap: wrap;
  }

  .cart-item > div:first-child {
    width: 100%;
  }

  .cart-item > div:last-child {
    width: 100%;

    justify-content: space-between;
  }

  #storyViewer {
    padding: 9px;
  }

  #storyViewer .story-content {
    min-height: calc(100vh - 18px);

    border-radius: 27px;
  }

  footer {
    margin-top: 60px;
  }
}

@media (max-width: 390px) {
  .grid-4 {
    grid-template-columns: 1fr 1fr;
  }

  #navbar .logo {
    letter-spacing: .04em;
  }

  .nav-links button,
  .nav-links a {
    width: 34px;
  }

  #hero {
    min-height: 500px;
  }
}

/* ============================================================
   REDUCCIÓN DE MOVIMIENTO
============================================================ */

@media (prefers-reduced-motion: reduce) {
  *,
  *::before,
  *::after {
    animation-duration: .01ms !important;
    animation-iteration-count: 1 !important;
    scroll-behavior: auto !important;
    transition-duration: .01ms !important;
  }
}
</style>
<link rel="stylesheet" href="/assets/css/cart-coupon.css?v=14">
<link rel="stylesheet" href="/assets/css/cart-stock.css?v=16">
<link rel="stylesheet" href="/assets/css/home-editorial.css?v=15">
<link rel="stylesheet" href="/assets/css/photo-loader.css?v=18">
<link rel="stylesheet" href="/assets/css/stories.css?v=28">
<link rel="stylesheet" href="/assets/css/favorites.css?v=24">
<script src="/assets/js/favorites.js?v=24" defer></script>
</head>

<body>

<!-- ============================================================
     NAVBAR
============================================================ -->

<nav id="navbar">

  <span class="logo">AF MODAS</span>

  <div class="nav-links">
    <a href="/catalogo.html?favorites=1" title="Mis favoritos" aria-label="Mis favoritos"><i class="fas fa-star"></i></a>

    <a href="index.php" title="Inicio">
      <i class="fas fa-house"></i>
    </a>

    <a href="catalogo.html" title="Catálogo">
      <i class="fas fa-shirt"></i>
    </a>

    <button onclick="toggleCart()" style="position:relative;" title="Carrito">
      <i class="fas fa-shopping-bag"></i>
      <span id="cartBadge" class="badge-cart">0</span>
    </button>

    <button onclick="toggleTheme()" title="Tema">
      <i id="themeIcon" class="fas fa-moon"></i>
    </button>

  </div>

</nav>


<!-- ============================================================
     HERO
============================================================ -->

<section id="hero">

  <div class="story-ring-wrap">

    <div id="storyRing" onclick="openStoryViewer()">

      <div class="ring-inner">
        <i class="fas fa-play"></i>
      </div>

      <div id="storyDot" style="display:none;"></div>

    </div>

  </div>


  <div
    class="lottie-hero"
    id="lottieHero">
  </div>


  <span class="af-hero-kicker">Estilo propio · AF MODAS</span>

  <h1>AF MODAS</h1>


  <p
    id="heroDescription"
    style="font-weight:300;max-width:500px;margin:0 auto 0.5rem;">
    Elegancia que trasciende
  </p>


  <button
    class="btn-primary"
    onclick="window.location.href='catalogo.php'">

    Explorar colección

    <i class="fas fa-arrow-right"></i>

  </button>
  <span class="af-hero-note">Piezas para cada historia · Explorá la colección</span>

</section>


<!-- ============================================================
     SELECCIÓN DEL CATÁLOGO · imágenes reales
============================================================ -->
<section class="af-editorial" aria-labelledby="afLookbookTitle">
  <div class="af-editorial-heading">
    <div>
      <span class="af-editorial-eyebrow">Selección de la tienda</span>
      <h2 id="afLookbookTitle">Prendas que cuentan historias</h2>
      <p>Una mirada a las piezas disponibles hoy. Encontrá colores, texturas y detalles para elegir tu próximo look.</p>
    </div>
    <a class="af-editorial-link" href="/catalogo.html">Ver todo el catálogo <span aria-hidden="true">↗</span></a>
  </div>
  <div class="af-lookbook-grid" id="afLookbookGrid" aria-live="polite">
    <p class="af-lookbook-empty">Preparando la colección...</p>
  </div>
</section>

<!-- ============================================================
     CONTENIDO
============================================================ -->

<div class="section">


  <!-- FRASES -->

  <h2 class="section-title">
    ✦ Nuestra inspiración
  </h2>


  <div
    class="grid-3"
    style="margin-bottom:2rem;">

    <div class="card">

      <div class="quote-icon">
        <i class="fas fa-quote-left"></i>
      </div>

      <p>
        "La moda es la armadura para sobrevivir a la realidad"
        — Bill Cunningham
      </p>

    </div>


    <div class="card">

      <div class="quote-icon">
        <i class="fas fa-quote-left"></i>
      </div>

      <p>
        "AF MODAS: donde cada prenda cuenta una historia"
      </p>

    </div>


    <div class="card">

      <div class="quote-icon">
        <i class="fas fa-quote-left"></i>
      </div>

      <p>
        "La elegancia no es llamar la atención, es ser recordado"
        — Audrey Hepburn
      </p>

    </div>

  </div>


  <!-- BENEFICIOS -->

  <h2 class="section-title">
    ✦ La diferencia AF MODAS
  </h2>


  <div
    class="grid-4"
    style="margin-bottom:2rem;">

    <div class="card">

      <div
        class="benefit-lottie"
        id="lottieQuality">
      </div>

      <h4>Calidad Premium</h4>

    </div>


    <div class="card">

      <div
        class="benefit-lottie"
        id="lottieShip">
      </div>

      <h4>Envío Rápido</h4>

    </div>


    <div class="card">

      <div
        class="benefit-lottie"
        id="lottieSupport">
      </div>

      <h4>Atención 24/7</h4>

    </div>


    <div class="card">

      <div
        class="benefit-lottie"
        id="lottieTrend">
      </div>

      <h4>Tendencias</h4>

    </div>

  </div>


  <!-- GALERÍA -->

  <h2 class="section-title">
    ✦ Galería de Moda
  </h2>


  <div class="grid-4">

    <img
      class="gallery-img"
      src="https://images.unsplash.com/photo-1539109136881-3be0616acf4b?w=600&h=800&fit=crop"
      alt="AF MODAS · Colección"
      onclick="openImageViewer(this.src)">


    <img
      class="gallery-img"
      src="https://images.unsplash.com/photo-1490481651871-ab68de25d43d?w=600&h=800&fit=crop"
      alt="AF MODAS · Moda"
      onclick="openImageViewer(this.src)">


    <img
      class="gallery-img"
      src="https://images.unsplash.com/photo-1523381210434-271e8be1f52b?w=600&h=800&fit=crop"
      alt="AF MODAS · Estilo"
      onclick="openImageViewer(this.src)">


    <img
      class="gallery-img"
      src="https://images.unsplash.com/photo-1490481651871-ab68de25d43d?w=600&h=800&fit=crop"
      alt="AF MODAS · Colección"
      onclick="openImageViewer(this.src)">

  </div>

</div>


<!-- ============================================================
     FOOTER
============================================================ -->

<footer>

  <p>
    © <span id="footerYear"></span>
    <span id="footerSiteName">AF MODAS</span>
    · Todos los derechos reservados
  </p>

</footer>


<!-- ============================================================
     CARRITO
============================================================ -->

<div id="cartSheet">

  <h3
    style="display:flex;justify-content:space-between;margin-bottom:0.5rem;">

    <span>
      <i class="fas fa-shopping-bag"></i>
      Carrito
    </span>

    <span
      onclick="toggleCart()"
      style="cursor:pointer;font-size:1.3rem;">

      <i class="fas fa-times"></i>

    </span>

  </h3>


  <div id="cartItems"></div>


  <div
    class="cart-total"
    id="cartTotal">

    Total: $0

  </div>


  <button
    class="btn-whatsapp"
    onclick="checkout()">

    <i class="fab fa-whatsapp"></i>

    Generar PDF del pedido

  </button>

</div>


<!-- ============================================================
     BOTÓN CARRITO
============================================================ -->

<button
  id="cartFloating"
  onclick="toggleCart()">

  <i class="fas fa-shopping-bag"></i>

  <span
    id="floatingBadge"
    class="badge">

    0

  </span>

</button>


<!-- ============================================================
     STORY VIEWER
============================================================ -->

<div id="storyViewer" role="dialog" aria-modal="true" aria-label="Historias de AF MODAS" aria-hidden="true">
  <div class="story-content">
    <div class="story-progress" id="storyProgress" aria-hidden="true"></div>
    <div class="story-header">
      <img class="story-avatar" src="/assets/img/af-logo.png" alt="AF MODAS">
      <div class="story-account">AF MODAS<span class="story-age" id="storyAge"></span></div>
      <button id="storyShare" type="button" aria-label="Compartir historia" title="Compartir historia"><i class="fas fa-share-nodes" aria-hidden="true"></i></button>
      <button id="storyPause" type="button" aria-label="Pausar historia" aria-pressed="false">Ⅱ</button>
      <button class="story-close" type="button" onclick="closeStoryViewer()" aria-label="Cerrar historias">×</button>
    </div>
    <div id="storyBody" tabindex="0"></div>
    <div class="story-nav">
      <button id="storyPrevious" type="button" onclick="prevStory()" aria-label="Historia anterior">‹</button>
      <span class="story-position" id="storyPosition" aria-live="polite"></span>
      <button type="button" onclick="nextStory()" aria-label="Historia siguiente">›</button>
    </div>
  </div>
</div>

<!-- ============================================================
     IMAGE VIEWER
============================================================ -->

<div
  id="imageViewer"
  onclick="closeImageViewer(event)">

  <img
    id="viewerImg"
    src=""
    alt="Vista previa">


  <button onclick="closeImageViewer(event)">

    <i class="fas fa-times"></i>

  </button>

</div>


<script>

/* ============================================================
   CONFIGURACIÓN
============================================================ */

const API_URL = window.location.origin + '/api';


/* ============================================================
   VERIFICAR SI LA WEB ESTÁ ACTIVA
============================================================ */

async function checkMaintenanceMode() {

  try {

    const res =
      await fetch(API_URL + '/settings.php?key=web_enabled');

    const data = await res.json();

    let enabled = true;

    if (
      data &&
      data.data &&
      typeof data.data.web_enabled !== 'undefined'
    ) {

      enabled = data.data.web_enabled;

    } else if (
      data &&
      typeof data.web_enabled !== 'undefined'
    ) {

      enabled = data.web_enabled;

    }


    if (enabled === false) {

      let title =
        'Sitio en mantenimiento';

      let message =
        'Estamos actualizando nuestra tienda. Volvemos en breve ✨';


      try {

        const res2 =
          await fetch(API_URL + '/settings.php');

        const data2 =
          await res2.json();

        let cfg =
          data2.config ||
          data2.data ||
          data2;


        if (cfg.maintenance_title)
          title = cfg.maintenance_title;

        if (cfg.maintenance_message)
          message = cfg.maintenance_message;

      } catch(e) {}


      showMaintenanceScreen(
        title,
        message
      );

      return false;

    }


    return true;

  } catch(e) {

    console.warn(
      'No se pudo verificar el estado de la web:',
      e
    );

    return true;
  }
}


/* ============================================================
   PANTALLA DE MANTENIMIENTO
============================================================ */

function showMaintenanceScreen(title, message) {

  document.body.innerHTML = `

    <div style="
      min-height:100vh;
      display:flex;
      align-items:center;
      justify-content:center;
      padding:1rem;

      background:
        radial-gradient(
          circle at center,
          #f7f2e8,
          #e7dfd1
        );

      font-family:'Inter',sans-serif;
    ">

      <div style="
        text-align:center;
        max-width:520px;
        width:100%;
      ">

        <div
          id="lottie404"
          style="
            width:280px;
            height:280px;
            margin:0 auto;
          ">
        </div>


        <div style="
          width:60px;
          height:2px;
          background:#b08d57;
          margin:0 auto 22px;
        "></div>


        <h1 style="
          font-family:'Playfair Display',serif;
          font-weight:900;
          font-size:2.5rem;
          margin:1rem 0 .7rem;

          color:#1c1c1c;
        ">

          ${title}

        </h1>


        <p style="
          font-size:1rem;
          color:#66625c;
          line-height:1.8;
          margin-bottom:2rem;
        ">

          ${message}

        </p>


        <div style="
          display:inline-flex;
          align-items:center;
          gap:.6rem;

          padding:.75rem 1.25rem;

          background:rgba(255,255,255,.65);

          border-radius:40px;

          font-size:.78rem;
          color:#555;

          backdrop-filter:blur(12px);

          border:1px solid rgba(255,255,255,.7);
        ">

          <i
            class="fas fa-sparkles"
            style="color:#b08d57;">
          </i>

          <span>
            Trabajando para mejorar tu experiencia
          </span>

        </div>

      </div>

    </div>

    <link
      rel="stylesheet"
      href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">

    <link
      href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700;800&family=Playfair+Display:wght@900&display=swap"
      rel="stylesheet">

    <script src="https://cdnjs.cloudflare.com/ajax/libs/lottie-web/5.9.6/lottie.min.js"><\/script>

  `;


  setTimeout(() => {

    if (
      typeof lottie !== 'undefined'
    ) {

      lottie.loadAnimation({

        container:
          document.getElementById('lottie404'),

        path:
          'https://assets10.lottiefiles.com/packages/lf20_afwjhvgv.json',

        loop: true,

        autoplay: true

      });

    }

  }, 500);
}


/* ============================================================
   CONFIGURACIÓN DEL SITIO
============================================================ */

window.SITE_CONFIG = {

  whatsapp: '573001234567',

  site_name: 'AF MODAS',

  free_ship: 100000,

  logo_url: '',

  description:
    'Tienda de moda premium · Elegancia que trasciende'

};


window.products = [];

window.cart = [];

window.notifications = [];

window.storyIndex = 0;

window.storyTimer = null;


/* ============================================================
   TOAST
============================================================ */

function showToast(msg) {

  const t =
    document.createElement('div');

  t.className = 'toast';

  t.innerText = msg;

  document.body.appendChild(t);

  setTimeout(() => {

    t.remove();

  }, 2500);
}


/* ============================================================
   TEMA
============================================================ */

function toggleTheme() {

  document.body.classList.toggle('dark');

  document.getElementById('themeIcon').className =
    document.body.classList.contains('dark')
      ? 'fas fa-sun'
      : 'fas fa-moon';

  localStorage.setItem(
    'af_theme',
    document.body.classList.contains('dark')
      ? 'dark'
      : 'light'
  );
}


/* ============================================================
   CARGAR CONFIGURACIÓN
============================================================ */

async function loadSiteConfig() {

  try {

    const res =
      await fetch(API_URL + '/settings.php');

    if (!res.ok)
      throw new Error(
        'HTTP ' + res.status
      );

    const data =
      await res.json();


    let config = null;


    if (data && data.config)
      config = data.config;

    else if (
      data &&
      data.data &&
      data.data.config
    )
      config = data.data.config;

    else if (
      data &&
      data.data &&
      typeof data.data === 'object'
    )
      config = data.data;

    else if (
      data &&
      data.whatsapp
    )
      config = data;


    if (config) {

      if (config.whatsapp)
        window.SITE_CONFIG.whatsapp =
          config.whatsapp;

      if (config.site_name)
        window.SITE_CONFIG.site_name =
          config.site_name;

      if (config.free_ship)
        window.SITE_CONFIG.free_ship =
          config.free_ship;

      if (config.logo_url)
        window.SITE_CONFIG.logo_url =
          config.logo_url;

      if (config.description)
        window.SITE_CONFIG.description =
          config.description;


      const siteName =
        window.SITE_CONFIG.site_name ||
        'AF MODAS';


      const description =
        window.SITE_CONFIG.description ||
        'Tienda de moda premium · Elegancia que trasciende';


      /* LOGO */

      const logoEl =
        document.querySelector(
          '#navbar .logo'
        );


      if (logoEl) {

        if (
          window.SITE_CONFIG.logo_url
        ) {

          logoEl.innerHTML =
            '<img src="' +
            window.SITE_CONFIG.logo_url +
            '" alt="' +
            siteName +
            '" style="' +
            'max-height:42px;' +
            'max-width:190px;' +
            'object-fit:contain;' +
            'display:block;' +
            '">';

          logoEl.style.background =
            'none';

          logoEl.style.webkitTextFillColor =
            'initial';

        } else {

          logoEl.textContent =
            siteName;

        }
      }


      /* HERO */

      const heroH1 =
        document.querySelector(
          '#hero h1'
        );

      if (heroH1)
        heroH1.textContent =
          siteName;


      /* DESCRIPCIÓN */

      const heroP =
        document.getElementById(
          'heroDescription'
        );

      if (heroP)
        heroP.textContent =
          description;


      /* TÍTULO */

      document.title =
        siteName +
        ' · ' +
        description;


      /* META */

      let metaDesc =
        document.querySelector(
          'meta[name="description"]'
        );


      if (!metaDesc) {

        metaDesc =
          document.createElement('meta');

        metaDesc.name =
          'description';

        document.head.appendChild(
          metaDesc
        );
      }


      metaDesc.content =
        description;


      /* FOOTER */

      const footerName =
        document.getElementById(
          'footerSiteName'
        );


      if (footerName)
        footerName.textContent =
          siteName;


      console.log(
        '✅ Configuración cargada:',
        window.SITE_CONFIG
      );
    }

  } catch(e) {

    console.warn(
      '⚠️ No se pudo cargar configuración',
      e
    );

  }
}


/* ============================================================
   NOTIFICACIONES
============================================================ */

async function loadNotifications() {

  try {

    const res =
      await fetch(
        API_URL + '/notifications.php?active=1'
      );

    const data =
      await res.json();
    if (!res.ok || data?.success === false) throw new Error('No se pudieron cargar las historias');


    let list = [];


    if (Array.isArray(data))
      list = data;

    else if (
      data &&
      Array.isArray(data.data)
    )
      list = data.data;


    window.notifications = list;
    window.storiesLoadFailed = false;

  } catch(e) {

    window.notifications = [];
    window.storiesLoadFailed = true;

  }


  updateStoryRing();
}


/* ============================================================
   CARRITO
============================================================ */

function loadCart() {

  try {

    const d =
      localStorage.getItem('af_cart');

    if (d)
      window.cart =
        JSON.parse(d);

  } catch(e) {

    window.cart = [];

  }
}


function saveCart() {

  localStorage.setItem(
    'af_cart',
    JSON.stringify(window.cart)
  );

  updateCartBadge();
}


function updateCartBadge() {

  const total =
    window.cart.reduce(
      (s, i) =>
        s + i.qty,
      0
    );


  const badge =
    document.getElementById(
      'cartBadge'
    );


  const floating =
    document.getElementById(
      'floatingBadge'
    );


  if (badge)
    badge.innerText =
      total;


  if (floating)
    floating.innerText =
      total;
}


function displayCart() {

  const container =
    document.getElementById(
      'cartItems'
    );


  const totalEl =
    document.getElementById(
      'cartTotal'
    );


  if (!container)
    return;


  if (
    window.cart.length === 0
  ) {

    container.innerHTML = `

      <div style="
        padding:45px 15px;
        text-align:center;
        color:var(--text-muted);
      ">

        <div style="
          width:64px;
          height:64px;

          display:flex;
          align-items:center;
          justify-content:center;

          margin:0 auto 14px;

          border-radius:20px;

          background:var(--bg-soft);

          border:1px solid var(--line);

          font-size:1.4rem;

          color:var(--gold);
        ">

          <i class="fas fa-bag-shopping"></i>

        </div>

        <strong style="
          display:block;
          color:var(--text);
          margin-bottom:5px;
        ">

          Tu carrito está vacío

        </strong>

        <span style="
          font-size:.78rem;
        ">

          Agrega tus prendas favoritas

        </span>

      </div>

    `;


    if (totalEl)
      totalEl.innerText =
        'Total: $0';


    return;
  }


  let total = 0;

  let html = '';


  window.cart.forEach(
    (item, i) => {

      const sub =
        item.price *
        item.qty;


      total += sub;


      html += `

        <div class="cart-item">

          <div style="flex:1;">

            <strong style="
              font-size:.88rem;
            ">

              ${item.name}

            </strong>

            <div style="
              font-size:.72rem;
              color:var(--text-muted);
              margin-top:4px;
            ">

              $${item.price.toLocaleString()}
              · unidad

            </div>

          </div>


          <div style="
            display:flex;
            align-items:center;
            gap:.65rem;
          ">


            <div class="cart-qty-controls">

              <button
                onclick="decreaseQuantity(${i})">
                -
              </button>


              <span style="
                display:inline-block;
                min-width:20px;
                text-align:center;
                font-weight:800;
                font-size:.8rem;
              ">

                ${item.qty}

              </span>


              <button
                onclick="increaseQuantity(${i})">
                +
              </button>

            </div>


            <span style="
              font-weight:800;
              min-width:70px;
              text-align:right;
              font-size:.82rem;
            ">

              $${sub.toLocaleString()}

            </span>


            <button
              onclick="removeFromCart(${i})"
              style="
                background:rgba(201,83,77,.10);
                color:var(--danger);
                border:1px solid rgba(201,83,77,.12);
                width:29px;
                height:29px;
                border-radius:50%;
                cursor:pointer;
              ">

              <i class="fas fa-trash-can"
                 style="font-size:.65rem;">
              </i>

            </button>

          </div>

        </div>

      `;
    }
  );


  container.innerHTML =
    html;


  if (totalEl)
    totalEl.innerText =
      'Total: $' +
      total.toLocaleString();
}


function toggleCart() {

  const sheet =
    document.getElementById(
      'cartSheet'
    );


  sheet.classList.toggle(
    'open'
  );


  displayCart();
}


function removeFromCart(index) {

  window.cart.splice(
    index,
    1
  );

  saveCart();

  displayCart();
}


function increaseQuantity(index) {
  if (!window.AFStockCart) { showToast('No se pudo verificar el stock. Recargá la página.'); return; }
  return window.AFStockCart.increase(index);
}


function decreaseQuantity(index) {

  if (
    window.cart[index].qty > 1
  ) {

    window.cart[index].qty -= 1;

  } else {

    window.cart.splice(
      index,
      1
    );

  }


  saveCart();

  displayCart();
}


/* ============================================================
   CHECKOUT
============================================================ */

function checkout() {
  if (typeof window.AFCheckoutPDF === 'function') return window.AFCheckoutPDF();
  alert('El generador de PDF no se cargó. Recargá la página e intentá de nuevo.');
}


/* ============================================================
   STORIES
============================================================ */

function escapeStoryHtml(value) {
  return String(value ?? '').replace(/[&<>"']/g, char => ({ '&':'&amp;', '<':'&lt;', '>':'&gt;', '"':'&quot;', "'":'&#39;' })[char]);
}

function getActiveStories() {

  const now =
    Date.now();


  return window.notifications.filter(
    n => {

      const created =
        n.created_at
          ? new Date(
              n.created_at
            ).getTime()
          : now;


      return created <= now && (
        now - created
      ) < 86400000;

    }
  );
}


function updateStoryRing() {

  const active =
    getActiveStories();


  const ring =
    document.getElementById(
      'storyRing'
    );


  const dot =
    document.getElementById(
      'storyDot'
    );


  if (!ring || !dot)
    return;


  if (active.length > 0) {

    ring.classList.add(
      'has-stories'
    );

    dot.style.display =
      'block';

  } else {

    ring.classList.remove(
      'has-stories'
    );

    dot.style.display =
      'none';

  }
}


/* ============================================================
   IMAGE VIEWER
============================================================ */

function openImageViewer(url) {

  document.getElementById(
    'viewerImg'
  ).src = url;


  document.getElementById(
    'imageViewer'
  ).style.display =
    'flex';
}


function closeImageViewer(e) {

  if (
    !e ||
    e.target === e.currentTarget ||
    e.target.tagName === 'BUTTON' ||
    e.target.tagName === 'I'
  ) {

    document.getElementById(
      'imageViewer'
    ).style.display =
      'none';

  }
}


/* ============================================================
   INIT
============================================================ */

document.addEventListener(
  'DOMContentLoaded',
  async () => {

    console.log(
      '🚀 Iniciando AF MODAS...'
    );


    /* MANTENIMIENTO */

    const isActive =
      await checkMaintenanceMode();


    if (!isActive)
      return;


    /* TEMA */

    try {

      if (
        localStorage.getItem(
          'af_theme'
        ) === 'dark'
      ) {

        document.body.classList.add(
          'dark'
        );


        document.getElementById(
          'themeIcon'
        ).className =
          'fas fa-sun';

      }

    } catch(e) {}


    /* AÑO */

    const yearEl =
      document.getElementById(
        'footerYear'
      );


    if (yearEl)
      yearEl.textContent =
        new Date().getFullYear();


    /* CARRITO */

    loadCart();


    /* CONFIG */

    await loadSiteConfig();


    /* NOTIFICACIONES */

    await loadNotifications();
    window.openSharedStory?.();


    /* ACTUALIZAR */

    displayCart();

    updateCartBadge();


    /* ========================================================
       LOTTIE
    ======================================================== */

    if (
      typeof lottie !== 'undefined'
    ) {

      if (
        document.getElementById(
          'lottieHero'
        )
      ) {

        const afHeroAnimation = lottie.loadAnimation({

          container:
            document.getElementById(
              'lottieHero'
            ),

          path:
            '/assets/anim/af-sparkle.json',

          loop: true,

          autoplay: true

        });
        afHeroAnimation.addEventListener('DOMLoaded', () => document.getElementById('lottieHero').classList.add('has-lottie'));

      }


      if (
        document.getElementById(
          'lottieQuality'
        )
      ) {

        lottie.loadAnimation({

          container:
            document.getElementById(
              'lottieQuality'
            ),

          path:
            'https://assets4.lottiefiles.com/packages/lf20_yrncp8jg.json',

          loop: true,

          autoplay: true

        });

      }


      if (
        document.getElementById(
          'lottieShip'
        )
      ) {

        lottie.loadAnimation({

          container:
            document.getElementById(
              'lottieShip'
            ),

          path:
            'https://assets8.lottiefiles.com/packages/lf20_kkxfpo5r.json',

          loop: true,

          autoplay: true

        });

      }


      if (
        document.getElementById(
          'lottieSupport'
        )
      ) {

        lottie.loadAnimation({

          container:
            document.getElementById(
              'lottieSupport'
            ),

          path:
            'https://assets1.lottiefiles.com/packages/lf20_2b4y8a0i.json',

          loop: true,

          autoplay: true

        });

      }


      if (
        document.getElementById(
          'lottieTrend'
        )
      ) {

        lottie.loadAnimation({

          container:
            document.getElementById(
              'lottieTrend'
            ),

          path:
            'https://assets4.lottiefiles.com/packages/lf20_xg9of6lq.json',

          loop: true,

          autoplay: true

        });

      }

    }


    /* STORIES */

    setInterval(
      updateStoryRing,
      60000
    );


    console.log(
      '✅ Home lista'
    );

  }
);

</script>

<script src="/assets/js/vendor/pdf-lib.min.js?v=14"></script>
<script src="/assets/js/order-pdf.js?v=30"></script>
<script src="/assets/js/cart-coupon.js?v=17"></script>
<script src="/assets/js/home-editorial.js?v=19"></script>
<script src="/assets/js/photo-loader.js?v=18"></script>
<script src="/assets/js/cart-stock.js?v=17"></script>
<script src="/assets/js/stories.js?v=28"></script>
</body>
</html>
