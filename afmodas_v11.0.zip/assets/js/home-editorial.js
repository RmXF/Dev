/* AF MODAS · Fotos del catálogo en la portada. */
(() => {
  'use strict';
  const grid = document.getElementById('afLookbookGrid');
  if (!grid) return;
  const money = value => '$' + new Intl.NumberFormat('es-AR').format(Number(value) || 0);
  async function populate() {
    try {
      const response = await fetch('/api/products.php', { cache: 'no-store' });
      if (!response.ok) throw new Error('Catálogo no disponible');
      const payload = await response.json();
      const products = Array.isArray(payload) ? payload : Array.isArray(payload.data) ? payload.data : [];
      const used = new Set();
      const picks = products.filter(product => {
        const code = String(product?.code ?? '');
        if (!code || !product?.image || Number(product.stock) <= 0 || used.has(code)) return false;
        used.add(code); return true;
      }).slice(0,4);
      grid.replaceChildren();
      if (!picks.length) {
        const empty = document.createElement('p'); empty.className = 'af-lookbook-empty';
        empty.textContent = 'Muy pronto vas a descubrir nuestras prendas aquí.';
        grid.appendChild(empty); return;
      }
      picks.forEach((product,index) => {
        const link = document.createElement('a'); link.className = 'af-lookbook-card'; link.href = '/producto.php?code=' + encodeURIComponent(String(product.code));
        link.setAttribute('aria-label','Ver prenda: '+String(product.name || 'prenda'));
        const photo = document.createElement('div'); photo.className = 'af-lookbook-photo';
        const img = document.createElement('img');
        img.src = '/api/product_image.php?code=' + encodeURIComponent(String(product.code));
        img.alt = String(product.name || 'Prenda AF MODAS');
        img.loading = index === 0 ? 'eager' : 'lazy';
        img.decoding = 'async';
        img.width = 600; img.height = 760;
        if (index === 0) img.fetchPriority = 'high';
        img.addEventListener('error', () => {
          if (img.dataset.fallback === '2') return;
          if (img.dataset.fallback === '1') { img.dataset.fallback = '2'; img.src = '/assets/img/af-logo.png'; return; }
          img.dataset.fallback = '1'; img.src = String(product.image);
        }, { once: false });
        const badge = document.createElement('span'); badge.className = 'af-lookbook-count'; badge.textContent = String(index+1).padStart(2,'0')+' / COLECCIÓN';
        const loading = document.createElement('span'); loading.className = 'af-lookbook-loading'; loading.setAttribute('aria-hidden','true');
        photo.append(img,loading,badge);
        const name = document.createElement('strong'); name.className = 'af-lookbook-name'; name.textContent = String(product.name || 'Prenda AF MODAS');
        const detail = document.createElement('span'); detail.className = 'af-lookbook-detail';
        const color = document.createElement('span'); color.textContent = String(product.color || product.category || 'AF MODAS');
        const price = document.createElement('strong'); price.textContent = money(product.price);
        detail.append(color,price); link.append(photo,name,detail); grid.appendChild(link);
      });
      window.AFPhotoLoader?.refresh(grid);
    } catch (_) {
      grid.replaceChildren();
      const empty = document.createElement('p'); empty.className = 'af-lookbook-empty';
      empty.textContent = 'Explorá la colección completa en el catálogo.';
      grid.appendChild(empty);
    }
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', populate);
  else populate();
})();
