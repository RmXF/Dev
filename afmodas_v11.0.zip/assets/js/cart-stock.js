/* AF MODAS · Límite de unidades disponibles, siempre contrastado con la API. */
(() => {
  'use strict';
  const busy = new Set();
  let lastSync = 0, syncing = null;
  const totalSelected = code => (window.cart || []).reduce((sum,item) => sum + (String(item.code) === String(code) ? Number(item.qty || 0) : 0), 0);
  const updateProduct = product => {
    if (!Array.isArray(window.products)) window.products = [];
    const index = window.products.findIndex(item => String(item.code) === String(product.code));
    if (index >= 0) window.products[index] = { ...window.products[index], ...product };
    else window.products.push(product);
  };
  async function liveProduct(code) {
    const response = await fetch('/api/products.php?code=' + encodeURIComponent(String(code)), { cache: 'no-store' });
    const payload = await response.json();
    if (!response.ok || !payload.success || !payload.data) throw new Error(payload.message || 'No se pudo consultar el stock');
    updateProduct(payload.data);
    return payload.data;
  }
  function renderRemaining() {
    const container = document.getElementById('cartItems');
    if (!container) return;
    container.querySelectorAll('.cart-item').forEach((row,index) => {
      const item = (window.cart || [])[index];
      if (!item) return;
      const product = (window.products || []).find(p => String(p.code) === String(item.code));
      if (!product) return;
      const left = Math.max(0, Number(product.stock || 0) - totalSelected(item.code));
      let note = row.querySelector('.cart-stock-left');
      if (!note) { note = document.createElement('small'); note.className = 'cart-stock-left'; row.firstElementChild?.appendChild(note); }
      note.textContent = left === 0 ? 'Límite disponible alcanzado' : `${left} ${left === 1 ? 'unidad disponible' : 'unidades disponibles'} para agregar`;
      const plus = row.querySelector('.cart-qty-controls button:last-child');
      if (plus) { plus.disabled = left <= 0; plus.title = left <= 0 ? 'No quedan más unidades' : 'Agregar una unidad'; }
    });
  }
  async function syncStock() {
    if (syncing) return syncing;
    syncing = (async () => {
      try {
        const response = await fetch('/api/products.php', { cache: 'no-store' });
        const payload = await response.json();
        if (!response.ok || !Array.isArray(payload.data)) return;
        window.products = payload.data;
        lastSync = Date.now();
        renderRemaining();
        if (typeof window.displayProducts === 'function') window.displayProducts();
      } catch (_) { /* La validación individual sigue cerrada ante errores. */ }
      finally { syncing = null; }
    })();
    return syncing;
  }
  async function add(code) {
    code = String(code);
    if (busy.has(code)) return;
    busy.add(code);
    try {
      const product = await liveProduct(code);
      const stock = Math.max(0, Number(product.stock) || 0);
      if (totalSelected(code) >= stock) { showToast(stock ? `Solo hay ${stock} unidades disponibles` : 'Producto agotado'); renderRemaining(); return; }
      const existing = (window.cart || []).find(item => String(item.code) === code);
      if (existing) existing.qty = Number(existing.qty || 0) + 1;
      else window.cart.push({ code: product.code, name: product.name, price: Number(product.price) || 0, qty: 1, image: product.image });
      saveCart(); displayCart();
      if (typeof window.displayProducts === 'function') window.displayProducts();
      renderRemaining();
      showToast('✓ Producto agregado al carrito');
    } catch (error) { showToast('No se pudo verificar el stock. Intentá de nuevo.'); }
    finally { busy.delete(code); }
  }
  async function increase(index) {
    const item = (window.cart || [])[index];
    if (!item) return;
    const code = String(item.code);
    if (busy.has(code)) return;
    busy.add(code);
    try {
      const product = await liveProduct(code);
      const stock = Math.max(0, Number(product.stock) || 0);
      if (totalSelected(code) >= stock) { showToast(stock ? `Solo hay ${stock} unidades disponibles` : 'Producto agotado'); renderRemaining(); return; }
      item.qty = Number(item.qty || 0) + 1;
      item.price = Number(product.price) || 0;
      saveCart(); displayCart();
      if (typeof window.displayProducts === 'function') window.displayProducts();
      renderRemaining();
    } catch (_) { showToast('No se pudo verificar el stock. Intentá de nuevo.'); }
    finally { busy.delete(code); }
  }
  const previousDisplay = window.displayCart;
  if (typeof previousDisplay === 'function') window.displayCart = function (...args) {
    const result = previousDisplay.apply(this,args);
    renderRemaining();
    if (Date.now() - lastSync > 10000 && !syncing && (window.cart || []).length) syncStock();
    return result;
  };
  window.AFStockCart = { add, increase, syncStock };
  if ((window.cart || []).length) syncStock();
})();
