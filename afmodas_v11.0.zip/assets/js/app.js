// ============================================
// AF MODAS - APLICACIÓN PRINCIPAL
// ============================================

// ===== CONFIGURACIÓN =====
const API_BASE = window.location.origin + '/afmodas/api';
const WHATSAPP_NUMBER = '573001234567';

// ===== VARIABLES GLOBALES =====
let products = [];
let cart = [];
let notifications = [];
let coupons = [];
let appliedCoupon = null;
let badgeFilter = 'all';
let storyIndex = 0;
let storyTimer = null;

// ===== API CALLS =====
async function fetchProducts() {
    try { const r = await fetch(API_BASE + '/products.php'); products = await r.json(); } catch(e) { products = []; }
}
async function fetchCoupons() {
    try { const r = await fetch(API_BASE + '/coupons.php'); coupons = await r.json(); } catch(e) { coupons = []; }
}
async function fetchNotifications() {
    try { const r = await fetch(API_BASE + '/notifications.php'); notifications = await r.json(); } catch(e) { notifications = []; }
}
async function saveProductToServer(p) {
    try { await fetch(API_BASE + '/products.php', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(p) }); } catch(e) {}
}
async function updateProductOnServer(p) {
    try { await fetch(API_BASE + '/products.php', { method: 'PUT', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(p) }); } catch(e) {}
}
async function updateCouponOnServer(c) {
    try { await fetch(API_BASE + '/coupons.php', { method: 'PUT', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(c) }); } catch(e) {}
}

// ===== STORAGE LOCAL =====
function loadCart() {
    try { const d = localStorage.getItem('af_cart'); cart = d ? JSON.parse(d) : []; } catch(e) { cart = []; }
}
function saveCart() {
    try { localStorage.setItem('af_cart', JSON.stringify(cart)); } catch(e) {}
    updateCartBadge();
}

// ===== UTILITY =====
function showToast(msg, type) {
    const t = document.createElement('div');
    t.className = 'toast' + (type === 'warning' ? ' toast-warning' : '');
    t.textContent = msg;
    document.body.appendChild(t);
    setTimeout(() => t.remove(), 3000);
}
function toggleTheme() {
    document.body.classList.toggle('dark');
    try { localStorage.setItem('af_theme', document.body.classList.contains('dark') ? 'dark' : 'light'); } catch(e) {}
}
function toggleSlideMenu() { document.getElementById('slideMenu').classList.toggle('open'); }
function getBadgeLabel(b) { const labels = { new: 'Nuevo', offer: 'Oferta', featured: 'Destacado', low: 'Últimas' }; return labels[b] || ''; }
function getBadgeClass(b) { return 'badge-' + b; }
function closeModal(id) { document.getElementById(id).classList.remove('open'); }

// ===== NAV =====
function showTab(tab) {
    document.getElementById('homeTab').classList.toggle('active', tab === 'home');
    document.getElementById('catalogTab').classList.toggle('active', tab === 'catalog');
    document.getElementById('hero').style.display = tab === 'catalog' ? 'none' : 'block';
    if (tab === 'catalog') displayProducts();
}

// ===== CATALOG =====
function setBadgeFilter(f) {
    badgeFilter = f;
    document.querySelectorAll('.badge-chip').forEach(c => c.classList.remove('active'));
    if (event && event.target) event.target.classList.add('active');
    displayProducts();
}
function displayProducts() {
    const grid = document.getElementById('productGrid');
    if (!grid) return;
    const search = document.getElementById('searchInput') ? document.getElementById('searchInput').value.toLowerCase() : '';
    const cat = document.getElementById('categoryFilter') ? document.getElementById('categoryFilter').value : 'all';
    const filtered = products.filter(p => p.name.toLowerCase().includes(search) && (cat === 'all' || p.category === cat) && (badgeFilter === 'all' || p.badge === badgeFilter));
    grid.innerHTML = filtered.map(p => {
        const qty = cart.filter(c => c.code === p.code).reduce((s, c) => s + c.qty, 0);
        const outStock = p.stock <= 0;
        return `<div class="product-card">
            <div class="badge-container">${p.badge ? `<span class="badge-tag ${getBadgeClass(p.badge)}">${getBadgeLabel(p.badge)}</span>` : ''}${outStock ? '<span class="badge-tag badge-out"><i class="fas fa-ban"></i> Sin Stock</span>' : ''}</div>
            <img src="${p.image}" onclick="openImageViewer('${p.image}')" onerror="this.src='https://via.placeholder.com/300x300?text=AF'">
            <div class="product-code">#${p.code}</div>
            <div class="product-name">${p.name}</div>
            <div class="product-price">$${p.price.toLocaleString()}</div>
            ${qty > 0 ? `<span class="badge-tag" style="background:var(--mc-orange);color:#fff;">${qty} en carrito</span>` : ''}
            <button class="btn-add" onclick="addToCart('${p.code}')" ${outStock ? 'disabled' : ''}>${outStock ? 'Sin stock' : '<i class="fas fa-plus"></i> Agregar'}</button>
        </div>`;
    }).join('') || '<p style="color:#888;">No hay productos</p>';
}
function filterProducts() { displayProducts(); }

// ===== CART =====
function addToCart(code) {
    const p = products.find(x => x.code === code);
    if (!p || p.stock <= 0) { showToast('Sin stock', 'warning'); return; }
    const ex = cart.find(c => c.code === code);
    if (ex) ex.qty++; else cart.push({ code, name: p.name, price: p.price, qty: 1, image: p.image });
    p.stock--;
    saveCart();
    updateProductOnServer(p);
    updateCartBadge();
    displayCart();
    displayProducts();
    showToast('Agregado');
}
function removeFromCart(i) {
    const item = cart[i];
    const p = products.find(x => x.code === item.code);
    if (p) { p.stock += item.qty; updateProductOnServer(p); }
    cart.splice(i, 1);
    saveCart();
    updateCartBadge();
    displayCart();
    displayProducts();
}
function incQty(i) {
    const p = products.find(x => x.code === cart[i].code);
    if (!p || p.stock <= 0) { showToast('Stock insuficiente', 'warning'); return; }
    cart[i].qty++; p.stock--;
    saveCart(); updateProductOnServer(p); updateCartBadge(); displayCart();
}
function decQty(i) {
    const p = products.find(x => x.code === cart[i].code);
    if (cart[i].qty > 1) { cart[i].qty--; if (p) p.stock++; }
    else { if (p) p.stock += cart[i].qty; cart.splice(i, 1); }
    saveCart(); if (p) updateProductOnServer(p); updateCartBadge(); displayCart(); displayProducts();
}
function updateCartBadge() {
    const total = cart.reduce((s, c) => s + c.qty, 0);
    document.getElementById('floatingBadge').textContent = total;
    document.getElementById('menuCartBadge').textContent = total;
}
function displayCart() {
    const container = document.getElementById('cartItems');
    if (!container) return;
    if (!cart.length) { container.innerHTML = '<p style="text-align:center;color:#888;">Carrito vacío</p>'; document.getElementById('cartTotal').textContent = '$0'; return; }
    let subtotal = 0;
    container.innerHTML = cart.map((c, i) => {
        subtotal += c.price * c.qty;
        return `<div class="cart-item"><img src="${c.image}" class="cart-item-img" onerror="this.src='https://via.placeholder.com/40x40?text=AF'"><div class="cart-item-info"><strong style="font-size:.8rem;">${c.name}</strong><br><span style="font-size:.7rem;">$${c.price} c/u</span></div><button class="qty-btn" onclick="decQty(${i})"><i class="fas fa-minus"></i></button><span class="qty-display">${c.qty}</span><button class="qty-btn" onclick="incQty(${i})"><i class="fas fa-plus"></i></button><button class="btn-remove" onclick="removeFromCart(${i})"><i class="fas fa-trash"></i></button></div>`;
    }).join('');
    let total = subtotal;
    if (appliedCoupon) {
        const discount = appliedCoupon.type === 'percent' ? subtotal * (appliedCoupon.value / 100) : appliedCoupon.value;
        total = Math.max(0, subtotal - discount);
        document.getElementById('cartTotal').innerHTML = `<s style="opacity:.5;">$${subtotal}</s> <span style="color:var(--success);">$${total}</span>`;
    } else {
        document.getElementById('cartTotal').textContent = '$' + subtotal;
    }
}
function toggleCart() { document.getElementById('cartSheet').classList.toggle('open'); displayCart(); }
function applyCoupon() {
    const code = document.getElementById('couponInput').value.trim().toUpperCase();
    if (!code) { showToast('Ingresa código', 'warning'); return; }
    const coupon = coupons.find(c => c.code === code);
    if (!coupon) { showToast('Cupón inválido', 'warning'); return; }
    if (coupon.used >= coupon.limit) { showToast('Cupón agotado', 'warning'); return; }
    if (new Date(coupon.expiry) < new Date()) { showToast('Cupón expirado', 'warning'); return; }
    appliedCoupon = coupon;
    displayCart();
    showToast('Cupón aplicado');
}
function checkout() {
    if (!cart.length) { showToast('Carrito vacío', 'warning'); return; }
    let subtotal = cart.reduce((s, c) => s + c.price * c.qty, 0);
    let total = subtotal;
    let couponMsg = '';
    if (appliedCoupon) {
        const discount = appliedCoupon.type === 'percent' ? subtotal * (appliedCoupon.value / 100) : appliedCoupon.value;
        total = Math.max(0, subtotal - discount);
        couponMsg = appliedCoupon.code;
        appliedCoupon.used++;
        updateCouponOnServer(appliedCoupon);
    }
    let msg = 'PEDIDO AF MODAS%0A%0A';
    cart.forEach(c => { msg += c.name + ' x' + c.qty + ' = $' + c.price * c.qty + '%0A'; });
    msg += '%0ATOTAL: $' + total;
    if (couponMsg) msg += '%0ACupón: ' + couponMsg;
    window.open('https://wa.me/' + WHATSAPP_NUMBER + '?text=' + msg, '_blank');
    appliedCoupon = null;
    document.getElementById('couponInput').value = '';
}

// ===== IMAGE VIEWER =====
function openImageViewer(url) { document.getElementById('viewerImg').src = url; document.getElementById('imageViewer').classList.add('open'); }
function closeImageViewer() { document.getElementById('imageViewer').classList.remove('open'); }

// ===== STORIES =====
function getActiveStories() { return notifications.filter(n => (Date.now() - n.createdAt) < 86400000); }
function updateStoryRing() { const active = getActiveStories(); document.getElementById('storyRing').classList.toggle('has-stories', active.length > 0); }
function openStoryViewer() {
    const active = getActiveStories();
    if (!active.length) { showToast('No hay historias'); return; }
    storyIndex = 0;
    document.getElementById('storyViewer').classList.add('open');
    showStory(0);
}
function showStory(i) {
    const active = getActiveStories();
    if (i < 0) i = active.length - 1;
    if (i >= active.length) i = 0;
    storyIndex = i;
    const s = active[i];
    document.getElementById('storyProgress').innerHTML = active.map((_, j) => `<span class="${j === i ? 'active' : ''}"></span>`).join('');
    const icon = s.type === 'Alerta' ? 'fa-exclamation-triangle' : s.type === 'Información' ? 'fa-info-circle' : 'fa-percent';
    const color = s.type === 'Alerta' ? '#e76f51' : s.type === 'Información' ? '#2a9d8f' : '#e9c46a';
    document.getElementById('storyBody').innerHTML = `${s.image ? `<img src="${s.image}">` : ''}<div style="font-size:2.5rem;color:${color};"><i class="fas ${icon}"></i></div><h3>${s.title}</h3><p>${s.message}</p>`;
    if (storyTimer) clearInterval(storyTimer);
    let sec = 0;
    storyTimer = setInterval(() => { sec++; if (sec >= 30) { clearInterval(storyTimer); nextStory(); } }, 1000);
}
function nextStory() { const active = getActiveStories(); if (storyIndex < active.length - 1) showStory(storyIndex + 1); else closeStoryViewer(); }
function prevStory() { if (storyIndex > 0) showStory(storyIndex - 1); }
function closeStoryViewer() { document.getElementById('storyViewer').classList.remove('open'); if (storyTimer) clearInterval(storyTimer); }

// ===== PARTICLES =====
function createParticles() {
    const c = document.getElementById('particles');
    if (!c) return;
    const colors = ['#e76f51','#2a9d8f','#e9c46a','#8ab17d','#b35f9e'];
    for (let i = 0; i < 15; i++) {
        const p = document.createElement('div');
        p.className = 'particle';
        p.style.width = p.style.height = (Math.random() * 8 + 3) + 'px';
        p.style.background = colors[Math.floor(Math.random() * colors.length)];
        p.style.left = Math.random() * 100 + '%';
        p.style.top = Math.random() * 100 + '%';
        p.style.animationDuration = (Math.random() * 15 + 10) + 's';
        c.appendChild(p);
    }
}

// ===== LOTTIE =====
function initLottie() {
    if (typeof lottie === 'undefined') return;
    const animations = [
        { id: 'lottieQuality', path: 'https://assets4.lottiefiles.com/packages/lf20_yrncp8jg.json' },
        { id: 'lottieShip', path: 'https://assets8.lottiefiles.com/packages/lf20_kkxfpo5r.json' },
        { id: 'lottieSupport', path: 'https://assets1.lottiefiles.com/packages/lf20_2b4y8a0i.json' },
        { id: 'lottieTrend', path: 'https://assets4.lottiefiles.com/packages/lf20_xg9of6lq.json' }
    ];
    animations.forEach(anim => {
        const el = document.getElementById(anim.id);
        if (el) { try { lottie.loadAnimation({ container: el, path: anim.path, loop: true, autoplay: true }); } catch(e) {} }
    });
}

// ===== INIT =====
async function init() {
    loadCart();
    await fetchProducts();
    await fetchCoupons();
    await fetchNotifications();
    displayProducts();
    displayCart();
    updateCartBadge();
    updateStoryRing();
    createParticles();
    try { if (localStorage.getItem('af_theme') === 'dark') document.body.classList.add('dark'); } catch(e) {}
    initLottie();
    setInterval(updateStoryRing, 60000);
}
if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init);
else init();