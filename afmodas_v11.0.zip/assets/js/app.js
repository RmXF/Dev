// ============================================
// AF MODAS - APLICACIÓN PRINCIPAL
// VERSION: COLOR + TALLES
// ============================================

const API_BASE = window.location.origin + '/api';
const WHATSAPP_NUMBER = '573001234567';

// ===== VARIABLES GLOBALES =====
let products = [];
let cart = [];
let notifications = [];
let coupons = [];
let appliedCoupon = null;
let badgeFilter = 'all';
let storyIndex = 0;
let storyTimer = null;


// ============================================
// API CALLS
// ============================================

async function fetchProducts() {
    try {
        const response =
            await fetch(API_BASE + '/products.php');

        if (!response.ok) {
            throw new Error('Error al cargar productos');
        }

        const data = await response.json();

        products = Array.isArray(data)
            ? data.map(normalizeProduct)
            : [];

    } catch (error) {
        console.error(
            'Error cargando productos:',
            error
        );

        products = [];
    }
}


async function fetchCoupons() {
    try {
        const response =
            await fetch(API_BASE + '/coupons.php');

        if (!response.ok) {
            throw new Error('Error al cargar cupones');
        }

        const data = await response.json();

        coupons =
            Array.isArray(data)
                ? data
                : [];

    } catch (error) {

        console.error(
            'Error cargando cupones:',
            error
        );

        coupons = [];
    }
}


async function fetchNotifications() {
    try {

        const response =
            await fetch(
                API_BASE +
                '/notifications.php'
            );

        if (!response.ok) {
            throw new Error(
                'Error al cargar notificaciones'
            );
        }

        const data =
            await response.json();

        notifications =
            Array.isArray(data)
                ? data
                : [];

    } catch (error) {

        console.error(
            'Error cargando notificaciones:',
            error
        );

        notifications = [];
    }
}


async function saveProductToServer(product) {

    try {

        await fetch(
            API_BASE + '/products.php',
            {
                method: 'POST',

                headers: {
                    'Content-Type':
                        'application/json'
                },

                body:
                    JSON.stringify(
                        product
                    )
            }
        );

    } catch (error) {

        console.error(
            'Error guardando producto:',
            error
        );

    }

}


async function updateProductOnServer(product) {

    try {

        await fetch(
            API_BASE + '/products.php',
            {
                method: 'PUT',

                headers: {
                    'Content-Type':
                        'application/json'
                },

                body:
                    JSON.stringify(
                        product
                    )
            }
        );

    } catch (error) {

        console.error(
            'Error actualizando producto:',
            error
        );

    }

}


async function updateCouponOnServer(coupon) {

    try {

        await fetch(
            API_BASE + '/coupons.php',
            {
                method: 'PUT',

                headers: {
                    'Content-Type':
                        'application/json'
                },

                body:
                    JSON.stringify(
                        coupon
                    )
            }
        );

    } catch (error) {

        console.error(
            'Error actualizando cupón:',
            error
        );

    }

}


// ============================================
// NORMALIZACIÓN DE PRODUCTOS
// ============================================

function normalizeProduct(product) {

    if (!product || typeof product !== 'object') {
        return {};
    }


    // ------------------------------
    // Talles
    // ------------------------------

    let sizes = [];

    const rawSizes =
        product.sizes ??
        product.talles ??
        product.tallesDisponibles ??
        '';


    if (Array.isArray(rawSizes)) {

        sizes =
            rawSizes
                .map(
                    size =>
                        String(size).trim()
                )
                .filter(Boolean);

    } else if (typeof rawSizes === 'string') {

        const trimmed =
            rawSizes.trim();

        if (trimmed) {

            // JSON string tipo '["S","M","L"]'
            if (
                trimmed.length > 1 &&
                trimmed.charAt(0) === '[' &&
                trimmed.charAt(trimmed.length - 1) === ']'
            ) {

                try {

                    const parsed =
                        JSON.parse(trimmed);

                    if (Array.isArray(parsed)) {

                        sizes =
                            parsed
                                .map(
                                    size =>
                                        String(size).trim()
                                )
                                .filter(Boolean);

                    }

                } catch (error) {

                    // fallback a split por coma
                    sizes =
                        trimmed
                            .split(',')
                            .map(
                                size =>
                                    size.trim()
                            )
                            .filter(Boolean);

                }

            } else {

                sizes =
                    trimmed
                        .split(',')
                        .map(
                            size =>
                                size.trim()
                        )
                        .filter(Boolean);

            }

        }

    }


    // ------------------------------
    // Color
    // ------------------------------

    let color = '';

    if (
        product.color !== undefined &&
        product.color !== null
    ) {

        color =
            String(
                product.color
            ).trim();

    } else if (
        product.colour !== undefined &&
        product.colour !== null
    ) {

        color =
            String(
                product.colour
            ).trim();

    }


    return {

        ...product,

        code:
            product.code !== undefined
                ? String(product.code)
                : '',

        name:
            product.name || '',

        color,

        sizes,

        price:
            Number(product.price) || 0,

        stock:
            Number(product.stock) || 0,

        category:
            product.category || '',

        gender:
            product.gender || 'unisex',

        image:
            product.image || '',

        badge:
            product.badge || ''

    };

}


// ============================================
// STORAGE LOCAL
// ============================================

function loadCart() {

    try {

        const data =
            localStorage.getItem(
                'af_cart'
            );

        cart =
            data
                ? JSON.parse(data)
                : [];

        if (!Array.isArray(cart)) {
            cart = [];
        }

    } catch (error) {

        console.error(
            'Error cargando carrito:',
            error
        );

        cart = [];
    }

}


function saveCart() {

    try {

        localStorage.setItem(
            'af_cart',
            JSON.stringify(cart)
        );

    } catch (error) {

        console.error(
            'Error guardando carrito:',
            error
        );

    }

    updateCartBadge();

}


// ============================================
// UTILIDADES
// ============================================

function escapeHtml(value) {

    if (
        value === null ||
        value === undefined
    ) {
        return '';
    }

    return String(value)
        .replace(
            /&/g,
            '&amp;'
        )
        .replace(
            /</g,
            '&lt;'
        )
        .replace(
            />/g,
            '&gt;'
        )
        .replace(
            /"/g,
            '&quot;'
        )
        .replace(
            /'/g,
            '&#039;'
        );

}


function escapeAttribute(value) {
    return escapeHtml(value);
}


function showToast(
    msg,
    type
) {

    const t =
        document.createElement(
            'div'
        );

    t.className =
        'toast' +
        (
            type === 'warning'
                ? ' toast-warning'
                : ''
        );

    t.textContent = msg;

    document.body.appendChild(t);

    setTimeout(
        () => {

            if (
                t &&
                t.parentNode
            ) {
                t.remove();
            }

        },
        3000
    );

}


function toggleTheme() {

    document.body.classList.toggle(
        'dark'
    );

    try {

        localStorage.setItem(
            'af_theme',

            document.body.classList.contains(
                'dark'
            )
                ? 'dark'
                : 'light'
        );

    } catch (error) {}

}


function toggleSlideMenu() {

    const menu =
        document.getElementById(
            'slideMenu'
        );

    if (menu) {
        menu.classList.toggle(
            'open'
        );
    }

}


function getBadgeLabel(badge) {

    const labels = {

        new:
            'Nuevo',

        offer:
            'Oferta',

        featured:
            'Destacado',

        low:
            'Últimas'

    };

    return (
        labels[badge] ||
        ''
    );

}


function getBadgeClass(badge) {

    return 'badge-' + badge;

}


function closeModal(id) {

    const modal =
        document.getElementById(id);

    if (modal) {
        modal.classList.remove(
            'open'
        );
    }

}


// ============================================
// NAV
// ============================================

function showTab(tab) {

    const homeTab =
        document.getElementById(
            'homeTab'
        );

    const catalogTab =
        document.getElementById(
            'catalogTab'
        );

    const hero =
        document.getElementById(
            'hero'
        );


    if (homeTab) {

        homeTab.classList.toggle(
            'active',
            tab === 'home'
        );

    }


    if (catalogTab) {

        catalogTab.classList.toggle(
            'active',
            tab === 'catalog'
        );

    }


    if (hero) {

        hero.style.display =
            tab === 'catalog'
                ? 'none'
                : 'block';

    }


    if (tab === 'catalog') {
        displayProducts();
    }

}


// ============================================
// CATALOG
// ============================================

function setBadgeFilter(filter) {

    badgeFilter = filter;


    document
        .querySelectorAll(
            '.badge-chip'
        )
        .forEach(
            chip =>
                chip.classList.remove(
                    'active'
                )
        );


    if (
        typeof event !== 'undefined' &&
        event &&
        event.target
    ) {

        event.target.classList.add(
            'active'
        );

    }


    displayProducts();

}


// ============================================
// NORMALIZACIÓN DE TALLES (HELPER)
// ============================================

function normalizeProductSizes(value) {

    if (Array.isArray(value)) {
        return value
            .map(size => String(size).trim())
            .filter(Boolean);
    }

    if (typeof value === 'string') {

        const trimmed = value.trim();

        if (!trimmed) {
            return [];
        }

        // JSON string tipo '["S","M","L"]'
        if (
            trimmed.length > 1 &&
            trimmed.charAt(0) === '[' &&
            trimmed.charAt(trimmed.length - 1) === ']'
        ) {

            try {

                const parsed = JSON.parse(trimmed);

                if (Array.isArray(parsed)) {
                    return parsed
                        .map(size => String(size).trim())
                        .filter(Boolean);
                }

            } catch (error) {
                // fallback a split por coma
            }

        }

        return trimmed
            .split(',')
            .map(size => size.trim())
            .filter(Boolean);
    }

    return [];

}


// ============================================
// HTML DE TALLES
// ============================================

function productSizesHtml(value) {

    const sizes =
        normalizeProductSizes(
            value
        );


    if (!sizes.length) {
        return '';
    }


    return `

        <div class="product-meta product-sizes">

            <span class="meta-label">

                <i
                    class="fas fa-ruler-combined"
                ></i>

                Talles disponibles

            </span>


            <div class="size-list">

                ${sizes
                    .map(
                        size =>
                            `
                            <span
                                class="size-chip"
                            >
                                ${escapeHtml(
                                    size
                                )}
                            </span>
                            `
                    )
                    .join('')}

            </div>

        </div>

    `;

}


// ============================================
// HTML DE COLOR
// ============================================

function productColorHtml(color) {

    if (
        color === null ||
        color === undefined
    ) {
        return '';
    }


    const normalizedColor =
        String(color).trim();


    if (!normalizedColor) {
        return '';
    }


    return `

        <div class="product-meta product-color">

            <span class="meta-label">

                <i
                    class="fas fa-palette"
                ></i>

                Color

            </span>


            <span
                class="color-value"
            >
                ${escapeHtml(
                    normalizedColor
                )}
            </span>

        </div>

    `;

}


// ============================================
// CATALOGO
// ============================================

function displayProducts() {

    const grid =
        document.getElementById(
            'productGrid'
        );


    if (!grid) {
        return;
    }


    const searchElement =
        document.getElementById(
            'searchInput'
        );


    const categoryElement =
        document.getElementById(
            'categoryFilter'
        );


    const search =
        searchElement
            ? String(
                searchElement.value || ''
              ).toLowerCase().trim()
            : '';


    const category =
        categoryElement
            ? categoryElement.value
            : 'all';


    const filtered =
        products.filter(
            product => {

                const name =
                    String(
                        product.name || ''
                    ).toLowerCase();


                const code =
                    String(
                        product.code || ''
                    ).toLowerCase();


                const color =
                    String(
                        product.color || ''
                    ).toLowerCase();


                const sizes =
                    normalizeProductSizes(
                        product.sizes
                    )
                    .join(' ')
                    .toLowerCase();


                const matchesSearch =
                    !search ||
                    name.includes(search) ||
                    code.includes(search) ||
                    color.includes(search) ||
                    sizes.includes(search);


                const matchesCategory =
                    category === 'all' ||
                    product.category === category;


                const matchesBadge =
                    badgeFilter === 'all' ||
                    product.badge === badgeFilter;


                return (
                    matchesSearch &&
                    matchesCategory &&
                    matchesBadge
                );

            }
        );


    grid.innerHTML =
        filtered
            .map(
                product =>
                    renderProductCard(
                        product
                    )
            )
            .join('');


    if (!filtered.length) {

        grid.innerHTML =
            `
                <p
                    style="
                        color:#888;
                        grid-column:1/-1;
                        text-align:center;
                        padding:2rem;
                    "
                >
                    No hay productos
                </p>
            `;

    }

}


// ============================================
// TARJETA DE PRODUCTO
// ============================================

function renderProductCard(product) {

    const code =
        String(
            product.code || ''
        );


    const qty =
        cart
            .filter(
                item =>
                    String(item.code) ===
                    code
            )
            .reduce(
                (sum, item) =>
                    sum +
                    Number(item.qty || 0),
                0
            );


    const stock =
        Number(
            product.stock || 0
        );


    const outStock =
        stock <= 0;


    const image =
        escapeAttribute(
            product.image || ''
        );


    const name =
        escapeHtml(
            product.name || ''
        );


    const safeCode =
        escapeAttribute(
            code
        );


    const price =
        Number(
            product.price || 0
        ).toLocaleString();


    return `

        <div
            class="product-card"
            data-product-code="${safeCode}"
        >

            <div
                class="badge-container"
            >

                ${
                    product.badge
                        ? `
                            <span
                                class="
                                    badge-tag
                                    ${getBadgeClass(
                                        product.badge
                                    )}
                                "
                            >
                                ${getBadgeLabel(
                                    product.badge
                                )}
                            </span>
                        `
                        : ''
                }


                ${
                    outStock
                        ? `
                            <span
                                class="
                                    badge-tag
                                    badge-out
                                "
                            >
                                <i
                                    class="
                                        fas
                                        fa-ban
                                    "
                                ></i>

                                Sin Stock

                            </span>
                        `
                        : ''
                }

            </div>


            <img
                src="${image}"
                alt="${name}"
                onclick="openImageViewer('${image}')"
                onerror="
                    this.src='https://via.placeholder.com/300x300?text=AF'
                "
            >


            <div
                class="product-code"
            >
                #${escapeHtml(code)}
            </div>


            <div
                class="product-name"
            >
                ${name}
            </div>


            ${productColorHtml(
                product.color
            )}


            ${productSizesHtml(
                product.sizes
            )}


            <div
                class="product-price"
            >
                $${price}
            </div>


            ${
                qty > 0
                    ? `
                        <span
                            class="badge-tag"
                            style="
                                background:
                                var(--mc-orange);
                                color:#fff;
                            "
                        >
                            ${qty}
                            en carrito
                        </span>
                    `
                    : ''
            }


            <button
                class="btn-add"
                onclick="
                    addToCart('${safeCode}')
                "
                ${
                    outStock
                        ? 'disabled'
                        : ''
                }
            >

                ${
                    outStock
                        ? 'Sin stock'
                        : `
                            <i
                                class="
                                    fas
                                    fa-plus
                                "
                            ></i>

                            Agregar
                        `
                }

            </button>

        </div>

    `;

}


function filterProducts() {
    displayProducts();
}


// ============================================
// CART
// ============================================

function addToCart(code) {

    const normalizedCode =
        String(code);


    const product =
        products.find(
            item =>
                String(item.code) ===
                normalizedCode
        );


    if (
        !product ||
        Number(product.stock) <= 0
    ) {

        showToast(
            'Sin stock',
            'warning'
        );

        return;
    }


    const existing =
        cart.find(
            item =>
                String(item.code) ===
                normalizedCode
        );


    if (existing) {

        existing.qty++;

    } else {

        cart.push({

            code:
                normalizedCode,

            name:
                product.name,

            price:
                product.price,

            qty:
                1,

            image:
                product.image,

            // NUEVO
            color:
                product.color || '',

            // NUEVO
            sizes:
                normalizeProductSizes(
                    product.sizes
                )

        });

    }


    product.stock--;


    saveCart();

    updateProductOnServer(
        product
    );

    updateCartBadge();

    displayCart();

    displayProducts();

    showToast(
        'Agregado'
    );

}


// ============================================
// ELIMINAR DEL CARRITO
// ============================================

function removeFromCart(index) {

    const item =
        cart[index];


    if (!item) {
        return;
    }


    const product =
        products.find(
            product =>
                String(product.code) ===
                String(item.code)
        );


    if (product) {

        product.stock +=
            Number(
                item.qty || 0
            );


        updateProductOnServer(
            product
        );

    }


    cart.splice(
        index,
        1
    );


    saveCart();

    updateCartBadge();

    displayCart();

    displayProducts();

}


// ============================================
// AUMENTAR CANTIDAD
// ============================================

function incQty(index) {

    const item =
        cart[index];


    if (!item) {
        return;
    }


    const product =
        products.find(
            product =>
                String(product.code) ===
                String(item.code)
        );


    if (
        !product ||
        Number(product.stock) <= 0
    ) {

        showToast(
            'Stock insuficiente',
            'warning'
        );

        return;
    }


    item.qty++;

    product.stock--;


    saveCart();

    updateProductOnServer(
        product
    );

    updateCartBadge();

    displayCart();

    displayProducts();

}


// ============================================
// DISMINUIR CANTIDAD
// ============================================

function decQty(index) {

    const item =
        cart[index];


    if (!item) {
        return;
    }


    const product =
        products.find(
            product =>
                String(product.code) ===
                String(item.code)
        );


    if (
        Number(item.qty) > 1
    ) {

        item.qty--;


        if (product) {

            product.stock++;

            updateProductOnServer(
                product
            );

        }

    } else {

        if (product) {

            product.stock +=
                Number(
                    item.qty || 0
                );

            updateProductOnServer(
                product
            );

        }


        cart.splice(
            index,
            1
        );

    }


    saveCart();

    updateCartBadge();

    displayCart();

    displayProducts();

}


// ============================================
// BADGE DEL CARRITO
// ============================================

function updateCartBadge() {

    const total =
        cart.reduce(
            (sum, item) =>
                sum +
                Number(
                    item.qty || 0
                ),
            0
        );


    const floatingBadge =
        document.getElementById(
            'floatingBadge'
        );


    const menuCartBadge =
        document.getElementById(
            'menuCartBadge'
        );


    if (floatingBadge) {

        floatingBadge.textContent =
            total;

    }


    if (menuCartBadge) {

        menuCartBadge.textContent =
            total;

    }

}


// ============================================
// MOSTRAR CARRITO
// ============================================

function displayCart() {

    const container =
        document.getElementById(
            'cartItems'
        );


    if (!container) {
        return;
    }


    if (!cart.length) {

        container.innerHTML =
            `
                <p
                    style="
                        text-align:center;
                        color:#888;
                    "
                >
                    Carrito vacío
                </p>
            `;


        const totalElement =
            document.getElementById(
                'cartTotal'
            );


        if (totalElement) {
            totalElement.textContent =
                '$0';
        }


        return;
    }


    let subtotal = 0;


    container.innerHTML =
        cart
            .map(
                (item, index) => {

                    const price =
                        Number(
                            item.price || 0
                        );


                    const quantity =
                        Number(
                            item.qty || 0
                        );


                    subtotal +=
                        price *
                        quantity;


                    const color =
                        item.color || '';


                    const sizes =
                        normalizeProductSizes(
                            item.sizes
                        );


                    return `

                        <div
                            class="cart-item"
                        >

                            <img
                                src="${escapeAttribute(
                                    item.image || ''
                                )}"
                                class="
                                    cart-item-img
                                "
                                onerror="
                                    this.src='https://via.placeholder.com/40x40?text=AF'
                                "
                            >


                            <div
                                class="cart-item-info"
                            >

                                <strong
                                    style="
                                        font-size:.8rem;
                                    "
                                >
                                    ${escapeHtml(
                                        item.name || ''
                                    )}
                                </strong>


                                ${
                                    color
                                        ? `
                                            <div
                                                style="
                                                    font-size:.68rem;
                                                    color:var(--text-secondary);
                                                    margin-top:3px;
                                                "
                                            >
                                                <i
                                                    class="
                                                        fas
                                                        fa-palette
                                                    "
                                                ></i>

                                                ${escapeHtml(
                                                    color
                                                )}
                                            </div>
                                        `
                                        : ''
                                }


                                ${
                                    sizes.length
                                        ? `
                                            <div
                                                style="
                                                    font-size:.68rem;
                                                    color:var(--text-secondary);
                                                    margin-top:3px;
                                                "
                                            >
                                                <i
                                                    class="
                                                        fas
                                                        fa-ruler-combined
                                                    "
                                                ></i>

                                                Talles:
                                                ${escapeHtml(
                                                    sizes.join(
                                                        ', '
                                                    )
                                                )}
                                            </div>
                                        `
                                        : ''
                                }


                                <span
                                    style="
                                        font-size:.7rem;
                                    "
                                >
                                    $${price.toLocaleString()}
                                    c/u
                                </span>

                            </div>


                            <button
                                class="qty-btn"
                                onclick="
                                    decQty(${index})
                                "
                            >
                                <i
                                    class="
                                        fas
                                        fa-minus
                                    "
                                ></i>
                            </button>


                            <span
                                class="qty-display"
                            >
                                ${quantity}
                            </span>


                            <button
                                class="qty-btn"
                                onclick="
                                    incQty(${index})
                                "
                            >
                                <i
                                    class="
                                        fas
                                        fa-plus
                                    "
                                ></i>
                            </button>


                            <button
                                class="btn-remove"
                                onclick="
                                    removeFromCart(${index})
                                "
                            >
                                <i
                                    class="
                                        fas
                                        fa-trash
                                    "
                                ></i>
                            </button>

                        </div>

                    `;

                }
            )
            .join('');


    let total =
        subtotal;


    if (appliedCoupon) {

        const discount =
            appliedCoupon.type === 'percent'
                ? subtotal *
                    (
                        Number(
                            appliedCoupon.value
                        ) / 100
                    )
                : Number(
                    appliedCoupon.value
                );


        total =
            Math.max(
                0,
                subtotal -
                discount
            );


        const totalElement =
            document.getElementById(
                'cartTotal'
            );


        if (totalElement) {

            totalElement.innerHTML =
                `
                    <s
                        style="
                            opacity:.5;
                        "
                    >
                        $${subtotal.toLocaleString()}
                    </s>

                    <span
                        style="
                            color:var(--success);
                        "
                    >
                        $${total.toLocaleString()}
                    </span>
                `;

        }

    } else {

        const totalElement =
            document.getElementById(
                'cartTotal'
            );


        if (totalElement) {

            totalElement.textContent =
                '$' +
                subtotal.toLocaleString();

        }

    }

}


// ============================================
// ABRIR / CERRAR CARRITO
// ============================================

function toggleCart() {

    const cartSheet =
        document.getElementById(
            'cartSheet'
        );


    if (cartSheet) {

        cartSheet.classList.toggle(
            'open'
        );

    }


    displayCart();

}


// ============================================
// CUPÓN
// ============================================

function applyCoupon() {

    const input =
        document.getElementById(
            'couponInput'
        );


    const code =
        input
            ? input.value.trim().toUpperCase()
            : '';


    if (!code) {

        showToast(
            'Ingresa código',
            'warning'
        );

        return;
    }


    const coupon =
        coupons.find(
            item =>
                String(
                    item.code || ''
                ).toUpperCase() ===
                code
        );


    if (!coupon) {

        showToast(
            'Cupón inválido',
            'warning'
        );

        return;
    }


    if (
        Number(coupon.used || 0) >=
        Number(coupon.limit || 0)
    ) {

        showToast(
            'Cupón agotado',
            'warning'
        );

        return;
    }


    if (
        coupon.expiry &&
        new Date(
            coupon.expiry
        ) < new Date()
    ) {

        showToast(
            'Cupón expirado',
            'warning'
        );

        return;
    }


    appliedCoupon =
        coupon;


    displayCart();


    showToast(
        'Cupón aplicado'
    );

}


// ============================================
// CHECKOUT
// ============================================

function checkout() {

    if (!cart.length) {

        showToast(
            'Carrito vacío',
            'warning'
        );

        return;
    }


    let subtotal =
        cart.reduce(
            (sum, item) =>
                sum +
                Number(
                    item.price || 0
                ) *
                Number(
                    item.qty || 0
                ),
            0
        );


    let total =
        subtotal;


    let couponMsg =
        '';


    if (appliedCoupon) {

        const discount =
            appliedCoupon.type === 'percent'
                ? subtotal *
                    (
                        Number(
                            appliedCoupon.value
                        ) / 100
                    )
                : Number(
                    appliedCoupon.value
                );


        total =
            Math.max(
                0,
                subtotal -
                discount
            );


        couponMsg =
            appliedCoupon.code;


        appliedCoupon.used =
            Number(
                appliedCoupon.used || 0
            ) + 1;


        updateCouponOnServer(
            appliedCoupon
        );

    }


    let message =
        'PEDIDO AF MODAS\n\n';


    cart.forEach(
        item => {

            message +=
                item.name +
                ' x' +
                item.qty;


            if (item.color) {

                message +=
                    ' | Color: ' +
                    item.color;

            }


            const sizes =
                normalizeProductSizes(
                    item.sizes
                );


            if (sizes.length) {

                message +=
                    ' | Talles: ' +
                    sizes.join(', ');

            }


            message +=
                ' = $' +
                (
                    Number(
                        item.price || 0
                    ) *
                    Number(
                        item.qty || 0
                    )
                ).toLocaleString() +
                '\n';

        }
    );


    message +=
        '\nTOTAL: $' +
        total.toLocaleString();


    if (couponMsg) {

        message +=
            '\nCupón: ' +
            couponMsg;

    }


    const encodedMessage =
        encodeURIComponent(
            message
        );


    window.open(
        'https://wa.me/' +
        WHATSAPP_NUMBER +
        '?text=' +
        encodedMessage,
        '_blank'
    );


    appliedCoupon =
        null;


    const couponInput =
        document.getElementById(
            'couponInput'
        );


    if (couponInput) {
        couponInput.value = '';
    }

}


// ============================================
// IMAGE VIEWER
// ============================================

function openImageViewer(url) {

    const viewerImg =
        document.getElementById(
            'viewerImg'
        );


    const viewer =
        document.getElementById(
            'imageViewer'
        );


    if (viewerImg) {

        viewerImg.src =
            url;

    }


    if (viewer) {

        viewer.classList.add(
            'open'
        );

    }

}


function closeImageViewer() {

    const viewer =
        document.getElementById(
            'imageViewer'
        );


    if (viewer) {

        viewer.classList.remove(
            'open'
        );

    }

}


// ============================================
// STORIES
// ============================================

function getActiveStories() {

    return notifications.filter(
        notification => {

            const createdAt =
                Number(
                    notification.createdAt ||
                    notification.created_at ||
                    0
                );


            if (!createdAt) {
                return false;
            }


            return (
                Date.now() -
                createdAt
            ) <
            86400000;

        }
    );

}


function updateStoryRing() {

    const active =
        getActiveStories();


    const ring =
        document.getElementById(
            'storyRing'
        );


    if (ring) {

        ring.classList.toggle(
            'has-stories',
            active.length > 0
        );

    }

}


function openStoryViewer() {

    const active =
        getActiveStories();


    if (!active.length) {

        showToast(
            'No hay historias'
        );

        return;
    }


    storyIndex =
        0;


    const viewer =
        document.getElementById(
            'storyViewer'
        );


    if (viewer) {

        viewer.classList.add(
            'open'
        );

    }


    showStory(
        0
    );

}


function showStory(index) {

    const active =
        getActiveStories();


    if (!active.length) {
        return;
    }


    if (index < 0) {

        index =
            active.length - 1;

    }


    if (
        index >=
        active.length
    ) {

        index =
            0;

    }


    storyIndex =
        index;


    const story =
        active[index];


    const progress =
        document.getElementById(
            'storyProgress'
        );


    if (progress) {

        progress.innerHTML =
            active
                .map(
                    (_, currentIndex) =>
                        `
                            <span
                                class="
                                    ${
                                        currentIndex ===
                                        index
                                            ? 'active'
                                            : ''
                                    }
                                "
                            ></span>
                        `
                )
                .join('');

    }


    const icon =
        story.type === 'Alerta'
            ? 'fa-exclamation-triangle'
            : story.type === 'Información'
                ? 'fa-info-circle'
                : 'fa-percent';


    const color =
        story.type === 'Alerta'
            ? '#e76f51'
            : story.type === 'Información'
                ? '#2a9d8f'
                : '#e9c46a';


    const body =
        document.getElementById(
            'storyBody'
        );


    if (body) {

        body.innerHTML = `

            ${
                story.image
                    ? `
                        <img
                            src="${escapeAttribute(
                                story.image
                            )}"
                            alt=""
                        >
                    `
                    : ''
            }


            <div
                style="
                    font-size:2.5rem;
                    color:${color};
                "
            >
                <i
                    class="
                        fas
                        ${icon}
                    "
                ></i>
            </div>


            <h3>
                ${escapeHtml(
                    story.title || ''
                )}
            </h3>


            <p>
                ${escapeHtml(
                    story.message || ''
                )}
            </p>

        `;

    }


    if (storyTimer) {

        clearInterval(
            storyTimer
        );

    }


    let seconds =
        0;


    storyTimer =
        setInterval(
            () => {

                seconds++;


                if (
                    seconds >= 30
                ) {

                    clearInterval(
                        storyTimer
                    );


                    nextStory();

                }

            },
            1000
        );

}


function nextStory() {

    const active =
        getActiveStories();


    if (
        storyIndex <
        active.length - 1
    ) {

        showStory(
            storyIndex + 1
        );

    } else {

        closeStoryViewer();

    }

}


function prevStory() {

    if (
        storyIndex >
        0
    ) {

        showStory(
            storyIndex - 1
        );

    }

}


function closeStoryViewer() {

    const viewer =
        document.getElementById(
            'storyViewer'
        );


    if (viewer) {

        viewer.classList.remove(
            'open'
        );

    }


    if (storyTimer) {

        clearInterval(
            storyTimer
        );

        storyTimer =
            null;

    }

}


// ============================================
// PARTICLES
// ============================================

function createParticles() {

    const container =
        document.getElementById(
            'particles'
        );


    if (!container) {
        return;
    }


    // Evita duplicados
    container.innerHTML =
        '';


    const colors = [

        '#e76f51',
        '#2a9d8f',
        '#e9c46a',
        '#8ab17d',
        '#b35f9e'

    ];


    for (
        let index = 0;
        index < 15;
        index++
    ) {

        const particle =
            document.createElement(
                'div'
            );


        particle.className =
            'particle';


        const size =
            Math.random() *
            8 +
            3;


        particle.style.width =
            size +
            'px';


        particle.style.height =
            size +
            'px';


        particle.style.background =
            colors[
                Math.floor(
                    Math.random() *
                    colors.length
                )
            ];


        particle.style.left =
            Math.random() *
            100 +
            '%';


        particle.style.top =
            Math.random() *
            100 +
            '%';


        particle.style.animationDuration =
            Math.random() *
            15 +
            10 +
            's';


        container.appendChild(
            particle
        );

    }

}


// ============================================
// LOTTIE
// ============================================

function initLottie() {

    if (
        typeof lottie ===
        'undefined'
    ) {
        return;
    }


    const animations = [

        {
            id:
                'lottieQuality',

            path:
                'https://assets4.lottiefiles.com/packages/lf20_yrncp8jg.json'
        },

        {
            id:
                'lottieShip',

            path:
                'https://assets8.lottiefiles.com/packages/lf20_kkxfpo5r.json'
        },

        {
            id:
                'lottieSupport',

            path:
                'https://assets1.lottiefiles.com/packages/lf20_2b4y8a0i.json'
        },

        {
            id:
                'lottieTrend',

            path:
                'https://assets4.lottiefiles.com/packages/lf20_xg9of6lq.json'
        }

    ];


    animations.forEach(
        animation => {

            const element =
                document.getElementById(
                    animation.id
                );


            if (!element) {
                return;
            }


            try {

                lottie.loadAnimation({

                    container:
                        element,

                    path:
                        animation.path,

                    loop:
                        true,

                    autoplay:
                        true

                });

            } catch (error) {

                console.error(
                    'Error Lottie:',
                    error
                );

            }

        }
    );

}


// ============================================
// INIT
// ============================================

async function init() {

    loadCart();


    await fetchProducts();


    await fetchCoupons();


    await fetchNotifications();


    displayProducts();


    displayCart();


    updateCartBadge();


    updateStoryRing();


    createParticles();


    try {

        if (
            localStorage.getItem(
                'af_theme'
            ) ===
            'dark'
        ) {

            document.body.classList.add(
                'dark'
            );

        }

    } catch (error) {}


    initLottie();


    setInterval(
        updateStoryRing,
        60000
    );

}


// ============================================
// DOM READY
// ============================================

if (
    document.readyState ===
    'loading'
) {

    document.addEventListener(
        'DOMContentLoaded',
        init
    );

} else {

    init();

}