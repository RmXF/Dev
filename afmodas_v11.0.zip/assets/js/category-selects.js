/* AF MODAS · Sincroniza los selectores públicos y del panel con categorías.php. */
(() => {
  'use strict';
  let initiallySavedCategory = '';
  try { initiallySavedCategory = JSON.parse(localStorage.getItem('af_catalog_state') || '{}').category || ''; } catch (_) {}
  async function load() {
    const response = await fetch('/api/categories.php', { cache: 'no-store' });
    const payload = await response.json();
    if (!response.ok || !payload.success || !Array.isArray(payload.data)) throw new Error(payload.message || 'No se pudieron cargar las categorías');
    const names = payload.data.map(entry => entry.name).filter(name => typeof name === 'string' && name.trim());
    const publicFilter = document.getElementById('categoryFilter');
    const adminFilter = document.getElementById('adminCatFilter');
    const editor = document.getElementById('prodCategory');
    function populate(select, all) {
      if (!select) return;
      const previous = select.value;
      const saved = select === publicFilter ? initiallySavedCategory : '';
      select.replaceChildren();
      if (all) select.add(new Option('Todas las categorías', 'all'));
      names.forEach(name => select.add(new Option(name, name)));
      const choice = select === publicFilter && names.includes(saved) ? saved
        : names.includes(previous) || previous === 'all' ? previous
        : all ? 'all' : names[0];
      if (choice) select.value = choice;
    }
    populate(publicFilter, true);
    initiallySavedCategory = '';
    populate(adminFilter, true);
    populate(editor, false);
    if (publicFilter && typeof window.displayProducts === 'function') window.displayProducts();
    if (adminFilter && typeof window.renderAdminProducts === 'function') window.renderAdminProducts();
    return names;
  }
  window.AFCategorySelects = { load };
})();
