/* AF MODAS · Historias: progreso, pausa y navegación táctil. */
(() => {
  'use strict';
  const viewer = document.getElementById('storyViewer');
  if (!viewer) return;
  const body = document.getElementById('storyBody');
  const progress = document.getElementById('storyProgress');
  const pauseButton = document.getElementById('storyPause');
  const previous = document.getElementById('storyPrevious');
  let stories = [], index = 0, frame = 0, elapsed = 0, last = 0, duration = 10000;
  let open = false, ready = false, manualPause = false, hold = false, gesture = null, oldOverflow = '', oldFocus = null, generation = 0;
  const paused = () => !ready || manualPause || hold || document.hidden;
  function updatePause() {
    pauseButton.textContent = manualPause ? '▶' : 'Ⅱ';
    pauseButton.setAttribute('aria-label', manualPause ? 'Continuar historia' : 'Pausar historia');
    pauseButton.setAttribute('aria-pressed', manualPause ? 'true' : 'false');
  }
  function tick(time) {
    if (!open) return;
    if (last && !paused()) elapsed += Math.min(time - last, 100);
    last = time;
    const bar = progress.children[index]?.firstElementChild;
    if (bar) bar.style.transform = `scaleX(${Math.min(1, elapsed / duration)})`;
    if (elapsed >= duration) { window.nextStory(); return; }
    frame = requestAnimationFrame(tick);
  }
  function age(created) {
    const minutes = Math.max(0, Math.floor((Date.now() - new Date(created).getTime()) / 60000));
    return !Number.isFinite(minutes) || minutes < 1 ? 'Ahora' : minutes < 60 ? `${minutes} min` : `${Math.floor(minutes/60)} h`;
  }
  window.openStoryViewer = (storyId) => {
    if (open) return;
    stories = getActiveStories();
    const requested = typeof storyId === 'string' && storyId !== '';
    const target = requested ? stories.findIndex(story => String(story.id) === storyId) : 0;
    if (requested && target < 0) { showToast('Esta historia ya venció o fue eliminada'); return; }
    if (!stories.length) { showToast('No hay historias nuevas'); return; }
    if (window.storyTimer) { clearInterval(window.storyTimer); window.storyTimer = null; }
    oldFocus = document.activeElement; oldOverflow = document.body.style.overflow;
    open = true; viewer.style.display = 'flex'; viewer.setAttribute('aria-hidden','false');
    document.body.style.overflow = 'hidden';
    window.showStory(target); viewer.querySelector('.story-close').focus({preventScroll:true});
  };
  window.showStory = value => {
    if (!open || !stories.length) return;
    cancelAnimationFrame(frame); const token = ++generation;
    index = Math.max(0, Math.min(stories.length - 1,value)); window.storyIndex = index;
    elapsed = 0; last = 0; ready = false; manualPause = false; hold = false; gesture = null; updatePause();
    const story = stories[index]; duration = story.image ? 10000 : 15000;
    previous.disabled = index === 0;
    document.getElementById('storyPosition').textContent = `${index+1} / ${stories.length}`;
    document.getElementById('storyAge').textContent = age(story.created_at);
    progress.replaceChildren();
    stories.forEach((_,i) => { const span = document.createElement('span'), fill = document.createElement('i'); fill.style.transform = i < index ? 'scaleX(1)' : 'scaleX(0)'; span.appendChild(fill); progress.appendChild(span); });
    body.replaceChildren(); body.classList.toggle('story-text-only', !story.image);
    const copy = document.createElement('div'); copy.className = 'story-copy';
    const type = document.createElement('span'); type.className = 'story-type'; type.textContent = String(story.type || 'Novedad');
    const title = document.createElement('h3'); title.textContent = String(story.title || '');
    const message = document.createElement('p'); message.textContent = String(story.message || '');
    copy.append(type,title,message);
    if (story.product_code) {
      const link = document.createElement('a');
      link.className = 'story-product-link';
      link.href = '/producto.php?code=' + encodeURIComponent(String(story.product_code));
      link.textContent = 'Ver prenda →';
      copy.appendChild(link);
    }
    if (story.image) {
      const img = document.createElement('img'); img.className = 'story-photo'; img.alt = String(story.title || 'Historia AF MODAS'); img.draggable = false;
      const status = document.createElement('span'); status.className = 'story-status'; status.textContent = 'Cargando imagen…';
      const loaded = () => { if (token !== generation) return; status.remove(); ready = true; };
      img.addEventListener('load',loaded,{once:true});
      img.addEventListener('error',() => { if (token !== generation) return; img.remove(); body.classList.add('story-text-only'); status.remove(); ready = true; },{once:true});
      img.src = String(story.image); body.append(img,status);
      if (img.complete && img.naturalWidth) loaded();
    } else { const mark = document.createElement('div'); mark.className = 'story-brand-mark'; mark.textContent = 'AF'; body.appendChild(mark); ready = true; }
    body.appendChild(copy); frame = requestAnimationFrame(tick);
  };
  window.nextStory = () => { if (index < stories.length - 1) window.showStory(index+1); else window.closeStoryViewer(); };
  window.prevStory = () => { if (index > 0) window.showStory(index-1); };
  window.closeStoryViewer = () => {
    if (!open) return;
    open = false; ++generation; cancelAnimationFrame(frame); viewer.style.display = 'none'; viewer.setAttribute('aria-hidden','true');
    document.body.style.overflow = oldOverflow; oldFocus?.focus({preventScroll:true}); updateStoryRing();
  };
  let sharedLinkHandled = false;
  window.openSharedStory = () => {
    if (sharedLinkHandled) return;
    sharedLinkHandled = true;
    const id = new URL(window.location.href).searchParams.get('story');
    if (id && window.storiesLoadFailed) { showToast('No se pudo cargar la historia. Recargá la página para reintentar.'); return; }
    if (id) window.openStoryViewer(id);
  };
  const shareButton = document.getElementById('storyShare');
  shareButton.addEventListener('click', async () => {
    if (!open || !stories[index] || shareButton.disabled) return;
    const story = stories[index];
    const link = new URL('/', window.location.origin);
    link.searchParams.set('story', String(story.id));
    manualPause = true; updatePause();
    shareButton.disabled = true;
    try {
      if (navigator.share) {
        try {
          await navigator.share({title: String(story.title || 'Historia AF MODAS'), url:link.href});
          return;
        } catch (error) { if (error.name === 'AbortError') return; }
      }
      try {
        await navigator.clipboard.writeText(link.href);
        showToast('Enlace de la historia copiado');
      } catch (_) { window.prompt('Copiá este enlace para compartir la historia:', link.href); }
    } finally { shareButton.disabled = false; }
  });
  pauseButton.addEventListener('click',() => { manualPause = !manualPause; updatePause(); });
  viewer.addEventListener('click',event => { if (event.target === viewer) window.closeStoryViewer(); });
  body.addEventListener('pointerdown',event => { if (event.pointerType === 'mouse' && event.button !== 0) return; hold = true; gesture = {id:event.pointerId,x:event.clientX,y:event.clientY,time:performance.now(),copy:!!event.target.closest('.story-copy')}; });
  body.addEventListener('pointerup',event => {
    hold = false; if (!gesture || gesture.id !== event.pointerId) return;
    const g = gesture; gesture = null; const dx = event.clientX-g.x, dy = event.clientY-g.y;
    if (g.copy) return;
    if (dy > 90 && Math.abs(dy) > Math.abs(dx)) { window.closeStoryViewer(); return; }
    if (Math.abs(dx) > 60 && Math.abs(dx) > Math.abs(dy)) { dx < 0 ? window.nextStory() : window.prevStory(); return; }
    if (Math.abs(dx) < 20 && Math.abs(dy) < 20 && performance.now()-g.time < 250) {
      const rect = body.getBoundingClientRect(); (event.clientX-rect.left)/rect.width < .3 ? window.prevStory() : window.nextStory();
    }
  });
  body.addEventListener('pointercancel',() => { hold = false; gesture = null; });
  window.addEventListener('pointerup',() => { hold = false; });
  window.addEventListener('blur',() => { hold = false; last = 0; });
  document.addEventListener('visibilitychange',() => { last = 0; });
  document.addEventListener('keydown',event => {
    if (!open) return;
    if (event.key === 'Escape') window.closeStoryViewer();
    if (event.key === 'ArrowRight') window.nextStory();
    if (event.key === 'ArrowLeft') window.prevStory();
    if (event.code === 'Space' && event.target === body) { event.preventDefault(); manualPause = !manualPause; updatePause(); }
    if (event.key === 'Tab') {
      const controls = [...viewer.querySelectorAll('button:not(:disabled), a[href]')]; const first = controls[0], end = controls[controls.length-1];
      if (event.shiftKey && document.activeElement === first) { event.preventDefault(); end.focus(); }
      else if (!event.shiftKey && document.activeElement === end) { event.preventDefault(); first.focus(); }
    }
  });
})();
