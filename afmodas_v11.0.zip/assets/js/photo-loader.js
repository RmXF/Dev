/* AF MODAS · Estado visual de cada foto sin bloquear el resto del catálogo. */
(() => {
  'use strict';
  const frameFor = img => img?.parentElement?.matches('.af-image-frame,.af-lookbook-photo') ? img.parentElement : null;
  const finish = img => {
    const frame = frameFor(img);
    if (frame) { frame.classList.remove('is-failed'); frame.classList.add('is-loaded'); }
  };
  function refresh(root = document) {
    root.querySelectorAll('.af-image-frame > img,.af-lookbook-photo > img').forEach(img => {
      if (img.complete && img.naturalWidth > 0) finish(img);
    });
  }
  document.addEventListener('load', event => {
    if (event.target instanceof HTMLImageElement && frameFor(event.target)) finish(event.target);
  }, true);
  document.addEventListener('error', event => {
    const img = event.target;
    const frame = img instanceof HTMLImageElement ? frameFor(img) : null;
    if (!frame) return;
    frame.classList.remove('is-loaded');
    if (frame.classList.contains('af-lookbook-photo')) {
      // La portada conserva su respaldo actual: foto original y después logo.
      if (img.dataset.fallback === '2') frame.classList.add('is-failed');
      return;
    }
    const fallback = img.dataset.fullImage;
    if (!img.dataset.afAttempt && fallback && fallback !== img.src) {
      img.dataset.afAttempt = 'original'; img.src = fallback; return;
    }
    if (img.dataset.afAttempt !== 'logo') {
      img.dataset.afAttempt = 'logo'; img.src = '/assets/img/af-logo.png'; return;
    }
    frame.classList.add('is-failed');
  }, true);
  window.AFPhotoLoader = { refresh };
  refresh();
})();
