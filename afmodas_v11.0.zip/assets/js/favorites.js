/* AF MODAS · Favoritos privados de este navegador. */
(() => {
  'use strict';
  const key = 'af_favorites_v1';
  function read() {
    try {
      const value = JSON.parse(localStorage.getItem(key) || '[]');
      return new Set(Array.isArray(value) ? value.filter(code => typeof code === 'string' && code.length > 0 && code.length <= 80) : []);
    } catch (_) { return new Set(); }
  }
  let codes = read();
  function refresh(root = document) {
    root.querySelectorAll('[data-favorite-code]').forEach(button => {
      const saved = codes.has(button.dataset.favoriteCode);
      button.setAttribute('aria-pressed', saved ? 'true' : 'false');
      button.textContent = saved ? '★ Guardado' : '☆ Guardar favorito';
      button.title = saved ? 'Quitar de favoritos' : 'Guardar en favoritos';
    });
  }
  function message(text) {
    const existing = document.getElementById('favoriteStatus');
    if (existing) { existing.textContent = text; return; }
    if (typeof window.showToast === 'function') { window.showToast(text); return; }
    const node = document.createElement('div'); node.className = 'af-favorite-toast'; node.setAttribute('role','status'); node.textContent = text;
    document.body.appendChild(node); setTimeout(() => node.remove(),2500);
  }
  document.addEventListener('click', event => {
    const button = event.target.closest('[data-favorite-code]');
    if (!button) return;
    const code = button.dataset.favoriteCode;
    if (!code || code.length > 80) return;
    codes = read();
    const added = !codes.has(code);
    if (added) codes.add(code); else codes.delete(code);
    try { localStorage.setItem(key, JSON.stringify([...codes])); }
    catch (_) { codes = read(); message('No se pudo guardar. Revisá si el navegador permite almacenamiento.'); return; }
    refresh();
    if (window.AF_FAVORITES_ONLY && typeof window.displayProducts === 'function') window.displayProducts();
    message(added ? 'Prenda guardada en favoritos' : 'Prenda quitada de favoritos');
  });
  window.addEventListener('storage', event => {
    if (event.key !== key && event.key !== null) return;
    codes = read(); refresh();
    if (window.AF_FAVORITES_ONLY && typeof window.displayProducts === 'function') window.displayProducts();
  });
  window.AFFavorites = {has:code => codes.has(String(code)),refresh};
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', () => refresh()); else refresh();
})();
