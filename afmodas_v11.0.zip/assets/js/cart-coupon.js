/* AF MODAS · Cupones del carrito público. Funciona en portada y catálogo. */
(() => {
  'use strict';
  const sheet = document.getElementById('cartSheet');
  const cartItems = document.getElementById('cartItems');
  if (!sheet || !cartItems || typeof window.displayCart !== 'function') return;
  const box = document.createElement('section');
  box.className = 'coupon-box';
  box.innerHTML = '<button class="coupon-toggle" id="couponTogglePublic" type="button" aria-expanded="false" aria-controls="couponDetailsPublic"><i class="fas fa-ticket" aria-hidden="true"></i> <span>Agregar cupón</span> <i class="fas fa-chevron-down" aria-hidden="true"></i></button>' +
    '<div id="couponDetailsPublic" hidden><div class="coupon-row"><input class="coupon-input" id="couponCodePublic" type="text" maxlength="40" autocomplete="off" placeholder="Ingresá tu código" aria-label="Código de cupón">' +
    '<button class="coupon-action" id="couponApplyPublic" type="button">Aplicar</button></div>' +
    '<button class="coupon-remove" id="couponRemovePublic" type="button" hidden>Quitar cupón</button>' +
    '<p class="coupon-status" id="couponStatusPublic" role="status" aria-live="polite"></p></div>';
  const summary = document.createElement('div');
  summary.className = 'cart-breakdown';
  summary.innerHTML = '<div><span>Subtotal</span><strong id="cartSubtotalPublic">$0</strong></div>' +
    '<div class="discount" id="cartDiscountRowPublic" hidden><span>Descuento</span><strong id="cartDiscountPublic">−$0</strong></div>';
  const readyPanel = document.createElement('div');
  readyPanel.className = 'order-pdf-ready';
  readyPanel.hidden = true;
  readyPanel.innerHTML = '<strong><i class="fas fa-file-pdf" aria-hidden="true"></i> Tu pedido en PDF está listo</strong>' +
    '<p>Compartilo por WhatsApp desde el menú del celular o descargalo y adjuntalo al chat.</p>' +
    '<div class="order-pdf-actions"><button type="button" id="shareOrderPdf">Compartir PDF</button>' +
    '<button type="button" id="downloadOrderPdf">Descargar PDF + abrir WhatsApp</button></div>';
  cartItems.after(box, summary, readyPanel);
  let preparedFile = null;
  let preparedQuote = null;
  let preparedSnapshot = '';
  const fingerprint = () => JSON.stringify(items()) + '|' + applied;
  const clearPrepared = () => { preparedFile = null; preparedQuote = null; preparedSnapshot = ''; readyPanel.hidden = true; };
  const input = document.getElementById('couponCodePublic');
  const toggle = document.getElementById('couponTogglePublic');
  const details = document.getElementById('couponDetailsPublic');
  let expanded = false;
  toggle.addEventListener('click', () => {
    expanded = !expanded;
    details.hidden = !expanded;
    toggle.setAttribute('aria-expanded', String(expanded));
    if (expanded) input.focus();
  });
  const apply = document.getElementById('couponApplyPublic');
  const remove = document.getElementById('couponRemovePublic');
  const status = document.getElementById('couponStatusPublic');
  const totalEl = document.getElementById('cartTotal');
  const subtotalEl = document.getElementById('cartSubtotalPublic');
  const discountRow = document.getElementById('cartDiscountRowPublic');
  const discountEl = document.getElementById('cartDiscountPublic');
  const formatter = new Intl.NumberFormat('es-AR');
  const money = n => '$' + formatter.format(Math.max(0, Math.round(Number(n) || 0)));
  let applied = '';
  let quote = null;
  let revision = 0;
  let pending = false;
  const items = () => (window.cart || []).map(item => ({ code: String(item.code), qty: Number(item.qty) }));
  const localSubtotal = () => (window.cart || []).reduce((sum, item) => sum + Number(item.price || 0) * Number(item.qty || 0), 0);
  const message = (text, kind = '') => { status.textContent = text; status.className = 'coupon-status ' + kind; };
  function render() {
    const subtotal = quote?.subtotal ?? localSubtotal();
    const discount = applied && quote?.coupon === applied ? quote.discount : 0;
    subtotalEl.textContent = money(subtotal);
    discountRow.hidden = discount <= 0;
    discountEl.textContent = '−' + money(discount);
    totalEl.textContent = 'Total: ' + money(subtotal - discount);
    box.hidden = !(window.cart || []).length;
    summary.hidden = box.hidden;
    remove.hidden = !applied;
    toggle.querySelector('span').textContent = applied ? `Cupón ${applied}` : 'Agregar cupón';
    apply.disabled = pending || box.hidden;
  }
  async function requestQuote(code) {
    const response = await fetch('/api/validate_coupon.php', {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ items: items(), coupon: code }), cache: 'no-store'
    });
    const result = await response.json();
    if (!response.ok || !result.success) throw new Error(result.message || 'No se pudo validar el pedido');
    return result;
  }
  function orderKey(snapshot) {
    let keys = {};
    try {
      keys = JSON.parse(sessionStorage.getItem('af_order_keys') || '{}');
      if (keys && /^[a-f0-9]{32}$/.test(keys[snapshot] || '')) return keys[snapshot];
    } catch (_) {}
    const bytes = new Uint8Array(16);
    crypto.getRandomValues(bytes);
    const key = [...bytes].map(byte => byte.toString(16).padStart(2, '0')).join('');
    try {
      keys[snapshot] = key;
      const recent = Object.entries(keys).slice(-10);
      sessionStorage.setItem('af_order_keys', JSON.stringify(Object.fromEntries(recent)));
    } catch (_) {}
    return key;
  }
  function releaseOrderKey(snapshot) {
    if (!snapshot) return;
    try {
      const keys = JSON.parse(sessionStorage.getItem('af_order_keys') || '{}');
      if (keys && Object.prototype.hasOwnProperty.call(keys, snapshot)) {
        delete keys[snapshot];
        sessionStorage.setItem('af_order_keys', JSON.stringify(keys));
      }
    } catch (_) {}
  }
  async function createOrder(snapshot) {
    const response = await fetch('/api/create_order.php', {
      method: 'POST', headers: { 'Content-Type': 'application/json' }, cache: 'no-store',
      body: JSON.stringify({ items: items(), coupon: applied, order_key: orderKey(snapshot) })
    });
    const result = await response.json();
    if (!response.ok || !result.success) throw new Error(result.message || 'No se pudo emitir el comprobante');
    return result;
  }
  async function validate(code, announce) {
    clearPrepared();
    const ticket = ++revision;
    pending = true; render();
    try {
      const result = await requestQuote(code);
      if (ticket !== revision) return;
      applied = result.coupon || '';
      quote = result;
      if (announce) message(applied ? `Cupón ${applied} aplicado: ahorrás ${money(result.discount)}.` : '', 'ok');
    } catch (error) {
      if (ticket !== revision) return;
      applied = '';
      quote = null;
      message(error.message, 'error');
    } finally {
      if (ticket === revision) { pending = false; render(); }
    }
  }
  apply.addEventListener('click', () => {
    const code = input.value.trim().toUpperCase();
    if (!code) { message('Ingresá un código de cupón.', 'error'); input.focus(); return; }
    validate(code, true);
  });
  input.addEventListener('keydown', event => { if (event.key === 'Enter') { event.preventDefault(); apply.click(); } });
  remove.addEventListener('click', () => {
    revision++; pending = false; applied = ''; quote = null; input.value = ''; clearPrepared();
    expanded = false; details.hidden = true; toggle.setAttribute('aria-expanded', 'false');
    message('Cupón quitado.'); render();
  });
  const originalDisplay = window.displayCart;
  window.displayCart = function (...args) {
    const result = originalDisplay.apply(this, args);
    if (preparedSnapshot && preparedSnapshot !== fingerprint()) releaseOrderKey(preparedSnapshot);
    cartItems.querySelectorAll('.cart-item').forEach((row, index) => {
      const item = (window.cart || [])[index];
      const product = (window.products || []).find(p => String(p.code) === String(item?.code));
      if (!product || !row.firstElementChild || row.querySelector('.cart-variant')) return;
      const gender = String(product.gender || 'unisex').toLowerCase();
      const group = gender === 'mujer' ? 'Mujer' : gender === 'hombre' ? 'Varón' : 'Unisex';
      const variant = document.createElement('small');
      variant.className = 'cart-variant';
      variant.textContent = [product.color ? 'Color: ' + product.color : '', group].filter(Boolean).join(' · ');
      row.firstElementChild.appendChild(variant);
    });
    quote = null; clearPrepared();
    if (!(window.cart || []).length) { applied = ''; revision++; message(''); }
    render();
    if (applied && (window.cart || []).length) validate(applied, false);
    return result;
  };
  const whatsappText = current => {
    const label = window.SITE_CONFIG?.site_name || 'AF MODAS';
    return `Hola, quiero confirmar mi pedido en ${label}. Adjunto el PDF con ${current.items.length} producto(s). Total estimado: ${money(current.total)}${current.coupon ? ` (cupón ${current.coupon})` : ''}.`;
  };
  const whatsappUrl = current => {
    const phone = String(window.SITE_CONFIG?.whatsapp || '').replace(/\D/g, '');
    if (!phone) throw new Error('No hay un WhatsApp configurado en la tienda.');
    return 'https://wa.me/' + phone + '?text=' + encodeURIComponent(whatsappText(current));
  };
  function download(file) {
    const url = URL.createObjectURL(file);
    const link = document.createElement('a');
    link.href = url; link.download = file.name;
    document.body.appendChild(link); link.click(); link.remove();
    setTimeout(() => URL.revokeObjectURL(url), 60000);
  }
  document.getElementById('shareOrderPdf').addEventListener('click', async () => {
    if (!preparedFile || !preparedQuote || preparedSnapshot !== fingerprint()) { message('El carrito cambió. Generá el PDF nuevamente.', 'error'); clearPrepared(); return; }
    if (!navigator.share || (navigator.canShare && !navigator.canShare({ files: [preparedFile] }))) {
      message('Este navegador no permite compartir archivos. Usá la opción de descargar.', 'error'); return;
    }
    try {
      await navigator.share({ files: [preparedFile], title: 'Pedido AF MODAS', text: whatsappText(preparedQuote) });
      message('PDF compartido. La compra se confirma con la tienda por WhatsApp.', 'ok');
    } catch (error) {
      if (error.name !== 'AbortError') message('No se pudo compartir. Podés descargar el PDF.', 'error');
    }
  });
  document.getElementById('downloadOrderPdf').addEventListener('click', () => {
    if (!preparedFile || !preparedQuote || preparedSnapshot !== fingerprint()) { message('El carrito cambió. Generá el PDF nuevamente.', 'error'); clearPrepared(); return; }
    download(preparedFile);
    window.open(whatsappUrl(preparedQuote), '_blank', 'noopener');
    message('PDF descargado. Adjuntalo en el chat de WhatsApp antes de enviar.', 'ok');
  });
  window.AFCheckoutPDF = async function () {
    if (!(window.cart || []).length) { message('Agregá prendas antes de finalizar.', 'error'); return; }
    if (pending) { message('Esperá mientras validamos el cupón.', 'error'); return; }
    if (!window.AFOrderPDF) { message('No se pudo cargar el generador de PDF. Recargá la página.', 'error'); return; }
    const checkoutButton = sheet.querySelector('.btn-whatsapp');
    if (checkoutButton) { checkoutButton.disabled = true; checkoutButton.dataset.label = checkoutButton.innerHTML; checkoutButton.textContent = 'Preparando PDF...'; }
    clearPrepared();
    try {
      const snapshot = fingerprint();
      const current = await createOrder(snapshot);
      if (snapshot !== fingerprint()) throw new Error('El carrito cambió durante la validación.');
      const file = await window.AFOrderPDF.generate(current, window.SITE_CONFIG?.site_name || 'AF MODAS');
      if (snapshot !== fingerprint()) throw new Error('El carrito cambió mientras se preparaba el PDF.');
      preparedFile = file; preparedQuote = current; preparedSnapshot = snapshot;
      readyPanel.hidden = false;
      readyPanel.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
      message(current.coupon ? 'PDF listo. El cupón ya cuenta como un uso; el stock del panel no cambia.' : 'PDF listo. El stock del panel no cambia.', 'ok');
    } catch (error) {
      message(error.message + ' Revisá el carrito o quitá el cupón.', 'error');
      clearPrepared();
    } finally {
      if (checkoutButton) { checkoutButton.disabled = false; checkoutButton.innerHTML = checkoutButton.dataset.label; }
    }
  };

  render();
})();
