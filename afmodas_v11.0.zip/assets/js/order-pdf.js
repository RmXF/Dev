/* AF MODAS · Comprobante PDF del pedido (pdf-lib, licencia en vendor/). */
(() => {
  'use strict';
  const { PDFDocument, StandardFonts, rgb } = window.PDFLib || {};
  if (!PDFDocument) return;
  const C = {
    ink: rgb(.12,.11,.12), muted: rgb(.43,.42,.43), paper: rgb(.985,.978,.964),
    wine: rgb(.41,.18,.27), gold: rgb(.73,.54,.32), line: rgb(.89,.86,.83), white: rgb(1,1,1), green: rgb(.15,.51,.39)
  };
  const money = n => '$' + new Intl.NumberFormat('es-AR', { maximumFractionDigits: 0 }).format(Number(n) || 0);
  const safe = value => String(value ?? '').replace(/[\u{10000}-\u{10ffff}]/gu, '').replace(/[\u2010-\u2015]/g, '-').replace(/[\u2018\u2019]/g, "'").replace(/[\u201c\u201d]/g, '"').replace(/[\u2022]/g, '-').replace(/[^\x20-\x7E\xA0-\xFF]/g, ' ').trim();
  const fit = (text, font, size, width) => {
    const words = safe(text).split(/\s+/).filter(Boolean);
    const lines = []; let line = '';
    for (const word of words) {
      const candidate = line ? line + ' ' + word : word;
      if (font.widthOfTextAtSize(candidate, size) <= width) { line = candidate; continue; }
      if (line) lines.push(line);
      line = '';
      for (const char of word) {
        if (font.widthOfTextAtSize(line + char, size) > width && line) { lines.push(line); line = char; }
        else line += char;
      }
    }
    if (line) lines.push(line);
    return lines.length ? lines : [''];
  };
  async function generate(quote, siteName, previewConfig) {
    let config = previewConfig;
    if (!config) {
      const response = await fetch('/api/pdf_settings.php', {cache:'no-store'});
      const result = await response.json();
      if (!response.ok || !result.success) throw new Error('No se pudo cargar la configuración del comprobante.');
      config = result.data;
    }
    siteName = config.name || siteName || 'AF MODAS';
    const hex = /^#[0-9a-f]{6}$/i.test(config.color || '') ? config.color.slice(1) : '692e45';
    const channels = [0,2,4].map(i=>parseInt(hex.slice(i,i+2),16)/255);
    const accent = rgb(...channels);
    const C = {...window.AFOrderPDF.colors, wine:accent, gold:accent};
    const luminance = channels.map(c=>c<=.04045 ? c/12.92 : ((c+.055)/1.055)**2.4);
    const accentText = .2126*luminance[0]+.7152*luminance[1]+.0722*luminance[2] > .179 ? C.ink : C.white;
    const doc = await PDFDocument.create();
    doc.setTitle('Pedido - ' + safe(siteName));
    doc.setAuthor(safe(siteName));
    doc.setSubject('Resumen de pedido para enviar al comercio');
    const regular = await doc.embedFont(StandardFonts.Helvetica);
    const bold = await doc.embedFont(StandardFonts.HelveticaBold);
    const serif = await doc.embedFont(StandardFonts.TimesRoman);
    let logo = null;
    try {
      const response = await fetch(config.logo || '/assets/img/af-logo.png');
      if (response.ok) logo = await doc.embedPng(await response.arrayBuffer());
    } catch (_) {}
    const W = 595.28, H = 841.89, left = 48, right = W - 48;
    let page, y, index = 0;
    const label = (text, x, baseline, size = 9, font = regular, color = C.ink) => {
      page.drawText(safe(text), { x, y: baseline, size, font, color });
    };
    const aligned = (text, xRight, baseline, size = 9, font = regular, color = C.ink) => {
      const value = safe(text); label(value, xRight - font.widthOfTextAtSize(value, size), baseline, size, font, color);
    };
    function newPage(withColumns = true) {
      page = doc.addPage([W,H]); index++;
      page.drawRectangle({ x:0, y:0, width:W, height:H, color:C.paper });
      page.drawRectangle({ x:0, y:H-160, width:W, height:160, color:C.ink });
      page.drawRectangle({ x:left, y:H-160, width:45, height:3, color:C.gold });
      label(quote.preview ? 'VISTA PREVIA / SIN VALIDEZ' : 'RESUMEN / PEDIDO', left, H-39, 9, bold, C.white);
      let nameSize = 26;
      while (fit(siteName,serif,nameSize,330).length > 2 && nameSize > 10) nameSize--;
      fit(siteName,serif,nameSize,330).slice(0,2).forEach((line,i)=>label(line,left,H-83-i*(nameSize+5),nameSize,serif,C.white));
      if (logo) {
        const dimension = logo.scaleToFit(91,91);
        page.drawImage(logo,{x:right-93+(91-dimension.width)/2,y:H-119+(91-dimension.height)/2,width:dimension.width,height:dimension.height});
      } else {
        page.drawCircle({x:right-45,y:H-76,size:41,borderColor:C.gold,borderWidth:1});
        label('AF',right-63,H-86,30,serif,C.gold);
      }
      y = H-195;
      label('RESUMEN DE TU PEDIDO',left,y,9,bold,C.ink);
      aligned(new Intl.DateTimeFormat('es-AR',{dateStyle:'medium',timeStyle:'short',timeZone:'America/Argentina/Buenos_Aires'}).format(new Date(quote.issued_at || Date.now())),right,y,9,regular,C.muted);
      y -= 19;
      label('COMPROBANTE  '+(quote.order_id || 'PENDIENTE'),left,y,8,bold,C.muted);
      y -= 25;
      page.drawLine({start:{x:left,y},end:{x:right,y},thickness:1,color:C.line});
      y -= 29;
      if (!withColumns) return;
      label('PRODUCTO',left,y,9,bold,C.muted);
      aligned('CANT.',right-128,y,9,bold,C.muted);
      aligned('UNITARIO',right-57,y,9,bold,C.muted);
      aligned('IMPORTE',right,y,9,bold,C.muted);
      y -= 16;
    }
    newPage();
    const items = Array.isArray(quote.items) ? quote.items : [];
    for (let i=0; i<items.length; i++) {
      const item=items[i];
      const lines=fit(item.name || 'Producto',bold,10,210);
      const gender = String(item.gender || 'unisex').toLowerCase();
      const line = gender === 'mujer' || gender === 'femenino' ? 'Mujer' : gender === 'hombre' || gender === 'varon' || gender === 'varón' || gender === 'masculino' ? 'Varón' : 'Unisex';
      const details = [
        'Color: ' + (item.color || 'No especificado'),
        'Línea: ' + line,
        item.sizes ? 'Talles disponibles: ' + item.sizes : ''
      ].filter(Boolean).flatMap(text=>fit(text,regular,8,210));
      const rowHeight=Math.max(82,lines.length*13+details.length*11+29);
      if (y-rowHeight<156) newPage();
      if (i%2===0) page.drawRectangle({x:left-8,y:y-rowHeight+3,width:right-left+16,height:rowHeight,color:C.white});
      lines.forEach((line,j)=>label(line,left,y-14-j*13,10,bold,C.ink));
      label('Cód. '+(item.code || ''),left,y-16-lines.length*13,8,regular,C.muted);
      details.forEach((detail,j)=>label(detail,left,y-29-lines.length*13-j*11,8,regular,C.muted));
      aligned(String(item.qty || 0),right-128,y-18,10,bold,C.ink);
      aligned(money(item.price),right-57,y-18,9,regular,C.ink);
      aligned(money(item.subtotal),right,y-18,10,bold,C.ink);
      y -= rowHeight;
    }
    if (y<250) newPage(false);
    y -= 13;
    page.drawLine({start:{x:left,y},end:{x:right,y},thickness:1,color:C.line});
    y -= 26;
    label('Subtotal',left,y,10,regular,C.muted); aligned(money(quote.subtotal),right,y,11,bold);
    if (quote.coupon) {
      y -= 26;
      label('Cupón '+quote.coupon,left,y,10,regular,C.green);
      aligned('-'+money(quote.discount),right,y,11,bold,C.green);
    }
    y -= 52;
    page.drawRectangle({x:left,y:y-30,width:right-left,height:64,color:C.wine});
    label('TOTAL ESTIMADO',left+18,y-8,10,bold,accentText);
    aligned(money(quote.total),right-18,y-12,21,bold,accentText);
    y -= 61;
    function paragraph(text, size = 9, font = regular) {
      if (!String(text || '').trim()) return;
      const lines = fit(text,font,size,right-left);
      const height = lines.length * (size+5) + 9;
      if (height < 450 && y-height < 90) newPage(false);
      for (const line of lines) {
        if (y < 90) newPage(false);
        label(line,left,y,size,font,C.muted); y -= size+5;
      }
      y -= 9;
    }
    paragraph(config.thanks,11,bold);
    if (quote.coupon && !quote.preview) paragraph('El cupón se contabilizó al emitir este comprobante.',8.5);
    paragraph(config.instructions);
    paragraph(config.disclaimer,9,bold);
    paragraph([config.address, config.phone ? 'Tel.: '+config.phone : '', config.social, config.website].filter(Boolean).join(' · '),8.5);
    doc.getPages().forEach((p,i)=>{
      p.drawLine({start:{x:left,y:63},end:{x:right,y:63},thickness:1,color:C.line});
      p.drawText(fit(siteName,regular,8,360)[0]+'  ·  Pedido',{x:left,y:44,size:8,font:regular,color:C.muted});
      const text=`${i+1} / ${doc.getPageCount()}`;
      p.drawText(text,{x:right-regular.widthOfTextAtSize(text,8),y:44,size:8,font:regular,color:C.muted});
    });
    const bytes=await doc.save();
    return new File([bytes],`AF-MODAS-pedido-${new Date().toISOString().slice(0,10)}.pdf`,{type:'application/pdf'});
  }
  window.AFOrderPDF={generate,colors:C};
})();
