"""Genera el indicador SVG ligero de AF MODAS con la biblioteca estándar de Python."""
from pathlib import Path
from xml.sax.saxutils import escape

root = Path(__file__).resolve().parents[1]
output = root / 'assets' / 'img' / 'af-photo-loader.svg'
brand = escape('AF')
svg = f'''<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 120 120" role="img" aria-label="Cargando imagen">
<defs>
  <linearGradient id="gold" x1="0" y1="0" x2="1" y2="1"><stop stop-color="#dac59f"/><stop offset=".55" stop-color="#aa854c"/><stop offset="1" stop-color="#e3d4b8"/></linearGradient>
</defs>
<circle cx="60" cy="60" r="47" fill="none" stroke="#aa854c" stroke-opacity=".16" stroke-width="2"/>
<circle cx="60" cy="60" r="47" fill="none" stroke="url(#gold)" stroke-width="2.5" stroke-linecap="round" stroke-dasharray="60 236">
  <animateTransform attributeName="transform" type="rotate" from="0 60 60" to="360 60 60" dur="2.1s" repeatCount="indefinite"/>
</circle>
<circle cx="60" cy="60" r="36" fill="none" stroke="#aa854c" stroke-opacity=".32" stroke-width="1"/>
<text x="60" y="68" text-anchor="middle" fill="#a7814b" font-family="Georgia,serif" font-size="28" font-weight="bold" letter-spacing="-2">{brand}</text>
<circle cx="60" cy="93" r="2" fill="#b39159"><animate attributeName="opacity" values=".25;1;.25" dur="1.6s" repeatCount="indefinite"/></circle>
</svg>
'''
output.write_text(svg, encoding='utf-8')
print(f'{output}: {output.stat().st_size} bytes')
