<?php
declare(strict_types=1);
require_once __DIR__ . '/api/product_gallery.php';
// Ficha pública individual. El código identifica la prenda aunque cambie su nombre.
$code = $_GET['code'] ?? '';
if (!is_string($code) || $code === '' || strlen($code) > 80) $code = '';
$productsRaw = @file_get_contents(__DIR__ . '/data/products.json');
$products = $productsRaw === false ? [] : json_decode($productsRaw, true);
if (is_array($products) && isset($products['products']) && is_array($products['products'])) $products = $products['products'];
if (!is_array($products)) $products = [];
$product = null;
foreach ($products as $row) {
    if (is_array($row) && (string) ($row['code'] ?? '') === $code) { $product = $row; break; }
}
$configRaw = @file_get_contents(__DIR__ . '/data/settings.json');
$config = $configRaw === false ? [] : json_decode($configRaw, true);
if (!is_array($config)) $config = [];
if (isset($config['config']) && is_array($config['config'])) $config = $config['config'];
$maintenance = ($config['web_enabled'] ?? true) === false;
$gallery = $product === null ? [] : af_product_images($product);
if ($product !== null && !$gallery) $gallery = ['https://afmodas.online/assets/img/af-logo.png'];
if ($product !== null) $product['image'] = $gallery[0] ?? '';
if ($maintenance) http_response_code(503);
elseif ($product === null) http_response_code(404);
function e($value): string { return htmlspecialchars((string) $value, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8'); }
$name = $product === null ? 'Prenda no encontrada' : trim((string) ($product['name'] ?? 'Prenda AF MODAS'));
if ($name === '') $name = 'Prenda AF MODAS';
$site = (string) ($config['site_name'] ?? 'AF MODAS');
$canonical = 'https://afmodas.online/producto.php?code=' . rawurlencode($code);
$photo = 'https://afmodas.online/assets/img/af-logo.png';
if ($product !== null && !empty($product['image'])) {
    $host = strtolower((string) parse_url((string) $product['image'], PHP_URL_HOST));
    if ($host === 'www.dropbox.com' || $host === 'dl.dropboxusercontent.com'
        || preg_match('/^[a-z0-9-]+\.dropboxusercontent\.com$/D', $host)) {
        $photo = 'https://afmodas.online/api/product_image.php?code=' . rawurlencode($code) . '&format=jpeg';
    } elseif (filter_var($product['image'], FILTER_VALIDATE_URL)
        && strtolower((string) parse_url((string) $product['image'], PHP_URL_SCHEME)) === 'https') {
        $photo = (string) $product['image'];
    }
}
$stock = max(0, (int) ($product['stock'] ?? 0));
$price = max(0, (int) ($product['price'] ?? 0));
$description = $product === null ? 'Descubrí las prendas de AF MODAS.' :
    $name . ' · ' . trim((string) ($product['category'] ?? 'Moda'))
    . (!empty($product['color']) ? ' · Color ' . trim((string) $product['color']) : '')
    . (!empty($product['sizes']) ? ' · Talles ' . (is_array($product['sizes']) ? implode(', ', $product['sizes']) : (string) $product['sizes']) : '')
    . ' · $' . number_format($price, 0, ',', '.') . ' en ' . $site . '.';
?>
<!doctype html>
<html lang="es">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<script>try{if(localStorage.getItem('af_theme')==='dark')document.documentElement.classList.add('dark')}catch(_){}</script>
<title><?= e($name) ?> · <?= e($site) ?></title>
<meta name="description" content="<?= e($description) ?>">
<meta name="robots" content="<?= $maintenance || $product === null ? 'noindex, follow' : 'index, follow' ?>">
<link rel="canonical" href="<?= e($canonical) ?>">
<link rel="icon" href="/assets/img/af-logo.png">
<meta property="og:type" content="product">
<meta property="og:site_name" content="<?= e($site) ?>">
<meta property="og:locale" content="es_AR">
<meta property="og:url" content="<?= e($canonical) ?>">
<meta property="og:title" content="<?= e($name . ' · ' . $site) ?>">
<meta property="og:description" content="<?= e($description) ?>">
<meta property="og:image" content="<?= e($photo) ?>">
<meta property="og:image:secure_url" content="<?= e($photo) ?>">
<?php if ($photo === 'https://afmodas.online/assets/img/af-logo.png' || strpos($photo, '/api/product_image.php') !== false): ?>
<meta property="og:image:type" content="<?= strpos($photo, '/api/product_image.php') !== false ? 'image/jpeg' : 'image/png' ?>">
<?php endif; ?>
<meta property="og:image:alt" content="<?= e($name) ?>">
<meta name="twitter:card" content="summary_large_image">
<meta name="twitter:title" content="<?= e($name . ' · ' . $site) ?>">
<meta name="twitter:description" content="<?= e($description) ?>">
<meta name="twitter:image" content="<?= e($photo) ?>">
<?php if ($product !== null && !$maintenance): ?>
<script type="application/ld+json"><?= json_encode([
    '@context' => 'https://schema.org', '@type' => 'Product', 'name' => $name,
    'sku' => $code, 'description' => $description, 'image' => [$photo],
    'brand' => ['@type' => 'Brand', 'name' => $site],
    'offers' => ['@type' => 'Offer', 'priceCurrency' => 'ARS', 'price' => $price,
        'availability' => $stock > 0 ? 'https://schema.org/InStock' : 'https://schema.org/OutOfStock',
        'url' => $canonical]
], JSON_UNESCAPED_UNICODE | JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT | JSON_INVALID_UTF8_SUBSTITUTE) ?></script>
<?php endif; ?>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&family=Playfair+Display:wght@600;700&display=swap" rel="stylesheet">
<style>
:root{font-family:Inter,system-ui,sans-serif;color:#20292c;background:#f5f1ea}*{box-sizing:border-box}body{margin:0}a{color:inherit;text-decoration:none}button{font:inherit;cursor:pointer}.shell{max-width:1150px;margin:auto;padding:22px 24px 70px}header{display:flex;align-items:center;justify-content:space-between;gap:16px;padding-bottom:22px;border-bottom:1px solid #ddd3c4}.brand{font-family:'Playfair Display',serif;font-size:28px;font-weight:700;letter-spacing:.08em}.back{color:#315963;font-weight:700;font-size:.9rem}.crumb{margin:30px 0;color:#677478;font-size:.85rem}.crumb a{text-decoration:underline}.layout{display:grid;grid-template-columns:minmax(0,1.04fr) minmax(0,.96fr);gap:clamp(26px,6vw,84px);align-items:center}.photo{background:#eae3da;border-radius:28px;overflow:hidden;min-height:420px;position:relative;box-shadow:0 25px 65px #332b2318}.photo img{width:100%;height:100%;min-height:420px;max-height:720px;object-fit:contain;display:block;cursor:zoom-in}.label{text-transform:uppercase;letter-spacing:.16em;color:#a27d45;font-weight:800;font-size:.78rem}.detail h1{font-family:'Playfair Display',serif;font-size:clamp(2.2rem,5vw,4.3rem);line-height:1.08;margin:16px 0}.price{font-size:2rem;font-weight:800;color:#244955;margin:18px 0 26px}.facts{border-top:1px solid #d9cfc1;margin:0 0 27px}.facts div{display:flex;gap:12px;justify-content:space-between;padding:15px 0;border-bottom:1px solid #d9cfc1}.facts dt{color:#697579}.facts dd{margin:0;font-weight:700;text-align:right}.stock{color:#287a67}.sold{color:#a44e4e}.actions{display:flex;flex-wrap:wrap;gap:11px}.actions button,.actions a{padding:15px 20px;border-radius:13px;font-weight:800;border:1px solid #315963}.primary{background:#244955;color:white}.primary:disabled{opacity:.52;cursor:not-allowed}.secondary{background:transparent;color:#244955}.message{min-height:24px;color:#315963;font-size:.88rem;font-weight:600;margin:16px 0}.empty{text-align:center;padding:110px 20px}.empty h1{font-family:'Playfair Display',serif}.zoom{position:fixed;inset:0;background:#10171be8;display:none;align-items:center;justify-content:center;padding:4rem 16px 16px;z-index:10}.zoom.open{display:flex}.zoom img{max-width:100%;max-height:100%;object-fit:contain}.zoom button{position:absolute;right:24px;top:16px;background:white;border:0;border-radius:50%;width:42px;height:42px;font-size:24px}@media(max-width:720px){.shell{padding:16px 18px 45px}.layout{grid-template-columns:1fr;gap:28px}.photo,.photo img{min-height:310px}.brand{font-size:22px}.actions>*{flex:1;text-align:center}}
.dark{color:#eee8dc;background:#10171b;color-scheme:dark}.dark body{background:#10171b}.dark header,.dark .facts,.dark .facts div{border-color:#3a4143}.dark .photo{background:#273238;box-shadow:0 25px 65px #0007}.dark .back,.dark .crumb,.dark .secondary{color:#d3b881}.dark .price{color:#e5c487}.dark .facts dt{color:#b5bec1}.dark .stock{color:#8bd0b5}.dark .sold{color:#ee9a9a}.dark .primary{background:#d3b881;color:#182126;border-color:#d3b881}.dark .primary:disabled{opacity:.55}.dark .secondary{border-color:#8f7e65}.dark .message{color:#e5c487}.dark .label{color:#d3b881}.dark .theme-button{border-color:#8f7e65;color:#e5c487}.theme-button{border:1px solid #315963;color:#315963;background:transparent;border-radius:12px;padding:10px 13px;font-weight:700}.header-links{display:flex;gap:10px;align-items:center}.like-row{display:flex;align-items:center;gap:12px;flex-wrap:wrap;margin:0 0 25px}.like-button{border:1px solid #b77b89;background:#fff5f6;color:#9c4459;border-radius:999px;padding:11px 17px;font-weight:800;transition:transform .2s,background .2s}.like-button:hover:not(:disabled){transform:translateY(-2px)}.like-button[aria-pressed="true"]{background:#af5470;color:#fff;border-color:#af5470}.like-button:disabled{cursor:default}.like-count{font-size:.85rem;color:#697579}.dark .like-button{background:#332630;color:#f0a7b9;border-color:#925368}.dark .like-button[aria-pressed="true"]{background:#b6627a;color:#fff}.dark .like-count{color:#c1aab0}
</style>
<style>
.gallery-thumbs{display:flex;gap:9px;overflow-x:auto;padding:12px 2px 4px}.gallery-thumbs button{padding:3px;border:2px solid transparent;border-radius:12px;background:transparent;flex-shrink:0}.gallery-thumbs button[aria-pressed="true"]{border-color:#b58d50}.gallery-thumbs img{width:66px;height:78px;object-fit:cover;display:block;border-radius:8px}.gallery-caption{font-size:.8rem;color:#697579;margin:8px 0}.dark .gallery-caption{color:#b5bec1}.zoom .gallery-nav{position:static;border-radius:12px;width:auto;height:auto;padding:10px 16px;font-size:18px}.zoom .gallery-tools{position:absolute;bottom:20px;left:50%;transform:translateX(-50%);display:flex;align-items:center;gap:14px;color:#fff;background:#172027dd;padding:8px;border-radius:15px}.zoom{padding-bottom:90px}.zoom .gallery-close{top:16px;right:24px}.photo img:focus-visible{outline:3px solid #b58d50;outline-offset:-4px}
</style>
<link rel="stylesheet" href="/assets/css/favorites.css?v=24">
<script src="/assets/js/favorites.js?v=24" defer></script>
</head>
<body>
<div class="shell">
<header><a class="brand" href="/">AF MODAS</a><div class="header-links"><a class="back" href="/catalogo.html?favorites=1" aria-label="Mis favoritos">★</a><button class="theme-button" id="themeToggle" type="button" aria-label="Cambiar tema">◐</button><a class="back" href="/catalogo.html">← Ver catálogo</a></div></header>
<script>
document.getElementById('themeToggle').addEventListener('click', () => {
  const dark = document.documentElement.classList.toggle('dark');
  try { localStorage.setItem('af_theme', dark ? 'dark' : 'light'); } catch (_) {}
});
window.addEventListener('storage', event => {
  if (event.key === 'af_theme') document.documentElement.classList.toggle('dark', event.newValue === 'dark');
});
</script>
<?php if ($maintenance): ?>
<section class="empty"><h1><?= e($config['maintenance_title'] ?? 'Sitio en mantenimiento') ?></h1><p><?= e($config['maintenance_message'] ?? 'Volvemos pronto.') ?></p></section>
<?php elseif ($product === null): ?>
<section class="empty"><h1>Esta prenda no está disponible</h1><p>Quizás el enlace cambió o el producto fue retirado.</p><a class="back" href="/catalogo.html">Explorar prendas →</a></section>
<?php else: ?>
<nav class="crumb"><a href="/">Inicio</a> / <a href="/catalogo.html">Catálogo</a> / <?= e($name) ?></nav>
<main class="layout">
<div class="product-gallery">
<div class="photo"><img id="productPhoto" src="/api/product_image.php?code=<?= rawurlencode($code) ?>" data-original="<?= e($product['image'] ?? '') ?>" alt="<?= e($name) ?>" tabindex="0" role="button" aria-label="Ampliar foto de <?= e($name) ?>" fetchpriority="high" decoding="async" onerror="if(this.dataset.fallback!=='1'){this.dataset.fallback='1';this.src=this.dataset.original||'/assets/img/af-logo.png'}"></div>
<?php if (count($gallery) > 1): ?>
<div class="gallery-thumbs" aria-label="Fotos de la prenda">
<?php foreach ($gallery as $index => $url): ?>
<button type="button" data-gallery-index="<?= $index ?>" aria-pressed="<?= $index === 0 ? 'true' : 'false' ?>" aria-label="Ver foto <?= $index + 1 ?> de <?= count($gallery) ?>">
<img src="/api/product_image.php?code=<?= rawurlencode($code) ?>&amp;index=<?= $index ?>" data-original="<?= e($url) ?>" alt="<?= e($name) ?> · foto <?= $index + 1 ?>" loading="lazy" onerror="if(this.dataset.fallback!=='1'){this.dataset.fallback='1';this.src=this.dataset.original}">
</button>
<?php endforeach; ?>
</div>
<?php endif; ?>
<p class="gallery-caption" id="galleryCaption"><?= count($gallery) > 1 ? 'Elegí una foto para ver otro ángulo. Tocá la imagen para ampliarla.' : 'Tocá la imagen para ampliarla.' ?></p>
</div>
<div class="detail">
<span class="label"><?= e($product['category'] ?? 'Colección') ?> · #<?= e($code) ?></span>
<h1><?= e($name) ?></h1><div class="price">$<?= number_format($price, 0, ',', '.') ?></div>
<div class="like-row"><button class="like-button" id="likeButton" type="button" aria-pressed="false" disabled>♡ Me encanta</button><button class="af-favorite-button" type="button" style="margin-top:0;" data-favorite-code="<?= e($code) ?>" aria-pressed="false">☆ Guardar favorito</button></div>
<dl class="facts">
<?php if (!empty($product['color'])): ?><div><dt>Color</dt><dd><?= e($product['color']) ?></dd></div><?php endif; ?>
<?php if (!empty($product['sizes'])): ?><div><dt>Talles</dt><dd><?= e(is_array($product['sizes']) ? implode(', ', $product['sizes']) : $product['sizes']) ?></dd></div><?php endif; ?>
<div><dt>Línea</dt><dd><?= e(ucfirst((string) ($product['gender'] ?? 'unisex'))) ?></dd></div>
<div><dt>Disponibilidad</dt><dd class="<?= $stock ? 'stock' : 'sold' ?>"><?= $stock ? e($stock . ($stock === 1 ? ' unidad' : ' unidades')) : 'Agotado' ?></dd></div>
</dl>
<div class="actions"><button class="primary" id="add" type="button" <?= $stock ? '' : 'disabled' ?>><?= $stock ? 'Agregar al carrito' : 'Agotado' ?></button><button class="secondary" id="share" type="button">Compartir prenda</button><a class="secondary" href="/catalogo.html?cart=1">Ver carrito</a></div>
<p class="message" id="message" role="status" aria-live="polite"></p>
</div></main>
<div class="zoom" id="zoom" role="dialog" aria-modal="true" aria-label="Imagen ampliada"><button class="gallery-close" type="button" aria-label="Cerrar imagen">×</button><img alt="<?= e($name) ?>"><div class="gallery-tools" <?= count($gallery) <= 1 ? 'hidden style="display:none"' : '' ?>><button class="gallery-nav" id="galleryPrevious" type="button" aria-label="Foto anterior">‹</button><span id="galleryPosition" aria-live="polite">1 / <?= count($gallery) ?></span><button class="gallery-nav" id="galleryNext" type="button" aria-label="Foto siguiente">›</button></div></div>
<script>
(() => {
  const code = <?= json_encode($code, JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT) ?>;
  const msg = document.getElementById('message');
  const add = document.getElementById('add');
  const share = document.getElementById('share');
  const like = document.getElementById('likeButton');
  function showLikes(data) {
    like.setAttribute('aria-pressed', data.liked ? 'true' : 'false');
    like.textContent = data.liked ? '♥ Te encanta' : '♡ Me encanta';
    like.disabled = !!data.liked;
  }
  fetch('/api/product_likes.php?code=' + encodeURIComponent(code), {cache:'no-store'})
    .then(async response => { const data = await response.json(); if (!response.ok || !data.success) throw new Error(); return data; })
    .then(showLikes)
    .catch(() => { like.title = 'No se pudo consultar tu voto. Recargá la página para intentarlo de nuevo.'; });
  like.addEventListener('click', async () => {
    like.disabled = true;
    try {
      const response = await fetch('/api/product_likes.php', {method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({code})});
      const data = await response.json();
      if (!response.ok || !data.success) throw new Error(data.message || 'No se pudo guardar');
      showLikes(data);
    } catch (_) { like.disabled = false; msg.textContent = 'No se pudo guardar tu voto. Intentá de nuevo.'; }
  });
  const photo = document.getElementById('productPhoto');
  const zoom = document.getElementById('zoom');
  const gallery = <?= json_encode($gallery, JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT | JSON_INVALID_UTF8_SUBSTITUTE) ?>;
  let currentPhoto = 0;
  function selectPhoto(index) {
    if (!gallery.length) return;
    currentPhoto = (index + gallery.length) % gallery.length;
    photo.dataset.original = gallery[currentPhoto]; photo.dataset.fallback = '';
    photo.src = '/api/product_image.php?code=' + encodeURIComponent(code) + '&index=' + currentPhoto;
    document.querySelectorAll('[data-gallery-index]').forEach(button => button.setAttribute('aria-pressed', Number(button.dataset.galleryIndex) === currentPhoto ? 'true' : 'false'));
    zoom.querySelector('img').src = gallery[currentPhoto];
    document.getElementById('galleryPosition').textContent = `${currentPhoto + 1} / ${gallery.length}`;
  }
  function openZoom() { selectPhoto(currentPhoto); zoom.classList.add('open'); document.body.style.overflow = 'hidden'; zoom.querySelector('.gallery-close').focus(); }
  function closeZoom() { zoom.classList.remove('open'); document.body.style.overflow = ''; photo.focus(); }
  document.querySelectorAll('[data-gallery-index]').forEach(button => button.addEventListener('click', () => selectPhoto(Number(button.dataset.galleryIndex))));
  photo.addEventListener('click', openZoom);
  photo.addEventListener('keydown', event => { if (event.key === 'Enter' || event.key === ' ') { event.preventDefault(); openZoom(); } });
  zoom.querySelector('.gallery-close').addEventListener('click', closeZoom);
  zoom.addEventListener('click', event => { if (event.target === zoom) closeZoom(); });
  document.getElementById('galleryPrevious').addEventListener('click', () => selectPhoto(currentPhoto - 1));
  document.getElementById('galleryNext').addEventListener('click', () => selectPhoto(currentPhoto + 1));
  document.addEventListener('keydown', event => {
    if (!zoom.classList.contains('open')) return;
    if (event.key === 'Escape') closeZoom();
    if (event.key === 'ArrowLeft') selectPhoto(currentPhoto - 1);
    if (event.key === 'ArrowRight') selectPhoto(currentPhoto + 1);
  });
  share.addEventListener('click', async () => {
    const data = {title: document.title, text: <?= json_encode($name, JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT) ?>, url: location.href};
    try {
      if (navigator.share) await navigator.share(data);
      else if (navigator.clipboard?.writeText) { await navigator.clipboard.writeText(data.url); msg.textContent = 'Enlace copiado'; }
      else { window.prompt('Copiá el enlace:', data.url); }
    } catch (error) { if (error.name !== 'AbortError') msg.textContent = 'No se pudo compartir el enlace'; }
  });
  add.addEventListener('click', async () => {
    add.disabled = true; msg.textContent = 'Comprobando disponibilidad…';
    try {
      const response = await fetch('/api/products.php?code=' + encodeURIComponent(code), {cache:'no-store'});
      const payload = await response.json();
      if (!response.ok || !payload.success || !payload.data) throw new Error('No se pudo verificar el stock');
      const p = payload.data;
      const cart = JSON.parse(localStorage.getItem('af_cart') || '[]');
      if (!Array.isArray(cart)) throw new Error('No se pudo abrir el carrito');
      const qty = cart.reduce((sum,item) => sum + (String(item.code) === code ? Number(item.qty || 0) : 0), 0);
      const stock = Math.max(0, Number(p.stock) || 0);
      if (qty >= stock) { msg.textContent = stock ? `Solo hay ${stock} unidades disponibles` : 'Producto agotado'; return; }
      const existing = cart.find(item => String(item.code) === code);
      if (existing) { existing.qty = Number(existing.qty || 0) + 1; existing.price = Number(p.price) || 0; }
      else cart.push({code:p.code,name:p.name,price:Number(p.price)||0,qty:1,image:p.image});
      localStorage.setItem('af_cart', JSON.stringify(cart));
      msg.textContent = '✓ Agregado al carrito. Podés verlo en el catálogo.';
    } catch (_) { msg.textContent = 'No se pudo comprobar el stock. Intentá de nuevo.'; }
    finally { add.disabled = false; }
  });
})();
</script>
<?php endif; ?>
</div>
</body>
</html>
