<?php
// ============================================
// AF MODAS - CONFIGURACIÓN PRINCIPAL
// ============================================

define('DATA_DIR', __DIR__ . '/../data/');

// Leer configuración
function getConfig() {
    $file = DATA_DIR . 'settings.json';
    if (file_exists($file)) {
        $data = json_decode(file_get_contents($file), true);
        return $data['config'] ?? [];
    }
    return [];
}

// Leer datos JSON
function readJson($file) {
    $path = DATA_DIR . $file . '.json';
    if (!file_exists($path)) return [];
    $data = file_get_contents($path);
    return json_decode($data, true) ?: [];
}

// Escribir datos JSON
function writeJson($file, $data) {
    $path = DATA_DIR . $file . '.json';
    file_put_contents($path, json_encode($data, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
}

// Log de actividad
function logActivity($type, $action, $details = '') {
    $activity = readJson('activity');
    $entry = [
        'id' => 'a' . time() . rand(100, 999),
        'type' => $type,
        'action' => $action,
        'details' => $details,
        'timestamp' => date('Y-m-d H:i:s'),
        'ip' => $_SERVER['REMOTE_ADDR'] ?? 'unknown'
    ];
    array_unshift($activity, $entry);
    if (count($activity) > 200) $activity = array_slice($activity, 0, 200);
    writeJson('activity', $activity);
    return $entry;
}