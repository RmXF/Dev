#!/usr/bin/env python3
"""Comprobación de lectura pública; no cambia el servidor ni usa credenciales."""
from html.parser import HTMLParser
from urllib.request import Request, urlopen
from urllib.error import HTTPError, URLError
from urllib.parse import urljoin, urlparse
import time

SITE = 'https://afmodas.online/'
class Meta(HTMLParser):
    def __init__(self):
        super().__init__(); self.tags = {}
    def handle_starttag(self, tag, attrs):
        values = dict(attrs)
        if tag == 'meta':
            key = values.get('property') or values.get('name')
            if key: self.tags[key] = values.get('content', '')

def fetch(url, agent, limit):
    start = time.monotonic()
    try:
        with urlopen(Request(url, headers={'User-Agent': agent}), timeout=20) as response:
            data = response.read(limit)
            print('  HTTP:', response.status, '| Tipo:', response.headers.get('Content-Type', '?'))
            print('  URL final:', response.url, '| Tiempo:', round(time.monotonic()-start, 2), 's')
            return data, response.headers
    except HTTPError as error:
        print('  ERROR HTTP:', error.code, error.reason)
        if error.code in (401,403,429,503): print('  Revisá bloqueo, desafío de bots o límite de solicitudes en servidor/Cloudflare.')
    except URLError as error:
        print('  ERROR de conexión/SSL:', error.reason)
    except Exception as error:
        print('  ERROR:', error)
    return None, None

def main():
    for label, agent in [('Navegador', 'Mozilla/5.0'), ('WhatsApp', 'WhatsApp/2.0'), ('Meta', 'facebookexternalhit/1.1')]:
        print('\n===', label, '===')
        page, headers = fetch(SITE, agent, 512*1024)
        if page is None: continue
        parser = Meta(); parser.feed(page.decode('utf-8', errors='replace'))
        for key in ('og:title','og:description','og:image','og:image:type'):
            print(' ', key + ':', parser.tags.get(key, 'FALTA'))
        image = parser.tags.get('og:image')
        if not image:
            print('  La página recibida no tiene og:image. Comprobá qué portada se sirve o si se recibe un desafío de acceso.')
            continue
        image = urljoin(SITE, image)
        if urlparse(image).hostname != urlparse(SITE).hostname:
            print('  La imagen está en un servicio externo; abrí su enlace para comprobar si es pública.')
            continue
        print('  Comprobando imagen pública:')
        data, image_headers = fetch(image, agent, 3*1024*1024)
        if data is not None:
            signature = 'JPEG' if data.startswith(b'\xff\xd8') else 'PNG' if data.startswith(b'\x89PNG') else 'NO reconocida como JPEG/PNG'
            print('  Archivo:', signature, '| Bytes leídos:', len(data))
    print('\nSi las tres pruebas reciben HTML con las etiquetas y una imagen válida, comprobá la caché de la vista previa y probá el enlace en un chat nuevo.')

if __name__ == '__main__': main()
