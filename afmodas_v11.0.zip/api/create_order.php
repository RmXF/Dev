<?php
declare(strict_types=1);
// Emite el comprobante y registra el uso del cupón. El stock del panel nunca se modifica aquí.
ini_set('display_errors', '0');
require_once __DIR__ . '/cart_quote.php';
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');
header('X-Content-Type-Options: nosniff');
if (($_SERVER['REQUEST_METHOD'] ?? '') !== 'POST') cartError('Método no permitido', 405);
$input = cartInput();
$key = $input['order_key'] ?? '';
if (!is_string($key) || !preg_match('/^[a-f0-9]{32}$/D', $key)) cartError('Identificador de pedido inválido');
$hash = hash('sha256', $key);
$cartHash = hash('sha256', json_encode([$input['items'] ?? null, strtoupper(trim((string) ($input['coupon'] ?? '')))], JSON_UNESCAPED_UNICODE));
$code = strtoupper(trim((string) ($input['coupon'] ?? '')));
if (strlen($code) > 40) cartError('Cupón inválido');
$now = new DateTimeImmutable('now', new DateTimeZone('America/Argentina/Buenos_Aires'));
$number = 'AF-' . $now->format('Ymd') . '-' . strtoupper(substr($hash, 0, 8));
if ($code === '') {
    $quote = cartQuote($input);
    $quote['order_id'] = $number;
    $quote['issued_at'] = $now->format(DateTimeInterface::ATOM);
    echo json_encode($quote, JSON_UNESCAPED_UNICODE | JSON_INVALID_UTF8_SUBSTITUTE);
    exit;
}
$path = __DIR__ . '/../data/coupons.json';
$lock = @fopen(__DIR__ . '/../data/coupons.lock', 'c');
if (!$lock || !@flock($lock, LOCK_EX)) cartError('No se pudo reservar el cupón', 503);
$coupons = cartRead($path, 'Cupones');
$position = null;
foreach ($coupons as $i => $entry) if (is_array($entry) && strtoupper(trim((string) ($entry['code'] ?? ''))) === $code) { $position = $i; break; }
if ($position === null) cartError('El cupón no existe', 422);
$prior = $coupons[$position]['redemptions'][$hash] ?? null;
if (is_array($prior)) {
    if (($prior['cart_hash'] ?? '') !== $cartHash) cartError('Este comprobante pertenece a otro carrito', 409);
    $stored = $prior['quote'] ?? null;
    if (!is_array($stored)) cartError('El comprobante anterior no está disponible', 503);
    echo json_encode($stored, JSON_UNESCAPED_UNICODE | JSON_INVALID_UTF8_SUBSTITUTE);
    exit;
}
$ipHash = hash('sha256', (string) ($_SERVER['REMOTE_ADDR'] ?? 'unknown'));
$recent = 0;
foreach ($coupons as $entry) {
    foreach (($entry['redemptions'] ?? []) as $redeemed) {
        if (is_array($redeemed) && ($redeemed['ip_hash'] ?? '') === $ipHash
            && (int) ($redeemed['time'] ?? 0) >= time() - 3600) $recent++;
    }
}
if ($recent >= 10) cartError('Demasiados comprobantes con cupón. Intentá más tarde.', 429);
$quote = cartQuote($input, $coupons);
$quote['order_id'] = $number;
$quote['issued_at'] = $now->format(DateTimeInterface::ATOM);
$coupons[$position]['used'] = (int) ($coupons[$position]['used'] ?? 0) + 1;
if (!isset($coupons[$position]['redemptions']) || !is_array($coupons[$position]['redemptions'])) $coupons[$position]['redemptions'] = [];
$coupons[$position]['redemptions'][$hash] = ['cart_hash' => $cartHash, 'quote' => $quote, 'ip_hash' => $ipHash, 'time' => time()];
$json = json_encode($coupons, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_INVALID_UTF8_SUBSTITUTE);
$temp = @tempnam(dirname($path), '.coupons-');
if ($json === false || $temp === false) cartError('No se pudo emitir el comprobante', 503);
$mode = @fileperms($path);
if (@file_put_contents($temp, $json, LOCK_EX) !== strlen($json)) { @unlink($temp); cartError('No se pudo registrar el cupón', 503); }
@chmod($temp, $mode === false ? 0640 : ($mode & 0777));
if (!@rename($temp, $path)) { @unlink($temp); cartError('No se pudo guardar el uso del cupón', 503); }
echo json_encode($quote, JSON_UNESCAPED_UNICODE | JSON_INVALID_UTF8_SUBSTITUTE);
