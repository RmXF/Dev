<?php
/**
 * AF MODAS · Toggle Web
 * 
 * Activa o desactiva la web pública usando .htaccess
 * 
 * POST /api/toggle_web.php
 * Body: { "enabled": true }  → activa la web
 *       { "enabled": false } → apaga la web (redirige a 404.html)
 */

error_reporting(0);
ini_set('display_errors', 0);

header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') { exit(0); }

require_once __DIR__ . '/log_activity.php';

// ============================================================
// CONFIGURACIÓN
// ============================================================
$rootDir = __DIR__ . '/..';                        // /var/www/html
$htaccessFile = $rootDir . '/.htaccess';           // .htaccess principal
$htaccessBackup = $rootDir . '/.htaccess.backup';  // backup del original
$dataDir = $rootDir . '/data';
$settingsFile = $dataDir . '/settings.json';

// ============================================================
// VERIFICAR MÉTODO
// ============================================================
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'message' => 'Método no permitido']);
    exit;
}

// ============================================================
// LEER INPUT
// ============================================================
$input = json_decode(file_get_contents('php://input'), true);

if (!is_array($input) || !isset($input['enabled'])) {
    echo json_encode(['success' => false, 'message' => 'Falta el parámetro enabled']);
    exit;
}

$enabled = filter_var($input['enabled'], FILTER_VALIDATE_BOOLEAN);

// ============================================================
// CONTENIDO DEL .HTACCESS NORMAL
// ============================================================
$htaccessNormal = <<<'HTACCESS'
<IfModule mod_rewrite.c>

    RewriteEngine On
    RewriteBase /

    # NO reescribir nada dentro de /admin/
    RewriteCond %{REQUEST_URI} ^/admin/
    RewriteRule ^ - [L]

    # NO reescribir nada dentro de /api/
    RewriteCond %{REQUEST_URI} ^/api/
    RewriteRule ^ - [L]

    # NO reescribir nada dentro de /data/
    RewriteCond %{REQUEST_URI} ^/data/
    RewriteRule ^ - [L]

    # NO reescribir archivos o carpetas existentes
    RewriteCond %{REQUEST_FILENAME} !-f
    RewriteCond %{REQUEST_FILENAME} !-d

    # Reescribir el resto a index.html
    RewriteRule ^(.*)$ index.php?url=$1 [QSA,L]

</IfModule>

<FilesMatch "\.(json|env|sql)$">
    Order Deny,Allow
    Deny from all
</FilesMatch>

Options -Indexes
HTACCESS;

// ============================================================
// CONTENIDO DEL .HTACCESS DE MANTENIMIENTO
// ============================================================
$htaccessMaintenance = <<<'HTACCESS'
<IfModule mod_rewrite.c>

    RewriteEngine On
    RewriteBase /

    # NO reescribir nada dentro de /admin/
    RewriteCond %{REQUEST_URI} ^/admin/
    RewriteRule ^ - [L]

    # NO reescribir nada dentro de /api/
    RewriteCond %{REQUEST_URI} ^/api/
    RewriteRule ^ - [L]

    # NO reescribir nada dentro de /data/
    RewriteCond %{REQUEST_URI} ^/data/
    RewriteRule ^ - [L]

    # Permitir acceso a 404.html
    RewriteCond %{REQUEST_URI} ^/404\.html$
    RewriteRule ^ - [L]

    # Permitir archivos estáticos (imágenes, css, js del 404)
    RewriteCond %{REQUEST_URI} \.(css|js|png|jpg|jpeg|gif|svg|ico|woff|woff2|ttf)$
    RewriteRule ^ - [L]

    # Redirigir TODAS las demás URLs a 404.html
    RewriteRule ^(.*)$ 404.html [L]

</IfModule>

<FilesMatch "\.(json|env|sql)$">
    Order Deny,Allow
    Deny from all
</FilesMatch>

Options -Indexes
HTACCESS;

// ============================================================
// APLICAR CAMBIO
// ============================================================
try {
    // Hacer backup si no existe
    if (!file_exists($htaccessBackup) && file_exists($htaccessFile)) {
        @copy($htaccessFile, $htaccessBackup);
    }

    if ($enabled) {
        // ACTIVAR WEB → restaurar .htaccess normal
        if (file_put_contents($htaccessFile, $htaccessNormal, LOCK_EX) === false) {
            throw new Exception('No se pudo escribir el .htaccess');
        }
    } else {
        // APAGAR WEB → aplicar .htaccess de mantenimiento
        if (file_put_contents($htaccessFile, $htaccessMaintenance, LOCK_EX) === false) {
            throw new Exception('No se pudo escribir el .htaccess');
        }
    }

    // Guardar el estado en settings.json
    if (is_dir($dataDir)) {
        $settings = [];
        if (file_exists($settingsFile)) {
            $content = @file_get_contents($settingsFile);
            if ($content) {
                $decoded = json_decode($content, true);
                if (is_array($decoded)) {
                    $settings = isset($decoded['config']) ? $decoded['config'] : $decoded;
                }
            }
        }
        $settings['web_enabled'] = $enabled;
        $settings['updated_at'] = date('c');

        @file_put_contents(
            $settingsFile,
            json_encode($settings, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE),
            LOCK_EX
        );
    }

    // ⭐ REGISTRAR ACTIVIDAD: web activada/apagada
    if ($enabled) {
        logActivityEvent(
            'web_toggle',
            '🟢 Web activada',
            'La tienda volvió a estar disponible para los clientes'
        );
    } else {
        logActivityEvent(
            'web_toggle',
            '🔴 Web apagada',
            'Los clientes verán la pantalla de mantenimiento 404'
        );
    }

    echo json_encode([
        'success' => true,
        'enabled' => $enabled,
        'message' => $enabled
            ? '✅ Web activada correctamente'
            : '🔴 Web apagada · Los clientes verán la pantalla 404'
    ]);

} catch (Exception $e) {
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'message' => 'Error: ' . $e->getMessage()
    ]);
}