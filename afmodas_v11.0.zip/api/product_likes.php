<?php
declare(strict_types=1);
// Un voto por navegador y prenda. Los votos se guardan fuera de la web pública.
ini_set('display_errors', '0');
require_once __DIR__ . '/security.php';

$method = $_SERVER['REQUEST_METHOD'] ?? 'GET';
if (!in_array($method, ['GET', 'POST'], true)) {
    header('Allow: GET, POST');
    af_json(['success' => false, 'message' => 'Método no permitido'], 405);
}
$dir = __DIR__ . '/../data';
$file = $dir . '/likes.json';
$ranking = $method === 'GET' && ($_GET['ranking'] ?? '') === '1';
if ($ranking) af_require_admin();

function likesError(string $message, int $status = 503): void {
    af_json(['success' => false, 'message' => $message], $status);
}
function likesSecret(string $dir): string {
    $file = $dir . '/likes_secret.key';
    $handle = @fopen($file, 'c+');
    if (!$handle || !@flock($handle, LOCK_EX)) likesError('No se pudo iniciar la identificación');
    @chmod($file, 0600);
    $secret = trim((string) stream_get_contents($handle));
    if (strlen($secret) !== 64 || !ctype_xdigit($secret)) {
        $secret = bin2hex(random_bytes(32));
        rewind($handle);
        if (!ftruncate($handle, 0) || fwrite($handle, $secret) !== 64 || !fflush($handle)) {
            fclose($handle); likesError('No se pudo guardar la identificación');
        }
    }
    flock($handle, LOCK_UN);
    fclose($handle);
    return $secret;
}
function likesVisitor(string $secret): string {
    $cookie = $_COOKIE['af_like_visitor'] ?? '';
    if (is_string($cookie) && preg_match('/^[a-f0-9]{32}\.[a-f0-9]{64}$/D', $cookie)) {
        [$id, $signature] = explode('.', $cookie, 2);
        if (hash_equals(hash_hmac('sha256', $id, $secret), $signature)) return $id;
    }
    $id = bin2hex(random_bytes(16));
    $value = $id . '.' . hash_hmac('sha256', $id, $secret);
    $secure = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') || (int) ($_SERVER['SERVER_PORT'] ?? 0) === 443;
    setcookie('af_like_visitor', $value, [
        'expires' => time() + 365 * 86400, 'path' => '/', 'secure' => $secure,
        'httponly' => true, 'samesite' => 'Lax'
    ]);
    return $id;
}
function likesRead(string $file): array {
    if (!is_file($file)) return [];
    $raw = @file_get_contents($file);
    $data = $raw === false ? null : json_decode($raw, true);
    if (!is_array($data) || !is_array($data['items'] ?? null)) likesError('No se pudieron leer los votos');
    return $data['items'];
}
function likesProduct(string $dir, string $code): bool {
    $raw = @file_get_contents($dir . '/products.json');
    $products = $raw === false ? null : json_decode($raw, true);
    if (isset($products['products']) && is_array($products['products'])) $products = $products['products'];
    if (!is_array($products)) likesError('Catálogo no disponible');
    foreach ($products as $product) {
        if (is_array($product) && (string) ($product['code'] ?? '') === $code) return true;
    }
    return false;
}

if ($ranking) {
    $items = likesRead($file);
    $raw = @file_get_contents($dir . '/products.json');
    $products = $raw === false ? null : json_decode($raw, true);
    if (isset($products['products']) && is_array($products['products'])) $products = $products['products'];
    if (!is_array($products)) likesError('Catálogo no disponible');
    $list = [];
    $known = [];
    foreach ($products as $product) {
        if (!is_array($product)) continue;
        $code = (string) ($product['code'] ?? '');
        $known[$code] = true;
        $count = is_array($items[$code] ?? null) ? count($items[$code]) : 0;
        if ($code !== '' && $count > 0) {
            $list[] = ['code' => $code, 'name' => (string) ($product['name'] ?? 'Prenda'), 'likes' => $count];
        }
    }
    foreach ($items as $code => $votes) {
        if (!isset($known[$code]) && is_array($votes) && count($votes) > 0) {
            $list[] = ['code' => (string) $code, 'name' => 'Prenda retirada · #' . $code, 'likes' => count($votes), 'removed' => true];
        }
    }
    usort($list, static function ($a, $b) {
        return $b['likes'] <=> $a['likes'] ?: strcmp($a['name'], $b['name']);
    });
    $total = array_sum(array_column($list, 'likes'));
    af_json(['success' => true, 'total' => $total, 'data' => $list]);
}

$code = $method === 'GET' ? ($_GET['code'] ?? '') : '';
if ($method === 'POST') {
    if (stripos($_SERVER['CONTENT_TYPE'] ?? '', 'application/json') !== 0) likesError('Contenido inválido', 415);
    $origin = $_SERVER['HTTP_ORIGIN'] ?? '';
    if ($origin !== '') {
        $host = strtolower((string) ($_SERVER['HTTP_HOST'] ?? ''));
        if (strtolower((string) parse_url($origin, PHP_URL_HOST)) !== explode(':', $host)[0]) likesError('Origen no permitido', 403);
    }
    $raw = @file_get_contents('php://input', false, null, 0, 1025);
    if ($raw === false || strlen($raw) > 1024) likesError('Solicitud demasiado grande', 413);
    $body = json_decode($raw, true);
    $code = is_array($body) ? ($body['code'] ?? '') : '';
}
if (!is_string($code) || $code === '' || strlen($code) > 80) likesError('Código inválido', 400);
if (!likesProduct($dir, $code)) likesError('La prenda no existe', 404);

$secret = likesSecret($dir);
$visitor = likesVisitor($secret);
$id = hash_hmac('sha256', $visitor, $secret);
if ($method === 'GET') {
    $items = likesRead($file);
    $votes = is_array($items[$code] ?? null) ? $items[$code] : [];
    af_json(['success' => true, 'liked' => isset($votes[$id])]);
}

$lock = @fopen($dir . '/likes.lock', 'c');
if (!$lock || !@flock($lock, LOCK_EX)) likesError('No se pudo guardar el voto');
$items = likesRead($file);
$votes = is_array($items[$code] ?? null) ? $items[$code] : [];
if (!isset($votes[$id])) {
    $votes[$id] = time();
    $items[$code] = $votes;
    $json = json_encode(['version' => 1, 'items' => (object) $items], JSON_UNESCAPED_UNICODE);
    $temp = @tempnam($dir, '.likes-');
    if ($json === false || $temp === false || @file_put_contents($temp, $json, LOCK_EX) !== strlen($json)) {
        if ($temp) @unlink($temp);
        likesError('No se pudo guardar el voto');
    }
    @chmod($temp, 0640);
    if (!@rename($temp, $file)) { @unlink($temp); likesError('No se pudo guardar el voto'); }
}
af_json(['success' => true, 'liked' => true]);
