<?php
/**
 * AF MODAS · VPS Monitor API
 * 
 * Endpoint seguro para obtener métricas reales del VPS
 * Lee desde /proc, df, free, uptime, ps
 * 
 * Uso: GET /api/vps_monitor.php
 */

error_reporting(E_ALL);
ini_set('display_errors', 0);

header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-cache, no-store, must-revalidate');
header('Pragma: no-cache');
header('Expires: 0');

// ============================================================
// CONFIGURACIÓN
// ============================================================
$CONFIG = [
    'services' => ['apache2', 'mysql', 'ssh', 'cron'],
    'top_processes' => 10,          // procesos top a devolver
    'cache_ttl' => 2,                // segundos de caché (evitar sobrecarga)
];

// ============================================================
// CACHÉ SIMPLE (evita ejecutar comandos si se llama varias veces)
// ============================================================
$cacheDir = __DIR__ . '/../data';
$cacheFile = $cacheDir . '/vps_cache.json';

if (!is_dir($cacheDir)) {
    @mkdir($cacheDir, 0755, true);
}

if (file_exists($cacheFile)) {
    $cacheAge = time() - filemtime($cacheFile);
    if ($cacheAge < $CONFIG['cache_ttl']) {
        $cached = @file_get_contents($cacheFile);
        if ($cached) {
            echo $cached;
            exit;
        }
    }
}

// ============================================================
// HELPERS
// ============================================================
function readFileSafe($path) {
    if (!is_readable($path)) return null;
    return @file_get_contents($path);
}

function execSafe($cmd) {
    // Solo comandos definidos internamente (nunca de input del usuario)
    $output = [];
    $retval = 0;
    @exec($cmd . ' 2>/dev/null', $output, $retval);
    return $output;
}

function bytesToMb($bytes) {
    return round($bytes / 1024 / 1024, 2);
}

function bytesToGb($bytes) {
    return round($bytes / 1024 / 1024 / 1024, 2);
}

// ============================================================
// 1. CPU (desde /proc/stat)
// ============================================================
function getCpuStats() {
    $stat = readFileSafe('/proc/stat');
    if (!$stat) return null;

    $lines = explode("\n", $stat);
    $cores = [];
    $globalStats = null;

    foreach ($lines as $line) {
        if (preg_match('/^cpu\s+(.+)$/', $line, $m)) {
            $parts = preg_split('/\s+/', trim($m[1]));
            $user = (int)$parts[0];
            $nice = (int)$parts[1];
            $system = (int)$parts[2];
            $idle = (int)$parts[3];
            $iowait = isset($parts[4]) ? (int)$parts[4] : 0;
            $irq = isset($parts[5]) ? (int)$parts[5] : 0;
            $softirq = isset($parts[6]) ? (int)$parts[6] : 0;

            $total = $user + $nice + $system + $idle + $iowait + $irq + $softirq;
            $active = $total - $idle - $iowait;

            $globalStats = [
                'user' => $user,
                'system' => $system,
                'idle' => $idle,
                'iowait' => $iowait,
                'total' => $total,
                'active' => $active,
            ];
        } elseif (preg_match('/^cpu(\d+)\s+(.+)$/', $line, $m)) {
            $parts = preg_split('/\s+/', trim($m[2]));
            $user = (int)$parts[0];
            $system = (int)$parts[2];
            $idle = (int)$parts[3];
            $total = $user + $system + $idle;
            $active = $total - $idle;

            $cores[] = [
                'id' => (int)$m[1],
                'active' => $active,
                'total' => $total,
            ];
        }
    }

    return ['global' => $globalStats, 'cores' => $cores];
}

// Calcular % desde dos muestras
function calculateCpuPercent($prev, $curr) {
    if (!$prev || !$curr) return null;

    $deltaTotal = $curr['total'] - $prev['total'];
    $deltaActive = $curr['active'] - $prev['active'];
    $deltaUser = $curr['user'] - $prev['user'];
    $deltaSystem = $curr['system'] - $prev['system'];
    $deltaIowait = $curr['iowait'] - $prev['iowait'];
    $deltaIdle = $curr['idle'] - $prev['idle'];

    if ($deltaTotal <= 0) return null;

    return [
        'total' => round(($deltaActive / $deltaTotal) * 100, 1),
        'user' => round(($deltaUser / $deltaTotal) * 100, 1),
        'system' => round(($deltaSystem / $deltaTotal) * 100, 1),
        'iowait' => round(($deltaIowait / $deltaTotal) * 100, 1),
        'idle' => round(($deltaIdle / $deltaTotal) * 100, 1),
    ];
}

// Muestreo en 2 puntos con 200ms de separación
function sampleCpu() {
    $s1 = getCpuStats();
    usleep(200000); // 200ms
    $s2 = getCpuStats();

    if (!$s1 || !$s2) return null;

    $percent = calculateCpuPercent($s1['global'], $s2['global']);

    // Por núcleo
    $coresPercent = [];
    foreach ($s2['cores'] as $i => $core) {
        if (isset($s1['cores'][$i])) {
            $c = calculateCpuPercent($s1['cores'][$i], $core);
            if ($c) {
                $coresPercent[] = $c['total'];
            }
        }
    }

    return array_merge($percent ?: ['total'=>0,'user'=>0,'system'=>0,'iowait'=>0,'idle'=>0], [
        'cores' => $coresPercent
    ]);
}

// ============================================================
// 2. RAM y SWAP (desde /proc/meminfo)
// ============================================================
function getMemoryStats() {
    $meminfo = readFileSafe('/proc/meminfo');
    if (!$meminfo) return null;

    $data = [];
    foreach (explode("\n", $meminfo) as $line) {
        if (preg_match('/^(\w+):\s+(\d+)/', $line, $m)) {
            $data[$m[1]] = (int)$m[2]; // en KB
        }
    }

    $totalKb = $data['MemTotal'] ?? 0;
    $freeKb = $data['MemFree'] ?? 0;
    $availableKb = $data['MemAvailable'] ?? $freeKb;
    $buffersKb = $data['Buffers'] ?? 0;
    $cachedKb = $data['Cached'] ?? 0;
    $usedKb = $totalKb - $availableKb;

    $ram = [
        'total_mb' => round($totalKb / 1024, 2),
        'used_mb' => round($usedKb / 1024, 2),
        'available_mb' => round($availableKb / 1024, 2),
        'free_mb' => round($freeKb / 1024, 2),
        'buffers_mb' => round($buffersKb / 1024, 2),
        'cached_mb' => round($cachedKb / 1024, 2),
        'percent' => $totalKb > 0 ? round(($usedKb / $totalKb) * 100, 1) : 0,
    ];

    // SWAP
    $swapTotalKb = $data['SwapTotal'] ?? 0;
    $swapFreeKb = $data['SwapFree'] ?? 0;
    $swapUsedKb = $swapTotalKb - $swapFreeKb;

    $swap = [
        'total_mb' => round($swapTotalKb / 1024, 2),
        'used_mb' => round($swapUsedKb / 1024, 2),
        'free_mb' => round($swapFreeKb / 1024, 2),
        'percent' => $swapTotalKb > 0 ? round(($swapUsedKb / $swapTotalKb) * 100, 1) : 0,
    ];

    return ['ram' => $ram, 'swap' => $swap];
}

// ============================================================
// 3. DISCO (df -k)
// ============================================================
function getDiskStats() {
    $output = execSafe('df -k --output=source,fstype,size,used,avail,pcent,target 2>/dev/null');
    if (empty($output)) {
        $output = execSafe('df -k');
    }

    $partitions = [];
    foreach ($output as $i => $line) {
        if ($i === 0) continue; // cabecera
        $parts = preg_split('/\s+/', trim($line));
        if (count($parts) < 6) continue;

        // Formato: source fstype size used avail pcent target
        $source = $parts[0] ?? '';
        $fstype = $parts[1] ?? '';
        $sizeKb = (int)str_replace('%', '', $parts[2] ?? 0);
        $usedKb = (int)str_replace('%', '', $parts[3] ?? 0);
        $availKb = (int)str_replace('%', '', $parts[4] ?? 0);
        $pcent = (int)str_replace('%', '', $parts[5] ?? 0);
        $target = $parts[6] ?? '';

        // Filtrar particiones virtuales (tmpfs, devtmpfs, etc.)
        if (in_array($fstype, ['tmpfs', 'devtmpfs', 'squashfs', 'overlay', 'proc', 'sysfs'])) {
            continue;
        }

        if ($sizeKb > 0 && $target) {
            $partitions[] = [
                'source' => $source,
                'fstype' => $fstype,
                'mount' => $target,
                'total_gb' => round($sizeKb / 1024 / 1024, 2),
                'used_gb' => round($usedKb / 1024 / 1024, 2),
                'avail_gb' => round($availKb / 1024 / 1024, 2),
                'percent' => $pcent,
            ];
        }
    }

    // Disco principal (raíz /)
    $main = null;
    foreach ($partitions as $p) {
        if ($p['mount'] === '/') { $main = $p; break; }
    }
    if (!$main && !empty($partitions)) $main = $partitions[0];

    return [
        'main' => $main,
        'partitions' => $partitions,
    ];
}

// ============================================================
// 4. NETWORK (desde /proc/net/dev)
// ============================================================
function getNetworkStats() {
    $dev = readFileSafe('/proc/net/dev');
    if (!$dev) return null;

    $rx = 0; $tx = 0;
    $lines = explode("\n", $dev);
    foreach ($lines as $i => $line) {
        if ($i < 2) continue; // cabecera
        if (preg_match('/^\s*(\S+):\s+(.+)$/', $line, $m)) {
            $iface = $m[1];
            if ($iface === 'lo') continue; // ignorar loopback

            $parts = preg_split('/\s+/', trim($m[2]));
            if (count($parts) >= 9) {
                $rx += (int)$parts[0];  // RX bytes
                $tx += (int)$parts[8];  // TX bytes
            }
        }
    }

    return [
        'rx_bytes' => $rx,
        'tx_bytes' => $tx,
        'rx_mb' => round($rx / 1024 / 1024, 2),
        'tx_mb' => round($tx / 1024 / 1024, 2),
    ];
}

// ============================================================
// 5. LOAD AVERAGE (desde /proc/loadavg)
// ============================================================
function getLoadStats() {
    $loadavg = readFileSafe('/proc/loadavg');
    if (!$loadavg) return null;

    $parts = preg_split('/\s+/', trim($loadavg));

    // Contar CPUs
    $cpuinfo = readFileSafe('/proc/cpuinfo');
    $cores = 0;
    if ($cpuinfo) {
        $cores = preg_match_all('/^processor\s*:/m', $cpuinfo);
    }
    if ($cores === 0) $cores = 1;

    $load1 = (float)($parts[0] ?? 0);
    $load5 = (float)($parts[1] ?? 0);
    $load15 = (float)($parts[2] ?? 0);

    // Calcular estado según carga relativa
    $ratio = $load1 / $cores;
    $status = 'normal';
    if ($ratio > 1.5) $status = 'critical';
    elseif ($ratio > 0.8) $status = 'warning';

    return [
        'load_1' => $load1,
        'load_5' => $load5,
        'load_15' => $load15,
        'cores' => $cores,
        'ratio' => round($ratio, 2),
        'status' => $status,
    ];
}

// ============================================================
// 6. UPTIME (desde /proc/uptime)
// ============================================================
function getUptimeStats() {
    $uptimeRaw = readFileSafe('/proc/uptime');
    if (!$uptimeRaw) return null;

    $parts = explode(' ', $uptimeRaw);
    $uptime = (float)($parts[0] ?? 0);

    $days = floor($uptime / 86400);
    $hours = floor(($uptime % 86400) / 3600);
    $minutes = floor(($uptime % 3600) / 60);
    $seconds = floor($uptime % 60);

    $bootTime = time() - (int)$uptime;

    return [
        'seconds' => (int)$uptime,
        'days' => (int)$days,
        'hours' => (int)$hours,
        'minutes' => (int)$minutes,
        'seconds_rem' => (int)$seconds,
        'boot_time' => date('Y-m-d H:i:s', $bootTime),
        'formatted' => $days . 'd ' . $hours . 'h ' . $minutes . 'm',
    ];
}

// ============================================================
// 7. PROCESOS (ps aux)
// ============================================================
function getProcessStats($limit = 10) {
    // --sort=-%cpu: ordenar por CPU descendente
    $output = execSafe('ps aux --sort=-%cpu --no-headers 2>/dev/null');
    if (empty($output)) return [];

    $procs = [];
    foreach ($output as $line) {
        $parts = preg_split('/\s+/', trim($line), 11);
        if (count($parts) < 11) continue;

        $procs[] = [
            'user' => $parts[0],
            'pid' => (int)$parts[1],
            'cpu' => (float)$parts[2],
            'ram' => (float)$parts[3],
            'vsz' => (int)$parts[4],
            'rss' => (int)$parts[5],
            'state' => $parts[7],
            'name' => $parts[10],
        ];

        if (count($procs) >= $limit) break;
    }

    return $procs;
}

// ============================================================
// 8. SERVICIOS (systemctl)
// ============================================================
function getServiceStats($services) {
    $result = [];
    foreach ($services as $svc) {
        $status = trim(implode(' ', execSafe('systemctl is-active ' . escapeshellarg($svc))));
        $isActive = ($status === 'active');

        // Obtener uptime del servicio
        $uptimeInfo = '';
        if ($isActive) {
            $lines = execSafe('systemctl show ' . escapeshellarg($svc) . ' --property=ActiveEnterTimestamp');
            if (!empty($lines) && preg_match('/ActiveEnterTimestamp=(.+)/', $lines[0], $m)) {
                $timestamp = strtotime($m[1]);
                if ($timestamp) {
                    $since = time() - $timestamp;
                    $d = floor($since / 86400);
                    $h = floor(($since % 86400) / 3600);
                    if ($d > 0) $uptimeInfo = $d . 'd ' . $h . 'h';
                    else $uptimeInfo = $h . 'h';
                }
            }
        }

        $result[] = [
            'name' => $svc,
            'status' => $isActive ? 'active' : $status,
            'uptime' => $uptimeInfo,
        ];
    }
    return $result;
}

// ============================================================
// RECOPILAR TODAS LAS MÉTRICAS
// ============================================================
$response = [
    'success' => true,
    'timestamp' => time(),
    'timestamp_iso' => date('c'),
];

// CPU
$cpu = sampleCpu();
$response['cpu'] = $cpu;

// RAM y SWAP
$mem = getMemoryStats();
$response['ram'] = $mem['ram'] ?? null;
$response['swap'] = $mem['swap'] ?? null;

// DISCO
$response['disk'] = getDiskStats();

// NETWORK
$response['network'] = getNetworkStats();

// LOAD
$response['load'] = getLoadStats();

// UPTIME
$response['uptime'] = getUptimeStats();

// PROCESOS
$response['processes'] = getProcessStats($CONFIG['top_processes']);

// SERVICIOS
$response['services'] = getServiceStats($CONFIG['services']);

// ============================================================
// GUARDAR EN CACHÉ
// ============================================================
$json = json_encode($response, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
@file_put_contents($cacheFile, $json, LOCK_EX);

echo $json;