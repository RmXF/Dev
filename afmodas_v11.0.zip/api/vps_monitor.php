<?php
/**
 * AF MODAS · VPS Monitor API
 */

error_reporting(E_ALL);
ini_set('display_errors', 0);

header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-cache, no-store, must-revalidate');

$CONFIG = [
    'services' => ['apache2', 'mysql', 'ssh', 'cron'],
    'top_processes' => 10,
    'cache_ttl' => 2,
];

$cacheDir = __DIR__ . '/../data';
$cacheFile = $cacheDir . '/vps_cache.json';

if (!is_dir($cacheDir)) @mkdir($cacheDir, 0755, true);

if (file_exists($cacheFile)) {
    $cacheAge = time() - filemtime($cacheFile);
    if ($cacheAge < $CONFIG['cache_ttl']) {
        echo @file_get_contents($cacheFile);
        exit;
    }
}

function readFileSafe($path) {
    return is_readable($path) ? @file_get_contents($path) : null;
}

function execSafe($cmd) {
    $output = [];
    @exec($cmd . ' 2>/dev/null', $output);
    return $output;
}

function getCpuStats() {
    $stat = readFileSafe('/proc/stat');
    if (!$stat) return null;
    $lines = explode("\n", $stat);
    $cores = [];
    $globalStats = null;
    foreach ($lines as $line) {
        if (preg_match('/^cpu\s+(.+)$/', $line, $m)) {
            $parts = preg_split('/\s+/', trim($m[1]));
            $user = (int)$parts[0];
            $system = (int)$parts[2];
            $idle = (int)$parts[3];
            $iowait = isset($parts[4]) ? (int)$parts[4] : 0;
            $total = $user + $system + $idle + $iowait;
            $globalStats = ['user'=>$user,'system'=>$system,'idle'=>$idle,'iowait'=>$iowait,'total'=>$total,'active'=>$total-$idle];
        } elseif (preg_match('/^cpu(\d+)\s+(.+)$/', $line, $m)) {
            $parts = preg_split('/\s+/', trim($m[2]));
            $user = (int)$parts[0];
            $system = (int)$parts[2];
            $idle = (int)$parts[3];
            $total = $user + $system + $idle;
            $cores[] = ['id'=>(int)$m[1],'active'=>$total-$idle,'total'=>$total];
        }
    }
    return ['global'=>$globalStats,'cores'=>$cores];
}

function calculateCpuPercent($prev, $curr) {
    if (!$prev || !$curr) return null;
    $dTotal = $curr['total'] - $prev['total'];
    $dActive = $curr['active'] - $prev['active'];
    $dUser = $curr['user'] - $prev['user'];
    $dSystem = $curr['system'] - $prev['system'];
    $dIowait = $curr['iowait'] - $prev['iowait'];
    $dIdle = $curr['idle'] - $prev['idle'];
    if ($dTotal <= 0) return null;
    return [
        'total'=>round(($dActive/$dTotal)*100,1),
        'user'=>round(($dUser/$dTotal)*100,1),
        'system'=>round(($dSystem/$dTotal)*100,1),
        'iowait'=>round(($dIowait/$dTotal)*100,1),
        'idle'=>round(($dIdle/$dTotal)*100,1),
    ];
}

function sampleCpu() {
    $s1 = getCpuStats();
    usleep(200000);
    $s2 = getCpuStats();
    if (!$s1 || !$s2) return null;
    $percent = calculateCpuPercent($s1['global'], $s2['global']);
    $coresPercent = [];
    foreach ($s2['cores'] as $i => $core) {
        if (isset($s1['cores'][$i])) {
            $c = calculateCpuPercent($s1['cores'][$i], $core);
            if ($c) $coresPercent[] = $c['total'];
        }
    }
    return array_merge($percent ?: ['total'=>0,'user'=>0,'system'=>0,'iowait'=>0,'idle'=>0], ['cores'=>$coresPercent]);
}

function getMemoryStats() {
    $meminfo = readFileSafe('/proc/meminfo');
    if (!$meminfo) return null;
    $data = [];
    foreach (explode("\n", $meminfo) as $line) {
        if (preg_match('/^(\w+):\s+(\d+)/', $line, $m)) $data[$m[1]] = (int)$m[2];
    }
    $totalKb = $data['MemTotal'] ?? 0;
    $freeKb = $data['MemFree'] ?? 0;
    $availableKb = $data['MemAvailable'] ?? $freeKb;
    $buffersKb = $data['Buffers'] ?? 0;
    $cachedKb = $data['Cached'] ?? 0;
    $usedKb = $totalKb - $availableKb;
    $ram = [
        'total_mb'=>round($totalKb/1024,2),
        'used_mb'=>round($usedKb/1024,2),
        'available_mb'=>round($availableKb/1024,2),
        'free_mb'=>round($freeKb/1024,2),
        'buffers_mb'=>round($buffersKb/1024,2),
        'cached_mb'=>round($cachedKb/1024,2),
        'percent'=>$totalKb>0?round(($usedKb/$totalKb)*100,1):0,
    ];
    $swapTotalKb = $data['SwapTotal'] ?? 0;
    $swapFreeKb = $data['SwapFree'] ?? 0;
    $swapUsedKb = $swapTotalKb - $swapFreeKb;
    $swap = [
        'total_mb'=>round($swapTotalKb/1024,2),
        'used_mb'=>round($swapUsedKb/1024,2),
        'free_mb'=>round($swapFreeKb/1024,2),
        'percent'=>$swapTotalKb>0?round(($swapUsedKb/$swapTotalKb)*100,1):0,
    ];
    return ['ram'=>$ram,'swap'=>$swap];
}

function getDiskStats() {
    $output = execSafe('df -k');
    $partitions = [];
    foreach ($output as $i => $line) {
        if ($i === 0) continue;
        $parts = preg_split('/\s+/', trim($line));
        if (count($parts) < 6) continue;
        $source = $parts[0]; $sizeKb = (int)$parts[1]; $usedKb = (int)$parts[2];
        $availKb = (int)$parts[3]; $pcent = (int)str_replace('%','',$parts[4]); $target = $parts[5];
        if (strpos($source, 'tmpfs') !== false || strpos($source, 'devtmpfs') !== false) continue;
        if ($sizeKb > 0 && $target) {
            $partitions[] = [
                'source'=>$source,'mount'=>$target,
                'total_gb'=>round($sizeKb/1024/1024,2),
                'used_gb'=>round($usedKb/1024/1024,2),
                'avail_gb'=>round($availKb/1024/1024,2),
                'percent'=>$pcent,
            ];
        }
    }
    $main = null;
    foreach ($partitions as $p) if ($p['mount'] === '/') { $main = $p; break; }
    if (!$main && !empty($partitions)) $main = $partitions[0];
    return ['main'=>$main,'partitions'=>$partitions];
}

function getNetworkStats() {
    $dev = readFileSafe('/proc/net/dev');
    if (!$dev) return null;
    $rx = 0; $tx = 0;
    foreach (explode("\n", $dev) as $i => $line) {
        if ($i < 2) continue;
        if (preg_match('/^\s*(\S+):\s+(.+)$/', $line, $m)) {
            if ($m[1] === 'lo') continue;
            $parts = preg_split('/\s+/', trim($m[2]));
            if (count($parts) >= 9) {
                $rx += (int)$parts[0];
                $tx += (int)$parts[8];
            }
        }
    }
    return [
        'rx_bytes'=>$rx,'tx_bytes'=>$tx,
        'rx_mb'=>round($rx/1024/1024,2),
        'tx_mb'=>round($tx/1024/1024,2),
    ];
}

function getLoadStats() {
    $loadavg = readFileSafe('/proc/loadavg');
    if (!$loadavg) return null;
    $parts = preg_split('/\s+/', trim($loadavg));
    $cpuinfo = readFileSafe('/proc/cpuinfo');
    $cores = 0;
    if ($cpuinfo) $cores = preg_match_all('/^processor\s*:/m', $cpuinfo);
    if ($cores === 0) $cores = 1;
    $load1 = (float)($parts[0] ?? 0);
    $load5 = (float)($parts[1] ?? 0);
    $load15 = (float)($parts[2] ?? 0);
    $ratio = $load1 / $cores;
    $status = 'normal';
    if ($ratio > 1.5) $status = 'critical';
    elseif ($ratio > 0.8) $status = 'warning';
    return [
        'load_1'=>$load1,'load_5'=>$load5,'load_15'=>$load15,
        'cores'=>$cores,'ratio'=>round($ratio,2),'status'=>$status,
    ];
}

function getUptimeStats() {
    $uptimeRaw = readFileSafe('/proc/uptime');
    if (!$uptimeRaw) return null;
    $parts = explode(' ', $uptimeRaw);
    $uptime = (float)($parts[0] ?? 0);
    $days = floor($uptime / 86400);
    $hours = floor(($uptime % 86400) / 3600);
    $minutes = floor(($uptime % 3600) / 60);
    $seconds = floor($uptime % 60);
    $bootTime = time() - (int)$uptime;
    return [
        'seconds'=>(int)$uptime,'days'=>(int)$days,'hours'=>(int)$hours,
        'minutes'=>(int)$minutes,'seconds_rem'=>(int)$seconds,
        'boot_time'=>date('Y-m-d H:i:s', $bootTime),
        'formatted'=>$days.'d '.$hours.'h '.$minutes.'m',
    ];
}

function getProcessStats($limit = 10) {
    $output = execSafe('ps aux --sort=-%cpu --no-headers');
    if (empty($output)) return [];
    $procs = [];
    foreach ($output as $line) {
        $parts = preg_split('/\s+/', trim($line), 11);
        if (count($parts) < 11) continue;
        $procs[] = [
            'user'=>$parts[0],'pid'=>(int)$parts[1],'cpu'=>(float)$parts[2],
            'ram'=>(float)$parts[3],'vsz'=>(int)$parts[4],'rss'=>(int)$parts[5],
            'state'=>$parts[7],'name'=>$parts[10],
        ];
        if (count($procs) >= $limit) break;
    }
    return $procs;
}

function getServiceStats($services) {
    $result = [];
    foreach ($services as $svc) {
        $status = trim(implode(' ', execSafe('systemctl is-active ' . escapeshellarg($svc))));
        $isActive = ($status === 'active');
        $uptimeInfo = '';
        if ($isActive) {
            $lines = execSafe('systemctl show ' . escapeshellarg($svc) . ' --property=ActiveEnterTimestamp');
            if (!empty($lines) && preg_match('/ActiveEnterTimestamp=(.+)/', $lines[0], $m)) {
                $timestamp = strtotime($m[1]);
                if ($timestamp) {
                    $since = time() - $timestamp;
                    $d = floor($since / 86400);
                    $h = floor(($since % 86400) / 3600);
                    $uptimeInfo = $d > 0 ? ($d.'d '.$h.'h') : ($h.'h');
                }
            }
        }
        $result[] = ['name'=>$svc,'status'=>$isActive?'active':$status,'uptime'=>$uptimeInfo];
    }
    return $result;
}

$response = [
    'success' => true,
    'timestamp' => time(),
    'timestamp_iso' => date('c'),
];
$response['cpu'] = sampleCpu();
$mem = getMemoryStats();
$response['ram'] = $mem['ram'] ?? null;
$response['swap'] = $mem['swap'] ?? null;
$response['disk'] = getDiskStats();
$response['network'] = getNetworkStats();
$response['load'] = getLoadStats();
$response['uptime'] = getUptimeStats();
$response['processes'] = getProcessStats($CONFIG['top_processes']);
$response['services'] = getServiceStats($CONFIG['services']);

$json = json_encode($response, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
@file_put_contents($cacheFile, $json, LOCK_EX);
echo $json;
