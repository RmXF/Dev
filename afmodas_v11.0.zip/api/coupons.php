<?php
// ============================================
// AF MODAS - API CUPONES
// ============================================

header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') { exit(0); }

require_once __DIR__ . '/../config/config.php';

if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    echo json_encode(readJson('coupons'));
} elseif ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $data = json_decode(file_get_contents('php://input'), true);
    $coupons = readJson('coupons');
    $data['id'] = 'c' . time() . rand(100, 999);
    $data['createdAt'] = date('Y-m-d H:i:s');
    $coupons[] = $data;
    writeJson('coupons', $coupons);
    logActivity('coupon', 'Cupón creado', $data['code'] ?? '');
    echo json_encode(['success' => true, 'coupon' => $data]);
} elseif ($_SERVER['REQUEST_METHOD'] === 'PUT') {
    $data = json_decode(file_get_contents('php://input'), true);
    $id = $data['id'] ?? '';
    $coupons = readJson('coupons');
    foreach ($coupons as $key => $c) {
        if ($c['id'] === $id) {
            $data['updatedAt'] = date('Y-m-d H:i:s');
            $coupons[$key] = $data;
            break;
        }
    }
    writeJson('coupons', $coupons);
    echo json_encode(['success' => true]);
} elseif ($_SERVER['REQUEST_METHOD'] === 'DELETE') {
    $id = $_GET['id'] ?? '';
    $coupons = readJson('coupons');
    $coupons = array_filter($coupons, function($c) use ($id) {
        return $c['id'] !== $id;
    });
    writeJson('coupons', array_values($coupons));
    echo json_encode(['success' => true]);
}