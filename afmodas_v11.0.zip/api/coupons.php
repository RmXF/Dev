<?php
declare(strict_types=1);
// AF MODAS · Administración de cupones.
ini_set('display_errors', '0');
require_once __DIR__ . '/security.php';
require_once __DIR__ . '/log_activity.php';
af_require_admin(false);
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');

function couponReply(array $body, int $status = 200): void {
    http_response_code($status);
    echo json_encode($body, JSON_UNESCAPED_UNICODE | JSON_INVALID_UTF8_SUBSTITUTE);
    exit;
}
function couponRead(string $path): array {
    if (!is_file($path)) return [];
    $raw = @file_get_contents($path);
    $items = $raw === false ? null : json_decode($raw, true);
    if (!is_array($items)) couponReply(['success' => false, 'message' => 'No se pudo leer coupons.json'], 500);
    return array_values($items);
}
function couponWrite(string $path, array $items): void {
    $json = json_encode(array_values($items), JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_INVALID_UTF8_SUBSTITUTE);
    $temp = @tempnam(dirname($path), '.coupons-');
    if ($json === false || $temp === false) couponReply(['success' => false, 'message' => 'No se pudo guardar el cupón'], 500);
    $mode = is_file($path) ? @fileperms($path) : false;
    if (@file_put_contents($temp, $json, LOCK_EX) !== strlen($json)) { @unlink($temp); couponReply(['success' => false, 'message' => 'No se pudo escribir el cupón'], 500); }
    @chmod($temp, $mode === false ? 0640 : ($mode & 0777));
    if (!@rename($temp, $path)) { @unlink($temp); couponReply(['success' => false, 'message' => 'No se pudo reemplazar coupons.json'], 500); }
}
function couponInput(): array {
    $raw = file_get_contents('php://input', false, null, 0, 4097);
    if ($raw === false || strlen($raw) > 4096) couponReply(['success' => false, 'message' => 'Solicitud demasiado grande'], 413);
    $data = json_decode($raw, true);
    if (!is_array($data)) couponReply(['success' => false, 'message' => 'Datos inválidos'], 400);
    return $data;
}
function couponFields(array $data): array {
    $code = strtoupper(trim((string) ($data['code'] ?? '')));
    $name = trim((string) ($data['name'] ?? ''));
    $type = (string) ($data['type'] ?? '');
    $value = $data['value'] ?? null;
    $expiry = (string) ($data['expiry'] ?? '');
    $limit = $data['limit'] ?? null;
    if (!preg_match('/^[A-Z0-9_-]{3,24}$/D', $code) || strlen($name) < 2 || strlen($name) > 100
        || !in_array($type, ['percent', 'fixed', 'amount'], true) || !is_numeric($value) || !is_finite((float) $value)
        || (float) $value <= 0 || (float) $value > 10000000 || ($type === 'percent' && (float) $value > 100)
        || !preg_match('/^\d{4}-\d{2}-\d{2}$/D', $expiry) || !checkdate((int) substr($expiry, 5, 2), (int) substr($expiry, 8, 2), (int) substr($expiry, 0, 4))
        || !is_numeric($limit) || (int) $limit < 1 || (int) $limit > 100000) {
        couponReply(['success' => false, 'message' => 'Revisá código, valor, fecha y límite'], 400);
    }
    return ['code' => $code, 'name' => $name, 'type' => $type, 'value' => (float) $value,
        'expiry' => $expiry, 'limit' => (int) $limit, 'active' => !empty($data['active'])];
}

$method = $_SERVER['REQUEST_METHOD'] ?? 'GET';
if (!in_array($method, ['GET', 'POST', 'PUT', 'DELETE'], true)) couponReply(['success' => false, 'message' => 'Método no permitido'], 405);
$path = __DIR__ . '/../data/coupons.json';
if ($method === 'GET') couponReply(['success' => true, 'data' => couponRead($path)]);
$lock = @fopen(__DIR__ . '/../data/coupons.lock', 'c');
if (!$lock || !@flock($lock, LOCK_EX)) couponReply(['success' => false, 'message' => 'No se pudo bloquear cupones'], 503);
$items = couponRead($path);
$data = couponInput();
if ($method === 'DELETE') {
    $id = (string) ($data['id'] ?? '');
    $next = array_values(array_filter($items, static function ($item) use ($id) { return (string) ($item['id'] ?? '') !== $id; }));
    if ($id === '' || count($next) === count($items)) couponReply(['success' => false, 'message' => 'Cupón no encontrado'], 404);
    couponWrite($path, $next);
    logActivityEvent('coupon', 'Cupón eliminado', $id);
    couponReply(['success' => true]);
}
$fields = couponFields($data);
$id = (string) ($data['id'] ?? '');
$index = null;
foreach ($items as $i => $item) if ((string) ($item['id'] ?? '') === $id) { $index = $i; break; }
if ($method === 'PUT' && $index === null) couponReply(['success' => false, 'message' => 'Cupón no encontrado'], 404);
foreach ($items as $i => $item) {
    if ($i !== $index && strtoupper((string) ($item['code'] ?? '')) === $fields['code']) couponReply(['success' => false, 'message' => 'Ese código ya existe'], 409);
}
if ($method === 'POST') {
    $fields['id'] = 'c' . bin2hex(random_bytes(8));
    $fields['used'] = 0;
    $fields['createdAt'] = date('c');
    $items[] = $fields;
} else {
    $fields = array_merge($items[$index], $fields);
    $fields['updatedAt'] = date('c');
    $items[$index] = $fields;
}
couponWrite($path, $items);
logActivityEvent('coupon', $method === 'POST' ? 'Cupón creado' : 'Cupón actualizado', $fields['code']);
couponReply(['success' => true, 'coupon' => $fields]);
