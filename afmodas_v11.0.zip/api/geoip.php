<?php
/**
 * AF MODAS · GeoIP Proxy
 * 
 * GET /api/geoip.php?ip=1.2.3.4
 * 
 * Usa ip-api.com (gratis, sin API key, 45 req/min)
 * Si superás el límite, agregá una API key de ipinfo.io
 */

error_reporting(E_ALL);
ini_set('display_errors', 0);

header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');

// Obtener IP
$ip = $_GET['ip'] ?? '';

if (empty($ip) || !filter_var($ip, FILTER_VALIDATE_IP)) {
    echo json_encode(['success' => false, 'message' => 'IP inválida']);
    exit;
}

// IPs privadas → no buscar
if (
    preg_match('/^127\./', $ip) ||
    preg_match('/^10\./', $ip) ||
    preg_match('/^192\.168\./', $ip) ||
    preg_match('/^172\.(1[6-9]|2[0-9]|3[0-1])\./', $ip) ||
    $ip === '::1'
) {
    echo json_encode([
        'success' => true,
        'data' => [
            'ip' => $ip,
            'country' => 'Local',
            'region' => 'Red privada',
            'city' => 'Localhost',
            'lat' => 0,
            'lon' => 0,
            'isp' => 'Red local',
            'timezone' => ''
        ]
    ]);
    exit;
}

// Cache local (1 día)
$cacheDir = __DIR__ . '/../data/geoip_cache';
if (!is_dir($cacheDir)) @mkdir($cacheDir, 0755, true);

$cacheFile = $cacheDir . '/' . md5($ip) . '.json';
if (file_exists($cacheFile) && (time() - filemtime($cacheFile)) < 86400) {
    echo @file_get_contents($cacheFile);
    exit;
}

// Consultar ip-api.com
$url = "http://ip-api.com/json/{$ip}?fields=status,message,country,regionName,city,lat,lon,isp,timezone,query";

$ctx = stream_context_create([
    'http' => [
        'timeout' => 5,
        'method' => 'GET',
        'header' => "User-Agent: AF-MODAS-GeoIP\r\n"
    ]
]);

$response = @file_get_contents($url, false, $ctx);

if ($response === false) {
    // Fallback: devolver vacío
    echo json_encode([
        'success' => true,
        'data' => [
            'ip' => $ip,
            'country' => 'Desconocido',
            'region' => '',
            'city' => '',
            'lat' => 0,
            'lon' => 0,
            'isp' => '',
            'timezone' => ''
        ]
    ]);
    exit;
}

$data = json_decode($response, true);

if (!$data || $data['status'] !== 'success') {
    echo json_encode([
        'success' => false,
        'message' => 'No se pudo obtener la ubicación'
    ]);
    exit;
}

$result = [
    'success' => true,
    'data' => [
        'ip' => $data['query'] ?? $ip,
        'country' => $data['country'] ?? '',
        'region' => $data['regionName'] ?? '',
        'city' => $data['city'] ?? '',
        'lat' => $data['lat'] ?? 0,
        'lon' => $data['lon'] ?? 0,
        'isp' => $data['isp'] ?? '',
        'timezone' => $data['timezone'] ?? ''
    ]
];

$json = json_encode($result, JSON_UNESCAPED_UNICODE);
@file_put_contents($cacheFile, $json, LOCK_EX);

echo $json;