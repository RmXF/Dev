<?php
// ============================================
// AF MODAS - API CONFIGURACIÓN
// ============================================

header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') { exit(0); }

require_once __DIR__ . '/../config/config.php';

if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    $settings = readJson('settings');
    if (!isset($settings['config'])) {
        $settings['config'] = [];
    }
    echo json_encode($settings);
} elseif ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $data = json_decode(file_get_contents('php://input'), true);
    $settings = readJson('settings');
    
    if (isset($data['config'])) {
        foreach ($data['config'] as $key => $value) {
            $settings['config'][$key] = $value;
        }
    }
    
    writeJson('settings', $settings);
    echo json_encode(['success' => true]);
}