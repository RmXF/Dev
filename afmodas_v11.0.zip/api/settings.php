<?php
/**
 * AF MODAS · API de Configuración
 * 
 * GET    /api/settings.php         → Devuelve toda la configuración
 * GET    /api/settings.php?key=X   → Devuelve una configuración específica
 * POST   /api/settings.php         → Guarda la configuración
 */

error_reporting(0);
ini_set('display_errors', 0);

header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') { exit(0); }

$dataDir = __DIR__ . '/../data';
$dataFile = $dataDir . '/settings.json';

if (!is_dir($dataDir)) @mkdir($dataDir, 0755, true);

// Configuraciones por defecto
$defaults = [
    'whatsapp'    => '573001234567',
    'site_name'   => 'AF MODAS',
    'free_ship'   => 100000,
    'logo_url'    => '',
    'description' => 'Tienda de moda premium · Elegancia que trasciende',
    'web_enabled' => true,     // ⭐ NUEVO: modo mantenimiento
    'maintenance_title' => 'Sitio en mantenimiento',
    'maintenance_message' => 'Estamos actualizando nuestra tienda. Volvemos en breve ✨'
];

function readSettings($file, $defaults) {
    if (!file_exists($file)) return $defaults;
    $content = @file_get_contents($file);
    if (!$content) return $defaults;
    $data = json_decode($content, true);
    if (!is_array($data)) return $defaults;

    // Soportar estructura {config: {...}} o {...}
    if (isset($data['config']) && is_array($data['config'])) {
        return array_merge($defaults, $data['config']);
    }
    return array_merge($defaults, $data);
}

function writeSettings($file, $settings) {
    $settings['updated_at'] = date('c');
    return @file_put_contents(
        $file,
        json_encode($settings, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE),
        LOCK_EX
    );
}

$settings = readSettings($dataFile, $defaults);

// ============================================================
// GET
// ============================================================
if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    // ?key=web_enabled → devolver solo eso
    if (!empty($_GET['key'])) {
        $key = $_GET['key'];
        $value = $settings[$key] ?? null;
        echo json_encode([
            'success' => true,
            'data' => [$key => $value]
        ]);
        exit;
    }

    // Devolver todo
    echo json_encode([
        'success' => true,
        'data' => $settings
    ]);
    exit;
}

// ============================================================
// POST
// ============================================================
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $input = json_decode(file_get_contents('php://input'), true);

    if (!is_array($input)) {
        echo json_encode(['success' => false, 'message' => 'JSON inválido']);
        exit;
    }

    // Aceptar {config: {...}} o {...}
    $newConfig = isset($input['config']) ? $input['config'] : $input;

    // Convertir valores de string a tipos adecuados
    if (isset($newConfig['web_enabled'])) {
        $newConfig['web_enabled'] = filter_var($newConfig['web_enabled'], FILTER_VALIDATE_BOOLEAN);
    }
    if (isset($newConfig['free_ship'])) {
        $newConfig['free_ship'] = (int)$newConfig['free_ship'];
    }

    unset($newConfig['updated_at']);

    $settings = array_merge($settings, $newConfig);
    writeSettings($dataFile, $settings);

    echo json_encode([
        'success' => true,
        'message' => 'Configuración guardada',
        'data' => $settings
    ]);
    exit;
}

http_response_code(405);
echo json_encode(['success' => false, 'message' => 'Método no soportado']);