<?php
// ============================================
// AF MODAS - API CONFIGURACIÓN
// ============================================

error_reporting(0);
ini_set('display_errors', 0);

header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') { exit(0); }

require_once __DIR__ . '/../config/config.php';

// Configuraciones por defecto
$defaults = [
    'whatsapp'    => '573001234567',
    'site_name'   => 'AF MODAS',
    'free_ship'   => 100000,
    'logo_url'    => '',
    'description' => 'Tienda de moda premium · Elegancia que trasciende'
];

// ============================================
// GET - Obtener configuración
// ============================================
if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    $settings = readJson('settings');
    if (!is_array($settings)) $settings = [];

    // Si viene ?key=whatsapp, devolver solo eso
    if (!empty($_GET['key'])) {
        $key = $_GET['key'];
        $value = isset($settings['config'][$key])
            ? $settings['config'][$key]
            : (isset($settings[$key]) ? $settings[$key] : ($defaults[$key] ?? null));

        echo json_encode([
            'success' => true,
            'data' => [$key => $value]
        ]);
        exit;
    }

    // Devolver todo el config (mezcla con defaults)
    $config = isset($settings['config']) ? $settings['config'] : $settings;
    $config = array_merge($defaults, $config);

    echo json_encode([
        'success' => true,
        'data' => $config
    ]);
    exit;
}

// ============================================
// POST - Guardar configuración
// ============================================
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $data = json_decode(file_get_contents('php://input'), true);

    if (!is_array($data)) {
        echo json_encode(['success' => false, 'message' => 'JSON inválido']);
        exit;
    }

    $settings = readJson('settings');
    if (!is_array($settings)) $settings = [];

    // Asegurar estructura
    if (!isset($settings['config'])) {
        $settings['config'] = [];
    }

    // Aceptar dos formatos:
    // 1) {"config": {...}}  2) {...} (directo)
    $newConfig = isset($data['config']) ? $data['config'] : $data;

    unset($newConfig['updated_at']);

    $settings['config'] = array_merge($settings['config'], $newConfig);
    $settings['updated_at'] = date('c');

    writeJson('settings', $settings);

    echo json_encode([
        'success' => true,
        'message' => 'Configuración guardada',
        'data' => $settings['config']
    ]);
    exit;
}

// Método no soportado
http_response_code(405);
echo json_encode(['success' => false, 'message' => 'Método no soportado']);