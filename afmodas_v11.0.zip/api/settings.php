<?php
// ============================================
// AF MODAS - API CONFIGURACIÓN
// ============================================

header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') { exit(0); }

require_once __DIR__ . '/../config/config.php';

if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    echo json_encode(readJson('settings'));
} elseif ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $data = json_decode(file_get_contents('php://input'), true);
    $settings = readJson('settings');
    if (isset($data['config'])) {
        $settings['config'] = array_merge($settings['config'] ?? [], $data['config']);
    }
    writeJson('settings', $settings);
    echo json_encode(['success' => true]);
}