<?php
/**
 * AF MODAS · API de Notificaciones (Historias)
 * Endpoints:
 *   GET    /api/notifications.php            → Listar todas
 *   POST   /api/notifications.php            → Crear notificación
 *   DELETE /api/notifications.php?id=XXX     → Eliminar
 *   PUT    /api/notifications.php?id=XXX&renew=1 → Renovar 24h
 */

error_reporting(0);
ini_set('display_errors', 0);

header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

// ============================================================
// CONFIGURACIÓN
// ============================================================
$dataDir  = __DIR__ . '/../data';
$dataFile = $dataDir . '/notifications.json';

if (!is_dir($dataDir)) {
    @mkdir($dataDir, 0777, true);
}

if (!file_exists($dataFile)) {
    file_put_contents($dataFile, json_encode([], JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
}

// ============================================================
// HELPERS
// ============================================================
function readNotifications($file) {
    $content = @file_get_contents($file);
    if ($content === false) return [];
    $data = json_decode($content, true);
    if (!is_array($data)) return [];
    if (isset($data['notifications']) && is_array($data['notifications'])) {
        return $data['notifications'];
    }
    return $data;
}

function writeNotifications($file, $notifs) {
    $json = json_encode(array_values($notifs), JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);
    return file_put_contents($file, $json, LOCK_EX);
}

function normalizeNotification($n) {
    $created = isset($n['created_at']) ? $n['created_at'] : date('c');
    return [
        'id'         => isset($n['id']) ? (string)$n['id'] : ('n' . time() . mt_rand(100, 999)),
        'type'       => isset($n['type']) ? (string)$n['type'] : 'Información',
        'title'      => isset($n['title']) ? (string)$n['title'] : '',
        'message'    => isset($n['message']) ? (string)$n['message'] : '',
        'image'      => isset($n['image']) ? (string)$n['image'] : '',
        'created_at' => $created
    ];
}

function sendJson($data, $code = 200) {
    http_response_code($code);
    echo json_encode($data, JSON_UNESCAPED_UNICODE);
    exit;
}

// ============================================================
// ROUTER
// ============================================================
$method = $_SERVER['REQUEST_METHOD'];
$notifs = readNotifications($dataFile);

// ---------- GET ----------
if ($method === 'GET') {
    // Solo devolver las de las últimas 24h si se pide
    $onlyActive = isset($_GET['active']) && $_GET['active'] == '1';
    $result = [];

    foreach ($notifs as $n) {
        $item = normalizeNotification($n);
        if ($onlyActive) {
            $ts = strtotime($item['created_at']);
            if ($ts && (time() - $ts) < 86400) {
                $result[] = $item;
            }
        } else {
            $result[] = $item;
        }
    }

    sendJson(['success' => true, 'data' => $result]);
}

// ---------- POST (crear) ----------
if ($method === 'POST') {
    $raw = file_get_contents('php://input');
    $input = json_decode($raw, true);

    if (!is_array($input)) {
        sendJson(['success' => false, 'message' => 'JSON inválido'], 400);
    }

    if (empty($input['title']) || empty($input['message'])) {
        sendJson(['success' => false, 'message' => 'Título y mensaje son requeridos'], 400);
    }

    if (empty($input['id'])) {
        $input['id'] = 'n' . time() . mt_rand(100, 999);
    }

    $input['created_at'] = date('c');
    $notif = normalizeNotification($input);

    $notifs[] = $notif;

    if (writeNotifications($dataFile, $notifs) === false) {
        sendJson(['success' => false, 'message' => 'Error al guardar'], 500);
    }

    sendJson(['success' => true, 'message' => 'Notificación creada', 'data' => $notif], 201);
}

// ---------- PUT (renovar) ----------
if ($method === 'PUT') {
    $id = isset($_GET['id']) ? $_GET['id'] : '';
    if (empty($id)) {
        sendJson(['success' => false, 'message' => 'ID requerido'], 400);
    }

    $found = false;
    foreach ($notifs as $i => $n) {
        if (isset($n['id']) && $n['id'] === $id) {
            $notifs[$i]['created_at'] = date('c');
            $found = true;
            break;
        }
    }

    if (!$found) {
        sendJson(['success' => false, 'message' => 'Notificación no encontrada'], 404);
    }

    if (writeNotifications($dataFile, $notifs) === false) {
        sendJson(['success' => false, 'message' => 'Error al guardar'], 500);
    }

    sendJson(['success' => true, 'message' => 'Notificación renovada 24h']);
}

// ---------- DELETE ----------
if ($method === 'DELETE') {
    $id = isset($_GET['id']) ? $_GET['id'] : '';
    if (empty($id)) {
        sendJson(['success' => false, 'message' => 'ID requerido'], 400);
    }

    $newList = [];
    $found = false;
    foreach ($notifs as $n) {
        if (isset($n['id']) && $n['id'] === $id) {
            $found = true;
            continue;
        }
        $newList[] = $n;
    }

    if (!$found) {
        sendJson(['success' => false, 'message' => 'Notificación no encontrada'], 404);
    }

    if (writeNotifications($dataFile, $newList) === false) {
        sendJson(['success' => false, 'message' => 'Error al eliminar'], 500);
    }

    sendJson(['success' => true, 'message' => 'Notificación eliminada']);
}

// ---------- Método no soportado ----------
sendJson(['success' => false, 'message' => 'Método no soportado'], 405);