<?php
declare(strict_types=1);
// Historias públicas. Las escrituras del panel requieren sesión y CSRF.
ini_set('display_errors', '0');
require_once __DIR__ . '/security.php';
af_require_admin(true);
require_once __DIR__ . '/log_activity.php';
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');
header('X-Content-Type-Options: nosniff');

$dir = __DIR__ . '/../data';
$path = $dir . '/notifications.json';
$method = $_SERVER['REQUEST_METHOD'] ?? 'GET';
if (!in_array($method, ['GET','POST','PUT','DELETE'], true)) af_json(['success'=>false,'message'=>'Método no permitido'],405);
if (!is_dir($dir) && !@mkdir($dir,0750,true)) af_json(['success'=>false,'message'=>'Almacenamiento no disponible'],503);
if ($method !== 'GET') {
    $lock = @fopen($dir . '/notifications.lock','c');
    if (!$lock || !@flock($lock,LOCK_EX)) af_json(['success'=>false,'message'=>'No se pudo bloquear las notificaciones'],503);
}
function notifRead(string $path): array {
    if (!is_file($path)) return [];
    $raw = @file_get_contents($path);
    $data = $raw === false ? null : json_decode($raw,true);
    if (isset($data['notifications']) && is_array($data['notifications'])) $data = $data['notifications'];
    if (!is_array($data)) af_json(['success'=>false,'message'=>'Notificaciones no disponibles'],503);
    foreach ($data as $row) if (!is_array($row)) af_json(['success'=>false,'message'=>'Datos de notificaciones inválidos'],503);
    return array_values($data);
}
function notifWrite(string $path,array $rows): void {
    $json = json_encode(array_values($rows),JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE|JSON_INVALID_UTF8_SUBSTITUTE);
    $temp = @tempnam(dirname($path),'.notifs-');
    if ($json === false || $temp === false) af_json(['success'=>false,'message'=>'No se pudo guardar'],503);
    $mode = is_file($path) ? @fileperms($path) : false;
    if (@file_put_contents($temp,$json,LOCK_EX) !== strlen($json)) { @unlink($temp); af_json(['success'=>false,'message'=>'No se pudo guardar'],503); }
    @chmod($temp,$mode === false ? 0640 : ($mode & 0777));
    if (!@rename($temp,$path)) { @unlink($temp); af_json(['success'=>false,'message'=>'No se pudo guardar'],503); }
}
function notifOrdered(array $rows): array {
    usort($rows,static function($a,$b) {
        $ao = isset($a['sort_order']) && is_numeric($a['sort_order']) ? (int)$a['sort_order'] : PHP_INT_MAX;
        $bo = isset($b['sort_order']) && is_numeric($b['sort_order']) ? (int)$b['sort_order'] : PHP_INT_MAX;
        if ($ao !== $bo) return $ao <=> $bo;
        return (strtotime((string)($b['created_at'] ?? '')) ?: 0) <=> (strtotime((string)($a['created_at'] ?? '')) ?: 0);
    });
    return $rows;
}
function notifPublic(array $row): array {
    return [
        'id'=>(string)($row['id'] ?? ''),
        'type'=>(string)($row['type'] ?? 'Información'),
        'title'=>(string)($row['title'] ?? ''),
        'message'=>(string)($row['message'] ?? ''),
        'image'=>(string)($row['image'] ?? ''),
        'product_code'=>(string)($row['product_code'] ?? ''),
        'created_at'=>(string)($row['created_at'] ?? ''),
        'sort_order'=>(int)($row['sort_order'] ?? 0)
    ];
}
function notifInput(): array {
    $raw = file_get_contents('php://input',false,null,0,32769);
    if ($raw === false || strlen($raw) > 32768) af_json(['success'=>false,'message'=>'Solicitud demasiado grande'],413);
    $input = json_decode($raw,true);
    if (!is_array($input)) af_json(['success'=>false,'message'=>'Solicitud inválida'],400);
    return $input;
}
function notifFields(array $input): array {
    $type = $input['type'] ?? '';
    $title = $input['title'] ?? '';
    $message = $input['message'] ?? '';
    $image = $input['image'] ?? '';
    if (!is_string($type) || !in_array($type,['Alerta','Información','Promoción'],true)
        || !is_string($title) || !is_string($message) || !is_string($image)) af_json(['success'=>false,'message'=>'Datos inválidos'],422);
    $title = trim($title); $message = trim($message); $image = trim($image);
    if ($title === '' || $message === '' || strlen($title)>180 || strlen($message)>1000 || strlen($image)>2048)
        af_json(['success'=>false,'message'=>'Revisá el título, mensaje e imagen'],422);
    if ($image !== '' && (!filter_var($image,FILTER_VALIDATE_URL) || parse_url($image,PHP_URL_SCHEME) !== 'https'))
        af_json(['success'=>false,'message'=>'La imagen debe tener una URL HTTPS válida'],422);
    $product_code = $input['product_code'] ?? '';
    if (!is_string($product_code) || strlen($product_code) > 80) af_json(['success'=>false,'message'=>'Prenda inválida'],422);
    $product_code = trim($product_code);
    if ($product_code !== '') {
        $rawProducts = @file_get_contents(__DIR__ . '/../data/products.json');
        $products = $rawProducts === false ? null : json_decode($rawProducts,true);
        if (isset($products['products']) && is_array($products['products'])) $products = $products['products'];
        if (!is_array($products)) af_json(['success'=>false,'message'=>'No se pudo comprobar la prenda'],503);
        $found = false;
        foreach ($products as $product) {
            if (is_array($product) && (string)($product['code'] ?? '') === $product_code) { $found = true; break; }
        }
        if (!$found) af_json(['success'=>false,'message'=>'La prenda ya no existe. Elegí otra o quitá el vínculo.'],422);
    }
    return compact('type','title','message','image','product_code');
}
$rows = notifRead($path);
if ($method === 'GET') {
    $ordered = notifOrdered($rows);
    if (($_GET['active'] ?? '') === '1') $ordered = array_values(array_filter($ordered,static function($row) {
        $time = strtotime((string)($row['created_at'] ?? ''));
        return $time !== false && $time <= time() && time()-$time < 86400;
    }));
    af_json(['success'=>true,'data'=>array_map('notifPublic',$ordered)]);
}
if ($method === 'POST') {
    $fields = notifFields(notifInput());
    if (count($rows)>=500) af_json(['success'=>false,'message'=>'Límite de historias alcanzado'],422);
    $ordered = notifOrdered($rows);
    // Fijar el orden anterior antes de colocar la historia nueva al inicio.
    foreach ($ordered as $i => &$row) $row['sort_order'] = $i+1;
    unset($row);
    $entry = array_merge($fields,[
        'id'=>'n'.bin2hex(random_bytes(10)),
        'created_at'=>date('c'),
        'sort_order'=>0
    ]);
    array_unshift($ordered,$entry);
    notifWrite($path,$ordered);
    logActivityEvent('notification','Notificación publicada','"'.$entry['title'].'" · Tipo: '.$entry['type']);
    af_json(['success'=>true,'message'=>'Notificación publicada','data'=>notifPublic($entry)],201);
}
$input = $method === 'PUT' && (($_GET['renew'] ?? '') !== '1') ? notifInput() : [];
$id = $_GET['id'] ?? '';
if ($method === 'PUT' && (($_GET['reorder'] ?? '') === '1')) {
    $ids = $input['ids'] ?? null;
    if (!is_array($ids) || count($ids) !== count($rows)) af_json(['success'=>false,'message'=>'La lista cambió. Recargá e intentá de nuevo'],409);
    $map = [];
    foreach ($rows as $row) {
        $key = (string)($row['id'] ?? '');
        if ($key === '' || isset($map[$key])) af_json(['success'=>false,'message'=>'Hay IDs duplicados en las historias'],503);
        $map[$key] = $row;
    }
    $ordered = [];
    foreach ($ids as $i=>$value) {
        if (!is_string($value) || !isset($map[$value])) af_json(['success'=>false,'message'=>'La lista cambió. Recargá e intentá de nuevo'],409);
        $row = $map[$value]; $row['sort_order'] = $i; $ordered[] = $row; unset($map[$value]);
    }
    if ($map) af_json(['success'=>false,'message'=>'La lista cambió. Recargá e intentá de nuevo'],409);
    notifWrite($path,$ordered);
    logActivityEvent('notification','Historias ordenadas','Se actualizó el orden de '.count($ordered).' historias');
    af_json(['success'=>true,'message'=>'Orden guardado']);
}
if (!is_string($id) || $id === '' || strlen($id)>100) af_json(['success'=>false,'message'=>'ID requerido'],400);
$position = null;
foreach ($rows as $i=>$row) if ((string)($row['id'] ?? '') === $id) { $position=$i; break; }
if ($position === null) af_json(['success'=>false,'message'=>'Notificación no encontrada'],404);
if ($method === 'DELETE') {
    $title = (string)($rows[$position]['title'] ?? $id);
    array_splice($rows,$position,1);
    notifWrite($path,$rows);
    logActivityEvent('notification','Notificación eliminada','Se eliminó "'.$title.'"');
    af_json(['success'=>true,'message'=>'Notificación eliminada']);
}
if (($_GET['renew'] ?? '') === '1') {
    $rows[$position]['created_at'] = date('c');
    notifWrite($path,$rows);
    logActivityEvent('notification','Notificación renovada','Se renovó "'.($rows[$position]['title'] ?? $id).'"');
    af_json(['success'=>true,'message'=>'Notificación renovada 24h']);
}
if (!array_key_exists('product_code', $input)) $input['product_code'] = (string)($rows[$position]['product_code'] ?? '');
$fields = notifFields($input);
$rows[$position] = array_merge($rows[$position],$fields);
notifWrite($path,$rows);
logActivityEvent('notification','Notificación editada','Se editó "'.$fields['title'].'"');
// created_at y sort_order permanecen intactos al editar.
af_json(['success'=>true,'message'=>'Notificación actualizada','data'=>notifPublic($rows[$position])]);
