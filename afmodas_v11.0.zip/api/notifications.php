<?php
// ============================================
// AF MODAS - API NOTIFICACIONES
// ============================================

header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') { exit(0); }

require_once __DIR__ . '/../config/config.php';

if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    $notifications = readJson('notifications');
    $active = array_filter($notifications, function($n) {
        $created = strtotime($n['createdAt']);
        return (time() - $created) < 86400;
    });
    echo json_encode(array_values($active));
} elseif ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $data = json_decode(file_get_contents('php://input'), true);
    $notifications = readJson('notifications');
    $data['id'] = 'n' . time() . rand(100, 999);
    $data['createdAt'] = date('Y-m-d H:i:s');
    $notifications[] = $data;
    writeJson('notifications', $notifications);
    logActivity('notif', 'Notificación publicada', $data['title'] ?? '');
    echo json_encode(['success' => true]);
} elseif ($_SERVER['REQUEST_METHOD'] === 'DELETE') {
    $id = $_GET['id'] ?? '';
    $notifications = readJson('notifications');
    $notifications = array_filter($notifications, function($n) use ($id) {
        return $n['id'] !== $id;
    });
    writeJson('notifications', array_values($notifications));
    echo json_encode(['success' => true]);
}