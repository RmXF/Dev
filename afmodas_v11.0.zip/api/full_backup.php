<?php
declare(strict_types=1);

// Respaldo completo de los datos administrados por AF MODAS (sin credenciales ni cachés).
ini_set('display_errors', '0');
require_once __DIR__ . '/security.php';
$method = $_SERVER['REQUEST_METHOD'] ?? 'GET';
if (!in_array($method, ['GET', 'POST'], true)) {
    header('Allow: GET, POST');
    af_json(['success' => false, 'message' => 'Método no permitido'], 405);
}
af_require_admin();

$dir = __DIR__ . '/../data';
$allowed = ['products.json', 'categories.json', 'notifications.json', 'coupons.json',
    'settings.json', 'orders.json', 'activity.json', 'vps_history.json', 'vps_cache.json', 'likes.json'];

function fullRead(string $path) {
    $raw = @file_get_contents($path);
    if ($raw === false || strlen($raw) > 16 * 1024 * 1024) throw new RuntimeException('No se pudo leer ' . basename($path));
    $value = json_decode($raw);
    if (json_last_error() !== JSON_ERROR_NONE || !is_array($value) && !is_object($value)) {
        throw new RuntimeException('JSON inválido en ' . basename($path));
    }
    return $value;
}
function fullManifest(string $dir, array $allowed): array {
    $files = [];
    foreach ($allowed as $name) {
        if (is_file($dir . '/' . $name)) $files[$name] = fullRead($dir . '/' . $name);
    }
    if (!isset($files['categories.json'])) {
        $list = ['BUSO','REMERAS','PANTALONES','MEDIAS','BODY','CONJUNTOS','GORRAS','GUANTES','SHORT','CAMISAS','CAMPERAS','VESTIDOS'];
        foreach (($files['products.json'] ?? []) as $product) {
            $category = is_object($product) ? trim((string) ($product->category ?? '')) : '';
            if ($category !== '' && !in_array($category, $list, true)) $list[] = $category;
        }
        $files['categories.json'] = $list;
    }
    return ['format' => 'afmodas-full-backup', 'version' => 1,
        'exported_at' => gmdate('c'), 'files' => $files];
}
function fullEncode($value): string {
    $json = json_encode($value, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_INVALID_UTF8_SUBSTITUTE);
    if ($json === false) throw new RuntimeException('No se pudo codificar el respaldo');
    return $json;
}

try {
    if ($method === 'GET') {
        $manifest = fullManifest($dir, $allowed);
        header('Content-Type: application/json; charset=utf-8');
        header('Cache-Control: private, no-store');
        header('X-Content-Type-Options: nosniff');
        header('Content-Disposition: attachment; filename="afmodas-completo-' . gmdate('Y-m-d') . '.json"');
        echo fullEncode($manifest);
        exit;
    }

    if ((int) ($_SERVER['CONTENT_LENGTH'] ?? 0) > 16 * 1024 * 1024) {
        af_json(['success' => false, 'message' => 'El respaldo supera los 16 MB'], 413);
    }
    $raw = @file_get_contents('php://input', false, null, 0, 16 * 1024 * 1024 + 1);
    if ($raw === false || strlen($raw) > 16 * 1024 * 1024) {
        af_json(['success' => false, 'message' => 'El respaldo supera los 16 MB'], 413);
    }
    $input = json_decode($raw);
    if (!is_object($input) || ($input->format ?? null) !== 'afmodas-full-backup'
        || ($input->version ?? null) !== 1 || !is_object($input->files)
        || !isset($input->files->{'products.json'})) {
        af_json(['success' => false, 'message' => 'Formato de respaldo completo inválido'], 400);
    }
    $files = get_object_vars($input->files);
    foreach ($files as $name => $value) {
        if (!in_array($name, $allowed, true) || !is_array($value) && !is_object($value)) {
            af_json(['success' => false, 'message' => 'Datos inválidos en el respaldo'], 400);
        }
        if (in_array($name, ['settings.json', 'vps_history.json', 'vps_cache.json', 'likes.json'], true) && !is_object($value)
            || in_array($name, ['products.json', 'categories.json', 'notifications.json', 'activity.json'], true) && !is_array($value)
            || $name === 'coupons.json' && !is_array($value) && !(is_object($value) && !get_object_vars($value))) {
            af_json(['success' => false, 'message' => 'Estructura inválida en ' . $name], 400);
        }
    }
    if (!is_array($files['products.json']) || count($files['products.json']) > 10000) {
        af_json(['success' => false, 'message' => 'Catálogo inválido'], 400);
    }
    if (isset($files['likes.json']) && (!is_object($files['likes.json']->items ?? null)
        || ($files['likes.json']->version ?? null) !== 1)) {
        af_json(['success' => false, 'message' => 'Votos inválidos en el respaldo'], 400);
    }
    foreach ($files['products.json'] as $product) {
        if (!is_object($product) || !is_string($product->code ?? null) || $product->code === ''
            || !is_string($product->name ?? null)) {
            af_json(['success' => false, 'message' => 'Producto inválido en el respaldo'], 400);
        }
    }
    if (isset($files['categories.json'])) foreach ($files['categories.json'] as $category) {
        if (!is_string($category) || trim($category) === '' || strlen($category) > 80) {
            af_json(['success' => false, 'message' => 'Categoría inválida en el respaldo'], 400);
        }
    }
    // Las escrituras del catálogo y las categorías comparten estos candados.
    $locks = [];
    foreach (['products', 'categories', 'coupons', 'notifications', 'likes'] as $name) {
        $handle = @fopen($dir . '/' . $name . '.lock', 'c');
        if (!$handle || !@flock($handle, LOCK_EX)) throw new RuntimeException('No se pudo bloquear los datos');
        $locks[] = $handle;
    }
    $snapshot = fullManifest($dir, $allowed);
    $snapshotDir = $dir . '/full_backup_snapshots';
    if (!is_dir($snapshotDir) && !@mkdir($snapshotDir, 0750, true)) throw new RuntimeException('No se pudo crear la copia previa');
    $snapshotName = gmdate('Ymd-His') . '-' . bin2hex(random_bytes(4)) . '.json';
    $snapshotJson = fullEncode($snapshot);
    if (@file_put_contents($snapshotDir . '/' . $snapshotName, $snapshotJson, LOCK_EX) !== strlen($snapshotJson)) {
        throw new RuntimeException('No se pudo guardar la copia previa');
    }
    $staged = [];
    foreach ($files as $name => $value) {
        $json = fullEncode($value);
        $temp = @tempnam($dir, '.restore-');
        if ($temp === false || @file_put_contents($temp, $json, LOCK_EX) !== strlen($json)) {
            if ($temp) @unlink($temp);
            foreach ($staged as $path) @unlink($path);
            throw new RuntimeException('No se pudo preparar la restauración');
        }
        @chmod($temp, is_file($dir . '/' . $name) ? (fileperms($dir . '/' . $name) & 0777) : 0640);
        $staged[$name] = $temp;
    }
    $replaced = [];
    foreach ($staged as $name => $temp) {
        if (!@rename($temp, $dir . '/' . $name)) {
            foreach ($staged as $pending) if (is_file($pending)) @unlink($pending);
            foreach ($replaced as $done) {
                if (isset($snapshot['files'][$done])) {
                    $old = fullEncode($snapshot['files'][$done]);
                    $undo = @tempnam($dir, '.undo-');
                    if ($undo && @file_put_contents($undo, $old, LOCK_EX) === strlen($old)) @rename($undo, $dir . '/' . $done);
                    if ($undo && is_file($undo)) @unlink($undo);
                } else @unlink($dir . '/' . $done);
            }
            throw new RuntimeException('Restauración interrumpida: usá la copia previa ' . $snapshotName);
        }
        $replaced[] = $name;
    }
    af_json(['success' => true, 'restored' => count($files), 'snapshot' => $snapshotName]);
} catch (Throwable $error) {
    af_json(['success' => false, 'message' => $error->getMessage()], 500);
}
