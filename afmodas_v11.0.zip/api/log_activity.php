<?php
/**
 * AF MODAS · Log Activity Helper
 * 
 * Se incluye desde otros endpoints para registrar eventos
 */

function logActivityEvent($type, $action, $details = '', $user = 'Sistema', $ip = null) {
    $dataDir = __DIR__ . '/../data';
    $dataFile = $dataDir . '/activity.json';

    if (!is_dir($dataDir)) @mkdir($dataDir, 0755, true);

    // Leer
    $activity = [];
    if (file_exists($dataFile)) {
        $content = @file_get_contents($dataFile);
        if ($content) {
            $decoded = json_decode($content, true);
            if (is_array($decoded)) $activity = $decoded;
        }
    }

    // IP
    if ($ip === null) {
        if (!empty($_SERVER['HTTP_CF_CONNECTING_IP'])) {
            $ip = $_SERVER['HTTP_CF_CONNECTING_IP'];
        } elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
            $ips = explode(',', $_SERVER['HTTP_X_FORWARDED_FOR']);
            $ip = trim($ips[0]);
        } elseif (!empty($_SERVER['HTTP_X_REAL_IP'])) {
            $ip = $_SERVER['HTTP_X_REAL_IP'];
        } else {
            $ip = $_SERVER['REMOTE_ADDR'] ?? '0.0.0.0';
        }
    }

    // User agent
    $userAgent = $_SERVER['HTTP_USER_AGENT'] ?? 'Desconocido';

    // Parsear dispositivo
    $ua = strtolower($userAgent);
    $browser = 'Desconocido';
    if (strpos($ua, 'edg/') !== false) $browser = 'Edge';
    elseif (strpos($ua, 'chrome') !== false) $browser = 'Chrome';
    elseif (strpos($ua, 'firefox') !== false) $browser = 'Firefox';
    elseif (strpos($ua, 'safari') !== false) $browser = 'Safari';

    $os = 'Desconocido';
    if (strpos($ua, 'windows') !== false) $os = 'Windows';
    elseif (strpos($ua, 'mac') !== false) $os = 'macOS';
    elseif (strpos($ua, 'android') !== false) $os = 'Android';
    elseif (strpos($ua, 'iphone') !== false || strpos($ua, 'ipad') !== false) $os = 'iOS';
    elseif (strpos($ua, 'linux') !== false) $os = 'Linux';

    $deviceType = 'Desktop';
    if (strpos($ua, 'mobile') !== false || strpos($ua, 'android') !== false || strpos($ua, 'iphone') !== false) $deviceType = 'Mobile';
    elseif (strpos($ua, 'tablet') !== false || strpos($ua, 'ipad') !== false) $deviceType = 'Tablet';

    $icon = 'fa-desktop';
    if ($deviceType === 'Mobile') $icon = 'fa-mobile-alt';
    elseif ($deviceType === 'Tablet') $icon = 'fa-tablet-alt';

    // Crear evento
    $event = [
        'id'         => 'evt_' . time() . '_' . mt_rand(1000, 9999),
        'type'       => $type,
        'action'     => $action,
        'details'    => $details,
        'user'       => $user,
        'ip'         => $ip,
        'user_agent' => $userAgent,
        'device'     => [
            'browser' => $browser,
            'os' => $os,
            'type' => $deviceType,
            'icon' => $icon
        ],
        'timestamp'  => time(),
        'datetime'   => date('Y-m-d H:i:s')
    ];

    // Agregar
    $activity[] = $event;

    // Limitar
    if (count($activity) > 1000) {
        $activity = array_slice($activity, -1000);
    }

    // Guardar
    @file_put_contents(
        $dataFile,
        json_encode(array_values($activity), JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE),
        LOCK_EX
    );

    return $event;
}