<?php
// AF MODAS · Miniaturas públicas de fotos ya registradas en el catálogo.
declare(strict_types=1);
ini_set('display_errors', '0');
header('X-Content-Type-Options: nosniff');
require_once __DIR__ . '/product_gallery.php';

function imageFail(int $status): void {
    http_response_code($status);
    header('Cache-Control: no-store');
    exit;
}
function imagePublicIp(string $host): ?string {
    $records = @dns_get_record($host, DNS_A | DNS_AAAA);
    if (!$records) return null;
    $selected = null;
    foreach ($records as $record) {
        $ip = $record['ip'] ?? $record['ipv6'] ?? '';
        if (!filter_var($ip, FILTER_VALIDATE_IP, FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE)) return null;
        if ($selected === null || filter_var($ip, FILTER_VALIDATE_IP, FILTER_FLAG_IPV4)) $selected = $ip;
    }
    return $selected;
}
function imageAllowedUrl(string $url): bool {
    $parts = parse_url($url);
    if (!$parts || strtolower($parts['scheme'] ?? '') !== 'https' || isset($parts['user']) || isset($parts['pass']) || isset($parts['port'])) return false;
    $host = strtolower($parts['host'] ?? '');
    if ($host !== 'www.dropbox.com' && $host !== 'dl.dropboxusercontent.com'
        && !preg_match('/^[a-z0-9-]+\.dropboxusercontent\.com$/D', $host)) return false;
    return imagePublicIp($host) !== null;
}
function imageFetch(string $url): ?string {
    if (!function_exists('curl_init')) return null;
    for ($hop = 0; $hop < 4; $hop++) {
        if (!imageAllowedUrl($url)) return null;
        $host = strtolower((string) parse_url($url, PHP_URL_HOST));
        $ip = imagePublicIp($host);
        if ($ip === null) return null;
        $bytes = '';
        $headers = [];
        $curl = curl_init($url);
        curl_setopt_array($curl, [
            CURLOPT_FOLLOWLOCATION => false,
            CURLOPT_RETURNTRANSFER => false,
            CURLOPT_CONNECTTIMEOUT => 5,
            CURLOPT_TIMEOUT => 15,
            CURLOPT_SSL_VERIFYPEER => true,
            CURLOPT_SSL_VERIFYHOST => 2,
            CURLOPT_RESOLVE => [$host . ':443:' . (strpos($ip, ':') !== false ? '[' . $ip . ']' : $ip)],
            CURLOPT_HTTPHEADER => ['Accept: image/avif,image/webp,image/jpeg,image/png,*/*;q=0.2'],
            CURLOPT_HEADERFUNCTION => static function ($ch, $line) use (&$headers) {
                if (stripos($line, 'Location:') === 0) $headers['location'] = trim(substr($line, 9));
                return strlen($line);
            },
            CURLOPT_WRITEFUNCTION => static function ($ch, $chunk) use (&$bytes) {
                if (strlen($bytes) + strlen($chunk) > 8 * 1024 * 1024) return 0;
                $bytes .= $chunk;
                return strlen($chunk);
            }
        ]);
        $ok = curl_exec($curl);
        $status = curl_getinfo($curl, CURLINFO_RESPONSE_CODE);
        curl_close($curl);
        if ($ok === false) return null;
        if ($status >= 300 && $status < 400 && isset($headers['location'])) {
            $next = $headers['location'];
            // Solo redirecciones absolutas HTTPS hacia Dropbox.
            if (!imageAllowedUrl($next)) return null;
            $url = $next;
            continue;
        }
        return $status === 200 && strlen($bytes) > 0 ? $bytes : null;
    }
    return null;
}

if (($_SERVER['REQUEST_METHOD'] ?? '') !== 'GET') imageFail(405);
$code = $_GET['code'] ?? '';
if (!is_string($code) || strlen($code) > 80 || $code === '') imageFail(400);
$format = ($_GET['format'] ?? '') === 'jpeg' ? 'jpeg' : 'webp';
$raw = @file_get_contents(__DIR__ . '/../data/products.json');
$products = $raw === false ? null : json_decode($raw, true);
if (isset($products['products']) && is_array($products['products'])) $products = $products['products'];
if (!is_array($products)) imageFail(503);
$source = '';
$imageIndex = $_GET['index'] ?? '0';
if (!is_string($imageIndex) || !preg_match('/^(?:[0-9]|1[01])$/D', $imageIndex)) imageFail(400);
foreach ($products as $product) {
    if (is_array($product) && (string) ($product['code'] ?? '') === $code) {
        $images = af_product_images($product);
        $source = $images[(int) $imageIndex] ?? '';
        break;
    }
}
if ($source === '' || !imageAllowedUrl($source)) imageFail(404);
if (!function_exists('imagecreatefromstring') || !function_exists('imagewebp')
    || ($format === 'jpeg' && !function_exists('imagejpeg'))) imageFail(503);
$cacheDir = __DIR__ . '/../data/image_cache';
if (!is_dir($cacheDir) && !@mkdir($cacheDir, 0750, true)) imageFail(503);
$key = hash('sha256', $format === 'jpeg' ? $source . '|640|jpeg|v1' : $source . '|640|v1');
$cacheFile = $cacheDir . '/' . $key . '.' . ($format === 'jpeg' ? 'jpg' : 'webp');
if (!is_file($cacheFile)) {
    $lock = @fopen($cacheDir . '/' . $key . '.lock', 'c');
    if (!$lock || !@flock($lock, LOCK_EX)) imageFail(503);
    if (!is_file($cacheFile)) {
        $bytes = imageFetch($source);
        $dimensions = $bytes === null ? false : @getimagesizefromstring($bytes);
        if ($dimensions === false) imageFail(502);
        if ($dimensions[0] < 1 || $dimensions[1] < 1 || $dimensions[0] * $dimensions[1] > 25000000) imageFail(422);
        $original = @imagecreatefromstring($bytes);
        if ($original === false) imageFail(502);
        $w = imagesx($original); $h = imagesy($original);
        $scale = min(1, 640 / max($w, $h));
        $nw = max(1, (int) round($w * $scale));
        $nh = max(1, (int) round($h * $scale));
        $thumb = imagecreatetruecolor($nw, $nh);
        imagealphablending($thumb, false);
        imagesavealpha($thumb, true);
        imagecopyresampled($thumb, $original, 0, 0, 0, 0, $nw, $nh, $w, $h);
        $temp = @tempnam($cacheDir, '.thumb-');
        if ($format === 'jpeg') {
            $opaque = imagecreatetruecolor($nw, $nh);
            $white = imagecolorallocate($opaque, 255, 255, 255);
            imagefill($opaque, 0, 0, $white);
            imagecopy($opaque, $thumb, 0, 0, 0, 0, $nw, $nh);
            $saved = $temp && @imagejpeg($opaque, $temp, 86) && @rename($temp, $cacheFile);
            imagedestroy($opaque);
        } else {
            $saved = $temp && @imagewebp($thumb, $temp, 78) && @rename($temp, $cacheFile);
        }
        imagedestroy($thumb); imagedestroy($original);
        if (!$saved) { if ($temp) @unlink($temp); imageFail(503); }
    }
    flock($lock, LOCK_UN); fclose($lock);
}
header('Content-Type: image/' . $format);
header('Cache-Control: public, max-age=604800, immutable');
header('Content-Length: ' . filesize($cacheFile));
readfile($cacheFile);
