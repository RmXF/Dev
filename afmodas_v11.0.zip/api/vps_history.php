<?php
error_reporting(E_ALL);
ini_set('display_errors', 0);
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-cache');

$DATA_DIR = __DIR__ . '/../data';
$HISTORY_FILE = $DATA_DIR . '/vps_history.json';
$MAX_POINTS_DETAILED = 8640;
$MAX_POINTS_SUMMARY = 2016;

if (!is_dir($DATA_DIR)) @mkdir($DATA_DIR, 0755, true);

function readHistory($file) {
    if (!file_exists($file)) return ['detailed'=>[],'summary'=>[]];
    $content = @file_get_contents($file);
    if (!$content) return ['detailed'=>[],'summary'=>[]];
    $data = json_decode($content, true);
    if (!is_array($data)) return ['detailed'=>[],'summary'=>[]];
    if (!isset($data['detailed'])) $data['detailed'] = [];
    if (!isset($data['summary'])) $data['summary'] = [];
    return $data;
}

function writeHistory($file, $data) {
    return @file_put_contents($file, json_encode($data, JSON_UNESCAPED_UNICODE), LOCK_EX);
}

function compactPoint($entry) {
    return [
        't'=> $entry['timestamp'] ?? time(),
        'cpu'=> round((float)($entry['cpu']['total'] ?? 0), 1),
        'ram'=> round((float)($entry['ram']['percent'] ?? 0), 1),
        'swap'=> round((float)($entry['swap']['percent'] ?? 0), 1),
        'disk'=> round((float)($entry['disk']['main']['percent'] ?? 0), 1),
        'rx'=> (int)($entry['network']['rx_bytes'] ?? 0),
        'tx'=> (int)($entry['network']['tx_bytes'] ?? 0),
        'l1'=> round((float)($entry['load']['load_1'] ?? 0), 2),
        'l5'=> round((float)($entry['load']['load_5'] ?? 0), 2),
        'l15'=> round((float)($entry['load']['load_15'] ?? 0), 2),
    ];
}

function cleanOld($points, $maxPoints) {
    if (count($points) <= $maxPoints) return $points;
    return array_slice($points, -$maxPoints);
}

function filterByRange($points, $seconds) {
    $cutoff = time() - $seconds;
    return array_values(array_filter($points, function($p) use ($cutoff) {
        return ($p['t'] ?? 0) >= $cutoff;
    }));
}

$method = $_SERVER['REQUEST_METHOD'];

if ($method === 'GET') {
    $history = readHistory($HISTORY_FILE);
    $range = $_GET['range'] ?? '24h';
    $seconds = 86400;
    switch ($range) {
        case '5m': $seconds = 300; break;
        case '15m': $seconds = 900; break;
        case '1h': $seconds = 3600; break;
        case '6h': $seconds = 21600; break;
        case '24h': $seconds = 86400; break;
        case '7d': $seconds = 604800; break;
    }
    $points = ($range === '7d') ? $history['summary'] : $history['detailed'];
    $filtered = filterByRange($points, $seconds);
    echo json_encode(['success'=>true,'range'=>$range,'count'=>count($filtered),'data'=>$filtered]);
    exit;
}

if ($method === 'POST') {
    $raw = file_get_contents('php://input');
    $input = json_decode($raw, true);
    if (!is_array($input)) {
        http_response_code(400);
        echo json_encode(['success'=>false,'message'=>'JSON inválido']);
        exit;
    }
    $metrics = isset($input['data']) ? $input['data'] : $input;
    if (empty($metrics['timestamp'])) $metrics['timestamp'] = time();
    $point = compactPoint($metrics);
    $history = readHistory($HISTORY_FILE);
    $history['detailed'][] = $point;
    $history['detailed'] = cleanOld($history['detailed'], $MAX_POINTS_DETAILED);
    $lastSummary = end($history['summary']);
    $lastSummaryTime = $lastSummary ? ($lastSummary['t'] ?? 0) : 0;
    if (time() - $lastSummaryTime >= 300) {
        $history['summary'][] = $point;
        $history['summary'] = cleanOld($history['summary'], $MAX_POINTS_SUMMARY);
    }
    writeHistory($HISTORY_FILE, $history);
    echo json_encode([
        'success'=>true,'message'=>'Punto agregado','point'=>$point,
        'total_detailed'=>count($history['detailed']),
        'total_summary'=>count($history['summary']),
    ]);
    exit;
}

http_response_code(405);
echo json_encode(['success'=>false,'message'=>'Método no soportado']);
