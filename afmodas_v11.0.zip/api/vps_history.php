<?php
/**
 * AF MODAS · VPS History API
 * 
 * Guarda y devuelve el historial de métricas del VPS
 * 
 * Endpoints:
 *   GET  /api/vps_history.php                    → Últimas 24h
 *   GET  /api/vps_history.php?range=1h           → Última hora
 *   GET  /api/vps_history.php?range=6h           → Últimas 6h
 *   GET  /api/vps_history.php?range=24h          → Últimas 24h
 *   GET  /api/vps_history.php?range=7d           → Últimos 7 días (resumido)
 *   POST /api/vps_history.php                    → Agrega un punto al historial
 */

error_reporting(E_ALL);
ini_set('display_errors', 0);

header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-cache, no-store, must-revalidate');

// ============================================================
// CONFIGURACIÓN
// ============================================================
$DATA_DIR = __DIR__ . '/../data';
$HISTORY_FILE = $DATA_DIR . '/vps_history.json';

// Estrategia de retención:
// - Detalle completo: 24 horas (1 punto cada 10 segundos = ~8640 puntos)
// - Resumen 7 días: 1 punto cada 5 minutos = ~2016 puntos
// - Máximo total: ~10000 puntos por archivo
$MAX_POINTS_DETAILED = 8640;    // 24h * 3600s / 10s
$MAX_POINTS_SUMMARY = 2016;     // 7d * 24h * 60m / 5m

if (!is_dir($DATA_DIR)) {
    @mkdir($DATA_DIR, 0755, true);
}

// ============================================================
// HELPERS
// ============================================================
function readHistory($file) {
    if (!file_exists($file)) return ['detailed' => [], 'summary' => []];
    $content = @file_get_contents($file);
    if (!$content) return ['detailed' => [], 'summary' => []];
    $data = json_decode($content, true);
    if (!is_array($data)) return ['detailed' => [], 'summary' => []];
    if (!isset($data['detailed'])) $data['detailed'] = [];
    if (!isset($data['summary'])) $data['summary'] = [];
    return $data;
}

function writeHistory($file, $data) {
    $json = json_encode($data, JSON_UNESCAPED_UNICODE);
    return @file_put_contents($file, $json, LOCK_EX);
}

function compactPoint($entry) {
    // Solo guardamos las métricas mínimas necesarias
    return [
        't' => $entry['timestamp'] ?? time(),
        'cpu' => round((float)($entry['cpu']['total'] ?? 0), 1),
        'ram' => round((float)($entry['ram']['percent'] ?? 0), 1),
        'swap' => round((float)($entry['swap']['percent'] ?? 0), 1),
        'disk' => round((float)($entry['disk']['main']['percent'] ?? 0), 1),
        'rx' => (int)($entry['network']['rx_bytes'] ?? 0),
        'tx' => (int)($entry['network']['tx_bytes'] ?? 0),
        'l1' => round((float)($entry['load']['load_1'] ?? 0), 2),
        'l5' => round((float)($entry['load']['load_5'] ?? 0), 2),
        'l15' => round((float)($entry['load']['load_15'] ?? 0), 2),
    ];
}

function cleanOld($points, $maxPoints) {
    if (count($points) <= $maxPoints) return $points;
    return array_slice($points, -$maxPoints);
}

function filterByRange($points, $seconds) {
    $cutoff = time() - $seconds;
    return array_values(array_filter($points, function($p) use ($cutoff) {
        return ($p['t'] ?? 0) >= $cutoff;
    }));
}

// ============================================================
// ROUTER
// ============================================================
$method = $_SERVER['REQUEST_METHOD'];

// ---------- GET: devolver historial ----------
if ($method === 'GET') {
    $history = readHistory($HISTORY_FILE);

    $range = $_GET['range'] ?? '24h';

    $seconds = 86400; // por defecto 24h
    switch ($range) {
        case '5m':  $seconds = 300; break;
        case '15m': $seconds = 900; break;
        case '1h':  $seconds = 3600; break;
        case '6h':  $seconds = 21600; break;
        case '24h': $seconds = 86400; break;
        case '7d':  $seconds = 604800; break;
    }

    $points = ($range === '7d')
        ? $history['summary']
        : $history['detailed'];

    $filtered = filterByRange($points, $seconds);

    echo json_encode([
        'success' => true,
        'range' => $range,
        'count' => count($filtered),
        'data' => $filtered
    ], JSON_UNESCAPED_UNICODE);
    exit;
}

// ---------- POST: agregar punto ----------
if ($method === 'POST') {
    $raw = file_get_contents('php://input');
    $input = json_decode($raw, true);

    if (!is_array($input)) {
        http_response_code(400);
        echo json_encode(['success' => false, 'message' => 'JSON inválido']);
        exit;
    }

    // Acepta {cpu, ram, swap, disk, network, load, timestamp} o {data: {...}}
    $metrics = isset($input['data']) ? $input['data'] : $input;

    if (empty($metrics['timestamp'])) {
        $metrics['timestamp'] = time();
    }

    $point = compactPoint($metrics);

    $history = readHistory($HISTORY_FILE);

    // Agregar al detallado
    $history['detailed'][] = $point;
    $history['detailed'] = cleanOld($history['detailed'], $MAX_POINTS_DETAILED);

    // Agregar al resumido (cada 5 minutos)
    $lastSummary = end($history['summary']);
    $lastSummaryTime = $lastSummary ? ($lastSummary['t'] ?? 0) : 0;
    if (time() - $lastSummaryTime >= 300) {
        $history['summary'][] = $point;
        $history['summary'] = cleanOld($history['summary'], $MAX_POINTS_SUMMARY);
    }

    writeHistory($HISTORY_FILE, $history);

    echo json_encode([
        'success' => true,
        'message' => 'Punto agregado',
        'point' => $point,
        'total_detailed' => count($history['detailed']),
        'total_summary' => count($history['summary'])
    ]);
    exit;
}

// Método no soportado
http_response_code(405);
echo json_encode(['success' => false, 'message' => 'Método no soportado']);