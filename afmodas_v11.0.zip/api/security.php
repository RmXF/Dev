<?php
declare(strict_types=1);

// AF MODAS · Seguridad compartida. PHP 7.4 o superior.
const AF_SESSION_IDLE = 1800;
const AF_SESSION_MAX = 28800;

function af_json(array $data, int $status = 200): void {
    http_response_code($status);
    header('Content-Type: application/json; charset=utf-8');
    header('Cache-Control: no-store, private');
    header('X-Content-Type-Options: nosniff');
    echo json_encode($data, JSON_UNESCAPED_UNICODE | JSON_INVALID_UTF8_SUBSTITUTE);
    exit;
}

function af_start_session(): void {
    if (session_status() === PHP_SESSION_ACTIVE) return;
    ini_set('session.use_strict_mode', '1');
    ini_set('session.use_only_cookies', '1');
    ini_set('session.use_trans_sid', '0');
    ini_set('session.gc_maxlifetime', (string) AF_SESSION_MAX);
    session_name('AFMODAS_SESSION');
    $secure = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off')
        || (int) ($_SERVER['SERVER_PORT'] ?? 0) === 443;
    session_set_cookie_params([
        'lifetime' => 0, 'path' => '/', 'secure' => $secure,
        'httponly' => true, 'samesite' => 'Strict'
    ]);
    if (!session_start()) {
        af_json(['success' => false, 'message' => 'No se pudo iniciar la sesión.'], 503);
    }
}

function af_csrf(): string {
    af_start_session();
    if (empty($_SESSION['csrf'])) $_SESSION['csrf'] = bin2hex(random_bytes(32));
    return $_SESSION['csrf'];
}

function af_check_csrf(): void {
    $provided = $_SERVER['HTTP_X_CSRF_TOKEN'] ?? '';
    if (!is_string($provided) || !hash_equals(af_csrf(), $provided)) {
        af_json(['success' => false, 'message' => 'Sesión de formulario vencida. Recargá la página.'], 403);
    }
}

function af_authenticated(): bool {
    af_start_session();
    if (empty($_SESSION['admin_user'])) return false;
    $now = time();
    if ($now - (int) ($_SESSION['last_seen'] ?? 0) >= AF_SESSION_IDLE
        || $now - (int) ($_SESSION['created_at'] ?? 0) >= AF_SESSION_MAX) {
        $_SESSION = [];
        session_regenerate_id(true);
        return false;
    }
    return true;
}

// Las API públicas pueden permitir GET. Las demás operaciones requieren sesión.
function af_require_admin(bool $publicGet = false): void {
    $method = $_SERVER['REQUEST_METHOD'] ?? 'GET';
    if ($publicGet && $method === 'GET') return;
    if (!af_authenticated()) {
        af_json(['success' => false, 'message' => 'Iniciá sesión para continuar.'], 401);
    }
    if (!in_array($method, ['GET', 'HEAD'], true)) af_check_csrf();
    $_SESSION['last_seen'] = time();
}

function af_logout(): void {
    af_start_session();
    $_SESSION = [];
    $params = session_get_cookie_params();
    setcookie(session_name(), '', [
        'expires' => time() - 3600, 'path' => $params['path'],
        'secure' => $params['secure'], 'httponly' => true, 'samesite' => 'Strict'
    ]);
    session_destroy();
}