<?php
/**
 * AF MODAS · Activity API
 * 
 * GET  /api/activity.php              → Todas las actividades
 * GET  /api/activity.php?type=login   → Filtrar por tipo
 * GET  /api/activity.php?limit=100    → Limitar resultados
 * POST /api/activity.php              → Registrar evento
 * DELETE /api/activity.php            → Limpiar todo
 */

error_reporting(E_ALL);
ini_set('display_errors', 0);

header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') { exit(0); }

$dataDir = __DIR__ . '/../data';
$dataFile = $dataDir . '/activity.json';

if (!is_dir($dataDir)) @mkdir($dataDir, 0755, true);

// Máximo de eventos a guardar
$MAX_EVENTS = 1000;

// ============================================================
// HELPERS
// ============================================================
function readActivity($file) {
    if (!file_exists($file)) return [];
    $content = @file_get_contents($file);
    if (!$content) return [];
    $data = json_decode($content, true);
    return is_array($data) ? $data : [];
}

function writeActivity($file, $data) {
    return @file_put_contents(
        $file,
        json_encode(array_values($data), JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE),
        LOCK_EX
    );
}

function getUserIP() {
    if (!empty($_SERVER['HTTP_CF_CONNECTING_IP'])) {
        return $_SERVER['HTTP_CF_CONNECTING_IP'];
    }
    if (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
        $ips = explode(',', $_SERVER['HTTP_X_FORWARDED_FOR']);
        return trim($ips[0]);
    }
    if (!empty($_SERVER['HTTP_X_REAL_IP'])) {
        return $_SERVER['HTTP_X_REAL_IP'];
    }
    return $_SERVER['REMOTE_ADDR'] ?? '0.0.0.0';
}

function getUserAgent() {
    return $_SERVER['HTTP_USER_AGENT'] ?? 'Desconocido';
}

function parseDevice($ua) {
    $ua = strtolower($ua);

    // Detectar navegador
    $browser = 'Desconocido';
    if (strpos($ua, 'edg/') !== false) $browser = 'Edge';
    elseif (strpos($ua, 'opr/') !== false || strpos($ua, 'opera') !== false) $browser = 'Opera';
    elseif (strpos($ua, 'chrome') !== false) $browser = 'Chrome';
    elseif (strpos($ua, 'firefox') !== false) $browser = 'Firefox';
    elseif (strpos($ua, 'safari') !== false) $browser = 'Safari';

    // Detectar OS
    $os = 'Desconocido';
    if (strpos($ua, 'windows') !== false) $os = 'Windows';
    elseif (strpos($ua, 'mac os') !== false || strpos($ua, 'macos') !== false) $os = 'macOS';
    elseif (strpos($ua, 'android') !== false) $os = 'Android';
    elseif (strpos($ua, 'iphone') !== false || strpos($ua, 'ipad') !== false) $os = 'iOS';
    elseif (strpos($ua, 'linux') !== false) $os = 'Linux';

    // Detectar tipo
    $type = 'Desktop';
    if (strpos($ua, 'mobile') !== false || strpos($ua, 'android') !== false || strpos($ua, 'iphone') !== false) $type = 'Mobile';
    elseif (strpos($ua, 'tablet') !== false || strpos($ua, 'ipad') !== false) $type = 'Tablet';

    // Icono
    $icon = 'fa-desktop';
    if ($type === 'Mobile') $icon = 'fa-mobile-alt';
    elseif ($type === 'Tablet') $icon = 'fa-tablet-alt';

    return [
        'browser' => $browser,
        'os' => $os,
        'type' => $type,
        'icon' => $icon,
        'user_agent' => $ua
    ];
}

// ============================================================
// GET — Leer actividades
// ============================================================
if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    $activity = readActivity($dataFile);

    // Invertir para mostrar los más recientes primero
    $activity = array_reverse($activity);

    // Filtrar por tipo
    if (!empty($_GET['type']) && $_GET['type'] !== 'all') {
        $type = $_GET['type'];
        $activity = array_filter($activity, function($item) use ($type) {
            return ($item['type'] ?? '') === $type;
        });
        $activity = array_values($activity);
    }

    // Limitar
    if (!empty($_GET['limit'])) {
        $limit = (int)$_GET['limit'];
        $activity = array_slice($activity, 0, $limit);
    }

    echo json_encode([
        'success' => true,
        'count' => count($activity),
        'data' => array_values($activity)
    ]);
    exit;
}

// ============================================================
// POST — Registrar evento
// ============================================================
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $input = json_decode(file_get_contents('php://input'), true);

    if (!is_array($input)) {
        http_response_code(400);
        echo json_encode(['success' => false, 'message' => 'JSON inválido']);
        exit;
    }

    $type = $input['type'] ?? 'unknown';
    $action = $input['action'] ?? 'Acción';
    $details = $input['details'] ?? '';

    // Info del cliente
    $ip = $input['ip'] ?? getUserIP();
    $userAgent = $input['user_agent'] ?? getUserAgent();
    $device = parseDevice($userAgent);

    // Info del admin (si está logueado)
    $user = $input['user'] ?? ($_SERVER['PHP_AUTH_USER'] ?? 'Admin');

    $event = [
        'id'         => 'evt_' . time() . '_' . mt_rand(1000, 9999),
        'type'       => $type,
        'action'     => $action,
        'details'    => $details,
        'user'       => $user,
        'ip'         => $ip,
        'user_agent' => $userAgent,
        'device'     => $device,
        'timestamp'  => time(),
        'datetime'   => date('Y-m-d H:i:s')
    ];

    $activity = readActivity($dataFile);
    $activity[] = $event;

    // Limitar al máximo
    if (count($activity) > $MAX_EVENTS) {
        $activity = array_slice($activity, -$MAX_EVENTS);
    }

    writeActivity($dataFile, $activity);

    echo json_encode(['success' => true, 'event' => $event]);
    exit;
}

// ============================================================
// DELETE — Limpiar todo
// ============================================================
if ($_SERVER['REQUEST_METHOD'] === 'DELETE') {
    writeActivity($dataFile, []);
    echo json_encode(['success' => true, 'message' => 'Actividad eliminada']);
    exit;
}

http_response_code(405);
echo json_encode(['success' => false, 'message' => 'Método no soportado']);