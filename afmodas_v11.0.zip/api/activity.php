<?php
// ============================================
// AF MODAS - API ACTIVIDAD
// ============================================

header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') { exit(0); }

require_once __DIR__ . '/../config/config.php';

if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    echo json_encode(readJson('activity'));
} elseif ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $data = json_decode(file_get_contents('php://input'), true);
    $activity = readJson('activity');
    $data['id'] = 'a' . time() . rand(100, 999);
    $data['timestamp'] = date('Y-m-d H:i:s');
    array_unshift($activity, $data);
    if (count($activity) > 200) $activity = array_slice($activity, 0, 200);
    writeJson('activity', $activity);
    echo json_encode(['success' => true]);
}