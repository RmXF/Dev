<?php
declare(strict_types=1);
// Mantiene la imagen principal compatible con el catálogo y el carrito existentes.
function af_product_images(array $product): array {
    $values = array_merge([$product['image'] ?? ''], is_array($product['images'] ?? null) ? $product['images'] : []);
    $images = [];
    foreach ($values as $value) {
        if (!is_string($value)) continue;
        $url = trim($value);
        if ($url === '' || strlen($url) > 2048 || !filter_var($url, FILTER_VALIDATE_URL)
            || !in_array(strtolower((string) parse_url($url, PHP_URL_SCHEME)), ['https', 'http'], true)) continue;
        if (!in_array($url, $images, true)) $images[] = $url;
        if (count($images) >= 12) break;
    }
    return $images;
}
function af_validate_product_images(array $input): bool {
    if (isset($input['images']) && (!is_array($input['images']) || count($input['images']) > 12)) return false;
    $unique = [];
    foreach (array_merge([$input['image'] ?? ''], $input['images'] ?? []) as $url) {
        if (!is_string($url) || strlen($url) > 2048) return false;
        if (trim($url) !== '' && (!filter_var(trim($url), FILTER_VALIDATE_URL)
            || !in_array(strtolower((string) parse_url(trim($url), PHP_URL_SCHEME)), ['https', 'http'], true))) return false;
        if (trim($url) !== '') $unique[trim($url)] = true;
    }
    return count($unique) <= 12;
}
