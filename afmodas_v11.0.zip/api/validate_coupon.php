<?php
declare(strict_types=1);
ini_set('display_errors', '0');
require_once __DIR__ . '/cart_quote.php';
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');
header('X-Content-Type-Options: nosniff');
if (($_SERVER['REQUEST_METHOD'] ?? '') !== 'POST') cartError('Método no permitido', 405);
echo json_encode(cartQuote(cartInput()), JSON_UNESCAPED_UNICODE | JSON_INVALID_UTF8_SUBSTITUTE);
