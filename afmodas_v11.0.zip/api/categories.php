<?php
// ============================================
// AF MODAS - API CATEGORÍAS
// ============================================

header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') { exit(0); }

require_once __DIR__ . '/../config/config.php';

$file = DATA_DIR . 'categories.json';

// Inicializar categorías si no existen
function initCategories() {
    global $file;
    if (!file_exists($file)) {
        $defaultCategories = [
            'categories' => ['BUSO', 'REMERAS', 'PANTALONES', 'MEDIAS', 'BODY', 
                            'CONJUNTOS', 'GORRAS', 'GUANTES', 'SHORT', 'CAMISAS', 
                            'CAMPERAS', 'VESTIDOS']
        ];
        file_put_contents($file, json_encode($defaultCategories, JSON_PRETTY_PRINT));
    }
}

function readCategories() {
    global $file;
    initCategories();
    $data = json_decode(file_get_contents($file), true);
    return $data['categories'] ?? [];
}

function writeCategories($categories) {
    global $file;
    file_put_contents($file, json_encode(['categories' => $categories], JSON_PRETTY_PRINT));
}

// ===== GET - Obtener categorías =====
if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    $categories = readCategories();
    echo json_encode(['success' => true, 'categories' => $categories]);
    exit;
}

// ===== POST - Agregar categoría =====
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $data = json_decode(file_get_contents('php://input'), true);
    $newCategory = strtoupper(trim($data['category'] ?? ''));
    
    if (empty($newCategory)) {
        echo json_encode(['success' => false, 'message' => 'Categoría vacía']);
        exit;
    }
    
    $categories = readCategories();
    if (in_array($newCategory, $categories)) {
        echo json_encode(['success' => false, 'message' => 'La categoría ya existe']);
        exit;
    }
    
    $categories[] = $newCategory;
    sort($categories);
    writeCategories($categories);
    
    logActivity('category_add', 'Categoría agregada', $newCategory);
    echo json_encode(['success' => true, 'categories' => $categories]);
    exit;
}

// ===== PUT - Editar categoría =====
if ($_SERVER['REQUEST_METHOD'] === 'PUT') {
    $data = json_decode(file_get_contents('php://input'), true);
    $oldCategory = trim($data['old'] ?? '');
    $newCategory = strtoupper(trim($data['new'] ?? ''));
    
    if (empty($oldCategory) || empty($newCategory)) {
        echo json_encode(['success' => false, 'message' => 'Datos incompletos']);
        exit;
    }
    
    $categories = readCategories();
    $index = array_search($oldCategory, $categories);
    if ($index === false) {
        echo json_encode(['success' => false, 'message' => 'Categoría no encontrada']);
        exit;
    }
    
    if ($oldCategory !== $newCategory && in_array($newCategory, $categories)) {
        echo json_encode(['success' => false, 'message' => 'La categoría ya existe']);
        exit;
    }
    
    $categories[$index] = $newCategory;
    sort($categories);
    writeCategories($categories);
    
    // Actualizar productos que usan la categoría antigua
    $productsFile = DATA_DIR . 'products.json';
    if (file_exists($productsFile)) {
        $products = json_decode(file_get_contents($productsFile), true) ?: [];
        foreach ($products as &$product) {
            if (($product['category'] ?? '') === $oldCategory) {
                $product['category'] = $newCategory;
            }
        }
        file_put_contents($productsFile, json_encode($products, JSON_PRETTY_PRINT));
    }
    
    logActivity('category_edit', 'Categoría editada', "$oldCategory → $newCategory");
    echo json_encode(['success' => true, 'categories' => $categories]);
    exit;
}

// ===== DELETE - Eliminar categoría =====
if ($_SERVER['REQUEST_METHOD'] === 'DELETE') {
    $data = json_decode(file_get_contents('php://input'), true);
    $category = trim($data['category'] ?? '');
    
    if (empty($category)) {
        echo json_encode(['success' => false, 'message' => 'Categoría vacía']);
        exit;
    }
    
    $categories = readCategories();
    $index = array_search($category, $categories);
    if ($index === false) {
        echo json_encode(['success' => false, 'message' => 'Categoría no encontrada']);
        exit;
    }
    
    // Verificar si hay productos con esta categoría
    $productsFile = DATA_DIR . 'products.json';
    if (file_exists($productsFile)) {
        $products = json_decode(file_get_contents($productsFile), true) ?: [];
        foreach ($products as $product) {
            if (($product['category'] ?? '') === $category) {
                echo json_encode(['success' => false, 'message' => 'No se puede eliminar: hay productos con esta categoría']);
                exit;
            }
        }
    }
    
    unset($categories[$index]);
    $categories = array_values($categories);
    writeCategories($categories);
    
    logActivity('category_delete', 'Categoría eliminada', $category);
    echo json_encode(['success' => true, 'categories' => $categories]);
    exit;
}