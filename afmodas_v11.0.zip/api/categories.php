<?php
declare(strict_types=1);
// Categorías administrables. GET público; los cambios requieren sesión y CSRF.
ini_set('display_errors', '0');
require_once __DIR__ . '/security.php';
af_require_admin(true);
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');
header('X-Content-Type-Options: nosniff');

$dir = __DIR__ . '/../data';
$path = $dir . '/categories.json';
$productsPath = $dir . '/products.json';
$defaults = ['BUSO','REMERAS','PANTALONES','MEDIAS','BODY','CONJUNTOS','GORRAS','GUANTES','SHORT','CAMISAS','CAMPERAS','VESTIDOS'];

function categoryReply(array $data, int $status = 200): void {
    http_response_code($status);
    echo json_encode($data, JSON_UNESCAPED_UNICODE | JSON_INVALID_UTF8_SUBSTITUTE);
    exit;
}
function categoryName($value): string {
    if (!is_string($value)) categoryReply(['success' => false, 'message' => 'Nombre de categoría inválido'], 400);
    $name = trim((string) preg_replace('/\s+/u', ' ', $value));
    if ($name === '' || strlen($name) > 80 || !preg_match('/^[\p{L}\p{N}][\p{L}\p{N} _&\/.()\-]*$/uD', $name)
        || strcasecmp($name, 'all') === 0) categoryReply(['success' => false, 'message' => 'Usá un nombre de hasta 80 caracteres con letras, números o espacios'], 422);
    return $name;
}
function categoryKey(string $name): string {
    return function_exists('mb_strtolower') ? mb_strtolower($name, 'UTF-8') : strtolower($name);
}
function categoryProducts(string $path): array {
    $raw = @file_get_contents($path);
    $products = $raw === false ? null : json_decode($raw, true);
    if (is_array($products) && isset($products['products']) && is_array($products['products'])) $products = $products['products'];
    if (!is_array($products)) categoryReply(['success' => false, 'message' => 'No se pudo consultar los productos'], 503);
    return $products;
}
function categoryList(string $path, array $defaults, array $products): array {
    if (is_file($path)) {
        $raw = @file_get_contents($path);
        $list = $raw === false ? null : json_decode($raw, true);
        if (!is_array($list) || array_keys($list) !== range(0, count($list) - 1)) categoryReply(['success' => false, 'message' => 'Lista de categorías no disponible'], 503);
    } else $list = $defaults;
    $unique = [];
    foreach ($list as $value) {
        if (!is_string($value)) continue;
        $value = trim($value);
        if ($value !== '') $unique[categoryKey($value)] = $value;
    }
    // Preservar las categorías de productos existentes y de copias restauradas.
    foreach ($products as $product) {
        if (!is_array($product) || !is_string($product['category'] ?? null)) continue;
        $value = trim($product['category']);
        if ($value !== '' && !isset($unique[categoryKey($value)])) $unique[categoryKey($value)] = $value;
    }
    return array_values($unique);
}
function categoryWrite(string $path, array $list): void {
    $json = json_encode(array_values($list), JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_INVALID_UTF8_SUBSTITUTE);
    $temp = @tempnam(dirname($path), '.categories-');
    if ($json === false || $temp === false) categoryReply(['success' => false, 'message' => 'No se pudo guardar la categoría'], 503);
    $mode = is_file($path) ? @fileperms($path) : false;
    if (@file_put_contents($temp, $json, LOCK_EX) !== strlen($json)) { @unlink($temp); categoryReply(['success' => false, 'message' => 'No se pudo guardar la categoría'], 503); }
    @chmod($temp, $mode === false ? 0640 : ($mode & 0777));
    if (!@rename($temp, $path)) { @unlink($temp); categoryReply(['success' => false, 'message' => 'No se pudo guardar la categoría'], 503); }
}
function categoryWriteProducts(string $path, array $products): bool {
    $json = json_encode(array_values($products), JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_INVALID_UTF8_SUBSTITUTE);
    $temp = @tempnam(dirname($path), '.products-');
    if ($json === false || $temp === false) return false;
    $mode = is_file($path) ? @fileperms($path) : false;
    if (@file_put_contents($temp, $json, LOCK_EX) !== strlen($json)) { @unlink($temp); return false; }
    @chmod($temp, $mode === false ? 0640 : ($mode & 0777));
    if (!@rename($temp, $path)) { @unlink($temp); return false; }
    return true;
}

$method = $_SERVER['REQUEST_METHOD'] ?? 'GET';
if (!in_array($method, ['GET','POST','DELETE'], true)) categoryReply(['success' => false, 'message' => 'Método no permitido'], 405);
// El mismo candado que usa Productos protege la comprobación antes de borrar.
if ($method !== 'GET') {
    $productLock = @fopen($dir . '/products.lock', 'c');
    if (!$productLock || !@flock($productLock, LOCK_EX)) categoryReply(['success' => false, 'message' => 'No se pudo bloquear el catálogo'], 503);
    $categoryLock = @fopen($dir . '/categories.lock', 'c');
    if (!$categoryLock || !@flock($categoryLock, LOCK_EX)) categoryReply(['success' => false, 'message' => 'No se pudo bloquear las categorías'], 503);
}
$products = categoryProducts($productsPath);
$list = categoryList($path, $defaults, $products);
$counts = [];
foreach ($products as $product) if (is_array($product)) {
    $key = categoryKey(trim((string) ($product['category'] ?? '')));
    if ($key !== '') $counts[$key] = ($counts[$key] ?? 0) + 1;
}
if ($method === 'GET') {
    categoryReply(['success' => true, 'data' => array_map(static function ($name) use ($counts) {
        return ['name' => $name, 'products' => $counts[categoryKey($name)] ?? 0];
    }, $list)]);
}
$raw = file_get_contents('php://input', false, null, 0, 2049);
$input = $raw === false ? null : json_decode($raw, true);
if (!is_array($input)) categoryReply(['success' => false, 'message' => 'Solicitud inválida'], 400);
$name = categoryName($input['name'] ?? null);
$key = categoryKey($name);
if ($method === 'POST') {
    if (count($list) >= 100) categoryReply(['success' => false, 'message' => 'Límite de categorías alcanzado'], 422);
    foreach ($list as $existing) if (categoryKey($existing) === $key) categoryReply(['success' => false, 'message' => 'Esa categoría ya existe'], 409);
    $list[] = $name;
    categoryWrite($path, $list);
    require_once __DIR__ . '/log_activity.php';
    logActivityEvent('settings', 'Categoría creada', 'Se agregó la categoría ' . $name);
    categoryReply(['success' => true, 'message' => 'Categoría creada', 'data' => ['name' => $name]], 201);
}
$found = false;
foreach ($list as $existing) if (categoryKey($existing) === $key) $found = true;
if (!$found) categoryReply(['success' => false, 'message' => 'Categoría no encontrada'], 404);
if (count($list) <= 1) categoryReply(['success' => false, 'message' => 'Debe quedar al menos una categoría'], 422);
$used = $counts[$key] ?? 0;
$replacement = '';
if ($used > 0) {
    $requested = categoryName($input['reassign_to'] ?? null);
    foreach ($list as $existing) if (categoryKey($existing) === categoryKey($requested) && categoryKey($existing) !== $key) $replacement = $existing;
    if ($replacement === '') categoryReply(['success' => false, 'message' => 'Elegí otra categoría para mover las prendas'], 422);
}
$list = array_values(array_filter($list, static fn($existing) => categoryKey($existing) !== $key));
categoryWrite($path, $list);
if ($used > 0) {
    foreach ($products as &$product) {
        if (is_array($product) && categoryKey(trim((string) ($product['category'] ?? ''))) === $key) {
            $product['category'] = $replacement;
            $product['updated_at'] = date('c');
        }
    }
    unset($product);
    if (!categoryWriteProducts($productsPath, $products)) categoryReply(['success' => false, 'message' => 'No se pudieron mover las prendas; la categoría sigue disponible. Reintentá.'], 503);
}
require_once __DIR__ . '/log_activity.php';
logActivityEvent('settings', 'Categoría eliminada', 'Se eliminó la categoría ' . $name . ($used ? ' · ' . $used . ' prendas movidas a ' . $replacement : ''));
categoryReply(['success' => true, 'message' => $used ? 'Categoría eliminada y prendas movidas' : 'Categoría eliminada']);
