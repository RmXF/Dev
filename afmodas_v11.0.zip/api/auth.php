<?php
// ============================================
// AF MODAS - AUTENTICACIÓN MEJORADA
// <<< ACTUALIZADO >>> Código robusto con manejo de errores
// ============================================

// Desactivar errores en producción
error_reporting(0);
ini_set('display_errors', 0);

// Headers CORS
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization');

// Manejar OPTIONS (pre-flight)
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit(0);
}

// Solo permitir POST
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'message' => 'Método no permitido']);
    exit;
}

// Archivo de usuarios
$usersFile = __DIR__ . '/../config/admin_users.json';
$users = [];

if (file_exists($usersFile)) {
    $content = file_get_contents($usersFile);
    if ($content !== false) {
        $data = json_decode($content, true);
        if ($data && isset($data['users']) && is_array($data['users'])) {
            $users = $data['users'];
        }
    }
}

// Si no hay usuarios, crear uno por defecto
if (empty($users)) {
    $users = [
        [
            'username' => 'admin',
            'password' => hash('sha256', 'admin'),
            'created' => date('Y-m-d H:i:s'),
            'role' => 'admin'
        ]
    ];
    // Guardar usuarios por defecto
    file_put_contents($usersFile, json_encode(['users' => $users], JSON_PRETTY_PRINT));
}

// Leer entrada
$input = file_get_contents('php://input');
if ($input === false) {
    echo json_encode(['success' => false, 'message' => 'Error al leer la solicitud']);
    exit;
}

$data = json_decode($input, true);
if ($data === null) {
    echo json_encode(['success' => false, 'message' => 'Formato JSON inválido']);
    exit;
}

$username = $data['username'] ?? '';
$password = $data['password'] ?? '';

// Validar entrada
if (empty($username) || empty($password)) {
    echo json_encode(['success' => false, 'message' => 'Usuario y contraseña requeridos']);
    exit;
}

// Verificar autenticación
$auth_success = false;
$user_found = false;

foreach ($users as $user) {
    if ($user['username'] === $username) {
        $user_found = true;
        if ($user['password'] === hash('sha256', $password)) {
            $auth_success = true;
            break;
        }
    }
}

// Si el usuario existe pero la contraseña es incorrecta
if ($user_found && !$auth_success) {
    echo json_encode(['success' => false, 'message' => 'Contraseña incorrecta']);
    exit;
}

// Si el usuario no existe, verificar contra el sistema (fallback)
if (!$auth_success && !$user_found) {
    // Verificar si el usuario existe en el sistema
    $user_check = shell_exec("id -u $username 2>/dev/null");
    if (!empty($user_check)) {
        $auth_success = true;
    }
}

// Respuesta
if ($auth_success) {
    echo json_encode([
        'success' => true,
        'message' => 'Acceso concedido',
        'user' => $username
    ]);
} else {
    echo json_encode([
        'success' => false,
        'message' => 'Usuario o contraseña incorrectos'
    ]);
}