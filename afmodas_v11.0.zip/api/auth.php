<?php
// ============================================
// AF MODAS - AUTENTICACIÓN CON VPS
// ============================================

header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') { exit(0); }

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['success' => false, 'message' => 'Método no permitido']);
    exit;
}

require_once __DIR__ . '/../config/config.php';

$input = json_decode(file_get_contents('php://input'), true);
$username = $input['username'] ?? '';
$password = $input['password'] ?? '';

if (empty($username) || empty($password)) {
    echo json_encode(['success' => false, 'message' => 'Usuario y contraseña requeridos']);
    exit;
}

// ===== AUTENTICACIÓN CONTRA EL VPS =====
$auth_success = false;

// Método 1: PAM (si está instalado)
if (function_exists('pam_auth')) {
    $auth_success = pam_auth($username, $password, $error_message);
}

// Método 2: Validación con su (requiere sudo)
if (!$auth_success) {
    $command = "sudo -u $username -n true 2>&1";
    exec($command, $output, $return_code);
    if ($return_code === 0) {
        $auth_success = true;
    }
}

// Método 3: Verificar con chpasswd
if (!$auth_success) {
    $test = shell_exec("echo '$username:$password' | chpasswd -c SHA512 2>&1");
    if (strpos($test, 'password updated successfully') !== false) {
        $auth_success = true;
    }
}

if ($auth_success) {
    logActivity('login', 'Inicio de sesión', "Usuario: $username");
    echo json_encode([
        'success' => true,
        'message' => 'Acceso concedido',
        'user' => $username
    ]);
} else {
    logActivity('login_failed', 'Intento fallido', "Usuario: $username");
    echo json_encode([
        'success' => false,
        'message' => 'Usuario o contraseña incorrectos'
    ]);
}