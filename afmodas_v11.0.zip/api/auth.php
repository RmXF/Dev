<?php

error_reporting(0);
ini_set('display_errors', 0);

header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit(0);
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);

    echo json_encode([
        'success' => false,
        'message' => 'Método no permitido'
    ]);

    exit;
}

$usersFile = __DIR__ . '/../config/admin_users.json';
$users = [];

if (file_exists($usersFile)) {

    $content = file_get_contents($usersFile);

    if ($content !== false) {

        $data = json_decode($content, true);

        if (
            $data &&
            isset($data['users']) &&
            is_array($data['users'])
        ) {
            $users = $data['users'];
        }

    }

}

$input = file_get_contents('php://input');
$data = json_decode($input, true);

$username = $data['username'] ?? '';
$password = $data['password'] ?? '';

if (empty($username) || empty($password)) {

    echo json_encode([
        'success' => false,
        'message' => 'Usuario y contraseña requeridos'
    ]);

    exit;

}

$auth_success = false;

foreach ($users as $user) {

    if (
        isset($user['username']) &&
        isset($user['password']) &&
        $user['username'] === $username &&
        $user['password'] === hash('sha256', $password)
    ) {

        $auth_success = true;
        break;

    }

}

if ($auth_success) {

    echo json_encode([
        'success' => true,
        'message' => 'Acceso concedido',
        'user' => $username
    ]);

} else {

    echo json_encode([
        'success' => false,
        'message' => 'Usuario o contraseña incorrectos'
    ]);

}

?>
