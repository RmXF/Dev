<?php
declare(strict_types=1);

// AF MODAS · Autenticación exclusivamente en el servidor.
ini_set('display_errors', '0');
require_once __DIR__ . '/security.php';

header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store, private');
header('X-Content-Type-Options: nosniff');

$method = $_SERVER['REQUEST_METHOD'] ?? 'GET';
if (!in_array($method, ['GET', 'POST', 'DELETE'], true)) {
    header('Allow: GET, POST, DELETE');
    af_json(['success' => false, 'message' => 'Método no permitido.'], 405);
}

af_start_session();

if ($method === 'GET') {
    $authenticated = af_authenticated();
    af_json([
        'success' => true, 'authenticated' => $authenticated,
        'user' => $authenticated ? $_SESSION['admin_user'] : null,
        'csrf_token' => af_csrf()
    ]);
}

af_check_csrf();

if ($method === 'DELETE') {
    af_logout();
    af_json(['success' => true, 'message' => 'Sesión cerrada.']);
}

$raw = file_get_contents('php://input', false, null, 0, 16385);
if ($raw === false || strlen($raw) > 16384) {
    af_json(['success' => false, 'message' => 'Solicitud inválida.'], 400);
}
$input = json_decode($raw, true);
if (!is_array($input) || !is_string($input['username'] ?? null)
    || !is_string($input['password'] ?? null)) {
    af_json(['success' => false, 'message' => 'Ingresá usuario y contraseña.'], 400);
}

$username = trim($input['username']);
$password = $input['password'];
if ($username === '' || strlen($username) > 100
    || $password === '' || strlen($password) > 4096) {
    af_json(['success' => false, 'message' => 'Ingresá credenciales válidas.'], 400);
}

// Diez intentos por usuario e IP durante quince minutos.
// Se usa REMOTE_ADDR: las cabeceras de proxies no se confían automáticamente.
$ip = (string) ($_SERVER['REMOTE_ADDR'] ?? 'unknown');
$key = hash('sha256', $ip . '|' . strtolower($username));
$limiterFile = __DIR__ . '/../data/login_attempts.json';
$handle = @fopen($limiterFile, 'c+');
if ($handle === false || !flock($handle, LOCK_EX)) {
    if (is_resource($handle)) fclose($handle);
    af_json(['success' => false, 'message' => 'No se pudo verificar el acceso. Revisá los permisos de data.'], 503);
}

$contents = stream_get_contents($handle);
$attempts = json_decode($contents === false ? '' : $contents, true);
if (!is_array($attempts)) $attempts = [];
$now = time();
foreach ($attempts as $entryKey => $entry) {
    if (!is_array($entry) || $now - (int) ($entry['start'] ?? 0) >= 900) {
        unset($attempts[$entryKey]);
    }
}
$current = $attempts[$key] ?? ['start' => $now, 'count' => 0];
if ((int) $current['count'] >= 10 || (!isset($attempts[$key]) && count($attempts) >= 2000)) {
    flock($handle, LOCK_UN);
    fclose($handle);
    header('Retry-After: 900');
    af_json(['success' => false, 'message' => 'Demasiados intentos. Volvé a probar en 15 minutos.'], 429);
}
$current['count'] = (int) $current['count'] + 1;
$attempts[$key] = $current;
$encoded = json_encode($attempts);
rewind($handle);
$saved = $encoded !== false && ftruncate($handle, 0)
    && fwrite($handle, $encoded) === strlen($encoded) && fflush($handle);
flock($handle, LOCK_UN);
fclose($handle);
if (!$saved) af_json(['success' => false, 'message' => 'No se pudo verificar el acceso.'], 503);

$usersFile = __DIR__ . '/../config/admin_users.json';
$content = @file_get_contents($usersFile);
$config = $content === false ? null : json_decode($content, true);
if (!is_array($config) || !is_array($config['users'] ?? null)) {
    af_json(['success' => false, 'message' => 'La configuración de acceso no está disponible.'], 503);
}

$matched = null;
foreach ($config['users'] as $user) {
    if (!is_array($user) || ($user['username'] ?? null) !== $username
        || !is_string($user['password'] ?? null)) continue;
    $hash = $user['password'];
    // Compatibilidad con los SHA-256 del proyecto y con password_hash().
    $valid = preg_match('/^[a-f0-9]{64}$/i', $hash)
        ? hash_equals(strtolower($hash), hash('sha256', $password))
        : password_verify($password, $hash);
    if ($valid) $matched = $user;
    break;
}

if ($matched === null) {
    af_json(['success' => false, 'message' => 'Usuario o contraseña incorrectos.'], 401);
}

// Limpiar el contador solo después de verificar las credenciales.
$handle = @fopen($limiterFile, 'c+');
if ($handle !== false) {
    if (flock($handle, LOCK_EX)) {
        $attempts = json_decode((string) stream_get_contents($handle), true);
        if (is_array($attempts)) {
            unset($attempts[$key]);
            $encoded = json_encode($attempts);
            if ($encoded !== false) {
                rewind($handle);
                if (ftruncate($handle, 0)) { fwrite($handle, $encoded); fflush($handle); }
            }
        }
        flock($handle, LOCK_UN);
    }
    fclose($handle);
}

session_regenerate_id(true);
$_SESSION = [
    'admin_user' => $matched['username'],
    'created_at' => time(), 'last_seen' => time(),
    'csrf' => bin2hex(random_bytes(32))
];

require_once __DIR__ . '/log_activity.php';
logActivityEvent('login', 'Inicio de sesión', 'Acceso al panel de administración', $matched['username'], $ip);

af_json([
    'success' => true, 'authenticated' => true,
    'message' => 'Acceso concedido.', 'user' => $matched['username'],
    'csrf_token' => $_SESSION['csrf']
]);
