<?php
declare(strict_types=1);

// AF MODAS · Exportación, importación y vaciado del catálogo.
ini_set('display_errors', '0');
require_once __DIR__ . '/security.php';
require_once __DIR__ . '/product_gallery.php';
require_once __DIR__ . '/log_activity.php';

$method = $_SERVER['REQUEST_METHOD'] ?? 'GET';
if (!in_array($method, ['GET', 'POST', 'DELETE'], true)) {
    header('Allow: GET, POST, DELETE');
    af_json(['success' => false, 'message' => 'Método no permitido'], 405);
}
af_require_admin();

$dataDir = __DIR__ . '/../data';
$productsFile = $dataDir . '/products.json';
$snapshotsDir = $dataDir . '/backup_snapshots';

function backupReadProducts(string $file): array {
    if (!is_file($file)) return [];
    $raw = @file_get_contents($file);
    if ($raw === false) af_json(['success' => false, 'message' => 'No se pudo leer el catálogo'], 500);
    $data = json_decode($raw, true);
    if (!is_array($data)) af_json(['success' => false, 'message' => 'El catálogo contiene JSON inválido'], 500);
    if (isset($data['products']) && is_array($data['products'])) $data = $data['products'];
    foreach ($data as $entry) {
        if (!is_array($entry)) af_json(['success' => false, 'message' => 'El catálogo tiene registros inválidos'], 500);
    }
    return array_values($data);
}

function backupLock(string $directory) {
    if (!is_dir($directory) || !is_writable($directory)) {
        af_json(['success' => false, 'message' => 'La carpeta data no está disponible para escritura'], 503);
    }
    $handle = @fopen($directory . '/products.lock', 'c');
    if ($handle === false || !@flock($handle, LOCK_EX)) {
        af_json(['success' => false, 'message' => 'No se pudo bloquear el catálogo'], 503);
    }
    return $handle;
}

function backupSnapshot(string $directory, array $products): void {
    if (!is_dir($directory) && !@mkdir($directory, 0750, true)) {
        af_json(['success' => false, 'message' => 'No se pudo crear la copia previa'], 500);
    }
    $name = date('Ymd-His') . '-' . bin2hex(random_bytes(4)) . '.json';
    $json = json_encode($products, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_INVALID_UTF8_SUBSTITUTE);
    if ($json === false || @file_put_contents($directory . '/' . $name, $json, LOCK_EX) !== strlen($json)) {
        af_json(['success' => false, 'message' => 'No se pudo guardar la copia previa'], 500);
    }
}

function backupWriteProducts(string $file, array $products): void {
    $json = json_encode(array_values($products), JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_INVALID_UTF8_SUBSTITUTE);
    if ($json === false) af_json(['success' => false, 'message' => 'No se pudo generar el catálogo'], 500);
    $temporary = @tempnam(dirname($file), '.products-');
    if ($temporary === false) af_json(['success' => false, 'message' => 'No se pudo preparar la escritura'], 500);
    $mode = is_file($file) ? @fileperms($file) : false;
    $permissions = $mode === false ? 0640 : ($mode & 0777);
    $written = @file_put_contents($temporary, $json, LOCK_EX);
    if ($written !== strlen($json)) {
        @unlink($temporary);
        af_json(['success' => false, 'message' => 'No se pudo escribir el catálogo'], 500);
    }
    @chmod($temporary, $permissions);
    if (!@rename($temporary, $file)) {
        @unlink($temporary);
        af_json(['success' => false, 'message' => 'No se pudo reemplazar el catálogo'], 500);
    }
}

function backupPrune(string $directory): void {
    $files = glob($directory . '/*.json');
    if (!is_array($files) || count($files) <= 10) return;
    sort($files, SORT_STRING);
    foreach (array_slice($files, 0, count($files) - 10) as $file) @unlink($file);
}

function backupText($value, int $limit): string {
    if (!is_string($value) && !is_numeric($value)) return '';
    $text = trim((string) $value);
    return strlen($text) <= $limit ? $text : '';
}

function backupNormalize(array $item): ?array {
    if (!af_validate_product_images($item)) return null;
    $images = af_product_images($item);
    $code = backupText($item['code'] ?? '', 80);
    $name = backupText($item['name'] ?? '', 250);
    $image = backupText($item['image'] ?? '', 2048);
    $price = $item['price'] ?? null;
    $stock = $item['stock'] ?? 0;
    if ($name === '' || !is_numeric($price) || (float) $price <= 0
        || (float) $price > 1000000000 || !is_numeric($stock)
        || (float) $stock < 0 || (float) $stock > 1000000
        || floor((float) $stock) !== (float) $stock) return null;

    $sizes = $item['sizes'] ?? $item['talles'] ?? '';
    if (is_array($sizes)) {
        foreach ($sizes as $size) if (!is_scalar($size)) return null;
        $sizes = implode(', ', array_map('trim', array_map('strval', $sizes)));
    }
    if (!is_string($sizes) || strlen($sizes) > 500) return null;

    return [
        'code' => $code,
        'name' => $name,
        'price' => (int) $price,
        'category' => backupText($item['category'] ?? '', 100),
        'gender' => backupText($item['gender'] ?? 'unisex', 50),
        'image' => $images[0] ?? '',
        'images' => $images,
        'sizes' => $sizes,
        'color' => backupText($item['color'] ?? '', 150),
        'stock' => (int) $stock,
        'badge' => backupText($item['badge'] ?? '', 50),
        'created_at' => backupText($item['created_at'] ?? date('c'), 64),
        'updated_at' => backupText($item['updated_at'] ?? date('c'), 64)
    ];
}

if ($method === 'GET') {
    $products = backupReadProducts($productsFile);
    header('Content-Disposition: attachment; filename="afmodas-backup-' . date('Y-m-d') . '.json"');
    af_json($products);
}

if ($method === 'POST') {
    $raw = file_get_contents('php://input', false, null, 0, 10485761);
    if ($raw === false || strlen($raw) > 10485760) {
        af_json(['success' => false, 'message' => 'El respaldo supera los 10 MB'], 413);
    }
    $input = json_decode($raw, true);
    $rows = is_array($input['products'] ?? null) ? $input['products'] : $input;
    if (!is_array($rows) || count($rows) > 5000) {
        af_json(['success' => false, 'message' => 'Respaldo inválido o demasiado grande'], 400);
    }
    $incoming = [];
    foreach ($rows as $index => $row) {
        $product = is_array($row) ? backupNormalize($row) : null;
        if ($product === null) {
            af_json(['success' => false, 'message' => 'Producto inválido en la fila ' . ((int) $index + 1)], 400);
        }
        $incoming[] = $product;
    }

    $lock = backupLock($dataDir);
    $products = backupReadProducts($productsFile);
    $codes = [];
    foreach ($products as $product) $codes[(string) ($product['code'] ?? '')] = true;
    $added = 0;
    $skipped = 0;
    foreach ($incoming as $product) {
        $code = $product['code'];
        if ($code === '') {
            do { $code = (string) random_int(10000, 99999); } while (isset($codes[$code]));
            $product['code'] = $code;
        }
        if (isset($codes[$code])) { $skipped++; continue; }
        $codes[$code] = true;
        $products[] = $product;
        $added++;
    }
    if ($added > 0) {
        if (count($products) > 10000) {
            af_json(['success' => false, 'message' => 'El catálogo supera el límite de 10 000 productos'], 400);
        }
        $previous = array_slice($products, 0, count($products) - $added);
        backupSnapshot($snapshotsDir, $previous);
        backupWriteProducts($productsFile, $products);
        backupPrune($snapshotsDir);
        logActivityEvent('backup', 'Productos importados', $added . ' agregados; ' . $skipped . ' duplicados');
    }
    af_json(['success' => true, 'imported' => $added, 'skipped' => $skipped, 'total' => count($products)]);
}

$raw = file_get_contents('php://input');
$input = json_decode($raw === false ? '' : $raw, true);
if (!is_array($input) || ($input['confirm'] ?? '') !== 'ELIMINAR') {
    af_json(['success' => false, 'message' => 'Confirmación requerida'], 400);
}
$lock = backupLock($dataDir);
$products = backupReadProducts($productsFile);
$deleted = count($products);
if (!isset($input['expected_count']) || (int) $input['expected_count'] !== $deleted) {
    af_json(['success' => false, 'message' => 'El catálogo cambió. Actualizá la página e intentá de nuevo'], 409);
}
if ($deleted > 0) {
    backupSnapshot($snapshotsDir, $products);
    backupWriteProducts($productsFile, []);
    backupPrune($snapshotsDir);
    logActivityEvent('backup', 'Catálogo eliminado', $deleted . ' productos; copia previa guardada');
}
af_json(['success' => true, 'deleted' => $deleted]);
