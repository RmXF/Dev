<?php
/**
 * AF MODAS · API de Productos
 * Endpoints:
 *   GET    /api/products.php           → Listar todos los productos
 *   GET    /api/products.php?code=XXX  → Obtener un producto
 *   POST   /api/products.php           → Crear producto
 *   PUT    /api/products.php?code=XXX  → Actualizar producto
 *   DELETE /api/products.php?code=XXX  → Eliminar producto
 */

error_reporting(0);
ini_set('display_errors', 0);

header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

// ============================================================
// CONFIGURACIÓN
// ============================================================
$dataDir  = __DIR__ . '/../data';
$dataFile = $dataDir . '/products.json';

// Crear directorio si no existe
if (!is_dir($dataDir)) {
    @mkdir($dataDir, 0777, true);
}

// Crear archivo si no existe
if (!file_exists($dataFile)) {
    file_put_contents($dataFile, json_encode([], JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
}

// ============================================================
// HELPERS
// ============================================================
function readProducts($file) {
    $content = @file_get_contents($file);
    if ($content === false) return [];
    $data = json_decode($content, true);
    if (!is_array($data)) return [];
    // Soportar estructura {products: [...]} o [...]
    if (isset($data['products']) && is_array($data['products'])) {
        return $data['products'];
    }
    return $data;
}

function writeProducts($file, $products) {
    $json = json_encode(array_values($products), JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);
    return file_put_contents($file, $json, LOCK_EX);
}

function normalizeProduct($p) {
    return [
        'code'     => isset($p['code']) ? (string)$p['code'] : '',
        'name'     => isset($p['name']) ? (string)$p['name'] : '',
        'price'    => isset($p['price']) ? (int)$p['price'] : 0,
        'category' => isset($p['category']) ? (string)$p['category'] : '',
        'gender'   => isset($p['gender']) ? (string)$p['gender'] : 'unisex',
        'image'    => isset($p['image']) ? (string)$p['image'] : '',
        'sizes'    => isset($p['sizes']) ? (string)$p['sizes'] : '',
        'color'    => isset($p['color']) ? (string)$p['color'] : '',
        'stock'    => isset($p['stock']) ? (int)$p['stock'] : 0,
        'badge'    => isset($p['badge']) ? (string)$p['badge'] : '',
        'created_at' => isset($p['created_at']) ? $p['created_at'] : date('c'),
        'updated_at' => date('c')
    ];
}

function sendJson($data, $code = 200) {
    http_response_code($code);
    echo json_encode($data, JSON_UNESCAPED_UNICODE);
    exit;
}

// ============================================================
// ROUTER
// ============================================================
$method = $_SERVER['REQUEST_METHOD'];
$products = readProducts($dataFile);

// ---------- GET ----------
if ($method === 'GET') {
    // Obtener uno por código
    if (!empty($_GET['code'])) {
        $code = $_GET['code'];
        foreach ($products as $p) {
            if (isset($p['code']) && $p['code'] === $code) {
                sendJson(['success' => true, 'data' => normalizeProduct($p)]);
            }
        }
        sendJson(['success' => false, 'message' => 'Producto no encontrado'], 404);
    }

    // Listar todos
    $normalized = array_map('normalizeProduct', $products);
    sendJson(['success' => true, 'data' => array_values($normalized)]);
}

// ---------- POST (crear) ----------
if ($method === 'POST') {
    $raw = file_get_contents('php://input');
    $input = json_decode($raw, true);

    if (!is_array($input)) {
        sendJson(['success' => false, 'message' => 'JSON inválido'], 400);
    }

    // Generar código si no viene
    if (empty($input['code'])) {
        do {
            $input['code'] = (string)mt_rand(10000, 99999);
            $exists = false;
            foreach ($products as $p) {
                if (isset($p['code']) && $p['code'] === $input['code']) {
                    $exists = true;
                    break;
                }
            }
        } while ($exists);
    }

    // Validar duplicado
    foreach ($products as $p) {
        if (isset($p['code']) && $p['code'] === $input['code']) {
            sendJson(['success' => false, 'message' => 'El código ya existe'], 409);
        }
    }

    // Validaciones mínimas
    if (empty($input['name']) || empty($input['price'])) {
        sendJson(['success' => false, 'message' => 'Nombre y precio son requeridos'], 400);
    }

    $product = normalizeProduct($input);
    $products[] = $product;

    if (writeProducts($dataFile, $products) === false) {
        sendJson(['success' => false, 'message' => 'Error al guardar en disco'], 500);
    }

    sendJson(['success' => true, 'message' => 'Producto creado', 'data' => $product], 201);
}

// ---------- PUT (actualizar) ----------
if ($method === 'PUT') {
    $code = isset($_GET['code']) ? $_GET['code'] : '';
    if (empty($code)) {
        sendJson(['success' => false, 'message' => 'Código requerido'], 400);
    }

    $raw = file_get_contents('php://input');
    $input = json_decode($raw, true);
    if (!is_array($input)) {
        sendJson(['success' => false, 'message' => 'JSON inválido'], 400);
    }

    $found = false;
    foreach ($products as $i => $p) {
        if (isset($p['code']) && $p['code'] === $code) {
            $merged = array_merge($p, $input);
            $merged['code'] = $code; // No permitir cambiar el código
            $products[$i] = normalizeProduct($merged);
            $found = true;
            break;
        }
    }

    if (!$found) {
        sendJson(['success' => false, 'message' => 'Producto no encontrado'], 404);
    }

    if (writeProducts($dataFile, $products) === false) {
        sendJson(['success' => false, 'message' => 'Error al guardar'], 500);
    }

    sendJson(['success' => true, 'message' => 'Producto actualizado']);
}

// ---------- DELETE ----------
if ($method === 'DELETE') {
    $code = isset($_GET['code']) ? $_GET['code'] : '';
    if (empty($code)) {
        sendJson(['success' => false, 'message' => 'Código requerido'], 400);
    }

    $newList = [];
    $found = false;
    foreach ($products as $p) {
        if (isset($p['code']) && $p['code'] === $code) {
            $found = true;
            continue;
        }
        $newList[] = $p;
    }

    if (!$found) {
        sendJson(['success' => false, 'message' => 'Producto no encontrado'], 404);
    }

    if (writeProducts($dataFile, $newList) === false) {
        sendJson(['success' => false, 'message' => 'Error al eliminar'], 500);
    }

    sendJson(['success' => true, 'message' => 'Producto eliminado']);
}

// ---------- Método no soportado ----------
sendJson(['success' => false, 'message' => 'Método no soportado'], 405);