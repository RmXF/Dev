<?php
/**
 * AF MODAS · API de Productos
 */

error_reporting(0);
ini_set('display_errors', 0);

header('Content-Type: application/json; charset=utf-8');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

require_once __DIR__ . '/security.php';
require_once __DIR__ . '/product_gallery.php';
af_require_admin(true);


require_once __DIR__ . '/log_activity.php';

$dataDir  = __DIR__ . '/../data';
$dataFile = $dataDir . '/products.json';

if (!is_dir($dataDir)) {
    @mkdir($dataDir, 0777, true);
}

if (!file_exists($dataFile)) {
    file_put_contents($dataFile, json_encode([], JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
}

function readProducts($file) {
    $content = @file_get_contents($file);
    if ($content === false) sendJson(['success' => false, 'message' => 'No se pudo leer el catálogo'], 500);
    $data = json_decode($content, true);
    if (!is_array($data)) sendJson(['success' => false, 'message' => 'El catálogo contiene JSON inválido'], 500);
    if (isset($data['products']) && is_array($data['products'])) {
        return $data['products'];
    }
    return $data;
}

function writeProducts($file, $products) {
    $json = json_encode(array_values($products), JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);
    if ($json === false) return false;
    $temporary = @tempnam(dirname($file), '.products-');
    if ($temporary === false) return false;
    $mode = is_file($file) ? @fileperms($file) : false;
    $permissions = $mode === false ? 0640 : ($mode & 0777);
    $written = @file_put_contents($temporary, $json, LOCK_EX);
    if ($written !== strlen($json)) {
        @unlink($temporary);
        return false;
    }
    @chmod($temporary, $permissions);
    if (!@rename($temporary, $file)) {
        @unlink($temporary);
        return false;
    }
    return true;
}

// ⭐ FUNCIÓN CLAVE: Normaliza los talles a STRING
function normalizeSizesToString($sizes) {
    if (empty($sizes)) return '';

    // Array real
    if (is_array($sizes)) {
        return implode(', ', array_filter(array_map(function($s) {
            return trim((string)$s);
        }, $sizes)));
    }

    // String
    if (is_string($sizes)) {
        $trimmed = trim($sizes);
        if ($trimmed === '') return '';

        // ¿Es un JSON array como string? '["S","M","L"]'
        if (strlen($trimmed) > 1 && $trimmed[0] === '[' && substr($trimmed, -1) === ']') {
            $parsed = json_decode($trimmed, true);
            if (is_array($parsed)) {
                return implode(', ', array_filter(array_map(function($s) {
                    return trim((string)$s);
                }, $parsed)));
            }
            // Si falla, limpiar manualmente
            $cleaned = str_replace(['[', ']', '"', "'"], '', $trimmed);
            $parts = array_filter(array_map('trim', explode(',', $cleaned)));
            return implode(', ', $parts);
        }

        // String normal "S,M,L" → normalizar a "S, M, L"
        $parts = array_filter(array_map('trim', explode(',', $trimmed)));
        return implode(', ', $parts);
    }

    return '';
}

function normalizeProduct($p) {
    $images = af_product_images($p);
    return [
        'code'     => isset($p['code']) ? (string)$p['code'] : '',
        'name'     => isset($p['name']) ? (string)$p['name'] : '',
        'price'    => isset($p['price']) ? (int)$p['price'] : 0,
        'category' => isset($p['category']) ? (string)$p['category'] : '',
        'gender'   => isset($p['gender']) ? (string)$p['gender'] : 'unisex',
        'image'    => $images[0] ?? '',
        'images'   => $images,
        // ⭐ TALLES: SIEMPRE STRING
        'sizes'    => normalizeSizesToString($p['sizes'] ?? $p['talles'] ?? $p['tallesDisponibles'] ?? ''),
        'color'    => isset($p['color']) ? (string)$p['color'] : '',
        'stock'    => isset($p['stock']) ? (int)$p['stock'] : 0,
        'badge'    => isset($p['badge']) ? (string)$p['badge'] : '',
        'created_at' => isset($p['created_at']) ? $p['created_at'] : date('c'),
        'updated_at' => date('c')
    ];
}

function sendJson($data, $code = 200) {
    http_response_code($code);
    echo json_encode($data, JSON_UNESCAPED_UNICODE);
    exit;
}

$method = $_SERVER['REQUEST_METHOD'];
if ($method !== 'GET') {
    // El backup utiliza el mismo candado para que las escrituras no se pisen.
    $productLock = @fopen($dataDir . '/products.lock', 'c');
    if ($productLock === false || !@flock($productLock, LOCK_EX)) {
        sendJson(['success' => false, 'message' => 'No se pudo bloquear el catálogo'], 503);
    }
}
$products = readProducts($dataFile);

// ---------- GET ----------
if ($method === 'GET') {
    if (!empty($_GET['code'])) {
        $code = $_GET['code'];
        foreach ($products as $p) {
            if (isset($p['code']) && $p['code'] === $code) {
                sendJson(['success' => true, 'data' => normalizeProduct($p)]);
            }
        }
        sendJson(['success' => false, 'message' => 'Producto no encontrado'], 404);
    }
    $normalized = array_map('normalizeProduct', $products);
    sendJson(['success' => true, 'data' => array_values($normalized)]);
}

// ---------- POST (crear) ----------
if ($method === 'POST') {
    $raw = file_get_contents('php://input');
    $input = json_decode($raw, true);

    if (!is_array($input)) {
        sendJson(['success' => false, 'message' => 'JSON inválido'], 400);
    }

    if (empty($input['code'])) {
        do {
            $input['code'] = (string)mt_rand(10000, 99999);
            $exists = false;
            foreach ($products as $p) {
                if (isset($p['code']) && $p['code'] === $input['code']) {
                    $exists = true;
                    break;
                }
            }
        } while ($exists);
    }

    foreach ($products as $p) {
        if (isset($p['code']) && $p['code'] === $input['code']) {
            sendJson(['success' => false, 'message' => 'El código ya existe'], 409);
        }
    }

    if (empty($input['name']) || empty($input['price'])) {
        sendJson(['success' => false, 'message' => 'Nombre y precio son requeridos'], 400);
    }

    if (!af_validate_product_images($input)) sendJson(['success' => false, 'message' => 'Usá hasta 12 imágenes con enlaces HTTP o HTTPS válidos'], 400);
    $product = normalizeProduct($input);
    $products[] = $product;

    if (writeProducts($dataFile, $products) === false) {
        sendJson(['success' => false, 'message' => 'Error al guardar en disco'], 500);
    }

    // ⭐ REGISTRAR ACTIVIDAD: producto agregado
    logActivityEvent(
        'product_add',
        'Producto agregado',
        'Se agregó "' . $product['name'] . '" (#' . $product['code'] . ') · $' . number_format($product['price'], 0, ',', '.') . ' · Stock: ' . $product['stock']
    );

    sendJson(['success' => true, 'message' => 'Producto creado', 'data' => $product], 201);
}

// ---------- PUT (actualizar) ----------
if ($method === 'PUT') {
    $code = isset($_GET['code']) ? $_GET['code'] : '';
    if (empty($code)) {
        sendJson(['success' => false, 'message' => 'Código requerido'], 400);
    }

    $raw = file_get_contents('php://input');
    $input = json_decode($raw, true);
    if (!is_array($input)) {
        sendJson(['success' => false, 'message' => 'JSON inválido'], 400);
    }

    $found = false;
    $oldProduct = null;
    if (!af_validate_product_images($input)) sendJson(['success' => false, 'message' => 'Usá hasta 12 imágenes con enlaces HTTP o HTTPS válidos'], 400);
    foreach ($products as $i => $p) {
        if (isset($p['code']) && $p['code'] === $code) {
            $oldProduct = $p;
            $merged = array_merge($p, $input);
            $merged['code'] = $code;
            $products[$i] = normalizeProduct($merged);
            $found = true;
            break;
        }
    }

    if (!$found) {
        sendJson(['success' => false, 'message' => 'Producto no encontrado'], 404);
    }

    if (writeProducts($dataFile, $products) === false) {
        sendJson(['success' => false, 'message' => 'Error al guardar'], 500);
    }

    // ⭐ REGISTRAR ACTIVIDAD: producto actualizado
    // Detectar qué cambió
    $changes = [];
    $newProduct = null;
    foreach ($products as $p) {
        if (isset($p['code']) && $p['code'] === $code) {
            $newProduct = $p;
            break;
        }
    }

    if ($oldProduct && $newProduct) {
        if (af_product_images($oldProduct) !== af_product_images($newProduct)) $changes[] = 'galería de imágenes';
        if ($oldProduct['name'] !== $newProduct['name']) {
            $changes[] = 'nombre';
        }
        if ($oldProduct['price'] != $newProduct['price']) {
            $changes[] = 'precio ($' . number_format($oldProduct['price'], 0, ',', '.') . ' → $' . number_format($newProduct['price'], 0, ',', '.') . ')';
        }
        if ($oldProduct['stock'] != $newProduct['stock']) {
            $changes[] = 'stock (' . $oldProduct['stock'] . ' → ' . $newProduct['stock'] . ')';
        }
        if ($oldProduct['sizes'] !== $newProduct['sizes']) {
            $changes[] = 'talles';
        }
        if ($oldProduct['color'] !== $newProduct['color']) {
            $changes[] = 'color';
        }
        if ($oldProduct['category'] !== $newProduct['category']) {
            $changes[] = 'categoría';
        }
        if ($oldProduct['gender'] !== $newProduct['gender']) {
            $changes[] = 'género';
        }
    }

    $detailsMsg = 'Se editó "' . ($newProduct['name'] ?? $code) . '" (#' . $code . ')';
    if (!empty($changes)) {
        $detailsMsg .= ' · Cambios: ' . implode(', ', $changes);
    }

    logActivityEvent(
        'settings',
        'Producto actualizado',
        $detailsMsg
    );

    sendJson(['success' => true, 'message' => 'Producto actualizado']);
}

// ---------- DELETE ----------
if ($method === 'DELETE') {
    $code = isset($_GET['code']) ? $_GET['code'] : '';
    if (empty($code)) {
        sendJson(['success' => false, 'message' => 'Código requerido'], 400);
    }

    $newList = [];
    $found = false;
    $deletedProduct = null;
    foreach ($products as $p) {
        if (isset($p['code']) && $p['code'] === $code) {
            $found = true;
            $deletedProduct = $p;
            continue;
        }
        $newList[] = $p;
    }

    if (!$found) {
        sendJson(['success' => false, 'message' => 'Producto no encontrado'], 404);
    }

    if (writeProducts($dataFile, $newList) === false) {
        sendJson(['success' => false, 'message' => 'Error al eliminar'], 500);
    }

    // ⭐ REGISTRAR ACTIVIDAD: producto eliminado
    if ($deletedProduct) {
        logActivityEvent(
            'product_delete',
            'Producto eliminado',
            'Se eliminó "' . $deletedProduct['name'] . '" (#' . $deletedProduct['code'] . ') · $' . number_format($deletedProduct['price'], 0, ',', '.')
        );
    }

    sendJson(['success' => true, 'message' => 'Producto eliminado']);
}

sendJson(['success' => false, 'message' => 'Método no soportado'], 405);
