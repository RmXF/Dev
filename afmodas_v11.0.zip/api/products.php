<?php
// ============================================
// AF MODAS - API PRODUCTOS
// ============================================

header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') { exit(0); }

require_once __DIR__ . '/../config/config.php';

if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    $products = readJson('products');
    $code = $_GET['code'] ?? null;
    if ($code) {
        foreach ($products as $p) {
            if ($p['code'] === $code) {
                echo json_encode($p);
                exit;
            }
        }
        echo json_encode(null);
    } else {
        echo json_encode($products);
    }
} elseif ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $data = json_decode(file_get_contents('php://input'), true);
    $products = readJson('products');
    
    do {
        $code = str_pad(rand(0, 99999), 5, '0', STR_PAD_LEFT);
        $exists = false;
        foreach ($products as $p) {
            if ($p['code'] === $code) { $exists = true; break; }
        }
    } while ($exists);
    
    $data['code'] = $code;
    $data['createdAt'] = date('Y-m-d H:i:s');
    $products[] = $data;
    writeJson('products', $products);
    logActivity('add', 'Producto agregado', $data['name'] ?? 'Sin nombre');
    echo json_encode(['success' => true, 'code' => $code, 'product' => $data]);
} elseif ($_SERVER['REQUEST_METHOD'] === 'PUT') {
    $data = json_decode(file_get_contents('php://input'), true);
    $code = $data['code'] ?? '';
    $products = readJson('products');
    foreach ($products as $key => $p) {
        if ($p['code'] === $code) {
            $data['updatedAt'] = date('Y-m-d H:i:s');
            $products[$key] = $data;
            break;
        }
    }
    writeJson('products', $products);
    logActivity('edit', 'Producto editado', $data['name'] ?? 'Sin nombre');
    echo json_encode(['success' => true]);
} elseif ($_SERVER['REQUEST_METHOD'] === 'DELETE') {
    $code = $_GET['code'] ?? '';
    $products = readJson('products');
    $name = '';
    foreach ($products as $p) {
        if ($p['code'] === $code) { $name = $p['name'] ?? ''; break; }
    }
    $products = array_filter($products, function($p) use ($code) {
        return $p['code'] !== $code;
    });
    writeJson('products', array_values($products));
    logActivity('delete', 'Producto eliminado', $name);
    echo json_encode(['success' => true]);
}