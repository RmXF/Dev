<?php
declare(strict_types=1);
// Cálculo común para vista previa y comprobante del carrito.
function cartError(string $message, int $status = 400): void {
    http_response_code($status);
    header('Content-Type: application/json; charset=utf-8');
    header('Cache-Control: no-store');
    echo json_encode(['success' => false, 'message' => $message], JSON_UNESCAPED_UNICODE);
    exit;
}
function cartInput(): array {
    $raw = file_get_contents('php://input', false, null, 0, 16385);
    if ($raw === false || strlen($raw) > 16384) cartError('Pedido demasiado grande', 413);
    $data = json_decode($raw, true);
    if (!is_array($data)) cartError('Pedido inválido');
    return $data;
}
function cartRead(string $path, string $label): array {
    $raw = @file_get_contents($path);
    $data = $raw === false ? null : json_decode($raw, true);
    if (!is_array($data)) cartError($label . ' no disponible', 503);
    if ($label === 'Catálogo' && isset($data['products']) && is_array($data['products'])) $data = $data['products'];
    return $data;
}
function cartQuote(array $data, ?array $coupons = null): array {
    $rows = $data['items'] ?? null;
    $code = $data['coupon'] ?? '';
    if (!is_array($rows) || count($rows) < 1 || count($rows) > 50 || !is_string($code) || strlen($code) > 40) cartError('Carrito inválido');
    $products = cartRead(__DIR__ . '/../data/products.json', 'Catálogo');
    $lookup = [];
    foreach ($products as $product) if (is_array($product) && isset($product['code'])) $lookup[(string) $product['code']] = $product;
    $quantities = [];
    foreach ($rows as $row) {
        if (!is_array($row) || !isset($row['code'], $row['qty']) || !is_scalar($row['code']) || !is_int($row['qty']) || $row['qty'] < 1 || $row['qty'] > 100) cartError('Cantidad inválida');
        $id = (string) $row['code'];
        if (strlen($id) > 80 || !isset($lookup[$id])) cartError('Un producto ya no está disponible. Actualizá el carrito.', 409);
        $quantities[$id] = ($quantities[$id] ?? 0) + $row['qty'];
    }
    $items = []; $subtotal = 0;
    foreach ($quantities as $id => $qty) {
        $product = $lookup[$id];
        $price = (int) ($product['price'] ?? 0);
        if ($price < 0 || $qty > (int) ($product['stock'] ?? 0)) cartError('Revisá el stock disponible antes de pedir.', 409);
        $sizes = $product['sizes'] ?? $product['talles'] ?? '';
        if (is_string($sizes) && isset($sizes[0]) && $sizes[0] === '[') {
            $decodedSizes = json_decode($sizes, true);
            if (is_array($decodedSizes)) $sizes = $decodedSizes;
        }
        if (is_array($sizes)) $sizes = implode(', ', array_map('strval', array_filter($sizes, 'is_scalar')));
        $item = [
            'code' => $id, 'name' => (string) ($product['name'] ?? ''),
            'color' => (string) ($product['color'] ?? ''), 'gender' => (string) ($product['gender'] ?? 'unisex'),
            'sizes' => is_scalar($sizes) ? (string) $sizes : '',
            'price' => $price, 'qty' => $qty, 'subtotal' => $price * $qty
        ];
        $items[] = $item;
        $subtotal += $item['subtotal'];
    }
    $discount = 0; $applied = '';
    $code = strtoupper(trim($code));
    if ($code !== '') {
        if ($coupons === null) $coupons = cartRead(__DIR__ . '/../data/coupons.json', 'Cupones');
        $coupon = null;
        foreach ($coupons as $entry) if (is_array($entry) && strtoupper(trim((string) ($entry['code'] ?? ''))) === $code) { $coupon = $entry; break; }
        if ($coupon === null) cartError('El cupón no existe', 422);
        if (array_key_exists('active', $coupon) && !$coupon['active']) cartError('El cupón está desactivado', 422);
        $expiry = (string) ($coupon['expiry'] ?? '');
        $today = new DateTimeImmutable('today', new DateTimeZone('America/Argentina/Buenos_Aires'));
        if (!preg_match('/^\d{4}-\d{2}-\d{2}$/D', $expiry) || $expiry < $today->format('Y-m-d')) cartError('El cupón está vencido', 422);
        $limit = (int) ($coupon['limit'] ?? 0);
        if ($limit <= 0 || (int) ($coupon['used'] ?? 0) >= $limit) cartError('El cupón está agotado', 422);
        $value = (float) ($coupon['value'] ?? 0);
        if (!is_finite($value) || $value <= 0) cartError('Cupón inválido', 422);
        if (($coupon['type'] ?? '') === 'percent') $discount = (int) round($subtotal * min(100, $value) / 100);
        elseif (in_array($coupon['type'] ?? '', ['fixed', 'amount'], true)) $discount = (int) round(min($subtotal, $value));
        else cartError('Tipo de cupón inválido', 422);
        $applied = (string) ($coupon['code'] ?? $code);
    }
    return ['success' => true, 'items' => $items, 'subtotal' => $subtotal, 'discount' => $discount, 'total' => max(0, $subtotal - $discount), 'coupon' => $applied];
}
