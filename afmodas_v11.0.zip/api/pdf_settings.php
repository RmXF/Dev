<?php
declare(strict_types=1);
require_once __DIR__ . '/security.php';
af_require_admin(true);
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');
header('X-Content-Type-Options: nosniff');
$defaults = ['name'=>'AF MODAS','address'=>'','phone'=>'','social'=>'','website'=>'','thanks'=>'Gracias por elegir AF MODAS.','instructions'=>'El comercio confirmará disponibilidad, entrega y forma de pago.','disclaimer'=>'Resumen del pedido. No acredita pago.','color'=>'#692e45','logo'=>''];
$file = __DIR__ . '/../data/pdf_settings.json';
$method = $_SERVER['REQUEST_METHOD'] ?? 'GET';
if ($method === 'GET') {
    $saved = is_file($file) ? json_decode((string)@file_get_contents($file),true) : [];
    if (!is_array($saved)) af_json(['success'=>false,'message'=>'Configuración PDF no disponible'],503);
    af_json(['success'=>true,'data'=>array_merge($defaults,array_intersect_key($saved,$defaults))]);
}
if ($method !== 'POST') af_json(['success'=>false,'message'=>'Método no permitido'],405);
$raw = file_get_contents('php://input',false,null,0,450001);
if ($raw === false || strlen($raw)>450000) af_json(['success'=>false,'message'=>'El logo supera el tamaño permitido'],413);
$input = json_decode($raw,true);
if (!is_array($input)) af_json(['success'=>false,'message'=>'Datos inválidos'],422);
$limits = ['name'=>100,'address'=>240,'phone'=>80,'social'=>160,'website'=>200,'thanks'=>300,'instructions'=>1000,'disclaimer'=>300,'color'=>7,'logo'=>400000];
$data = [];
foreach ($limits as $key=>$limit) {
    $value = $input[$key] ?? $defaults[$key];
    if (!is_string($value) || strlen($value)>$limit*($key==='logo'?1:4)) af_json(['success'=>false,'message'=>'Revisá el campo '.$key],422);
    $data[$key] = trim($value);
}
if ($data['name']==='' || !preg_match('/^#[a-f0-9]{6}$/iD',$data['color'])) af_json(['success'=>false,'message'=>'Nombre y color válidos son obligatorios'],422);
if ($data['logo']!=='') {
    if (!preg_match('/^data:image\/png;base64,([A-Za-z0-9+\/=]+)$/D',$data['logo'],$m)) af_json(['success'=>false,'message'=>'Logo PNG inválido'],422);
    $bytes = base64_decode($m[1],true);
    $size = $bytes === false ? false : @getimagesizefromstring($bytes);
    if (!$size || $size[2]!==IMAGETYPE_PNG || $size[0]>512 || $size[1]>512) af_json(['success'=>false,'message'=>'El logo debe ser PNG de hasta 512 píxeles'],422);
}
$dir = dirname($file);
if (!is_dir($dir) && !@mkdir($dir,0750,true)) af_json(['success'=>false,'message'=>'No se pudo crear el almacenamiento'],503);
$tmp = @tempnam($dir,'.pdf-');
$json = json_encode($data,JSON_UNESCAPED_UNICODE|JSON_PRETTY_PRINT);
if (!$tmp || $json===false || @file_put_contents($tmp,$json,LOCK_EX)!==strlen($json)) { if($tmp) @unlink($tmp); af_json(['success'=>false,'message'=>'No se pudo guardar'],503); }
@chmod($tmp,0640);
if (!@rename($tmp,$file)) { @unlink($tmp); af_json(['success'=>false,'message'=>'No se pudo guardar'],503); }
af_json(['success'=>true,'data'=>$data]);
