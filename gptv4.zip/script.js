// ============================================
// VPS CONTROL PANEL - CON CONEXIÓN PHP
// ============================================

// Configuración
const API_URL = 'http://localhost/vps-panel'; // Cambia esto a tu URL

// ============================================
// FUNCIONES DEL MODAL DE AGREGAR SERVIDOR
// ============================================

// Abrir modal para agregar servidor
window.openAddServerModal = function() {
    console.log('Abriendo modal de agregar servidor...');
    const modal = document.getElementById('addServerModal');
    const overlay = document.getElementById('overlay');
    
    if (modal) {
        modal.classList.add('active');
        overlay.classList.add('active');
        document.body.style.overflow = 'hidden';
        
        const form = document.getElementById('addServerForm');
        if (form) {
            form.reset();
            document.getElementById('serverPort').value = '22';
        }
        
        const connectionTest = document.getElementById('connectionTest');
        if (connectionTest) {
            connectionTest.style.display = 'none';
        }
    }
}

// Cerrar modal de agregar servidor
window.closeModal = function() {
    const modal = document.getElementById('addServerModal');
    const overlay = document.getElementById('overlay');
    
    if (modal) {
        modal.classList.remove('active');
        overlay.classList.remove('active');
        document.body.style.overflow = '';
        
        const form = document.getElementById('addServerForm');
        if (form) {
            form.reset();
            document.getElementById('serverPort').value = '22';
        }
        
        const connectionTest = document.getElementById('connectionTest');
        if (connectionTest) {
            connectionTest.style.display = 'none';
        }
        
        const submitBtn = document.getElementById('addServerSubmit');
        if (submitBtn) {
            submitBtn.disabled = false;
            submitBtn.innerHTML = '<i class="fas fa-plus"></i> Agregar Servidor';
        }
    }
}

// Mostrar/ocultar contraseña
window.togglePassword = function() {
    const passwordInput = document.getElementById('serverPassword');
    const toggleBtn = document.querySelector('.password-toggle i');
    
    if (passwordInput) {
        if (passwordInput.type === 'password') {
            passwordInput.type = 'text';
            if (toggleBtn) toggleBtn.className = 'fas fa-eye-slash';
        } else {
            passwordInput.type = 'password';
            if (toggleBtn) toggleBtn.className = 'fas fa-eye';
        }
    }
}

// Probar conexión y agregar servidor con PHP
window.testAndAddServer = async function() {
    console.log('Probando conexión vía PHP...');
    
    const form = document.getElementById('addServerForm');
    const submitBtn = document.getElementById('addServerSubmit');
    const connectionTest = document.getElementById('connectionTest');
    
    if (!form) return;
    
    if (!form.checkValidity()) {
        form.reportValidity();
        return;
    }
    
    const serverData = {
        ip: document.getElementById('serverIP')?.value || '',
        port: parseInt(document.getElementById('serverPort')?.value) || 22,
        user: document.getElementById('serverUser')?.value || '',
        password: document.getElementById('serverPassword')?.value || '',
        name: document.getElementById('serverName')?.value || '',
        location: document.getElementById('serverLocation')?.value || 'Desconocido',
        save_credentials: document.getElementById('saveCredentials')?.checked || false,
        auto_connect: document.getElementById('autoConnect')?.checked || false
    };
    
    // Validar datos básicos
    if (!serverData.name || !serverData.ip || !serverData.user || !serverData.password) {
        showToast('Error', 'Todos los campos son obligatorios', 'error');
        return;
    }
    
    // Mostrar test de conexión
    if (connectionTest) {
        connectionTest.style.display = 'flex';
        connectionTest.querySelector('span').textContent = 'Conectando al servidor...';
    }
    
    if (submitBtn) {
        submitBtn.disabled = true;
        submitBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Conectando...';
    }
    
    try {
        // 1. Probar conexión SSH vía PHP
        const connectResponse = await fetch(`${API_URL}/connect.php`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                ip: serverData.ip,
                port: serverData.port,
                user: serverData.user,
                password: serverData.password
            })
        });
        
        const connectResult = await connectResponse.json();
        
        if (!connectResult.success) {
            throw new Error(connectResult.error || 'Error de conexión');
        }
        
        // Actualizar mensaje
        if (connectionTest) {
            connectionTest.querySelector('span').textContent = 'Conexión exitosa, guardando servidor...';
        }
        
        // 2. Guardar servidor con la información obtenida
        const serverInfo = connectResult.server;
        
        const saveResponse = await fetch(`${API_URL}/save_server.php`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                ...serverData,
                cpu: serverInfo.cpu,
                ram: serverInfo.ram,
                disk: serverInfo.disk,
                uptime: serverInfo.uptime,
                os: serverInfo.os,
                kernel: serverInfo.kernel,
                cpu_cores: serverInfo.cpu_cores,
                ram_total: serverInfo.ram_total,
                disk_total: serverInfo.disk_total
            })
        });
        
        const saveResult = await saveResponse.json();
        
        if (!saveResult.success) {
            throw new Error(saveResult.error || 'Error al guardar servidor');
        }
        
        showToast('¡Éxito!', `Servidor ${serverData.name} agregado correctamente`, 'success');
        
        // Recargar servidores
        await loadServersFromAPI();
        
        // Cerrar modal
        setTimeout(() => {
            closeModal();
        }, 1000);
        
    } catch (error) {
        console.error('Error:', error);
        showToast('Error', error.message, 'error');
        
        if (connectionTest) {
            connectionTest.style.display = 'none';
        }
    } finally {
        if (submitBtn) {
            submitBtn.disabled = false;
            submitBtn.innerHTML = '<i class="fas fa-plus"></i> Agregar Servidor';
        }
    }
}

// Cargar servidores desde API
async function loadServersFromAPI() {
    try {
        const response = await fetch(`${API_URL}/get_servers.php`);
        const result = await response.json();
        
        if (result.success) {
            localStorage.setItem('vps_servers', JSON.stringify(result.servers));
            renderServers();
            updateStats();
            addActivity('Servidores cargados desde el servidor', 'success');
        }
    } catch (error) {
        console.error('Error cargando servidores:', error);
        showToast('Error', 'No se pudieron cargar los servidores', 'error');
    }
}

// Controlar servidor (iniciar/detener/reiniciar) vía PHP
window.controlServer = async function(serverId, action) {
    console.log(`Controlando servidor ${serverId}: ${action}`);
    
    const servers = JSON.parse(localStorage.getItem('vps_servers') || '[]');
    const server = servers.find(s => s.id === serverId);
    
    if (!server) {
        showToast('Error', 'Servidor no encontrado', 'error');
        return;
    }
    
    const actions = {
        start: { status: 'active', message: 'iniciado' },
        stop: { status: 'stopped', message: 'detenido' },
        restart: { status: 'active', message: 'reiniciado' }
    };
    
    const actionData = actions[action];
    
    if (!actionData) {
        showToast('Error', 'Acción no válida', 'error');
        return;
    }
    
    if (action === 'restart') {
        // Para reiniciar, usar API
        showToast('Reiniciando', `Servidor ${server.name} se está reiniciando...`, 'info');
        
        try {
            const response = await fetch(`${API_URL}/control_server.php`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({
                    id: serverId,
                    action: 'restart'
                })
            });
            
            const result = await response.json();
            
            if (result.success) {
                server.status = 'stopped';
                localStorage.setItem('vps_servers', JSON.stringify(servers));
                renderServers();
                
                setTimeout(async () => {
                    // Actualizar información después del reinicio
                    await updateServerInfo(serverId);
                    showToast('Reinicio completado', `Servidor ${server.name} está nuevamente activo`, 'success');
                    addActivity(`Servidor ${server.name} reiniciado correctamente`, 'success');
                }, 5000);
            } else {
                throw new Error(result.error || 'Error al reiniciar');
            }
        } catch (error) {
            showToast('Error', error.message, 'error');
        }
    } else {
        // Para start/stop, solo actualizar estado local
        server.status = actionData.status;
        server.lastChecked = new Date().toISOString();
        localStorage.setItem('vps_servers', JSON.stringify(servers));
        renderServers();
        updateStats();
        showToast('Servidor', `Servidor ${server.name} ${actionData.message}`, 'success');
        addActivity(`Servidor ${server.name} ${actionData.message}`, 'info');
    }
}

// Actualizar información de un servidor
async function updateServerInfo(serverId) {
    try {
        const response = await fetch(`${API_URL}/update_server.php`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({ id: serverId })
        });
        
        const result = await response.json();
        
        if (result.success) {
            const servers = JSON.parse(localStorage.getItem('vps_servers') || '[]');
            const index = servers.findIndex(s => s.id === serverId);
            
            if (index !== -1) {
                servers[index] = result.server;
                localStorage.setItem('vps_servers', JSON.stringify(servers));
                renderServers();
                updateStats();
            }
        }
    } catch (error) {
        console.error('Error actualizando servidor:', error);
    }
}

// Eliminar servidor
window.confirmDeleteServer = function(serverId) {
    const servers = JSON.parse(localStorage.getItem('vps_servers') || '[]');
    const server = servers.find(s => s.id === serverId);
    
    if (!server) return;
    
    if (confirm(`¿Estás seguro de eliminar ${server.name}?`)) {
        deleteServer(serverId);
    }
}

async function deleteServer(serverId) {
    try {
        const response = await fetch(`${API_URL}/delete_server.php`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({ id: serverId })
        });
        
        const result = await response.json();
        
        if (result.success) {
            const servers = JSON.parse(localStorage.getItem('vps_servers') || '[]');
            const server = servers.find(s => s.id === serverId);
            const newServers = servers.filter(s => s.id !== serverId);
            
            localStorage.setItem('vps_servers', JSON.stringify(newServers));
            renderServers();
            updateStats();
            
            if (server) {
                addActivity(`Servidor ${server.name} eliminado`, 'warning');
                showToast('Servidor eliminado', `${server.name} ha sido eliminado`, 'warning');
            }
        }
    } catch (error) {
        console.error('Error eliminando servidor:', error);
        showToast('Error', 'No se pudo eliminar el servidor', 'error');
    }
}

// ============================================
// FUNCIONES DE RENDERIZADO
// ============================================

// Renderizar lista de servidores
function renderServers() {
    const servers = JSON.parse(localStorage.getItem('vps_servers') || '[]');
    const grid = document.getElementById('serversGrid');
    const noServers = document.getElementById('noServers');
    const filter = document.getElementById('serverFilter')?.value || 'all';
    
    if (!grid) return;
    
    let filteredServers = servers;
    if (filter !== 'all') {
        filteredServers = servers.filter(s => s.status === filter);
    }
    
    if (filteredServers.length === 0) {
        grid.innerHTML = '';
        if (noServers) {
            noServers.style.display = 'block';
            if (servers.length > 0) {
                noServers.innerHTML = `
                    <i class="fas fa-filter"></i>
                    <h3>No hay servidores con este filtro</h3>
                    <p><a href="#" onclick="document.getElementById('serverFilter').value='all'; renderServers();">Mostrar todos</a></p>
                `;
            }
        }
        return;
    }
    
    if (noServers) noServers.style.display = 'none';
    
    grid.innerHTML = filteredServers.map(server => `
        <div class="server-card" onclick="viewServerDetails('${server.id}')">
            <div class="server-header">
                <div class="server-status status-${server.status}"></div>
                <div class="server-name">
                    <h3>${escapeHtml(server.name)}</h3>
                    <span class="server-ip">${escapeHtml(server.ip)}:${server.port}</span>
                </div>
                <button class="server-menu" onclick="event.stopPropagation(); toggleServerMenu('${server.id}')">
                    <i class="fas fa-ellipsis-v"></i>
                </button>
            </div>
            
            <div class="server-specs">
                <div class="spec">
                    <i class="fas fa-microchip"></i>
                    <span>${server.cpu_cores || 2} vCPU</span>
                </div>
                <div class="spec">
                    <i class="fas fa-memory"></i>
                    <span>${server.ram_total || 8} GB RAM</span>
                </div>
                <div class="spec">
                    <i class="fas fa-hdd"></i>
                    <span>${server.disk_total || 100} GB SSD</span>
                </div>
            </div>
            
            <div class="server-usage">
                <div class="usage-item">
                    <span>CPU: ${server.cpu || 0}%</span>
                    <div class="progress-bar">
                        <div class="progress" style="width: ${server.cpu || 0}%"></div>
                    </div>
                </div>
                <div class="usage-item">
                    <span>RAM: ${server.ram || 0} GB</span>
                    <div class="progress-bar">
                        <div class="progress" style="width: ${((server.ram || 0) / (server.ram_total || 8) * 100)}%"></div>
                    </div>
                </div>
            </div>
            
            <div class="server-footer">
                <span class="server-location">
                    <i class="fas fa-map-marker-alt"></i>
                    ${escapeHtml(server.location)}
                </span>
                <div class="server-actions" onclick="event.stopPropagation()">
                    <button class="server-action-btn" onclick="controlServer('${server.id}', 'start')" ${server.status === 'active' ? 'disabled' : ''}>
                        <i class="fas fa-play"></i>
                    </button>
                    <button class="server-action-btn" onclick="controlServer('${server.id}', 'stop')" ${server.status !== 'active' ? 'disabled' : ''}>
                        <i class="fas fa-stop"></i>
                    </button>
                    <button class="server-action-btn" onclick="controlServer('${server.id}', 'restart')" ${server.status !== 'active' ? 'disabled' : ''}>
                        <i class="fas fa-redo-alt"></i>
                    </button>
                    <button class="server-action-btn delete" onclick="confirmDeleteServer('${server.id}')">
                        <i class="fas fa-trash"></i>
                    </button>
                </div>
            </div>
        </div>
    `).join('');
}

// Actualizar estadísticas
function updateStats() {
    const servers = JSON.parse(localStorage.getItem('vps_servers') || '[]');
    const totalServers = servers.length;
    const activeServers = servers.filter(s => s.status === 'active').length;
    
    const totalServersEl = document.getElementById('totalServers');
    const serverCountEl = document.getElementById('serverCount');
    const serverChangeEl = document.getElementById('serverChange');
    const avgCpuEl = document.getElementById('avgCpu');
    const avgRamEl = document.getElementById('avgRam');
    const cpuChangeEl = document.getElementById('cpuChange');
    const ramChangeEl = document.getElementById('ramChange');
    
    if (totalServersEl) totalServersEl.textContent = totalServers;
    if (serverCountEl) serverCountEl.textContent = totalServers;
    if (serverChangeEl) serverChangeEl.innerHTML = `<i class="fas fa-arrow-up"></i> +${activeServers}`;
    
    if (totalServers > 0) {
        const avgCpu = Math.round(servers.reduce((acc, s) => acc + (s.cpu || 0), 0) / totalServers);
        const avgRam = (servers.reduce((acc, s) => acc + (s.ram || 0), 0) / totalServers).toFixed(1);
        
        if (avgCpuEl) avgCpuEl.textContent = avgCpu + '%';
        if (avgRamEl) avgRamEl.textContent = avgRam + ' GB';
        
        if (cpuChangeEl) {
            cpuChangeEl.innerHTML = `<i class="fas ${avgCpu > 50 ? 'fa-arrow-up' : 'fa-arrow-down'}"></i> ${avgCpu}%`;
            cpuChangeEl.className = `stat-change ${avgCpu > 50 ? 'negative' : 'positive'}`;
        }
        
        if (ramChangeEl) {
            ramChangeEl.innerHTML = `<i class="fas ${avgRam > 8 ? 'fa-arrow-up' : 'fa-arrow-down'}"></i> ${avgRam}`;
            ramChangeEl.className = `stat-change ${avgRam > 8 ? 'negative' : 'positive'}`;
        }
    }
}

// ============================================
// FUNCIONES DE ACTIVIDAD Y NOTIFICACIONES
// ============================================

function addActivity(message, type = 'info') {
    const activities = JSON.parse(localStorage.getItem('activities') || '[]');
    
    activities.unshift({
        id: Date.now(),
        message,
        type,
        time: new Date().toISOString()
    });
    
    if (activities.length > 15) activities.pop();
    
    localStorage.setItem('activities', JSON.stringify(activities));
    renderActivities();
}

function renderActivities() {
    const activities = JSON.parse(localStorage.getItem('activities') || '[]');
    const list = document.getElementById('activityList');
    
    if (!list) return;
    
    if (activities.length === 0) {
        list.innerHTML = '<div class="activity-item">No hay actividad reciente</div>';
        return;
    }
    
    list.innerHTML = activities.map(activity => {
        const timeAgo = getTimeAgo(new Date(activity.time));
        const icon = activity.type === 'success' ? 'fa-check-circle' : 
                    activity.type === 'warning' ? 'fa-exclamation-triangle' : 'fa-info-circle';
        
        return `
            <div class="activity-item">
                <div class="activity-icon ${activity.type}">
                    <i class="fas ${icon}"></i>
                </div>
                <div class="activity-content">
                    <span class="activity-text">${escapeHtml(activity.message)}</span>
                    <span class="activity-time">${timeAgo}</span>
                </div>
            </div>
        `;
    }).join('');
}

function getTimeAgo(date) {
    const seconds = Math.floor((new Date() - date) / 1000);
    if (seconds < 60) return 'hace unos segundos';
    if (seconds < 3600) return `hace ${Math.floor(seconds / 60)} minutos`;
    if (seconds < 86400) return `hace ${Math.floor(seconds / 3600)} horas`;
    return `hace ${Math.floor(seconds / 86400)} días`;
}

function showToast(title, message, type = 'info') {
    const container = document.getElementById('toastContainer');
    if (!container) return;
    
    const toast = document.createElement('div');
    toast.className = `toast ${type}`;
    
    const icons = {
        success: 'fa-check-circle',
        error: 'fa-times-circle',
        warning: 'fa-exclamation-triangle',
        info: 'fa-info-circle'
    };
    
    toast.innerHTML = `
        <div class="toast-icon">
            <i class="fas ${icons[type]}"></i>
        </div>
        <div class="toast-content">
            <div class="toast-title">${escapeHtml(title)}</div>
            <div class="toast-message">${escapeHtml(message)}</div>
        </div>
        <button class="toast-close" onclick="this.parentElement.remove()">
            <i class="fas fa-times"></i>
        </button>
    `;
    
    container.appendChild(toast);
    
    setTimeout(() => {
        if (toast.parentNode) toast.remove();
    }, 5000);
}

// ============================================
// FUNCIONES DE UTILIDAD
// ============================================

function escapeHtml(text) {
    if (!text) return '';
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
}

window.toggleMenu = function() {
    const sidebar = document.getElementById('sidebar');
    const overlay = document.getElementById('overlay');
    
    if (sidebar) {
        sidebar.classList.toggle('active');
        overlay.classList.toggle('active');
        document.body.style.overflow = sidebar.classList.contains('active') ? 'hidden' : '';
    }
}

// ============================================
// INICIALIZACIÓN
// ============================================

document.addEventListener('DOMContentLoaded', async function() {
    console.log('Inicializando panel VPS con PHP...');
    
    // Cargar servidores desde PHP
    await loadServersFromAPI();
    
    // Si no hay servidores, cargar demo
    const servers = JSON.parse(localStorage.getItem('vps_servers') || '[]');
    if (servers.length === 0) {
        // Cargar servidores de demostración
        const demoServers = [
            {
                id: '1',
                name: 'VPS-Web-01',
                ip: '192.168.1.101',
                port: 22,
                user: 'root',
                password: '****',
                location: 'US-East',
                status: 'active',
                cpu: 45,
                ram: 6.2,
                disk: 120,
                uptime: '15 días',
                os: 'Ubuntu 22.04 LTS',
                kernel: '5.15.0',
                cpu_cores: 4,
                ram_total: 8,
                disk_total: 160,
                created: new Date().toISOString(),
                lastChecked: new Date().toISOString()
            },
            {
                id: '2',
                name: 'VPS-DB-01',
                ip: '192.168.1.102',
                port: 22,
                user: 'root',
                password: '****',
                location: 'EU-West',
                status: 'active',
                cpu: 62,
                ram: 10.5,
                disk: 210,
                uptime: '23 días',
                os: 'Ubuntu 22.04 LTS',
                kernel: '5.15.0',
                cpu_cores: 8,
                ram_total: 16,
                disk_total: 320,
                created: new Date().toISOString(),
                lastChecked: new Date().toISOString()
            }
        ];
        localStorage.setItem('vps_servers', JSON.stringify(demoServers));
        renderServers();
        updateStats();
    }
    
    // Renderizar actividades
    renderActivities();
    
    // Event listeners
    const menuToggle = document.getElementById('menuToggle');
    if (menuToggle) menuToggle.addEventListener('click', toggleMenu);
    
    const overlay = document.getElementById('overlay');
    if (overlay) {
        overlay.addEventListener('click', function() {
            document.getElementById('sidebar')?.classList.remove('active');
            overlay.classList.remove('active');
            document.body.style.overflow = '';
            closeModal();
        });
    }
    
    const addServerBtn = document.getElementById('addServerBtn');
    if (addServerBtn) addServerBtn.addEventListener('click', openAddServerModal);
    
    const serverFilter = document.getElementById('serverFilter');
    if (serverFilter) serverFilter.addEventListener('change', renderServers);
    
    // Efecto de scroll
    let lastScroll = 0;
    const header = document.querySelector('.header');
    
    window.addEventListener('scroll', function() {
        const currentScroll = window.pageYOffset;
        if (header) {
            header.style.transform = currentScroll > lastScroll && currentScroll > 100 ? 'translateY(-100%)' : 'translateY(0)';
        }
        lastScroll = currentScroll;
    });
    
    // Cerrar con ESC
    document.addEventListener('keydown', function(e) {
        if (e.key === 'Escape') {
            closeModal();
            document.getElementById('sidebar')?.classList.remove('active');
            document.getElementById('overlay')?.classList.remove('active');
            document.body.style.overflow = '';
        }
    });
    
    console.log('Panel VPS inicializado correctamente');
});